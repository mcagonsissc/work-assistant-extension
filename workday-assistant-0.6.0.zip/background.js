var tv = Object.defineProperty;
var nv = (t, e, n) => e in t ? tv(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var me = (t, e, n) => nv(t, typeof e != "symbol" ? e + "" : e, n);
const rv = new TextEncoder(), Lh = new TextDecoder(), Gh = new TextDecoder("utf-8", { fatal: !0 });
function ov(...t) {
  const e = t.reduce((o, { length: i }) => o + i, 0), n = new Uint8Array(e);
  let r = 0;
  for (const o of t)
    n.set(o, r), r += o.length;
  return n;
}
const iv = /[^\x00-\x7f]/;
function qa(t) {
  if (typeof t == "string" && t.length >= 128) {
    if (iv.test(t))
      throw new TypeError("non-ASCII string encountered in encode()");
    return rv.encode(t);
  }
  const e = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++) {
    const r = t.charCodeAt(n);
    if (r > 127)
      throw new TypeError("non-ASCII string encountered in encode()");
    e[n] = r;
  }
  return e;
}
function av(t, e = !1) {
  if (Uint8Array.fromBase64)
    return Uint8Array.fromBase64(t, { alphabet: e ? "base64url" : "base64" });
  if (e) {
    if (t.includes("+") || t.includes("/"))
      throw new TypeError("Invalid base64url");
    t = t.replace(/-/g, "+").replace(/_/g, "/");
  }
  const n = atob(t), r = new Uint8Array(n.length);
  for (let o = 0; o < n.length; o++)
    r[o] = n.charCodeAt(o);
  return r;
}
class Mt extends Error {
  constructor(n, r) {
    var o;
    super(n, r);
    me(this, "code", "ERR_JOSE_GENERIC");
    this.name = this.constructor.name, (o = Error.captureStackTrace) == null || o.call(Error, this, this.constructor);
  }
}
me(Mt, "code", "ERR_JOSE_GENERIC");
class Or extends Mt {
  constructor(n, r, o = "unspecified", i = "unspecified") {
    super(n, { cause: { claim: o, reason: i, payload: r } });
    me(this, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED");
    me(this, "claim");
    me(this, "reason");
    me(this, "payload");
    this.claim = o, this.reason = i, this.payload = r;
  }
}
me(Or, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED");
class Wu extends Mt {
  constructor(n, r, o = "unspecified", i = "unspecified") {
    super(n, { cause: { claim: o, reason: i, payload: r } });
    me(this, "code", "ERR_JWT_EXPIRED");
    me(this, "claim");
    me(this, "reason");
    me(this, "payload");
    this.claim = o, this.reason = i, this.payload = r;
  }
}
me(Wu, "code", "ERR_JWT_EXPIRED");
class Fh extends Mt {
  constructor() {
    super(...arguments);
    me(this, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
  }
}
me(Fh, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
class $i extends Mt {
  constructor() {
    super(...arguments);
    me(this, "code", "ERR_JOSE_NOT_SUPPORTED");
  }
}
me($i, "code", "ERR_JOSE_NOT_SUPPORTED");
class It extends Mt {
  constructor() {
    super(...arguments);
    me(this, "code", "ERR_JWS_INVALID");
  }
}
me(It, "code", "ERR_JWS_INVALID");
class Ka extends Mt {
  constructor() {
    super(...arguments);
    me(this, "code", "ERR_JWT_INVALID");
  }
}
me(Ka, "code", "ERR_JWT_INVALID");
class Wa extends Mt {
  constructor() {
    super(...arguments);
    me(this, "code", "ERR_JWKS_INVALID");
  }
}
me(Wa, "code", "ERR_JWKS_INVALID");
class Ic extends Mt {
  constructor(n = "no applicable key found in the JSON Web Key Set", r) {
    super(n, r);
    me(this, "code", "ERR_JWKS_NO_MATCHING_KEY");
  }
}
me(Ic, "code", "ERR_JWKS_NO_MATCHING_KEY");
var Oh, Mh;
class Uh extends (Mh = Mt, Oh = Symbol.asyncIterator, Mh) {
  constructor(n = "multiple matching keys found in the JSON Web Key Set", r) {
    super(n, r);
    me(this, Oh, async function* () {
    });
    me(this, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
  }
}
me(Uh, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
class Zh extends Mt {
  constructor(n = "request timed out", r) {
    super(n, r);
    me(this, "code", "ERR_JWKS_TIMEOUT");
  }
}
me(Zh, "code", "ERR_JWKS_TIMEOUT");
class Yu extends Mt {
  constructor(n = "signature verification failed", r) {
    super(n, r);
    me(this, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
  }
}
me(Yu, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
const sv = "The input to be decoded is not correctly encoded.";
function zc(t) {
  try {
    return av(typeof t == "string" ? t : Lh.decode(t), !0);
  } catch (e) {
    throw new TypeError(sv, { cause: e });
  }
}
function wi(t) {
  if (typeof t != "object" || t === null || Object.prototype.toString.call(t) !== "[object Object]")
    return !1;
  const e = Object.getPrototypeOf(t);
  return e === null || Object.getPrototypeOf(e) === null;
}
function qh(t) {
  return wi(t) && Array.isArray(t.keys) && Array.from(t.keys).every(wi);
}
function uv(...t) {
  const e = /* @__PURE__ */ new Set();
  for (const n of t)
    if (n)
      for (const r of Object.keys(n)) {
        if (e.has(r))
          return !1;
        e.add(r);
      }
  return !0;
}
function od(t, e, n) {
  try {
    return zc(t);
  } catch (r) {
    throw new n(`Failed to base64url decode the ${e}`, { cause: r });
  }
}
function cv(t, e, n) {
  try {
    return qa(t);
  } catch (r) {
    throw new n(`The ${e} is not a valid base64url string`, { cause: r });
  }
}
function lv(t, e, n) {
  let r;
  try {
    r = JSON.parse(Gh.decode(zc(t)));
  } catch (o) {
    throw new e(n, { cause: o });
  }
  if (!wi(r))
    throw new e(n);
  return r;
}
const dv = { __proto__: null, b64: !0 };
function hv(t, e) {
  if (e !== void 0 && (!Array.isArray(e) || e.some((n) => typeof n != "string")))
    throw new TypeError(`"${t}" option must be an array of strings`);
  return e === void 0 ? void 0 : new Set(e);
}
function fv(t, e, n, r, o) {
  if (o.crit !== void 0 && (r == null ? void 0 : r.crit) === void 0)
    throw new t('"crit" (Critical) Header Parameter MUST be integrity protected');
  if (!r || r.crit === void 0)
    return [];
  if (!Array.isArray(r.crit) || r.crit.length === 0 || r.crit.some((a) => typeof a != "string" || a.length === 0))
    throw new t('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  const i = n === void 0 ? e : { __proto__: null, ...n, ...e };
  for (const a of r.crit) {
    if (!(a in i))
      throw new $i(`Extension Header Parameter "${a}" is not recognized`);
    if (!Object.hasOwn(o, a) || o[a] === void 0)
      throw new t(`Extension Header Parameter "${a}" is missing`);
    if (i[a] && (!Object.hasOwn(r, a) || r[a] === void 0))
      throw new t(`Extension Header Parameter "${a}" MUST be integrity protected`);
  }
  return r.crit;
}
function mv(t, e) {
  if (e.includes("b64")) {
    const n = t.b64;
    if (typeof n != "boolean")
      throw new It('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
    return n;
  }
  return !0;
}
const pv = (t) => t[Symbol.toStringTag], gv = (t, e, n) => {
  const { alg: r } = t;
  if (e.use !== void 0 && e.use !== "sig")
    throw new TypeError('Invalid key for this operation, its "use" must be "sig" when present');
  if (e.alg !== void 0 && e.alg !== r)
    throw new TypeError(`Invalid key for this operation, its "alg" must be "${r}" when present`);
  if (Array.isArray(e.key_ops)) {
    const o = n;
    if (!e.key_ops.includes(o))
      throw new TypeError(`Invalid key for this operation, its "key_ops" must include "${o}" when present`);
  }
};
async function vv(t, e, n) {
  var h, m;
  const { alg: r, secret: o } = t;
  if (o && e instanceof Uint8Array)
    return e;
  let i, a;
  if (wi(e)) {
    if (i = Pv(e), typeof i.kty != "string")
      throw id(r, e, o);
    if (!(o ? i.kty === "oct" && typeof i.k == "string" : i.kty !== "oct" && i.d === void 0 && i.priv === void 0))
      throw new TypeError(o ? 'JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present' : "JSON Web Key for this operation must be a public JWK");
    if (gv(t, i, n), i.kty === "oct")
      return zc(i.k);
    if (!Object.isFrozen(e)) {
      const { key_ops: p } = e;
      Array.isArray(p) && Object.freeze(p), Object.freeze(e);
    }
  } else {
    if (!wv(e))
      throw id(r, e, o);
    const p = o ? "secret" : "public";
    if (e.type !== p && (o || ["secret", "public", "private"].includes(e.type)))
      throw new TypeError(`${pv(e)} instances must be of type "${p}" for the ${r} algorithm`);
    if (Kh(e))
      return e;
    if (a = e, a.type === "secret")
      return a.export();
  }
  Tu || (Tu = /* @__PURE__ */ new WeakMap());
  const c = e;
  let l = Tu.get(c);
  if (l != null && l[r])
    return l[r];
  if (l || Tu.set(c, l = {}), a && typeof a.toCryptoKey == "function") {
    const p = a.type === "public", v = yv[(h = a.asymmetricKeyDetails) == null ? void 0 : h.namedCurve], k = ((m = t.resolve) == null ? void 0 : m.call(t, { crv: v, asymmetricKeyType: a.asymmetricKeyType })) ?? t.subtle;
    return l[r] = a.toCryptoKey(k, p, t.usages[p ? 0 : 1]);
  }
  return i ?? (i = a.export({ format: "jwk" })), i.alg = r, l[r] = await Yh(t, i);
}
let Tu;
const yv = {
  __proto__: null,
  prime256v1: "P-256",
  secp384r1: "P-384",
  secp521r1: "P-521"
}, Kh = (t) => {
  if ((t == null ? void 0 : t[Symbol.toStringTag]) === "CryptoKey")
    return !0;
  try {
    return t instanceof CryptoKey;
  } catch {
    return !1;
  }
}, bv = (t) => (t == null ? void 0 : t[Symbol.toStringTag]) === "KeyObject", wv = (t) => Kh(t) || bv(t);
function kv(t, e, ...n) {
  var r;
  if (n.length > 2) {
    const o = n.pop();
    t += `one of type ${n.join(", ")}, or ${o}.`;
  } else n.length === 2 ? t += `one of type ${n[0]} or ${n[1]}.` : t += `of type ${n[0]}.`;
  return e == null ? t += ` Received ${e}` : typeof e == "function" && e.name ? t += ` Received function ${e.name}` : typeof e == "object" && e != null && ((r = e.constructor) != null && r.name) && (t += ` Received an instance of ${e.constructor.name}`), t;
}
function id(t, e, n) {
  const r = ["CryptoKey", "KeyObject", "JSON Web Key"];
  return n && r.push("Uint8Array"), new TypeError(kv(`Key for the ${t} algorithm must be `, e, ...r));
}
const za = (t, e = "algorithm.name") => new TypeError(`CryptoKey does not support this operation, its ${e} must be ${t}`);
function _v(t, e) {
  if (!t.usages.includes(e))
    throw new TypeError(`CryptoKey does not support this operation, its usages must include ${e}.`);
}
function Tv(t, e) {
  const { modulusLength: n } = e.algorithm;
  if (typeof n != "number" || n < 2048)
    throw new TypeError(`${t} requires key modulusLength to be 2048 bits or larger`);
}
function Cv(t, e, n) {
  var o;
  const r = t.algorithm;
  if (r.name !== e.name)
    throw za(e.name);
  if (e.hash && ((o = r.hash) == null ? void 0 : o.name) !== e.hash)
    throw za(e.hash, "algorithm.hash");
  if (e.namedCurve && r.namedCurve !== e.namedCurve)
    throw za(e.namedCurve, "algorithm.namedCurve");
  if (e.length !== void 0 && r.length !== e.length)
    throw za(e.length, "algorithm.length");
  _v(t, n);
}
function Wh(t) {
  return { __proto__: null, ...t };
}
function Pv(t) {
  const e = Wh(t);
  if (e.ext !== void 0 && typeof e.ext != "boolean")
    throw new TypeError('"ext" (Extractable) Parameter must be a boolean');
  if (e.key_ops !== void 0) {
    const n = e.key_ops, r = Array.isArray(n) ? [...n] : void 0;
    if (!r || r.some((o) => typeof o != "string") || new Set(r).size !== r.length)
      throw new TypeError('"key_ops" (Key Operations) Parameter must be an array of unique strings');
    e.key_ops = r;
  }
  return e;
}
async function Yh(t, e, n) {
  var a;
  if (!t.kty.includes(e.kty))
    throw new $i('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
  const r = ((a = t.resolve) == null ? void 0 : a.call(t, { kty: e.kty, crv: e.crv })) ?? t.subtle, o = !!(e.d || e.priv), i = { ...e, ext: n ?? e.ext };
  return i.kty !== "AKP" && delete i.alg, delete i.use, crypto.subtle.importKey("jwk", i, r, i.ext ?? !o, e.key_ops ?? t.usages[o ? 1 : 0]);
}
async function Av(t, e, n, r = !1) {
  return t instanceof Uint8Array && (t = await crypto.subtle.importKey("raw", t, e, r, [n])), Cv(t, e, n), t;
}
function Ev(t) {
  const e = { __proto__: null };
  for (const n in t)
    e[n] = { ...t[n], alg: n };
  return e;
}
const Ni = [["verify"], ["sign"]];
function Cu(t) {
  const e = { name: "HMAC", hash: `SHA-${t}` };
  return { kty: ["oct"], secret: !0, subtle: e, signing: e, usages: Ni };
}
function oo(t, e) {
  const n = { name: e ? "RSA-PSS" : "RSASSA-PKCS1-v1_5", hash: `SHA-${t}` };
  return {
    kty: ["RSA"],
    subtle: n,
    signing: e ? { ...n, saltLength: e } : n,
    usages: Ni,
    minRsaBits: 2048
  };
}
function Pu(t, e) {
  return {
    kty: ["EC"],
    crv: t,
    subtle: { name: "ECDSA", namedCurve: t },
    signing: { name: "ECDSA", hash: `SHA-${e}` },
    usages: Ni
  };
}
function ad() {
  const t = { name: "Ed25519" };
  return {
    kty: ["OKP"],
    crv: "Ed25519",
    subtle: t,
    signing: t,
    usages: Ni
  };
}
function Au(t) {
  const e = { name: `ML-DSA-${t}` };
  return {
    kty: ["AKP"],
    subtle: e,
    signing: e,
    usages: Ni
  };
}
const Vh = Ev({
  HS256: Cu(256),
  HS384: Cu(384),
  HS512: Cu(512),
  RS256: oo(256),
  RS384: oo(384),
  RS512: oo(512),
  PS256: oo(256, 32),
  PS384: oo(384, 48),
  PS512: oo(512, 64),
  ES256: Pu("P-256", 256),
  ES384: Pu("P-384", 384),
  ES512: Pu("P-521", 512),
  EdDSA: ad(),
  Ed25519: ad(),
  "ML-DSA-44": Au(44),
  "ML-DSA-65": Au(65),
  "ML-DSA-87": Au(87)
});
function Sv(t) {
  const e = typeof t == "string" ? Vh[t] : void 0;
  if (!e)
    throw new $i(`alg ${t} is not supported either by JOSE or your javascript runtime`);
  return e;
}
function Dv(t) {
  return [t && hv("algorithms", t.algorithms), t == null ? void 0 : t.crit];
}
function Iv(t) {
  return t === void 0 ? {} : lv(t, It, "JWS Protected Header is invalid");
}
function zv(t) {
  try {
    return qa(t);
  } catch (e) {
    throw new It("JWS Compact Serialization payload must use only ASCII characters", {
      cause: e
    });
  }
}
async function Rv(t, e, n, r, o) {
  const { protected: i, header: a, payload: c } = t, l = Iv(i);
  if (!uv(l, a))
    throw new It("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  const h = { ...l, ...a }, m = mv(l, fv(It, dv, e[1], l, h)), { alg: p } = h;
  if (typeof p != "string" || !p)
    throw new It('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  if (e[0] && !e[0].has(p))
    throw new Fh('"alg" (Algorithm) Header Parameter value not allowed');
  if (m) {
    if (typeof c != "string")
      throw new It("JWS Payload must be a string");
  } else if (typeof c != "string" && !(c instanceof Uint8Array))
    throw new It("JWS Payload must be a string or an Uint8Array instance");
  const v = m || typeof c != "string" ? c : r(c);
  let k = !1;
  typeof n == "function" && (n = await n(l, t), k = !0);
  const P = Sv(p), A = ov(i !== void 0 ? qa(i) : new Uint8Array(), qa("."), typeof v == "string" ? e[2] ?? (e[2] = cv(v, "payload", It)) : v), S = od(t.signature, "signature", It), z = await vv(P, n, "verify"), L = await Av(z, P.subtle, "verify");
  P.minRsaBits && Tv(P.alg, L);
  let W = !1;
  try {
    W = await crypto.subtle.verify(P.signing, L, S, A);
  } catch (re) {
    throw new Yu(void 0, { cause: re });
  }
  if (!W)
    throw new Yu();
  const H = { payload: typeof v == "string" ? od(v, "payload", It) : v };
  return i !== void 0 && (H.protectedHeader = l), a !== void 0 && (H.unprotectedHeader = a), k ? [{ ...H, key: z }, m] : [H, m];
}
async function xv(t, e, n) {
  if (t instanceof Uint8Array && (t = Lh.decode(t)), typeof t != "string")
    throw new It("Compact JWS must be a string or Uint8Array");
  const { 0: r, 1: o, 2: i, length: a } = t.split(".");
  if (a !== 3)
    throw new It("Invalid Compact JWS");
  return Rv({ payload: o, protected: r, signature: i }, e, n, zv);
}
const Ov = (t) => Math.floor(t.getTime() / 1e3), Mv = {
  s: 1,
  m: 60,
  h: 3600,
  d: 86400,
  w: 604800,
  y: 31557600
}, $v = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i, uo = "check_failed";
function Eu() {
  throw new TypeError("Invalid time period format");
}
function sd(t) {
  typeof t != "string" && Eu();
  const e = $v.exec(t);
  (!e || e[4] && e[1]) && Eu();
  const n = parseFloat(e[2]), r = Math.round(n * Mv[e[3][0].toLowerCase()]);
  return Number.isFinite(r) || Eu(), e[1] === "-" || e[4] === "ago" ? -r : r;
}
function Su(t, e) {
  if (!Number.isFinite(e))
    throw new TypeError(`Invalid ${t} input`);
  return e;
}
const ud = (t) => {
  const e = t.toLowerCase();
  return t.includes("/") ? e : `application/${e}`;
}, Nv = (t, e) => typeof t == "string" ? e.includes(t) : Array.isArray(t) ? e.some((n) => t.includes(n)) : !1;
function Du(t, e, n = !1) {
  const r = t[e];
  if (!(r === void 0 && !n)) {
    if (typeof r != "number")
      throw new Or(`"${e}" claim must be a number`, t, e, "invalid");
    return r;
  }
}
function Iu(t, e) {
  throw new Or(`unexpected "${e}" claim value`, t, e, uo);
}
function jv(t, e, n = {}) {
  let r;
  try {
    r = JSON.parse(Gh.decode(e));
  } catch (L) {
    throw new Ka("JWT Claims Set must be a top-level JSON object", { cause: L });
  }
  if (!wi(r))
    throw new Ka("JWT Claims Set must be a top-level JSON object");
  const { typ: o } = n;
  if (o !== void 0 && (typeof t.typ != "string" || ud(t.typ) !== ud(o)))
    throw new Or('unexpected "typ" JWT header value', r, "typ", uo);
  const { requiredClaims: i = [], issuer: a, subject: c, audience: l, maxTokenAge: h } = n, m = [...i];
  h !== void 0 && m.push("iat"), l !== void 0 && m.push("aud"), c !== void 0 && m.push("sub"), a !== void 0 && m.push("iss");
  for (const L of new Set(m.reverse()))
    if (!Object.hasOwn(r, L))
      throw new Or(`missing required "${L}" claim`, r, L, "missing");
  a !== void 0 && !(Array.isArray(a) ? a : [a]).includes(r.iss) && Iu(r, "iss"), c !== void 0 && r.sub !== c && Iu(r, "sub"), l !== void 0 && !Nv(r.aud, typeof l == "string" ? [l] : l) && Iu(r, "aud");
  const { clockTolerance: p } = n;
  let v = 0;
  if (typeof p == "string")
    v = sd(p);
  else if (p !== void 0) {
    if (typeof p != "number")
      throw new TypeError("Invalid clockTolerance option type");
    v = p;
  }
  if (Su("clockTolerance option", v), v < 0)
    throw new TypeError("Invalid clockTolerance option input");
  const { currentDate: k } = n, P = Su("currentDate option", Ov(k === void 0 ? /* @__PURE__ */ new Date() : k)), A = Du(r, "iat", h !== void 0), S = Du(r, "nbf");
  if (S !== void 0 && S > P + v)
    throw new Or('"nbf" claim timestamp check failed', r, "nbf", uo);
  const z = Du(r, "exp");
  if (z !== void 0 && z <= P - v)
    throw new Wu('"exp" claim timestamp check failed', r, "exp", uo);
  if (h !== void 0) {
    const L = P - A, W = Su("maxTokenAge option", typeof h == "number" ? h : sd(h));
    if (W < 0)
      throw new TypeError("Invalid maxTokenAge option input");
    if (L - v > W)
      throw new Wu('"iat" claim timestamp check failed (too far in the past)', r, "iat", uo);
    if (L < -v)
      throw new Or('"iat" claim timestamp check failed (it should be in the past)', r, "iat", uo);
  }
  return r;
}
async function Lv(t, e, n) {
  const [r, o] = await xv(t, Dv(n), e);
  if (!o)
    throw new Ka("JWTs MUST NOT use unencoded payload");
  const i = jv(r.protectedHeader, r.payload, n);
  return { ...r, payload: i };
}
function Gv(t, e, n, r) {
  const { kty: o, key_ops: i, ext: a, kid: c, alg: l, use: h, crv: m } = t;
  return (a === void 0 || typeof a == "boolean") && (i === void 0 || Array.isArray(i) && i.every((p, v) => typeof p == "string" && i.indexOf(p) === v) && i.includes("verify")) && e.kty.includes(o) && (r === void 0 || typeof r == "string" && r === c) && (l === void 0 ? o !== "AKP" : n === l) && (h === void 0 || h === "sig") && (!e.crv || m === e.crv);
}
async function cd(t, e, n) {
  const r = t.get(e) || t.set(e, {}).get(e), { alg: o } = n;
  if (r[o] === void 0) {
    const i = Yh(n, e, !0).then((a) => {
      if (a.type !== "public")
        throw new Wa("JSON Web Key Set members must be public keys");
      return r[o] = a, a;
    }).catch((a) => {
      throw r[o] === i && delete r[o], a;
    });
    r[o] = i;
  }
  return r[o];
}
function ld(t) {
  let e;
  try {
    e = structuredClone(t);
  } catch (o) {
    throw new Wa("JSON Web Key Set malformed", { cause: o });
  }
  if (!qh(e))
    throw new Wa("JSON Web Key Set malformed");
  const n = e.keys.map((o) => {
    const i = Wh(o);
    return Array.isArray(i.key_ops) && (i.key_ops = [...i.key_ops]), i;
  }), r = /* @__PURE__ */ new WeakMap();
  return Object.defineProperty(async (o, i) => {
    const { alg: a, kid: c } = { ...o, ...i == null ? void 0 : i.header }, l = typeof a == "string" ? Vh[a] : void 0;
    if (!l || l.secret)
      throw new $i('Unsupported "alg" value for a JSON Web Key Set');
    const h = e.keys.filter((v, k) => Gv(n[k], l, a, c)), { 0: m, length: p } = h;
    if (!p)
      throw new Ic();
    if (p !== 1) {
      const v = new Uh();
      throw v[Symbol.asyncIterator] = async function* () {
        for (const k of h)
          try {
            yield await cd(r, k, l);
          } catch {
          }
      }, v;
    }
    return cd(r, m, l);
  }, "jwks", {
    value: () => structuredClone(e)
  });
}
function Fv() {
  return typeof WebSocketPair < "u" || typeof navigator < "u" && navigator.userAgent === "Cloudflare-Workers" || typeof EdgeRuntime < "u" && EdgeRuntime === "vercel";
}
let Vu;
var La, $h;
(typeof navigator > "u" || !(($h = (La = navigator.userAgent) == null ? void 0 : La.startsWith) != null && $h.call(La, "Mozilla/5.0 "))) && (Vu = "jose/v6.2.17");
const Uv = /* @__PURE__ */ Symbol();
async function Zv(t, e, n, r = fetch) {
  const o = await r(t, {
    method: "GET",
    signal: n,
    redirect: "manual",
    headers: e
  }).catch((i) => {
    throw i.name === "TimeoutError" ? new Zh(void 0, { cause: i }) : i;
  });
  if (o.status !== 200)
    throw new Mt("Expected 200 OK from the JSON Web Key Set HTTP response");
  try {
    return await o.json();
  } catch (i) {
    throw new Mt("Failed to parse the JSON Web Key Set HTTP response as JSON", { cause: i });
  }
}
const qv = /* @__PURE__ */ Symbol();
function Qo(t, e) {
  return Number.isFinite(t) && Date.now() < t + e;
}
function dd(t, e, n) {
  if (Number.isNaN(t))
    throw new TypeError(`"${n}" option must not be NaN`);
  if (typeof t == "number" && t < 0)
    throw new TypeError(`"${n}" option must not be negative`);
  return typeof t == "number" ? t : e;
}
function Kv(t, e) {
  if (!(t instanceof URL))
    throw new TypeError("url must be an instance of URL");
  const n = new URL(t.href).href, r = {}, o = r.timeoutDuration;
  if (typeof o == "number" && (!Number.isInteger(o) || o < 0))
    throw new TypeError('"timeoutDuration" option must be a non-negative integer');
  const i = typeof o == "number" ? o : 5e3, a = dd(r.cooldownDuration, 3e4, "cooldownDuration"), c = dd(r.cacheMaxAge, 6e5, "cacheMaxAge"), l = new Headers(r.headers);
  Vu && !l.has("User-Agent") && l.set("User-Agent", Vu), l.has("accept") || l.set("accept", "application/json, application/jwk-set+json");
  const h = r[Uv], m = r[qv];
  let p, v, k = 0, P = 0, A;
  if (m && typeof m == "object") {
    const { uat: z, jwks: L } = m;
    Qo(z, c) && qh(L) && (p = z, A = ld(L));
  }
  const S = async () => {
    if (v && Fv() && (v = void 0), !v) {
      const z = ++k, L = v = Zv(n, l, AbortSignal.timeout(i), h).then((W) => {
        const H = ld(W);
        if (z <= P)
          return;
        A = H;
        const re = Date.now();
        m && (m.uat = re, m.jwks = W), p = re, P = z;
      }).finally(() => {
        v === L && (v = void 0);
      });
    }
    await v;
  };
  return Object.defineProperties(async (z, L) => {
    (!A || !Qo(p, c)) && await S();
    try {
      return await A(z, L);
    } catch (W) {
      if (W instanceof Ic && !Qo(p, a))
        return await S(), A(z, L);
      throw W;
    }
  }, {
    coolingDown: {
      get: () => Qo(p, a),
      enumerable: !0
    },
    fresh: {
      get: () => Qo(p, c),
      enumerable: !0
    },
    reload: {
      value: S,
      enumerable: !0
    },
    reloading: {
      get: () => !!v,
      enumerable: !0
    },
    jwks: {
      value: () => A == null ? void 0 : A.jwks(),
      enumerable: !0
    }
  });
}
function Bu(t) {
  const e = Object.values(t).filter((r) => typeof r == "number");
  return Object.entries(t).filter(([r, o]) => e.indexOf(+r) === -1).map(([r, o]) => o);
}
function hd(t, e = "|") {
  return t.map((n) => Jh(n)).join(e);
}
function Hu(t, e) {
  return typeof e == "bigint" ? e.toString() : e;
}
class Wv {
  constructor(e) {
    this._getter = e, this._value = void 0;
  }
  get value() {
    const e = this._getter;
    return e !== void 0 && (this._value = e(), this._getter = void 0), this._value;
  }
}
function ms(t) {
  return new Wv(t);
}
function Yv(t) {
  return t == null;
}
function Rc(t) {
  const e = t.startsWith("^") ? 1 : 0, n = t.endsWith("$") ? t.length - 1 : t.length;
  return t.slice(e, n);
}
function Vv(t, e) {
  const n = t / e, r = Math.round(n), o = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - r) < o ? 0 : n - r;
}
function Cn(t, e, n) {
  Object.defineProperty(t, e, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function xc(t) {
  const e = Object.getOwnPropertyDescriptor(t, "shape");
  return e != null && e.get ? e.get.raw : e == null ? void 0 : e.value;
}
function Kn(t) {
  return xc(t._zod.def) ?? t._zod.def.shape;
}
function Bh(t, e, n) {
  Object.defineProperty(t, e, {
    get() {
      const r = n();
      return Cn(this, e, r), r;
    },
    enumerable: !0,
    configurable: !0
  });
}
function Hh(t, e, n) {
  e in t ? Cn(t, e, n) : t[e] = n;
}
function Gr(t, e, n, r) {
  const o = Kn(e);
  for (const i of n) {
    const a = Object.getOwnPropertyDescriptor(o, i);
    a.enumerable && (a.get ? Bh(t, i, () => {
      const c = e._zod.def.shape[i];
      return r ? r(c, i) : c;
    }) : Hh(t, i, r ? r(a.value, i) : a.value));
  }
}
function Bv(t, e) {
  for (const n of Reflect.ownKeys(e)) {
    const r = Object.getOwnPropertyDescriptor(e, n);
    r.enumerable && (r.get ? Bh(t, n, () => e[n]) : Hh(t, n, r.value));
  }
}
function Ft(...t) {
  const e = {};
  for (const n of t) {
    const r = Object.getOwnPropertyDescriptors(n);
    Object.assign(e, r);
  }
  return Object.defineProperties({}, e);
}
function Hv(t) {
  return JSON.stringify(t);
}
function Qv(t) {
  return t.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const Qh = "captureStackTrace" in Error ? Error.captureStackTrace : (...t) => {
};
function ki(t) {
  return typeof t == "object" && t !== null && !Array.isArray(t);
}
const Xv = /* @__PURE__ */ ms(() => {
  var t;
  if (wn.jitless || typeof navigator < "u" && ((t = navigator == null ? void 0 : navigator.userAgent) != null && t.includes("Cloudflare")))
    return !1;
  try {
    const e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function _i(t) {
  if (ki(t) === !1)
    return !1;
  const e = t.constructor;
  if (e === void 0 || typeof e != "function")
    return !0;
  const n = e.prototype;
  return !(ki(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function Xh(t) {
  return _i(t) ? { ...t } : Array.isArray(t) ? [...t] : t instanceof Map ? new Map(t) : t instanceof Set ? new Set(t) : t;
}
const Jv = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function vo(t) {
  return t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function mr(t, e, n) {
  const r = new t._zod.constr(e ?? t._zod.def);
  return (!e || n != null && n.parent) && (r._zod.parent = t), r;
}
function ne(t) {
  const e = t;
  if (!e)
    return {};
  if (typeof e == "string")
    return { error: () => e };
  if ((e == null ? void 0 : e.message) !== void 0) {
    if ((e == null ? void 0 : e.error) !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    e.error = e.message;
  }
  return delete e.message, typeof e.error == "string" ? { ...e, error: () => e.error } : e;
}
function Jh(t) {
  return typeof t == "bigint" ? t.toString() + "n" : typeof t == "string" ? `"${t}"` : `${t}`;
}
function ey(t) {
  return Object.keys(t).filter((e) => t[e]._zod.optin !== void 0 && t[e]._zod.optout === "optional");
}
const ef = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, ty = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function ny(t, e) {
  const n = t._zod.def, r = n.checks;
  if (r && r.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const i = {};
  return Gr(i, t, ps(t, e)), mr(t, Ft(n, { shape: i, checks: [] }));
}
function ps(t, e) {
  var o;
  const n = Kn(t), r = [];
  for (const i of Reflect.ownKeys(e)) {
    if (!((o = Object.getOwnPropertyDescriptor(n, i)) != null && o.enumerable))
      throw new Error(`Unrecognized key: "${String(i)}"`);
    e[i] && r.push(i);
  }
  return r;
}
function ry(t, e) {
  const n = t._zod.def, r = n.checks;
  if (r && r.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const i = new Set(ps(t, e)), a = {};
  return Gr(a, t, Reflect.ownKeys(Kn(t)).filter((c) => !i.has(c))), mr(t, Ft(n, { shape: a, checks: [] }));
}
function oy(t, e) {
  if (!_i(e))
    throw new Error("Invalid input to extend: expected a plain object");
  const n = t._zod.def.checks;
  if (n && n.length > 0) {
    const o = Kn(t);
    for (const i of Reflect.ownKeys(e))
      if (Object.getOwnPropertyDescriptor(o, i) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  return mr(t, Ft(t._zod.def, { shape: tf(t, e) }));
}
function tf(t, e) {
  const n = {};
  return Gr(n, t, Reflect.ownKeys(Kn(t))), Bv(n, e), n;
}
function iy(t, e) {
  if (!_i(e))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  return mr(t, Ft(t._zod.def, { shape: tf(t, e) }));
}
function ay(t, e) {
  var o, i;
  if (!((o = e == null ? void 0 : e._zod) != null && o.def))
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if ((i = t._zod.def.checks) != null && i.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const n = {};
  Gr(n, t, Reflect.ownKeys(Kn(t))), Gr(n, e, Reflect.ownKeys(Kn(e)));
  const r = Ft(t._zod.def, {
    shape: n,
    get catchall() {
      return e._zod.def.catchall;
    },
    checks: e._zod.def.checks ?? []
  });
  return mr(t, r);
}
function fd(t, e, n, r = "partial") {
  const i = e._zod.def.checks;
  if (i && i.length > 0)
    throw new Error(`.${r}() cannot be used on object schemas containing refinements`);
  const c = n ? new Set(ps(e, n)) : void 0, l = {};
  return Gr(l, e, Reflect.ownKeys(Kn(e)), t && ((h, m) => c && !c.has(m) ? h : new t({ type: "optional", innerType: h }))), mr(e, Ft(e._zod.def, { shape: l, checks: [] }));
}
function sy(t, e, n) {
  const r = n ? new Set(ps(e, n)) : void 0, o = {};
  return Gr(o, e, Reflect.ownKeys(Kn(e)), (i, a) => (
    // overwrite with non-optional
    r && !r.has(a) ? i : new t({ type: "nonoptional", innerType: i })
  )), mr(e, Ft(e._zod.def, { shape: o }));
}
function Nn(t, e = 0) {
  var n;
  if (t.aborted === !0)
    return !0;
  for (let r = e; r < t.issues.length; r++)
    if (((n = t.issues[r]) == null ? void 0 : n.continue) !== !0)
      return !0;
  return !1;
}
function uy(t, e = 0) {
  var n;
  if (t.aborted === !0)
    return !0;
  for (let r = e; r < t.issues.length; r++)
    if (((n = t.issues[r]) == null ? void 0 : n.continue) === !1)
      return !0;
  return !1;
}
function nf(t, e) {
  return e.map((n) => {
    var r;
    return (r = n).path ?? (r.path = []), n.path.unshift(t), n;
  });
}
function Xo(t) {
  return typeof t == "string" ? t : t == null ? void 0 : t.message;
}
function md(t) {
  const e = [];
  for (const n of t ?? []) {
    const r = n._zod.def;
    if (!/_(length|size)$|_equals$/.test(r.check))
      break;
    const o = r.maximum ?? r.length ?? r.size;
    o >= 0 && e.push([o, n]);
  }
  return e;
}
function Qu(t, e, n) {
  var r;
  for (let o = e; o < t.length; o++)
    (r = t[o]).schema ?? (r.schema = n);
}
function Io(t, e, n) {
  var l, h, m, p, v, k, P, A, S, z;
  var r;
  const o = (h = (l = t.inst) == null ? void 0 : l._zod) == null ? void 0 : h.traits;
  o != null && o.has("$ZodType") && (o.has("$ZodCheck") ? (r = t).schema ?? (r.schema = t.inst) : t.schema = t.inst);
  const i = t.schema !== t.inst ? (p = (m = t.schema) == null ? void 0 : m._zod.def) == null ? void 0 : p.error : void 0, a = t.message ? t.message : Xo((P = (k = (v = t.inst) == null ? void 0 : v._zod.def) == null ? void 0 : k.error) == null ? void 0 : P.call(k, t)) ?? Xo(i == null ? void 0 : i(t)) ?? Xo((A = e == null ? void 0 : e.error) == null ? void 0 : A.call(e, t)) ?? Xo((S = n.customError) == null ? void 0 : S.call(n, t)) ?? Xo((z = n.localeError) == null ? void 0 : z.call(n, t)) ?? "Invalid input", c = {};
  for (const L of Object.keys(t))
    L === "inst" || L === "schema" || L === "continue" || L === "input" || L === "__proto__" || (c[L] = t[L]);
  return c.path ?? (c.path = []), c.message = a, e != null && e.reportInput && (c.input = t.input), c;
}
const cy = /[\uD800-\uDBFF]/;
function Oc(t) {
  const e = t.length;
  if (!cy.test(t))
    return e;
  let n = e;
  for (let r = 0; r < e - 1; r++)
    (t.charCodeAt(r) & 64512) === 55296 && (t.charCodeAt(r + 1) & 64512) === 56320 && (n--, r++);
  return n;
}
function Mc(t) {
  return Array.isArray(t) ? "array" : typeof t == "string" ? "string" : "unknown";
}
function ly(t) {
  const e = typeof t;
  switch (e) {
    case "number":
      return Number.isNaN(t) ? "nan" : "number";
    case "object": {
      if (t === null)
        return "null";
      if (Array.isArray(t))
        return "array";
      const n = t;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return e;
}
function Ti(...t) {
  const [e, n, r] = t;
  return typeof e == "string" ? {
    message: e,
    code: "custom",
    input: n,
    inst: r
  } : { ...e };
}
function dy(t, e) {
  for (const n in e) {
    const r = Object.getOwnPropertyDescriptor(e, n);
    r.get ? Object.defineProperty(t, n, { ...r, enumerable: !1 }) : hy(t, n, r.value);
  }
}
function lr(t, e, n, r = !0) {
  return Object.defineProperty(t, e, { configurable: !0, writable: !0, enumerable: r, value: n }), n;
}
function rf(t, e, n) {
  return lr(t, e, n, !1);
}
function of(t, e) {
  for (const n in t) {
    const r = t[n];
    Object.defineProperty(e, n, {
      configurable: !0,
      enumerable: !0,
      get() {
        return lr(this, n, r(this));
      },
      set(o) {
        lr(this, n, o);
      }
    });
  }
  return e;
}
function hy(t, e, n) {
  Object.defineProperty(t, e, {
    configurable: !0,
    get() {
      return this == null ? n : lr(this, e, n.bind(this));
    },
    set(r) {
      lr(this, e, r);
    }
  });
}
function fy(t, e) {
  const n = Object.getPrototypeOf(t);
  return e in n ? void 0 : n;
}
let zu, rr = !1;
const my = {
  configurable: !0,
  get() {
    rr = !0;
  }
};
function Ae(t, e, n) {
  const r = Object.getPrototypeOf(t._zod);
  if (e in r && zu !== t._zod) {
    zu = void 0;
    return;
  }
  zu = t._zod, Object.defineProperty(r, e, {
    configurable: !0,
    get() {
      Object.defineProperty(this, e, my);
      const o = rr;
      rr = !1;
      try {
        const i = n(this);
        return rr ? delete this[e] : Object.defineProperty(this, e, { configurable: !0, writable: !0, value: i }), rr = rr || o, i;
      } catch (i) {
        throw delete this[e], rr = rr || o, i;
      }
    },
    set(o) {
      Object.defineProperty(this, e, { configurable: !0, writable: !0, value: o });
    }
  });
}
function py(t, e, n, r) {
  const o = fy(t, e);
  o && Object.defineProperty(o, e, {
    configurable: !0,
    get() {
      const i = { configurable: !0, writable: !0, enumerable: r, value: void 0 };
      return Object.defineProperty(this, e, i), i.value = n(this), Object.defineProperty(this, e, i), i.value;
    },
    set(i) {
      Object.defineProperty(this, e, { configurable: !0, writable: !0, enumerable: r, value: i });
    }
  });
}
const gy = "~constantCatch";
function vy(t) {
  const e = () => t;
  return e[gy] = !0, e;
}
var pd;
const Ru = { value: void 0, enumerable: !1 };
let gd = "captureStackTrace" in Error ? Error : null;
function yy(t) {
  const e = gd;
  if (e) {
    const n = e.stackTraceLimit;
    if (typeof n == "number") {
      try {
        e.stackTraceLimit = 0;
      } catch {
        return gd = null, new t();
      }
      try {
        return new t();
      } finally {
        e.stackTraceLimit = n;
      }
    }
  }
  return new t();
}
function F(t, e, n, r) {
  const o = {};
  function i(v) {
    this.def = v, this.constr = p, this.traits = /* @__PURE__ */ new Set();
  }
  i.prototype = o;
  const a = n, c = a && /* @__PURE__ */ new WeakSet();
  function l(v, k) {
    if (v._zod) {
      if (v._zod.traits.has(t))
        return;
    } else {
      Ru.value = new i(k);
      try {
        Object.defineProperty(v, "_zod", Ru);
      } finally {
        Ru.value = void 0;
      }
    }
    if (v._zod.traits.add(t), e(v, k), c) {
      const A = Object.getPrototypeOf(v), S = v._zod.constr.prototype;
      let z = A;
      for (; z && z !== S; )
        z = Object.getPrototypeOf(z);
      const L = z ?? A;
      c.has(L) || (c.add(L), dy(L, a));
    }
    const P = p.prototype;
    for (const A in P)
      Object.prototype.hasOwnProperty.call(P, A) && (A in v || (v[A] = P[A].bind(v)));
  }
  const h = (r == null ? void 0 : r.Parent) ?? Object;
  class m extends h {
  }
  Object.defineProperty(m, "name", { value: t });
  function p(v) {
    var S;
    const k = r != null && r.Parent ? yy(m) : this;
    l(k, v);
    const P = k._zod.deferred;
    if (P) {
      for (const z of P)
        z();
      k._zod.deferred = void 0;
    }
    const A = (S = globalThis.__zod_globalConfig) == null ? void 0 : S.postProcessor;
    return A && A(k), k;
  }
  return Object.defineProperty(p, "init", { value: l }), Object.defineProperty(p, Symbol.hasInstance, {
    value: (v) => {
      var k, P;
      return r != null && r.Parent && v instanceof r.Parent ? !0 : (P = (k = v == null ? void 0 : v._zod) == null ? void 0 : k.traits) == null ? void 0 : P.has(t);
    }
  }), Object.defineProperty(p, "name", { value: t }), p;
}
class Nr extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class af extends Error {
  constructor(e) {
    super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
  }
}
(pd = globalThis).__zod_globalConfig ?? (pd.__zod_globalConfig = {});
const wn = globalThis.__zod_globalConfig;
function pr(t) {
  return t && Object.assign(wn, t), wn;
}
function by() {
  const t = this._zod;
  return t.message ?? (t.message = JSON.stringify(t.def, Hu, 2)), t.message;
}
function wy(t) {
  this._zod.message = t;
}
const ky = {
  get: by,
  set: wy,
  enumerable: !0,
  configurable: !0
}, xu = { value: void 0, enumerable: !1 }, vd = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), _y = (t, e) => {
  t.name = "$ZodError", xu.value = e, Object.defineProperty(t, "issues", xu), xu.value = void 0, Object.defineProperty(t, "message", ky);
  const n = Object.getPrototypeOf(t);
  vd.has(n) || (vd.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      const r = () => this.message;
      return Object.defineProperty(this, "toString", { value: r, configurable: !0, writable: !0 }), r;
    },
    set(r) {
      Object.defineProperty(this, "toString", { value: r, configurable: !0, writable: !0 });
    }
  }));
}, Ty = F("$ZodError", _y);
function Cy(t, e, n) {
  return Object.prototype.hasOwnProperty.call(t, e) || (e === "__proto__" ? Object.defineProperty(t, e, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : t[e] = n()), t[e];
}
function Py(t, e = (n) => n.message) {
  const n = {}, r = [];
  for (const o of t.issues)
    o.path.length > 0 ? Cy(n, o.path[0], () => []).push(e(o)) : r.push(e(o));
  return { formErrors: r, fieldErrors: n };
}
function Ay(t, e = (n) => n.message) {
  const n = { _errors: [] }, r = (o, i = []) => {
    for (const a of o.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((c) => r({ issues: c }, [...i, ...a.path]));
      else if (a.code === "invalid_key")
        r({ issues: a.issues }, [...i, ...a.path]);
      else if (a.code === "invalid_element")
        r({ issues: a.issues }, [...i, ...a.path]);
      else {
        const c = [...i, ...a.path];
        if (c.length === 0)
          n._errors.push(e(a));
        else {
          let l = n, h = 0;
          for (; h < c.length; ) {
            const m = c[h], p = h === c.length - 1;
            if (m === "_errors") {
              p && l._errors.push(e(a)), h++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(l, m) || Object.defineProperty(l, m, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            const v = l[m];
            p && v._errors.push(e(a)), l = v, h++;
          }
        }
      }
  };
  return r(t), n;
}
function gs(t, e) {
  return { callee: (e == null ? void 0 : e.callee) ?? t, Err: e == null ? void 0 : e.Err };
}
const $c = (t) => {
  const e = (n, r, o, i) => {
    const a = o ? { ...o, async: !1 } : { async: !1 }, c = n._zod.run({ value: r, issues: [] }, a);
    if (c instanceof Promise)
      throw new Nr();
    if (c.issues.length) {
      const l = new ((i == null ? void 0 : i.Err) ?? t)(c.issues.map((h) => Io(h, a, pr())));
      throw Qh(l, (i == null ? void 0 : i.callee) ?? e), l;
    }
    return c.value;
  };
  return e;
}, Nc = (t) => {
  const e = async (n, r, o, i) => {
    const a = o ? { ...o, async: !0 } : { async: !0 };
    let c = n._zod.run({ value: r, issues: [] }, a);
    if (c instanceof Promise && (c = await c), c.issues.length) {
      const l = new ((i == null ? void 0 : i.Err) ?? t)(c.issues.map((h) => Io(h, a, pr())));
      throw Qh(l, (i == null ? void 0 : i.callee) ?? e), l;
    }
    return c.value;
  };
  return e;
}, jc = (t) => (e, n, r) => {
  const o = r ? { ...r, async: !1 } : { async: !1 }, i = e._zod.run({ value: n, issues: [] }, o);
  if (i instanceof Promise)
    throw new Nr();
  return i.issues.length ? sf(t, i.issues, o) : { success: !0, data: i.value };
};
function sf(t, e, n) {
  let r;
  return {
    success: !1,
    get error() {
      return r || (r = new t(e.map((o) => Io(o, n, pr()))), e = void 0, n = void 0), r;
    },
    set error(o) {
      r = o, e = void 0, n = void 0;
    }
  };
}
const Lc = (t) => async (e, n, r) => {
  const o = r ? { ...r, async: !0 } : { async: !0 };
  let i = e._zod.run({ value: n, issues: [] }, o);
  return i instanceof Promise && (i = await i), i.issues.length ? sf(t, i.issues, o) : { success: !0, data: i.value };
}, Ey = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), Sy = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), Dy = ((t, e, n) => {
  const r = t._zod.bag.validator;
  if (r !== void 0) {
    if (r(e) !== Ey)
      return !0;
    if (r.definite === !0 && n === void 0)
      return !1;
  }
  return Iy(t, e, n);
});
function Iy(t, e, n) {
  const r = n ? { ...n, async: !1, abortEarly: !0 } : { async: !1, abortEarly: !0 }, o = t._zod.bag.fallbackRun;
  let i;
  if (o ? (r[Sy] = !0, i = o({ value: e, issues: [] }, r)) : i = t._zod.run({ value: e, issues: [] }, r), i instanceof Promise)
    throw new Nr();
  return i.issues.length === 0;
}
const zy = async (t, e, n) => {
  const r = n ? { ...n, async: !0, abortEarly: !0 } : { async: !0, abortEarly: !0 };
  let o = t._zod.run({ value: e, issues: [] }, r);
  return o instanceof Promise && (o = await o), o.issues.length === 0;
}, Ry = (t) => {
  const e = $c(t), n = (r, o, i, a) => {
    const c = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return e(r, o, c, gs(n, a));
  };
  return n;
}, xy = (t) => {
  const e = $c(t), n = (r, o, i, a) => e(r, o, i, gs(n, a));
  return n;
}, Oy = (t) => {
  const e = Nc(t), n = async (r, o, i, a) => {
    const c = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return await e(r, o, c, gs(n, a));
  };
  return n;
}, My = (t) => {
  const e = Nc(t), n = async (r, o, i, a) => await e(r, o, i, gs(n, a));
  return n;
}, $y = (t) => (e, n, r) => {
  const o = r ? { ...r, direction: "backward" } : { direction: "backward" };
  return jc(t)(e, n, o);
}, Ny = (t) => (e, n, r) => jc(t)(e, n, r), jy = (t) => async (e, n, r) => {
  const o = r ? { ...r, direction: "backward" } : { direction: "backward" };
  return Lc(t)(e, n, o);
}, Ly = (t) => async (e, n, r) => Lc(t)(e, n, r), Gy = /^[cC][0-9a-z]{6,}$/, Fy = /^[0-9a-z]+$/, Uy = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, Zy = /^[0-9a-vA-V]{20}$/, qy = /^[A-Za-z0-9]{27}$/, Ky = /^[a-zA-Z0-9_-]{21}$/;
function Wy(t) {
  return new RegExp(`^[a-zA-Z0-9_-]{${t}}$`);
}
const Yy = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Vy = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, yd = (t) => t ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${t}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, By = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Hy = "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function Qy() {
  return new RegExp(Hy, "u");
}
const Xy = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Jy = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, eb = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, tb = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, nb = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, rb = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/, ob = /^https?$/, ib = /^\+[1-9]\d{6,14}$/, uf = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function ab(t) {
  return new RegExp(`^${t}$`);
}
const sb = /* @__PURE__ */ ab(uf);
function Xu(t) {
  const e = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof t.precision == "number" ? t.precision === -1 ? `${e}` : t.precision === 0 ? `${e}:[0-5]\\d` : `${e}:[0-5]\\d\\.\\d{${t.precision}}` : t.seconds ? `${e}:[0-5]\\d(?:\\.\\d+)?` : `${e}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function ub(t) {
  return new RegExp(`^${Xu(t)}$`);
}
function cb(t) {
  const e = ["Z"];
  t.offset && e.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${Xu({ precision: t.precision, seconds: !0 })}(?:${e.join("|")})`, r = t.local ? `${n}|${Xu({ precision: t.precision })}` : n;
  return new RegExp(`^${uf}T(?:${r})$`);
}
const lb = /^[\s\S]{0,}$/, db = /^-?\d+$/, cf = /^-?\d+(?:\.\d+)?$/, hb = /^(?:true|false)$/i, fb = /^[^A-Z]*$/, mb = /^[^a-z]*$/, Nt = /* @__PURE__ */ F("$ZodCheck", (t, e) => {
  var n;
  t._zod ?? (t._zod = {}), t._zod.def = e, (n = t._zod).onattach ?? (n.onattach = []);
}), Gc = (t) => {
  const e = t.value;
  return !Yv(e) && e.length !== void 0;
}, Ya = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, lf = /* @__PURE__ */ F("$ZodCheckLessThan", (t, e) => {
  Nt.init(t, e);
  const n = Ya[typeof e.value];
  t._zod.check = (r) => {
    (e.inclusive ? r.value <= e.value : r.value < e.value) || r.issues.push({
      origin: Ya[typeof r.value] ?? n,
      code: "too_big",
      maximum: typeof e.value == "object" ? e.value.getTime() : e.value,
      input: r.value,
      inclusive: e.inclusive,
      inst: t,
      continue: !e.abort
    });
  };
}), df = /* @__PURE__ */ F("$ZodCheckGreaterThan", (t, e) => {
  Nt.init(t, e);
  const n = Ya[typeof e.value];
  t._zod.check = (r) => {
    (e.inclusive ? r.value >= e.value : r.value > e.value) || r.issues.push({
      origin: Ya[typeof r.value] ?? n,
      code: "too_small",
      minimum: typeof e.value == "object" ? e.value.getTime() : e.value,
      input: r.value,
      inclusive: e.inclusive,
      inst: t,
      continue: !e.abort
    });
  };
}), pb = /* @__PURE__ */ F("$ZodCheckMultipleOf", (t, e) => {
  Nt.init(t, e), t._zod.check = (n) => {
    if (typeof n.value != typeof e.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      e.value !== BigInt(0) && n.value % e.value === BigInt(0)
    ) : Vv(n.value, e.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: e.value,
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), gb = /* @__PURE__ */ F("$ZodCheckNumberFormat", (t, e) => {
  var a;
  Nt.init(t, e), e.format = e.format || "float64";
  const n = (a = e.format) == null ? void 0 : a.includes("int"), r = n ? "int" : "number", [o, i] = ef[e.format];
  t._zod.check = (c) => {
    const l = c.value;
    if (n) {
      if (!Number.isInteger(l)) {
        c.issues.push({
          expected: r,
          format: e.format,
          code: "invalid_type",
          continue: !1,
          input: l,
          inst: t
        });
        return;
      }
      if (!Number.isSafeInteger(l)) {
        l > 0 ? c.issues.push({
          input: l,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: t,
          origin: r,
          inclusive: !0,
          continue: !e.abort
        }) : c.issues.push({
          input: l,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: t,
          origin: r,
          inclusive: !0,
          continue: !e.abort
        });
        return;
      }
    }
    l < o && c.issues.push({
      origin: "number",
      input: l,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: t,
      continue: !e.abort
    }), l > i && c.issues.push({
      origin: "number",
      input: l,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: t,
      continue: !e.abort
    });
  };
}), vb = /* @__PURE__ */ F("$ZodCheckMaxLength", (t, e) => {
  var n;
  Nt.init(t, e), (n = t._zod.def).when ?? (n.when = Gc), t._zod.check = (r) => {
    const o = r.value, i = o.length;
    if ((typeof o == "string" && i > e.maximum ? Oc(o) : i) <= e.maximum)
      return;
    const c = Mc(o);
    r.issues.push({
      origin: c,
      code: "too_big",
      maximum: e.maximum,
      inclusive: !0,
      input: o,
      inst: t,
      continue: !e.abort
    });
  };
}), yb = /* @__PURE__ */ F("$ZodCheckMinLength", (t, e) => {
  var n;
  Nt.init(t, e), (n = t._zod.def).when ?? (n.when = Gc), t._zod.check = (r) => {
    const o = r.value, i = o.length;
    if ((typeof o == "string" && i >= e.minimum && i < e.minimum * 2 ? Oc(o) : i) >= e.minimum)
      return;
    const c = Mc(o);
    r.issues.push({
      origin: c,
      code: "too_small",
      minimum: e.minimum,
      inclusive: !0,
      input: o,
      inst: t,
      continue: !e.abort
    });
  };
}), bb = /* @__PURE__ */ F("$ZodCheckLengthEquals", (t, e) => {
  var n;
  Nt.init(t, e), (n = t._zod.def).when ?? (n.when = Gc), t._zod.check = (r) => {
    const o = r.value, i = o.length, a = typeof o == "string" && i >= e.length && i <= e.length * 2 ? Oc(o) : i;
    if (a === e.length)
      return;
    const c = Mc(o), l = a > e.length;
    r.issues.push({
      origin: c,
      ...l ? { code: "too_big", maximum: e.length } : { code: "too_small", minimum: e.length },
      inclusive: !0,
      exact: !0,
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
}), vs = /* @__PURE__ */ F("$ZodCheckStringFormat", (t, e) => {
  var n, r;
  Nt.init(t, e), e.pattern ? (n = t._zod).check ?? (n.check = (o) => {
    e.pattern.lastIndex = 0, !e.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: e.format,
      input: o.value,
      ...e.pattern ? { pattern: e.pattern.toString() } : {},
      inst: t,
      continue: !e.abort
    });
  }) : (r = t._zod).check ?? (r.check = () => {
  });
}), wb = /* @__PURE__ */ F("$ZodCheckRegex", (t, e) => {
  vs.init(t, e), t._zod.check = (n) => {
    e.pattern.lastIndex = 0, !e.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: e.pattern.toString(),
      inst: t,
      continue: !e.abort
    });
  };
}), kb = /* @__PURE__ */ F("$ZodCheckLowerCase", (t, e) => {
  e.pattern ?? (e.pattern = fb), vs.init(t, e);
}), _b = /* @__PURE__ */ F("$ZodCheckUpperCase", (t, e) => {
  e.pattern ?? (e.pattern = mb), vs.init(t, e);
}), Tb = /* @__PURE__ */ F("$ZodCheckIncludes", (t, e) => {
  Nt.init(t, e);
  const n = vo(e.includes), r = new RegExp(typeof e.position == "number" ? `^.{${e.position},}${n}` : n);
  e.pattern = r, t._zod.check = (o) => {
    o.value.includes(e.includes, e.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: e.includes,
      input: o.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Cb = /* @__PURE__ */ F("$ZodCheckStartsWith", (t, e) => {
  Nt.init(t, e);
  const n = new RegExp(`^${vo(e.prefix)}.*`);
  e.pattern ?? (e.pattern = n), t._zod.check = (r) => {
    r.value.startsWith(e.prefix) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: e.prefix,
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Pb = /* @__PURE__ */ F("$ZodCheckEndsWith", (t, e) => {
  Nt.init(t, e);
  const n = new RegExp(`.*${vo(e.suffix)}$`);
  e.pattern ?? (e.pattern = n), t._zod.check = (r) => {
    r.value.endsWith(e.suffix) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: e.suffix,
      input: r.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Ab = /* @__PURE__ */ F("$ZodCheckOverwrite", (t, e) => {
  Nt.init(t, e), t._zod.check = (n) => {
    n.value = e.tx(n.value);
  };
});
class Eb {
  constructor(e = [], n = {}) {
    this.content = [], this.indent = 0, this.args = e, this.closed = n;
  }
  // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
  indented(e) {
    this.indent += 1;
    try {
      e(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(e) {
    if (typeof e == "function") {
      e(this, { execution: "sync" }), e(this, { execution: "async" });
      return;
    }
    const r = e.split(`
`).filter((a) => a), o = Math.min(...r.map((a) => a.length - a.trimStart().length)), i = r.map((a) => a.slice(o)).map((a) => " ".repeat(this.indent * 2) + a);
    for (const a of i)
      this.content.push(a);
  }
  compile() {
    const e = Function, n = (this == null ? void 0 : this.content) ?? [""];
    return new e(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
}
const Sb = {
  major: 4,
  minor: 6,
  patch: 7
}, Ze = /* @__PURE__ */ F("$ZodType", (t, e) => {
  var i;
  var n;
  t ?? (t = {}), t._zod.def = e, t._zod.bag = t._zod.bag || {}, t._zod.version = Sb;
  const r = t._zod.def.checks, o = t._zod.traits.has("$ZodCheck") ? [t, ...r ?? []] : r != null && r.length ? [...r] : [];
  for (const a of o)
    for (const c of a._zod.onattach)
      c(t);
  if (o.length === 0)
    (n = t._zod).deferred ?? (n.deferred = []), (i = t._zod.deferred) == null || i.push(() => {
      t._zod.run = t._zod.parse;
    });
  else {
    const a = (l, h, m) => {
      if (l.memo)
        return l;
      let p = Nn(l), v;
      for (const k of h) {
        if (k._zod.def.when) {
          if (uy(l) || !k._zod.def.when(l))
            continue;
        } else if (p)
          continue;
        const P = l.issues.length, A = k._zod.check(l);
        if (A instanceof Promise && (m == null ? void 0 : m.async) === !1)
          throw new Nr();
        if (v || A instanceof Promise)
          v = (v ?? Promise.resolve()).then(async () => {
            await A, l.issues.length !== P && (Qu(l.issues, P, t), p || (p = Nn(l, P)));
          });
        else {
          if (l.issues.length === P)
            continue;
          Qu(l.issues, P, t), p || (p = Nn(l, P));
        }
      }
      return v ? v.then(() => l) : l;
    }, c = (l, h, m) => {
      if (Nn(l))
        return l.aborted = !0, l;
      const p = a(h, o, m);
      if (p instanceof Promise) {
        if (m.async === !1)
          throw new Nr();
        return p.then((v) => t._zod.parse(v, m));
      }
      return t._zod.parse(p, m);
    };
    t._zod.run = (l, h) => {
      if (h.skipChecks)
        return t._zod.parse(l, h);
      if (h.direction === "backward") {
        const p = t._zod.parse({ value: l.value, issues: [] }, { ...h, skipChecks: !0 });
        return p instanceof Promise ? p.then((v) => c(v, l, h)) : c(p, l, h);
      }
      const m = t._zod.parse(l, h);
      if (m instanceof Promise) {
        if (h.async === !1)
          throw new Nr();
        return m.then((p) => a(p, o, h));
      }
      return a(m, o, h);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return rf(this, "~standard", ff(this));
  },
  set "~standard"(t) {
    lr(this, "~standard", t);
  }
}), hf = (t, e) => t.issues.length ? { issues: t.issues.map((n) => Io(n, e, pr())) } : { value: t.value };
async function Db(t, e) {
  const n = { async: !0 };
  return hf(await t._zod.run({ value: e, issues: [] }, n), n);
}
function ff(t) {
  return {
    validate: (e) => {
      const n = { async: !1 };
      try {
        const r = t._zod.run({ value: e, issues: [] }, n);
        if (!(r instanceof Promise))
          return hf(r, n);
      } catch {
      }
      return Db(t, e);
    },
    vendor: "zod",
    version: 1
  };
}
const Fc = /* @__PURE__ */ F("$ZodString", (t, e) => {
  Ze.init(t, e), t._zod.pattern = e.pattern ?? lb, t._zod.parse = (n, r) => {
    if (e.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: t
    }), n;
  };
}), Me = /* @__PURE__ */ F("$ZodStringFormat", (t, e) => {
  vs.init(t, e), Fc.init(t, e);
}), Ib = /* @__PURE__ */ F("$ZodGUID", (t, e) => {
  e.pattern ?? (e.pattern = Vy), Me.init(t, e);
}), zb = /* @__PURE__ */ F("$ZodUUID", (t, e) => {
  if (e.version) {
    const r = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[e.version];
    if (r === void 0)
      throw new Error(`Invalid UUID version: "${e.version}"`);
    e.pattern ?? (e.pattern = yd(r));
  } else
    e.pattern ?? (e.pattern = yd());
  Me.init(t, e);
}), Rb = /* @__PURE__ */ F("$ZodEmail", (t, e) => {
  e.pattern ?? (e.pattern = By), Me.init(t, e);
}), mf = 1, Va = 2;
function pf(t) {
  try {
    return typeof URL < "u" && typeof URL.canParse == "function" ? URL.canParse(t) : (new URL(t), !0);
  } catch {
    return !1;
  }
}
function xb(t, e) {
  return !("normalize" in e) && !("hostname" in e) && !("protocol" in e) ? pf(t) || Va : Ob(t, e);
}
function Ob(t, e) {
  var n;
  if (!e.normalize && ((n = e.protocol) == null ? void 0 : n.source) === ob.source && !/^https?:\/\//i.test(t))
    return mf;
  try {
    if (typeof URL < "u") {
      const r = URL;
      if (typeof r.parse == "function")
        return r.parse(t) ?? Va;
    }
    return new URL(t);
  } catch {
    return Va;
  }
}
const Mb = /[\t\n\r]/g;
function bd(t) {
  return t.replace(Mb, "");
}
function $b(t, e) {
  return e.lastIndex = 0, e.test(t.hostname);
}
function Nb(t, e) {
  return e.lastIndex = 0, e.test(t.protocol.endsWith(":") ? t.protocol.slice(0, -1) : t.protocol);
}
const jb = /* @__PURE__ */ F("$ZodURL", (t, e) => {
  Me.init(t, e), t._zod.check = (n) => {
    try {
      const r = n.value.trim(), o = xb(r, e);
      if (o === mf) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: t,
          continue: !e.abort
        });
        return;
      }
      if (o === Va) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: t,
          continue: !e.abort
        });
        return;
      }
      if (o === !0) {
        n.value = bd(r);
        return;
      }
      e.hostname && !$b(o, e.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: e.hostname.source,
        input: n.value,
        inst: t,
        continue: !e.abort
      }), e.protocol && !Nb(o, e.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: e.protocol.source,
        input: n.value,
        inst: t,
        continue: !e.abort
      }), n.value = e.normalize ? o.href : bd(r);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: t,
        continue: !e.abort
      });
    }
  };
}), Lb = /* @__PURE__ */ F("$ZodEmoji", (t, e) => {
  e.pattern ?? (e.pattern = Qy()), Me.init(t, e);
}), Gb = /* @__PURE__ */ F("$ZodNanoID", (t, e) => {
  if (e.length !== void 0 && (!Number.isInteger(e.length) || e.length < 1))
    throw new Error(`Invalid nanoid length: ${e.length}`);
  e.pattern ?? (e.pattern = e.length === void 0 ? Ky : Wy(e.length)), Me.init(t, e);
}), Fb = /* @__PURE__ */ F("$ZodCUID", (t, e) => {
  e.pattern ?? (e.pattern = Gy), Me.init(t, e);
}), Ub = /* @__PURE__ */ F("$ZodCUID2", (t, e) => {
  e.pattern ?? (e.pattern = Fy), Me.init(t, e);
}), Zb = /* @__PURE__ */ F("$ZodULID", (t, e) => {
  e.pattern ?? (e.pattern = Uy), Me.init(t, e);
}), qb = /* @__PURE__ */ F("$ZodXID", (t, e) => {
  e.pattern ?? (e.pattern = Zy), Me.init(t, e);
}), Kb = /* @__PURE__ */ F("$ZodKSUID", (t, e) => {
  e.pattern ?? (e.pattern = qy), Me.init(t, e);
}), Wb = /* @__PURE__ */ F("$ZodISODateTime", (t, e) => {
  e.pattern ?? (e.pattern = cb(e)), Me.init(t, e);
}), Yb = /* @__PURE__ */ F("$ZodISODate", (t, e) => {
  e.pattern ?? (e.pattern = sb), Me.init(t, e);
}), Vb = /* @__PURE__ */ F("$ZodISOTime", (t, e) => {
  e.pattern ?? (e.pattern = ub(e)), Me.init(t, e);
}), Bb = /* @__PURE__ */ F("$ZodISODuration", (t, e) => {
  e.pattern ?? (e.pattern = Yy), Me.init(t, e);
}), Hb = /* @__PURE__ */ F("$ZodIPv4", (t, e) => {
  e.pattern ?? (e.pattern = Xy), Me.init(t, e);
}), Qb = /^[0-9a-fA-F:.]+$/;
function gf(t) {
  return Qb.test(t) ? pf(`http://[${t}]`) : !1;
}
const Xb = /* @__PURE__ */ F("$ZodIPv6", (t, e) => {
  e.pattern ?? (e.pattern = Jy), Me.init(t, e), t._zod.check = (n) => {
    gf(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Jb = /* @__PURE__ */ F("$ZodCIDRv4", (t, e) => {
  e.pattern ?? (e.pattern = eb), Me.init(t, e);
});
function ew(t) {
  const e = t.split("/");
  if (e.length !== 2)
    return !1;
  const [n, r] = e;
  if (!r)
    return !1;
  const o = Number(r);
  return `${o}` !== r || o < 0 || o > 128 ? !1 : gf(n);
}
const tw = /* @__PURE__ */ F("$ZodCIDRv6", (t, e) => {
  e.pattern ?? (e.pattern = tb), Me.init(t, e), t._zod.check = (n) => {
    ew(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
});
function vf(t) {
  if (t === "")
    return !0;
  if (/\s/.test(t) || t.length % 4 !== 0)
    return !1;
  try {
    return atob(t), !0;
  } catch {
    return !1;
  }
}
const yf = /^[0-9a-zA-Z+/]*={0,2}$/, nw = /* @__PURE__ */ F("$ZodBase64", (t, e) => {
  e.pattern ?? (e.pattern = yf), Me.init(t, e), t._zod.check = (n) => {
    vf(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), Uc = /^[A-Za-z0-9_-]*$/;
function rw(t) {
  if (!Uc.test(t))
    return !1;
  const e = t.replace(/[-_]/g, (r) => r === "-" ? "+" : "/"), n = e.padEnd(Math.ceil(e.length / 4) * 4, "=");
  return vf(n);
}
const ow = /* @__PURE__ */ F("$ZodBase64URL", (t, e) => {
  e.pattern ?? (e.pattern = Uc), Me.init(t, e), t._zod.check = (n) => {
    rw(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), iw = /* @__PURE__ */ F("$ZodE164", (t, e) => {
  e.pattern ?? (e.pattern = ib), Me.init(t, e);
});
function aw(t, e = null) {
  try {
    const n = t.split(".");
    if (n.length !== 3)
      return !1;
    const [r] = n;
    if (!r)
      return !1;
    const o = JSON.parse(atob(r));
    return !("typ" in o && (o == null ? void 0 : o.typ) !== "JWT" || !o.alg || e && (!("alg" in o) || o.alg !== e));
  } catch {
    return !1;
  }
}
const sw = /* @__PURE__ */ F("$ZodJWT", (t, e) => {
  Me.init(t, e), t._zod.check = (n) => {
    aw(n.value, e.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: t,
      continue: !e.abort
    });
  };
}), bf = /* @__PURE__ */ F("$ZodNumber", (t, e) => {
  Ze.init(t, e), t._zod.pattern = cf, t._zod.parse = (n, r) => {
    if (e.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    const o = n.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return n;
    const i = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : String(o) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: t,
      ...i ? { received: i } : {}
    }), n;
  };
}), uw = /* @__PURE__ */ F("$ZodNumberFormat", (t, e) => {
  gb.init(t, e), bf.init(t, e);
}), cw = /* @__PURE__ */ F("$ZodBoolean", (t, e) => {
  Ze.init(t, e), t._zod.pattern = hb, t._zod.parse = (n, r) => {
    if (e.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    const o = n.value;
    return typeof o == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: t
    }), n;
  };
}), lw = /* @__PURE__ */ F("$ZodUnknown", (t, e) => {
  Ze.init(t, e), t._zod.parse = (n) => n;
}), dw = /* @__PURE__ */ F("$ZodNever", (t, e) => {
  Ze.init(t, e), t._zod.parse = (n, r) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: t
  }), n);
});
function hw(t, e) {
  const n = md(t._zod.def.checks);
  if (!n.length)
    return;
  const r = Math.min(...n.map((i) => i[0])), o = t._zod.parse;
  t._zod.parse = (i, a) => {
    const c = e(i.value);
    if (c > r && !(a != null && a.skipChecks) && (a == null ? void 0 : a.direction) !== "backward") {
      for (const [l, h] of md(t._zod.def.checks))
        if (c > l && h._zod.def.when(i)) {
          const m = i.issues.length;
          return h._zod.check(i), i.issues[m].continue = !1, Qu(i.issues, m, t), i;
        }
    }
    return o(i, a);
  };
}
const fw = (t) => Array.isArray(t) ? t.length : -1;
function wd(t, e, n) {
  t.issues.length && e.issues.push(...nf(n, t.issues)), e.value[n] = t.value;
}
const mw = /* @__PURE__ */ F("$ZodArray", (t, e) => {
  Ze.init(t, e);
  const n = wn.memoizer;
  n == null || n.attach(t), t._zod.parse = (r, o) => {
    const i = r.value;
    if (!Array.isArray(i))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: i,
        inst: t
      }), r;
    r.value = n ? n.alloc(t, r, Array(i.length), o) : Array(i.length);
    const a = [], c = o == null ? void 0 : o.abortEarly;
    for (let l = 0; l < i.length; l++) {
      const h = i[l], m = e.element._zod.run({
        value: h,
        issues: []
      }, o);
      if (m instanceof Promise)
        a.push(m.then((p) => wd(p, r, l)));
      else if (wd(m, r, l), c && m.issues.length !== 0 && Nn(m))
        break;
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  }, hw(t, fw);
});
function Ba(t, e, n, r, o, i) {
  const a = n in r, c = i === "optional";
  if (!(!a && c && o === "optional")) {
    if (t.issues.length) {
      if (o !== void 0 && c && !a)
        return;
      e.issues.push(...nf(n, t.issues));
    }
    if (!a && o === void 0) {
      t.issues.length || e.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    t.value === void 0 ? (a || o === "defaulted" && !c) && (e.value[n] = void 0) : e.value[n] = t.value;
  }
}
const pw = [];
function wf(t) {
  var a, c, l, h;
  const e = Object.keys(t.shape), n = Object.getOwnPropertySymbols(t.shape), r = n.length ? n : pw, o = r.length ? [...e, ...r] : e;
  for (const m of o)
    if (!((h = (l = (c = (a = t.shape) == null ? void 0 : a[m]) == null ? void 0 : c._zod) == null ? void 0 : l.traits) != null && h.has("$ZodType")))
      throw new Error(`Invalid element at key "${String(m)}": expected a Zod schema`);
  const i = ey(t.shape);
  return {
    ...t,
    allKeys: o,
    symbolKeys: r,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(e),
    numKeys: e.length,
    optionalKeys: new Set(i)
  };
}
function kf(t, e, n, r, o, i, a) {
  const c = [], l = o.keySet, h = o.catchall._zod, m = h.def.type, p = h.optin, v = h.optout;
  let k = 0;
  for (const P in e) {
    if (a && n.issues.length !== k) {
      if (Nn(n, k))
        break;
      k = n.issues.length;
    }
    if (l.has(P))
      continue;
    if (P === "__proto__") {
      m === "never" && c.push(P);
      continue;
    }
    if (m === "never") {
      c.push(P);
      continue;
    }
    const A = h.run({ value: e[P], issues: [] }, r);
    A instanceof Promise ? t.push(A.then((S) => Ba(S, n, P, e, p, v))) : Ba(A, n, P, e, p, v);
  }
  return c.length && n.issues.push({
    code: "unrecognized_keys",
    keys: c,
    input: e,
    inst: i,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), t.length ? Promise.all(t).then(() => n) : n;
}
const gw = /* @__PURE__ */ F("$ZodObject", (t, e) => {
  Ze.init(t, e);
  const n = Object.getOwnPropertyDescriptor(e, "shape"), r = n != null && n.get ? n.get.raw : e.shape ?? {};
  if (r) {
    const h = () => {
      const m = { ...r };
      return Object.defineProperty(e, "shape", { value: m }), h.raw = m, m;
    };
    h.raw = r, Object.defineProperty(e, "shape", { get: h });
  }
  const o = ms(() => wf(e));
  Ae(t, "propValues", (h) => {
    const m = h.def.shape, p = {};
    for (const v in m) {
      const k = m[v]._zod;
      if (k.values) {
        Object.prototype.hasOwnProperty.call(p, v) || Cn(p, v, /* @__PURE__ */ new Set());
        for (const P of k.values)
          p[v].add(P);
        k.optin !== void 0 && p[v].add(void 0);
      }
    }
    return p;
  });
  const i = ki, a = e.catchall;
  let c;
  const l = wn.memoizer;
  l == null || l.attach(t), t._zod.parse = (h, m) => {
    c ?? (c = o.value);
    const p = h.value;
    if (!i(p))
      return h.issues.push({
        expected: "object",
        code: "invalid_type",
        input: p,
        inst: t
      }), h;
    h.value = l ? l.alloc(t, h, {}, m) : {};
    const v = [], k = c.shape, P = m == null ? void 0 : m.abortEarly;
    let A = h.issues.length;
    for (const S of c.allKeys) {
      if (P && h.issues.length !== A) {
        if (Nn(h, A))
          break;
        A = h.issues.length;
      }
      if (S === "__proto__")
        continue;
      const z = k[S], L = z._zod.optin, W = z._zod.optout, H = z._zod.run({ value: p[S], issues: [] }, m);
      H instanceof Promise ? v.push(H.then((re) => Ba(re, h, S, p, L, W))) : Ba(H, h, S, p, L, W);
    }
    return a ? kf(v, p, h, m, o.value, t, P === !0) : v.length ? Promise.all(v).then(() => h) : h;
  };
}), vw = /* @__PURE__ */ F("$ZodObjectJIT", (t, e) => {
  gw.init(t, e);
  const n = t._zod.parse, r = ms(() => wf(e)), o = wn.memoizer, i = (k) => {
    var re, Ee;
    const P = r.value, A = P.symbolKeys, S = new Eb(["payload", "ctx"], { shape: k, inst: t, memo: o, syms: A }), z = (ye) => `shape[${ye}]._zod.run({ value: input[${ye}], issues: [] }, ctx)`, L = (ye, ue) => `
          let ${ye}_ab = false;
          for (let i = 0; i < ${ye}.issues.length; i++) {
            const iss = ${ye}.issues[i];
            iss.path = iss.path ? [${ue}, ...iss.path] : [${ue}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${ye}_ab = true;
          }
          if (${ye}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    S.write("const input = payload.value;");
    const W = /* @__PURE__ */ Object.create(null);
    let H = 0;
    for (const ye of P.allKeys)
      W[ye] = `key_${H++}`;
    S.write(o ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (const ye of P.allKeys) {
      if (ye === "__proto__")
        continue;
      const ue = W[ye], he = typeof ye == "symbol" ? `syms[${A.indexOf(ye)}]` : Hv(ye), _e = `${he} in input`, De = k[ye], Ce = (re = De == null ? void 0 : De._zod) == null ? void 0 : re.optin, We = Ce !== void 0, He = ((Ee = De == null ? void 0 : De._zod) == null ? void 0 : Ee.optout) === "optional";
      if (S.write(`const ${ue} = ${z(he)};`), We && He) {
        const Yt = Ce === "optional" ? `${ue}_present` : `${ue}.value !== undefined || ${ue}_present`;
        S.write(`
        const ${ue}_present = ${_e};
        if (!${ue}.issues.length || ${ue}_present) {
          if (${ue}.issues.length) {${L(ue, he)}
          }

          if (${Yt}) {
            newResult[${he}] = ${ue}.value;
          }
        }

      `);
      } else We ? (S.write(`
        if (${ue}.issues.length) {${L(ue, he)}
        }
      `), Ce === "defaulted" ? S.write(`newResult[${he}] = ${ue}.value;`) : S.write(`
        if (${ue}.value !== undefined || ${_e}) {
          newResult[${he}] = ${ue}.value;
        }
      `)) : S.write(`
        const ${ue}_present = ${_e};
        if (${ue}.issues.length) {${L(ue, he)}
        }
        if (!${ue}_present && !${ue}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${he}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${ue}_present) {
          newResult[${he}] = ${ue}.value;
        }

      `);
    }
    return S.write("payload.value = newResult;"), S.write("return payload;"), S.compile();
  };
  let a;
  const c = ki, l = !wn.jitless, m = l && Xv.value, p = e.catchall;
  let v;
  t._zod.parse = (k, P) => {
    v ?? (v = r.value);
    const A = k.value;
    return c(A) ? l && m && (P == null ? void 0 : P.async) === !1 && P.jitless !== !0 ? (a || (a = i(e.shape)), k = a(k, P), p ? kf([], A, k, P, v, t, (P == null ? void 0 : P.abortEarly) === !0) : k) : n(k, P) : (k.issues.push({
      expected: "object",
      code: "invalid_type",
      input: A,
      inst: t
    }), k);
  };
});
function kd(t, e, n, r) {
  for (const i of t)
    if (i.issues.length === 0)
      return e.value = i.value, e;
  const o = t.filter((i) => !Nn(i));
  return o.length === 1 ? (e.value = o[0].value, o[0]) : (e.issues.push({
    code: "invalid_union",
    input: e.value,
    inst: n,
    errors: t.map((i) => i.issues.map((a) => Io(a, r, pr())))
  }), e);
}
const _f = /* @__PURE__ */ F("$ZodUnion", (t, e) => {
  Ze.init(t, e), Ae(t, "optin", (r) => r.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : r.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0), Ae(t, "optout", (r) => r.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0), Ae(t, "values", (r) => {
    if (r.def.options.every((o) => o._zod.values))
      return new Set(r.def.options.flatMap((o) => Array.from(o._zod.values)));
  }), Ae(t, "pattern", (r) => {
    if (r.def.options.every((o) => o._zod.pattern)) {
      const o = r.def.options.map((i) => i._zod.pattern);
      return new RegExp(`^(${o.map((i) => Rc(i.source)).join("|")})$`);
    }
  });
  const n = e.options.length === 1 ? e.options[0]._zod.run : null;
  t._zod.parse = (r, o) => {
    if (n)
      return n(r, o);
    let i = !1;
    const a = [];
    for (const c of e.options) {
      const l = c._zod.run({
        value: r.value,
        issues: []
      }, o);
      if (l instanceof Promise)
        a.push(l), i = !0;
      else {
        if (l.issues.length === 0)
          return l;
        a.push(l);
      }
    }
    return i ? Promise.all(a).then((c) => kd(c, r, t, o)) : kd(a, r, t, o);
  };
});
function yw(t) {
  var n;
  const e = /* @__PURE__ */ new Map();
  for (const r of t.options) {
    const o = (n = r._zod.propValues) == null ? void 0 : n[t.discriminator];
    if (!o || o.size === 0)
      throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(r)}"`);
    for (const i of o)
      if (e.has(i)) {
        if (i !== void 0)
          throw new Error(`Duplicate discriminator value "${String(i)}"`);
        e.set(i, null);
      } else
        e.set(i, r);
  }
  return e;
}
const bw = /* @__PURE__ */ F("$ZodDiscriminatedUnion", (t, e) => {
  e.inclusive = !1, _f.init(t, e);
  const n = t._zod.parse;
  Ae(t, "propValues", (o) => {
    var c, l;
    const i = {};
    let a = 0;
    for (const h of o.def.options) {
      const m = h._zod.propValues;
      if (!m || Object.keys(m).length === 0)
        throw new Error(`Invalid discriminated union option at index "${o.def.options.indexOf(h)}"`);
      (c = m[o.def.discriminator]) != null && c.has(void 0) && a++;
      for (const [p, v] of Object.entries(m)) {
        Object.prototype.hasOwnProperty.call(i, p) || Cn(i, p, /* @__PURE__ */ new Set());
        for (const k of v)
          i[p].add(k);
      }
    }
    return !o.def.unionFallback && a > 1 && ((l = i[o.def.discriminator]) == null || l.delete(void 0)), i;
  }), e.options.forEach((o, i) => {
    const a = xc(o._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, e.discriminator))
      throw new Error(`Invalid discriminated union option at index "${i}"`);
  });
  const r = ms(() => yw(e));
  t._zod.parse = (o, i) => {
    const a = o.value;
    if (!ki(a))
      return o.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: t
      }), o;
    const c = a == null ? void 0 : a[e.discriminator], l = r.value.get(c);
    return l && (c !== void 0 || i.direction !== "backward") ? l._zod.run(o, i) : e.unionFallback || i.direction === "backward" ? n(o, i) : (o.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: e.discriminator,
      options: Array.from(r.value.keys()).filter((h) => r.value.get(h) !== null),
      input: a,
      path: [e.discriminator],
      inst: t
    }), o);
  };
}), ww = /* @__PURE__ */ F("$ZodIntersection", (t, e) => {
  Ze.init(t, e), t._zod.parse = (n, r) => {
    const o = n.value, i = e.left._zod.run({ value: o, issues: [] }, r), a = e.right._zod.run({ value: o, issues: [] }, r);
    return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([l, h]) => _d(n, l, h)) : _d(n, i, a);
  };
});
function Ju(t, e) {
  if (t === e)
    return { valid: !0, data: t };
  if (t instanceof Date && e instanceof Date && +t == +e)
    return { valid: !0, data: t };
  if (_i(t) && _i(e)) {
    const n = Object.keys(e), r = Object.keys(t).filter((i) => n.indexOf(i) !== -1), o = { ...t, ...e };
    Object.prototype.hasOwnProperty.call(o, "__proto__") && delete o.__proto__;
    for (const i of r) {
      if (i === "__proto__")
        continue;
      const a = Ju(t[i], e[i]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...a.mergeErrorPath]
        };
      o[i] = a.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(t) && Array.isArray(e)) {
    if (t.length !== e.length)
      return { valid: !1, mergeErrorPath: [] };
    const n = [];
    for (let r = 0; r < t.length; r++) {
      const o = t[r], i = e[r], a = Ju(o, i);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [r, ...a.mergeErrorPath]
        };
      n.push(a.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function _d(t, e, n) {
  const r = /* @__PURE__ */ new Map();
  let o;
  const i = /* @__PURE__ */ new Map(), a = (h, m) => {
    var v, k;
    let p;
    if (h.code === "unrecognized_keys" && !((v = h.path) != null && v.length))
      o ?? (o = h), p = h.keys;
    else if (h.code === "invalid_key" && h.origin === "record" && ((k = h.path) == null ? void 0 : k.length) === 1) {
      const P = String(h.path[0]);
      i.has(P) || i.set(P, h), p = [P];
    } else
      return !1;
    for (const P of p)
      r.has(P) || r.set(P, {}), r.get(P)[m] = !0;
    return !0;
  };
  for (const h of e.issues)
    a(h, "l") || t.issues.push(h);
  for (const h of n.issues)
    a(h, "r") || t.issues.push(h);
  const c = [...r].filter(([, h]) => h.l && h.r).map(([h]) => h);
  if (c.length) {
    const h = o ? c.filter((m) => o.keys.includes(m)) : [];
    h.length && t.issues.push({ ...o, keys: h });
    for (const m of c)
      !h.includes(m) && i.has(m) && t.issues.push(i.get(m));
  }
  const l = Ju(e.value, n.value);
  if (!l.valid) {
    if (Nn(t))
      return t;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(l.mergeErrorPath)}`);
  }
  return t.value = l.data, t;
}
const kw = /* @__PURE__ */ F("$ZodEnum", (t, e) => {
  Ze.init(t, e);
  const n = Bu(e.entries), r = new Set(n);
  t._zod.values = r, Ae(t, "pattern", (o) => {
    const i = Bu(o.def.entries).filter((a) => Jv.has(typeof a));
    return new RegExp(i.length ? `^(${i.map((a) => vo(a.toString())).join("|")})$` : "^[^\\s\\S]$");
  }), t._zod.parse = (o, i) => {
    const a = o.value;
    return r.has(a) || o.issues.push({
      code: "invalid_value",
      values: n,
      input: a,
      inst: t
    }), o;
  };
}), _w = /* @__PURE__ */ F("$ZodLiteral", (t, e) => {
  Ze.init(t, e);
  const n = new Set(e.values);
  t._zod.values = n, Ae(t, "pattern", (r) => {
    const o = r.def.values;
    return new RegExp(o.length ? `^(${o.map((i) => typeof i == "string" ? vo(i) : i ? vo(i.toString()) : String(i)).join("|")})$` : "^[^\\s\\S]$");
  }), t._zod.parse = (r, o) => {
    const i = r.value;
    return n.has(i) || r.issues.push({
      code: "invalid_value",
      values: e.values,
      input: i,
      inst: t
    }), r;
  };
}), Tw = /* @__PURE__ */ F("$ZodTransform", (t, e) => {
  var n;
  Ze.init(t, e), t._zod.optin = "optional", (n = wn.memoizer) == null || n.guard(t), t._zod.parse = (r, o) => {
    if (o.direction === "backward")
      throw new af(t.constructor.name);
    const i = e.transform(r.value, r);
    if (o.async)
      return (i instanceof Promise ? i : Promise.resolve(i)).then((c) => (r.value = c, r));
    if (i instanceof Promise)
      throw new Nr();
    return r.value = i, r;
  };
});
function Td(t, e) {
  return t.value = e.issues.length ? void 0 : e.value, t;
}
const Tf = /* @__PURE__ */ F("$ZodOptional", (t, e) => {
  Ze.init(t, e), Ae(t, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), t._zod.optout = "optional", Ae(t, "values", (n) => {
    const r = n.def.innerType._zod.values;
    return r ? /* @__PURE__ */ new Set([...r, void 0]) : void 0;
  }), Ae(t, "pattern", (n) => {
    const r = n.def.innerType._zod.pattern;
    return r ? new RegExp(`^(${Rc(r.source)})?$`) : void 0;
  }), t._zod.parse = (n, r) => {
    if (n.value === void 0) {
      if (e.innerType._zod.optin !== "defaulted")
        return n;
      const o = e.innerType._zod.run({ value: n.value, issues: [] }, r);
      return o instanceof Promise ? o.then((i) => Td(n, i)) : Td(n, o);
    }
    return e.innerType._zod.run(n, r);
  };
}), Cw = /* @__PURE__ */ F("$ZodExactOptional", (t, e) => {
  Tf.init(t, e), Ae(t, "values", (n) => n.def.innerType._zod.values), Ae(t, "pattern", (n) => n.def.innerType._zod.pattern), t._zod.parse = (n, r) => e.innerType._zod.run(n, r);
}), Pw = /* @__PURE__ */ F("$ZodNullable", (t, e) => {
  Ze.init(t, e), Ae(t, "optin", (n) => n.def.innerType._zod.optin), Ae(t, "optout", (n) => n.def.innerType._zod.optout), Ae(t, "pattern", (n) => {
    const r = n.def.innerType._zod.pattern;
    return r ? new RegExp(`^(${Rc(r.source)}|null)$`) : void 0;
  }), Ae(t, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), t._zod.parse = (n, r) => n.value === null ? n : e.innerType._zod.run(n, r);
}), Aw = /* @__PURE__ */ F("$ZodDefault", (t, e) => {
  Ze.init(t, e), t._zod.optin = "defaulted", Ae(t, "values", (n) => n.def.innerType._zod.values), t._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return e.innerType._zod.run(n, r);
    if (n.value === void 0)
      return n.value = e.defaultValue, n;
    const o = e.innerType._zod.run(n, r);
    return o instanceof Promise ? o.then((i) => Cd(i, e)) : Cd(o, e);
  };
});
function Cd(t, e) {
  return t.value === void 0 && (t.value = e.defaultValue), t;
}
const Ew = /* @__PURE__ */ F("$ZodPrefault", (t, e) => {
  Ze.init(t, e), t._zod.optin = "defaulted", Ae(t, "values", (n) => n.def.innerType._zod.values), t._zod.parse = (n, r) => (r.direction === "backward" || n.value === void 0 && (n.value = e.defaultValue), e.innerType._zod.run(n, r));
}), Sw = /* @__PURE__ */ F("$ZodNonOptional", (t, e) => {
  Ze.init(t, e), Ae(t, "values", (n) => {
    const r = n.def.innerType._zod.values;
    return r ? new Set([...r].filter((o) => o !== void 0)) : void 0;
  }), t._zod.parse = (n, r) => {
    const o = e.innerType._zod.run(n, r);
    return o instanceof Promise ? o.then((i) => Pd(i, t)) : Pd(o, t);
  };
});
function Pd(t, e) {
  return !t.issues.length && t.value === void 0 && t.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: t.value,
    inst: e
  }), t;
}
function Ad(t, e, n, r) {
  return e.issues.length ? (t.value = n.catchValue({
    ...e,
    value: t.value,
    error: {
      issues: e.issues.map((o) => Io(o, r, pr()))
    },
    input: t.value
  }), t) : (t.value = e.value, e.memo && (t.memo = !0), t);
}
const Dw = /* @__PURE__ */ F("$ZodCatch", (t, e) => {
  Ze.init(t, e), Ae(t, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), Ae(t, "optout", (n) => n.def.innerType._zod.optout), Ae(t, "values", (n) => n.def.innerType._zod.values), t._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return e.innerType._zod.run(n, r);
    const o = e.innerType._zod.run({ value: n.value, issues: [] }, r);
    return o instanceof Promise ? o.then((i) => Ad(n, i, e, r)) : Ad(n, o, e, r);
  };
}), Iw = /* @__PURE__ */ F("$ZodPipe", (t, e) => {
  Ze.init(t, e), Ae(t, "values", (n) => n.def.in._zod.values), Ae(t, "optin", (n) => n.def.in._zod.optin), Ae(t, "optout", (n) => n.def.out._zod.optout), Ae(t, "propValues", (n) => n.def.in._zod.propValues), t._zod.parse = (n, r) => {
    if (r.direction === "backward") {
      const i = e.out._zod.run(n, r);
      return i instanceof Promise ? i.then((a) => Ra(a, e.in, r)) : Ra(i, e.in, r);
    }
    const o = e.in._zod.run(n, r);
    return o instanceof Promise ? o.then((i) => Ra(i, e.out, r)) : Ra(o, e.out, r);
  };
});
function Ra(t, e, n) {
  return t.issues.some((r) => r.code !== "unrecognized_keys") ? (t.aborted = !0, t) : e._zod.run({ value: t.value, issues: t.issues }, n);
}
const zw = /* @__PURE__ */ F("$ZodReadonly", (t, e) => {
  Ze.init(t, e), Ae(t, "propValues", (n) => n.def.innerType._zod.propValues), Ae(t, "values", (n) => n.def.innerType._zod.values), Ae(t, "optin", (n) => {
    var r, o;
    return (o = (r = n.def.innerType) == null ? void 0 : r._zod) == null ? void 0 : o.optin;
  }), Ae(t, "optout", (n) => {
    var r, o;
    return (o = (r = n.def.innerType) == null ? void 0 : r._zod) == null ? void 0 : o.optout;
  }), t._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return e.innerType._zod.run(n, r);
    const o = e.innerType._zod.run(n, r);
    return o instanceof Promise ? o.then(Ed) : Ed(o);
  };
});
function Ed(t) {
  return t.memo || (t.value = Object.freeze(t.value)), t;
}
const Rw = /* @__PURE__ */ F("$ZodCustom", (t, e) => {
  Nt.init(t, e), Ze.init(t, e), t._zod.parse = (n, r) => n, t._zod.check = (n) => {
    const r = n.value, o = e.fn(r);
    if (o instanceof Promise)
      return o.then((i) => Sd(i, n, r, t));
    Sd(o, n, r, t);
  };
});
function Sd(t, e, n, r) {
  if (!t) {
    const o = {
      code: "custom",
      input: n,
      inst: r,
      // incorporates params.error into issue reporting
      path: [...r._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !r._zod.def.abort
      // params: inst._zod.def.params,
    };
    r._zod.def.params && (o.params = r._zod.def.params), e.issues.push(Ti(o));
  }
}
class xw extends Error {
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}
const ec = "~memo", Dd = [];
function Cf(t) {
  return t !== null && typeof t == "object";
}
function Ou(t) {
  return t.map((e) => e.path ? { ...e, path: e.path.slice() } : { ...e });
}
const Pf = /* @__PURE__ */ new WeakMap(), ti = 0, Ga = 1, di = 2;
function Fa(t, e, n) {
  const r = Pf.get(t);
  if (r !== void 0)
    return r ? di : ti;
  if (e.has(t))
    return di;
  e.add(t);
  let o = ti;
  const i = (m) => {
    if (o !== di && (m != null && m._zod)) {
      const p = Fa(m, e);
      p > o && (o = p);
    }
  }, a = (m, p) => {
    var k;
    let v = ti;
    for (const P of Reflect.ownKeys(m)) {
      const A = Object.getOwnPropertyDescriptor(m, P);
      if (!A.enumerable)
        continue;
      const S = A.get ? Ga : (k = A.value) != null && k._zod ? Fa(A.value, e) : ti;
      S > v && (v = S);
    }
    return v;
  }, c = (m) => {
    m > o && (o = m);
  }, l = t._zod.def;
  switch (l.type) {
    case "object": {
      const m = xc(l);
      c(m ? a(m) : Ga), i(l.catchall);
      break;
    }
    case "array":
      i(l.element);
      break;
    case "tuple":
      for (const m of l.items)
        i(m);
      i(l.rest);
      break;
    case "record":
    case "map":
      i(l.keyType), i(l.valueType);
      break;
    case "set":
      i(l.valueType);
      break;
    case "union":
      for (const m of l.options)
        i(m);
      break;
    case "intersection":
      i(l.left), i(l.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      i(l.innerType);
      break;
    case "pipe":
      i(l.in), i(l.out);
      break;
    case "function":
      i(l.input), i(l.output);
      break;
    // `$ZodLazy` caches its inner on the def, so a resolved edge is followed exactly
    case "lazy": {
      const m = l._cachedInner ?? void 0;
      c(m ? Fa(m, e) : Ga);
      break;
    }
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (const m in l) {
        const p = Object.getOwnPropertyDescriptor(l, m);
        if (!p || p.get)
          continue;
        const v = p.value;
        if (!(!v || typeof v != "object")) {
          if (v._zod)
            i(v);
          else if (Array.isArray(v))
            for (const k of v)
              i(k);
        }
      }
  }
  return e.delete(t), Ow(t, o);
}
function Ow(t, e) {
  return e !== Ga && Pf.set(t, e === di), e;
}
function Mw(t, e) {
  let n = t.buckets.get(e);
  return n || (n = /* @__PURE__ */ new WeakMap(), t.buckets.set(e, n)), n;
}
let xa;
const Oa = [], $w = {
  alloc(t, e, n) {
    const r = xa;
    if (!r)
      return n;
    xa = void 0;
    const o = { value: n, issues: null };
    return r.set(e.value, o), Oa.push(o), n;
  },
  guard(t) {
    var e;
    (e = t._zod).deferred ?? (e.deferred = []), t._zod.deferred.push(() => {
      const n = t._zod.parse, r = (o, i) => {
        if (i.direction !== "backward" && jw(i, o.value))
          throw new xw();
        return n(o, i);
      };
      t._zod.parse = r, t._zod.run === n && (t._zod.run = r);
    });
  },
  attach(t) {
    var e;
    let n, r = !1, o, i;
    (e = t._zod).deferred ?? (e.deferred = []), t._zod.deferred.push(() => {
      const a = t._zod.parse, c = (l, h) => {
        if (n === void 0) {
          const z = Fa(t, /* @__PURE__ */ new Set());
          if (z === ti)
            return t._zod.parse = a, t._zod.run === c && (t._zod.run = a), a(l, h);
          z === di || r ? n = !0 : r = !0;
        }
        const m = l.value;
        if (!Cf(m))
          return a(l, h);
        let p = h[ec];
        p || (p = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 }, h[ec] = p);
        let v;
        o === h ? v = i : (v = Mw(p, t), o = h, i = v);
        const k = v.get(m);
        if (k)
          return l.value = k.value, k.issues ? k.issues.length && l.issues.push(...Ou(k.issues)) : (l.memo = !0, p.backEdges ?? (p.backEdges = /* @__PURE__ */ new WeakSet()), p.backEdges.add(k.value)), l;
        xa = v;
        const P = Oa.length, A = a(l, h);
        xa = void 0;
        const S = Oa.length > P ? Oa.pop() : void 0;
        return A instanceof Promise ? A.then((z) => (S && (S.issues = z.issues.length ? Ou(z.issues) : Dd), z)) : (S && (S.issues = A.issues.length ? Ou(A.issues) : Dd), A);
      };
      t._zod.parse = c, t._zod.run === a && (t._zod.run = c);
    });
  }
};
function Nw() {
  return $w;
}
function jw(t, e) {
  var r;
  const n = (r = t[ec]) == null ? void 0 : r.backEdges;
  return n !== void 0 && Cf(e) && n.has(e);
}
const Lw = () => {
  const t = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function e(i) {
    return t[i] ?? null;
  }
  const n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    currency_code: "currency code",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  }, r = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function o(i, a) {
    return i === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : r[i] ?? i;
  }
  return (i) => {
    switch (i.code) {
      case "invalid_type": {
        const a = o(i.expected), c = ly(i.input), l = o(c, i.input);
        return `Invalid input: expected ${a}, received ${l}`;
      }
      case "invalid_value":
        return i.values.length === 1 ? `Invalid input: expected ${Jh(i.values[0])}` : `Invalid option: expected one of ${hd(i.values, "|")}`;
      case "too_big": {
        const a = i.exact ? "exactly " : i.inclusive ? "<=" : "<", c = e(i.origin);
        return c ? `Too big: expected ${i.origin ?? "value"} to have ${a}${i.maximum.toString()} ${c.unit ?? "elements"}` : `Too big: expected ${i.origin ?? "value"} to be ${a}${i.maximum.toString()}`;
      }
      case "too_small": {
        const a = i.exact ? "exactly " : i.inclusive ? ">=" : ">", c = e(i.origin);
        return c ? `Too small: expected ${i.origin} to have ${a}${i.minimum.toString()} ${c.unit}` : `Too small: expected ${i.origin} to be ${a}${i.minimum.toString()}`;
      }
      case "invalid_format": {
        const a = i;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${n[a.format] ?? i.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${i.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${i.keys.length > 1 ? "s" : ""}: ${hd(i.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${i.origin}`;
      case "invalid_union":
        return i.options && Array.isArray(i.options) && i.options.length > 0 ? `Invalid discriminator value. Expected ${i.options.map((c) => `'${c}'`).join(" | ")}` : i.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${i.origin}`;
      default:
        return "Invalid input";
    }
  };
};
function Gw() {
  return {
    localeError: Lw()
  };
}
var Id;
class Fw {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(e, ...n) {
    const r = n[0];
    return this._map.set(e, r), r && typeof r == "object" && "id" in r && this._idmap.set(r.id, e), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(e) {
    const n = this._map.get(e);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(e), this;
  }
  get(e) {
    const n = e._zod.parent;
    if (n) {
      const r = { ...this.get(n) ?? {} };
      delete r.id;
      const o = { ...r, ...this._map.get(e) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(e);
  }
  has(e) {
    return this._map.has(e);
  }
}
function Uw() {
  return new Fw();
}
(Id = globalThis).__zod_globalRegistry ?? (Id.__zod_globalRegistry = Uw());
const ni = globalThis.__zod_globalRegistry;
function Af(t) {
  return t.checks && (t.checks = [...t.checks]), t;
}
// @__NO_SIDE_EFFECTS__
function Zw(t, e) {
  return new t(Af({ type: "string", ...ne(e) }));
}
// @__NO_SIDE_EFFECTS__
function qw(t, e) {
  return new t({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Kw(t, e) {
  return new t({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Ww(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Yw(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Vw(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Bw(t, e) {
  return new t({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Hw(t, e) {
  return new t({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Qw(t, e) {
  return new t({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Xw(t, e) {
  return new t({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Jw(t, e) {
  return new t({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function e0(t, e) {
  return new t({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function t0(t, e) {
  return new t({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function n0(t, e) {
  return new t({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function r0(t, e) {
  return new t({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function o0(t, e) {
  return new t({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function i0(t, e) {
  return new t({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function a0(t, e) {
  return new t({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function s0(t, e) {
  return new t({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function u0(t, e) {
  return new t({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function c0(t, e) {
  return new t({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function l0(t, e) {
  return new t({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function d0(t, e) {
  return new t({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Ef(t, e) {
  return new t({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Sf(t, e) {
  return new t({
    type: "string",
    format: "date",
    check: "string_format",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function h0(t, e) {
  return new t({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function f0(t, e) {
  return new t({
    type: "string",
    format: "duration",
    check: "string_format",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function m0(t, e) {
  return new t(Af({ type: "number", checks: [], ...ne(e) }));
}
// @__NO_SIDE_EFFECTS__
function p0(t, e) {
  return new t({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function g0(t, e) {
  return new t({
    type: "boolean",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function v0(t) {
  return new t({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function y0(t, e) {
  return new t({
    type: "never",
    ...ne(e)
  });
}
// @__NO_SIDE_EFFECTS__
function zd(t, e) {
  return new lf({
    check: "less_than",
    ...ne(e),
    value: t,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Mu(t, e) {
  return new lf({
    check: "less_than",
    ...ne(e),
    value: t,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function Rd(t, e) {
  return new df({
    check: "greater_than",
    ...ne(e),
    value: t,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function $u(t, e) {
  return new df({
    check: "greater_than",
    ...ne(e),
    value: t,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function xd(t, e) {
  return new pb({
    check: "multiple_of",
    ...ne(e),
    value: t
  });
}
// @__NO_SIDE_EFFECTS__
function Df(t, e) {
  return new vb({
    check: "max_length",
    ...ne(e),
    maximum: t
  });
}
// @__NO_SIDE_EFFECTS__
function Ha(t, e) {
  return new yb({
    check: "min_length",
    ...ne(e),
    minimum: t
  });
}
// @__NO_SIDE_EFFECTS__
function If(t, e) {
  return new bb({
    check: "length_equals",
    ...ne(e),
    length: t
  });
}
// @__NO_SIDE_EFFECTS__
function b0(t, e) {
  return new wb({
    check: "string_format",
    format: "regex",
    ...ne(e),
    pattern: t
  });
}
// @__NO_SIDE_EFFECTS__
function w0(t) {
  return new kb({
    check: "string_format",
    format: "lowercase",
    ...ne(t)
  });
}
// @__NO_SIDE_EFFECTS__
function k0(t) {
  return new _b({
    check: "string_format",
    format: "uppercase",
    ...ne(t)
  });
}
// @__NO_SIDE_EFFECTS__
function _0(t, e) {
  return new Tb({
    check: "string_format",
    format: "includes",
    ...ne(e),
    includes: t
  });
}
// @__NO_SIDE_EFFECTS__
function T0(t, e) {
  return new Cb({
    check: "string_format",
    format: "starts_with",
    ...ne(e),
    prefix: t
  });
}
// @__NO_SIDE_EFFECTS__
function C0(t, e) {
  return new Pb({
    check: "string_format",
    format: "ends_with",
    ...ne(e),
    suffix: t
  });
}
// @__NO_SIDE_EFFECTS__
function zo(t) {
  return new Ab({
    check: "overwrite",
    tx: t
  });
}
// @__NO_SIDE_EFFECTS__
function P0(t) {
  return /* @__PURE__ */ zo((e) => e.normalize(t));
}
// @__NO_SIDE_EFFECTS__
function A0() {
  return /* @__PURE__ */ zo((t) => t.trim());
}
// @__NO_SIDE_EFFECTS__
function E0() {
  return /* @__PURE__ */ zo((t) => t.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function S0() {
  return /* @__PURE__ */ zo((t) => t.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function D0() {
  return /* @__PURE__ */ zo((t) => Qv(t));
}
// @__NO_SIDE_EFFECTS__
function I0(t, e, n) {
  return new t({
    type: "array",
    element: e,
    // get element() {
    //   return element;
    // },
    ...ne(n)
  });
}
// @__NO_SIDE_EFFECTS__
function z0(t, e, n) {
  return new t({
    type: "custom",
    check: "custom",
    fn: e,
    ...ne(n)
  });
}
// @__NO_SIDE_EFFECTS__
function R0(t, e) {
  const n = /* @__PURE__ */ x0((r) => (r.addIssue = (o) => {
    if (typeof o == "string")
      r.issues.push(Ti(o, r.value, n._zod.def));
    else {
      const i = o;
      i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), "input" in i || (i.input = r.value), i.inst ?? (i.inst = n), i.continue ?? (i.continue = !n._zod.def.abort), r.issues.push(Ti(i));
    }
  }, t(r.value, r)), e);
  return n;
}
// @__NO_SIDE_EFFECTS__
function x0(t, e) {
  const n = new Nt({
    check: "custom",
    ...ne(e)
  });
  return n._zod.check = t, n;
}
function hi(t, ...e) {
  for (const n of e)
    for (const r of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, r) && Cn(t, r, n[r]);
  return t;
}
function Qa(t) {
  let e = (t == null ? void 0 : t.target) ?? "draft-2020-12";
  return e === "draft-4" && (e = "draft-04"), e === "draft-7" && (e = "draft-07"), {
    processors: t.processors ?? {},
    metadataRegistry: (t == null ? void 0 : t.metadata) ?? ni,
    target: e,
    unrepresentable: (t == null ? void 0 : t.unrepresentable) ?? "throw",
    override: (t == null ? void 0 : t.override) ?? (() => {
    }),
    io: (t == null ? void 0 : t.io) ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: (t == null ? void 0 : t.cycles) ?? "ref",
    reused: (t == null ? void 0 : t.reused) ?? "inline",
    intersections: [],
    deferred: [],
    external: (t == null ? void 0 : t.external) ?? void 0
  };
}
function ot(t, e, n, r, o) {
  const i = typeof e.unrepresentable == "function" ? e.unrepresentable({ zodSchema: t, path: r.path, message: o }) : e.unrepresentable;
  if (i === "any")
    return !1;
  if (i === void 0 || i === "throw")
    throw new Error(o);
  return Object.assign(n, i), !0;
}
function Re(t, e, n = { path: [], schemaPath: [] }) {
  var m, p;
  var r;
  const o = t._zod.def, i = e.seen.get(t);
  if (i)
    return i.count++, n.schemaPath.includes(t) && (i.cycle = n.path), i.schema;
  const a = { schema: {}, count: 1, cycle: void 0, path: n.path };
  e.seen.set(t, a), e.sharedDefsExtractedFor = void 0, e.sharedEmitDoneFor = void 0;
  const c = (p = (m = t._zod).toJSONSchema) == null ? void 0 : p.call(m);
  if (c)
    a.schema = c;
  else {
    const v = {
      ...n,
      schemaPath: [...n.schemaPath, t],
      path: n.path
    };
    if (t._zod.processJSONSchema)
      t._zod.processJSONSchema(e, a.schema, v);
    else {
      const P = a.schema, A = e.processors[o.type];
      if (!A)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
      A(t, e, P, v);
    }
    const k = t._zod.parent;
    k && (a.ref || (a.ref = k), Re(k, e, v), e.seen.get(k).isParent = !0);
  }
  const l = e.metadataRegistry.get(t);
  return l && hi(a.schema, l), e.io === "input" && pt(t) && (delete a.schema.examples, delete a.schema.default), e.io === "input" && "_prefault" in a.schema && ((r = a.schema).default ?? (r.default = a.schema._prefault)), delete a.schema._prefault, e.seen.get(t).schema;
}
function Od(t) {
  return t.replace(/~/g, "~0").replace(/\//g, "~1");
}
function Xa(t, e) {
  var a, c, l, h;
  const n = t.seen.get(e);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (t.external && t.sharedDefsExtractedFor === t.external)
    return;
  const r = /* @__PURE__ */ new Map();
  for (const m of t.seen.entries()) {
    const p = (a = t.metadataRegistry.get(m[0])) == null ? void 0 : a.id;
    if (p) {
      const v = r.get(p);
      if (v && v !== m[0])
        throw new Error(`Duplicate schema id "${p}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      r.set(p, m[0]);
    }
  }
  const o = (m) => {
    var A;
    const p = t.target === "draft-2020-12" ? "$defs" : "definitions";
    if (t.external) {
      const S = (A = t.external.registry.get(m[0])) == null ? void 0 : A.id, z = t.external.uri ?? ((W) => W);
      if (S)
        return { ref: z(S) };
      const L = m[1].defId ?? m[1].schema.id ?? `schema${t.counter++}`;
      return m[1].defId = L, { defId: L, ref: `${z("__shared")}#/${p}/${Od(L)}` };
    }
    const v = "#", k = `${v}/${p}/`;
    if (m[1] === n && !m[1].schema.id)
      return { ref: v };
    const P = m[1].schema.id ?? `__schema${t.counter++}`;
    return { defId: P, ref: k + Od(P) };
  }, i = (m) => {
    if (m[1].schema.$ref)
      return;
    const p = m[1], { ref: v, defId: k } = o(m);
    p.def = { ...p.schema }, k && (p.defId = k);
    const P = p.schema;
    for (const A in P)
      delete P[A];
    P.$ref = v;
  };
  if (t.cycles === "throw")
    for (const m of t.seen.entries()) {
      const p = m[1];
      if (p.cycle)
        throw new Error(`Cycle detected: #/${(c = p.cycle) == null ? void 0 : c.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const m of t.seen.entries()) {
    const p = m[1];
    if (e === m[0]) {
      i(m);
      continue;
    }
    if (t.external) {
      const k = (l = t.external.registry.get(m[0])) == null ? void 0 : l.id;
      if (e !== m[0] && k) {
        i(m);
        continue;
      }
    }
    if ((h = t.metadataRegistry.get(m[0])) == null ? void 0 : h.id) {
      i(m);
      continue;
    }
    if (p.cycle) {
      i(m);
      continue;
    }
    p.count > 1 && t.reused === "ref" && i(m);
  }
  t.external && (t.sharedDefsExtractedFor = t.external);
}
function zf(t) {
  const e = t.anyOf;
  if (!Array.isArray(e) || e.length === 0 || t.type !== void 0)
    return;
  const n = [];
  for (const r of e) {
    if (!r || typeof r != "object")
      return;
    zf(r);
    const o = Object.keys(r);
    if (o.length !== 1 || o[0] !== "type")
      return;
    const i = r.type;
    for (const a of Array.isArray(i) ? i : [i]) {
      if (typeof a != "string")
        return;
      n.includes(a) || n.push(a);
    }
  }
  delete t.anyOf, t.type = n.length === 1 ? n[0] : n;
}
const Rf = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Md = ["oneOf", "anyOf"];
function $d(t) {
  const e = t.additionalProperties;
  return e === void 0 || e === !1 || typeof e != "object" || e === null ? null : Object.keys(e).length ? e : null;
}
function tc(t) {
  var i;
  const e = [];
  for (const a of t) {
    if (typeof a != "object" || a.type !== "object")
      return null;
    for (const c in a)
      if (!Rf.has(c))
        return null;
    e.push(a);
  }
  const n = {}, r = /* @__PURE__ */ new Set();
  for (const a of e) {
    for (const c in a.properties) {
      if (Object.prototype.hasOwnProperty.call(n, c))
        continue;
      const l = [];
      for (const m of e) {
        const p = ((i = m.properties) == null ? void 0 : i[c]) ?? $d(m);
        p != null && (l.some((v) => JSON.stringify(v) === JSON.stringify(p)) || l.push(p));
      }
      const h = l.length === 1 ? l[0] : tc(l) ?? { allOf: l };
      Cn(n, c, h);
    }
    for (const c of a.required ?? [])
      r.add(c);
  }
  const o = { type: "object", properties: n };
  if (r.size && (o.required = [...r]), e.every((a) => a.additionalProperties === !1))
    o.additionalProperties = !1;
  else {
    const a = [];
    for (const c of e) {
      const l = $d(c);
      l && !a.some((h) => JSON.stringify(h) === JSON.stringify(l)) && a.push(l);
    }
    a.length === 1 ? o.additionalProperties = a[0] : a.length > 1 && (o.additionalProperties = { allOf: a });
  }
  return o;
}
function O0(t) {
  const e = t.allOf;
  if (!Array.isArray(e) || e.length < 2)
    return;
  for (const o of Rf)
    if (o in t)
      return;
  const n = e.filter((o) => Md.some((i) => Array.isArray(o[i])));
  let r = null;
  if (!n.length)
    r = tc(e);
  else {
    const o = n[0], i = Md.find((l) => Array.isArray(o[l]));
    if (Object.keys(o).length !== 1)
      return;
    const a = e.filter((l) => l !== o), c = o[i].map((l) => tc([...a, l]));
    if (c.some((l) => !l))
      return;
    r = { [i]: c };
  }
  r && (delete t.allOf, hi(t, r));
}
function Ja(t, e) {
  var c, l, h, m;
  const n = t.seen.get(e);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const r = (p) => {
    const v = t.seen.get(p);
    if (v.ref === null)
      return;
    const k = v.def ?? v.schema, P = { ...k }, A = v.ref;
    if (v.ref = null, A) {
      r(A);
      const z = t.seen.get(A), L = z.schema;
      if (L.$ref && (t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0") ? (k.allOf = k.allOf ?? [], k.allOf.push(L)) : hi(k, L), hi(k, P), p._zod.parent === A)
        for (const H in k)
          H === "$ref" || H === "allOf" || H in P || delete k[H];
      if (L.$ref && z.def)
        for (const H in k)
          H === "$ref" || H === "allOf" || H in z.def && JSON.stringify(k[H]) === JSON.stringify(z.def[H]) && delete k[H];
    }
    const S = p._zod.parent;
    if (S && S !== A) {
      r(S);
      const z = t.seen.get(S);
      if (z != null && z.schema.$ref && (k.$ref = z.schema.$ref, z.def))
        for (const L in k)
          L === "$ref" || L === "allOf" || L in z.def && JSON.stringify(k[L]) === JSON.stringify(z.def[L]) && delete k[L];
    }
    t.override({
      zodSchema: p,
      jsonSchema: k,
      path: v.path ?? []
    });
  };
  if (!t.external || t.sharedEmitDoneFor !== t.external) {
    for (const p of [...t.seen.entries()].reverse())
      r(p[0]);
    if (t.target !== "openapi-3.0")
      for (const p of t.seen.entries())
        zf(p[1].def ?? p[1].schema);
    for (const p of t.deferred)
      p();
    if (t.intersections.length) {
      const p = /* @__PURE__ */ new Map();
      for (const v of t.seen.values())
        for (const k of [v.schema, v.def]) {
          const P = k == null ? void 0 : k.allOf;
          if (!Array.isArray(P))
            continue;
          const A = p.get(P);
          A ? A.push(k) : p.set(P, [k]);
        }
      for (const v of t.intersections)
        for (const k of p.get(v) ?? [])
          O0(k);
    }
  }
  const o = {};
  if (t.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : t.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : t.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : t.target, (c = t.external) != null && c.uri) {
    const p = (l = t.external.registry.get(e)) == null ? void 0 : l.id;
    if (!p)
      throw new Error("Schema is missing an `id` property");
    o.$id = t.external.uri(p);
  }
  hi(o, n.defId ? n.schema : n.def ?? n.schema);
  const i = (h = t.metadataRegistry.get(e)) == null ? void 0 : h.id;
  i !== void 0 && o.id === i && delete o.id;
  const a = ((m = t.external) == null ? void 0 : m.defs) ?? {};
  if (!t.external || t.sharedEmitDoneFor !== t.external)
    for (const p of t.seen.entries()) {
      const v = p[1];
      v.def && v.defId && (v.def.id === v.defId && delete v.def.id, Cn(a, v.defId, v.def));
    }
  t.external && (t.sharedEmitDoneFor = t.external), t.external || Object.keys(a).length > 0 && (t.target === "draft-2020-12" ? o.$defs = a : o.definitions = a);
  try {
    const p = JSON.parse(JSON.stringify(o));
    return Object.defineProperty(p, "~standard", {
      value: {
        ...e["~standard"],
        jsonSchema: {
          input: es(e, "input", t.processors),
          output: es(e, "output", t.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), p;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function pt(t, e) {
  const n = e ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(t))
    return !1;
  n.seen.add(t);
  const r = t._zod.def;
  if (r.type === "transform")
    return !0;
  if (r.type === "array")
    return pt(r.element, n);
  if (r.type === "set")
    return pt(r.valueType, n);
  if (r.type === "lazy")
    return pt(r.getter(), n);
  if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch")
    return pt(r.innerType, n);
  if (r.type === "intersection")
    return pt(r.left, n) || pt(r.right, n);
  if (r.type === "record" || r.type === "map")
    return pt(r.keyType, n) || pt(r.valueType, n);
  if (r.type === "pipe")
    return t._zod.traits.has("$ZodCodec") ? !0 : pt(r.in, n) || pt(r.out, n);
  if (r.type === "object") {
    for (const o in r.shape)
      if (pt(r.shape[o], n))
        return !0;
    return !1;
  }
  if (r.type === "union") {
    for (const o of r.options)
      if (pt(o, n))
        return !0;
    return !1;
  }
  if (r.type === "tuple") {
    for (const o of r.items)
      if (pt(o, n))
        return !0;
    return !!(r.rest && pt(r.rest, n));
  }
  return !1;
}
const M0 = (t, e = {}) => (n) => {
  const r = Qa({ ...n, processors: e });
  return Re(t, r), Xa(r, t), Ja(r, t);
}, es = (t, e, n = {}) => (r) => {
  const { libraryOptions: o, target: i } = r ?? {}, a = Qa({ ...o ?? {}, target: i, io: e, processors: n });
  return Re(t, a), Xa(a, t), Ja(a, t);
}, yo = (t, e, n) => {
  (t[e] === void 0 || n > t[e]) && (t[e] = n);
}, bo = (t, e, n) => {
  (t[e] === void 0 || n < t[e]) && (t[e] = n);
}, Nd = (t, e) => {
  yo(t, "minimum", e), bo(t, "maximum", e);
}, xf = (t, e) => {
  t.multipleOf ?? (t.multipleOf = []), t.multipleOf.includes(e) || t.multipleOf.push(e);
}, Of = (t, e) => {
  t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(e);
}, Mf = (t, e) => {
  t.mime = t.mime ? t.mime.filter((n) => e.includes(n)) : [...e];
}, $f = (t, e) => {
  t.format = e, e.includes("int") && (t.isInt = !0);
}, jd = (t, e) => yo(t, "minimum", e.minimum), Ld = (t, e) => bo(t, "maximum", e.maximum), Gd = (t) => (e, n) => {
  $f(e, n.format);
  const [r, o] = t[n.format];
  yo(e, "minimum", r), bo(e, "maximum", o);
}, Nu = {
  greater_than: (t, e) => yo(t, e.inclusive ? "minimum" : "exclusiveMinimum", e.value),
  less_than: (t, e) => bo(t, e.inclusive ? "maximum" : "exclusiveMaximum", e.value),
  multiple_of: (t, e) => xf(t, e.value),
  number_format: Gd(ef),
  bigint_format: Gd(ty),
  min_length: jd,
  max_length: Ld,
  length_equals: (t, e) => Nd(t, e.length),
  min_size: jd,
  max_size: Ld,
  size_equals: (t, e) => Nd(t, e.size),
  string_format: (t, e) => {
    $f(t, e.format), e.pattern && Of(t, e.pattern), (e.format === "base64" || e.format === "base64url") && (t.contentEncoding = e.format), (e.local || e.precision === -1) && (t.laxFormat = !0);
  },
  mime_type: (t, e) => Mf(t, e.mime)
};
function Zt(t) {
  var i;
  const e = {}, n = t._zod.def, r = t._zod.traits.has("$ZodCheck") ? [t, ...n.checks ?? []] : n.checks ?? [];
  for (const a of r)
    (i = Nu[a._zod.def.check]) == null || i.call(Nu, e, a._zod.def);
  const o = t._zod.bag;
  o.minimum !== void 0 && yo(e, "minimum", o.minimum), o.exclusiveMinimum !== void 0 && yo(e, "exclusiveMinimum", o.exclusiveMinimum), o.maximum !== void 0 && bo(e, "maximum", o.maximum), o.exclusiveMaximum !== void 0 && bo(e, "exclusiveMaximum", o.exclusiveMaximum), o.multipleOf !== void 0 && xf(e, o.multipleOf), o.format !== void 0 && (e.format ?? (e.format = o.format), o.format.includes("int") && (e.isInt = !0)), o.mime && Mf(e, o.mime);
  for (const a of o.patterns ?? [])
    Of(e, a);
  return e;
}
const $0 = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, N0 = /* @__PURE__ */ new Map([
  [yf, nb],
  [Uc, rb]
]), Nf = (t) => N0.get(t) ?? t, jf = (t, e, n, r) => {
  const o = n;
  o.type = "string";
  const { minimum: i, maximum: a, format: c, patterns: l, contentEncoding: h, laxFormat: m } = Zt(t);
  if (typeof i == "number" && (o.minLength = i), typeof a == "number" && (o.maxLength = a), c && (o.format = $0[c] ?? c, o.format === "" && delete o.format, (c === "time" || m) && delete o.format), h && (o.contentEncoding = h), l && l.size > 0) {
    const p = [...l].map(Nf);
    p.length === 1 ? o.pattern = p[0].source : p.length > 1 && (o.allOf = [
      ...p.map((v) => ({
        ...e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: v.source
      }))
    ]);
  }
}, Lf = (t, e, n, r) => {
  const o = n, { minimum: i, maximum: a, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: h, isInt: m } = Zt(t);
  o.type = m ? "integer" : "number";
  const p = typeof h == "number" && h >= (i ?? Number.NEGATIVE_INFINITY), v = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), k = e.target === "draft-04" || e.target === "openapi-3.0";
  if (p ? k ? (o.minimum = h, o.exclusiveMinimum = !0) : o.exclusiveMinimum = h : typeof i == "number" && (o.minimum = i), v ? k ? (o.maximum = l, o.exclusiveMaximum = !0) : o.exclusiveMaximum = l : typeof a == "number" && (o.maximum = a), c) {
    const P = /* @__PURE__ */ new Set();
    for (const z of c)
      Number.isFinite(z) && z !== 0 ? P.add(Math.abs(z)) : ot(t, e, o, r, `A multipleOf divisor of ${z} cannot be represented in JSON Schema`);
    const [A, ...S] = P;
    A !== void 0 && (o.multipleOf = A), S.length && (o.allOf = [...o.allOf ?? [], ...S.map((z) => ({ multipleOf: z }))]);
  }
}, Gf = (t, e, n, r) => {
  n.type = "boolean";
}, j0 = (t, e, n, r) => {
  ot(t, e, n, r, "BigInt cannot be represented in JSON Schema");
}, L0 = (t, e, n, r) => {
  ot(t, e, n, r, "Symbols cannot be represented in JSON Schema");
}, G0 = (t, e, n, r) => {
  e.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, F0 = (t, e, n, r) => {
  ot(t, e, n, r, "Undefined cannot be represented in JSON Schema");
}, U0 = (t, e, n, r) => {
  ot(t, e, n, r, "Void cannot be represented in JSON Schema");
}, Ff = (t, e, n, r) => {
  n.not = {};
}, Z0 = (t, e, n, r) => {
}, Uf = (t, e, n, r) => {
}, q0 = (t, e, n, r) => {
  ot(t, e, n, r, "Date cannot be represented in JSON Schema");
}, Zf = (t, e, n, r) => {
  const o = t._zod.def, i = Bu(o.entries);
  if (i.length === 0) {
    n.not = {};
    return;
  }
  i.every((a) => typeof a == "number") && (n.type = "number"), i.every((a) => typeof a == "string") && (n.type = "string"), n.enum = i;
}, qf = (t, e, n, r) => {
  const o = t._zod.def;
  if (o.values.length === 0) {
    n.not = {};
    return;
  }
  const i = [];
  for (const a of o.values)
    if (a === void 0) {
      if (ot(t, e, n, r, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (ot(t, e, n, r, "BigInt literals cannot be represented in JSON Schema"))
        return;
      i.push(Number(a));
    } else
      i.push(a);
  if (i.length !== 0) if (i.length === 1) {
    const a = i[0];
    n.type = a === null ? "null" : typeof a, e.target === "draft-04" || e.target === "openapi-3.0" ? n.enum = [a] : n.const = a;
  } else
    i.every((a) => typeof a == "number") && (n.type = "number"), i.every((a) => typeof a == "string") && (n.type = "string"), i.every((a) => typeof a == "boolean") && (n.type = "boolean"), i.every((a) => a === null) && (n.type = "null"), n.enum = i;
}, K0 = (t, e, n, r) => {
  ot(t, e, n, r, "NaN cannot be represented in JSON Schema");
}, W0 = (t, e, n, r) => {
  const o = n, i = t._zod.pattern;
  if (!i)
    throw new Error("Pattern not found in template literal");
  o.type = "string", o.pattern = i.source;
}, Y0 = (t, e, n, r) => {
  const o = n;
  o.type = "string", o.format = "binary", o.contentEncoding = "binary";
  const { minimum: i, maximum: a, mime: c } = Zt(t);
  i !== void 0 && (o.minLength = i), a !== void 0 && (o.maxLength = a), c && (c.length === 0 ? o.not = {} : c.length === 1 ? o.contentMediaType = c[0] : o.anyOf = c.map((l) => ({ contentMediaType: l })));
}, V0 = (t, e, n, r) => {
  n.type = "boolean";
}, Kf = (t, e, n, r) => {
  ot(t, e, n, r, "Custom types cannot be represented in JSON Schema");
}, B0 = (t, e, n, r) => {
  ot(t, e, n, r, "Function types cannot be represented in JSON Schema");
}, Wf = (t, e, n, r) => {
  ot(t, e, n, r, "Transforms cannot be represented in JSON Schema");
}, H0 = (t, e, n, r) => {
  ot(t, e, n, r, "Map cannot be represented in JSON Schema");
}, Q0 = (t, e, n, r) => {
  ot(t, e, n, r, "Set cannot be represented in JSON Schema");
}, Yf = (t, e, n, r) => {
  const o = n, i = t._zod.def, { minimum: a, maximum: c } = Zt(t);
  typeof a == "number" && (o.minItems = a), typeof c == "number" && (o.maxItems = c), o.type = "array", o.items = Re(i.element, e, {
    ...r,
    path: [...r.path, "items"]
  });
};
function Ci(t) {
  const e = t._zod.def;
  return e.type === "pipe" && e.in._zod.traits.has("$ZodTransform") ? Ci(e.out) : e.type === "catch" ? Ci(e.innerType) : t._zod.optin;
}
const Vf = (t, e, n, r) => {
  var h;
  const o = n, i = t._zod.def, a = i.shape;
  if (Object.getOwnPropertySymbols(a).length && ot(t, e, o, r, "Symbol keys cannot be represented in JSON Schema"))
    return;
  o.type = "object", o.properties = {};
  for (const m in a)
    Cn(o.properties, m, Re(a[m], e, {
      ...r,
      path: [...r.path, "properties", m]
    }));
  const l = [];
  for (const m of Object.keys(a)) {
    const p = i.shape[m];
    (e.io === "input" ? Ci(p) === void 0 : p._zod.optout === void 0) && l.push(m);
  }
  l.length > 0 && (o.required = l), ((h = i.catchall) == null ? void 0 : h._zod.def.type) === "never" ? o.additionalProperties = !1 : i.catchall ? i.catchall && (o.additionalProperties = Re(i.catchall, e, {
    ...r,
    path: [...r.path, "additionalProperties"]
  })) : e.io === "output" && (o.additionalProperties = !1);
}, Bf = (t, e, n, r) => {
  const o = t._zod.def, i = o.inclusive === !1, a = o.options.map((c, l) => Re(c, e, {
    ...r,
    path: [...r.path, i ? "oneOf" : "anyOf", l]
  }));
  i ? n.oneOf = a : n.anyOf = a;
}, Hf = (t, e, n, r) => {
  const o = t._zod.def, i = Re(o.left, e, {
    ...r,
    path: [...r.path, "allOf", 0]
  }), a = Re(o.right, e, {
    ...r,
    path: [...r.path, "allOf", 1]
  }), c = (h) => "allOf" in h && Object.keys(h).length === 1, l = [
    ...c(i) ? i.allOf : [i],
    ...c(a) ? a.allOf : [a]
  ];
  n.allOf = l, e.intersections.push(l);
}, X0 = (t, e, n, r) => {
  const o = n, i = t._zod.def;
  o.type = "array";
  const a = e.target === "draft-2020-12" ? "prefixItems" : "items", c = e.target === "draft-2020-12" || e.target === "openapi-3.0" ? "items" : "additionalItems", l = i.items.map((A, S) => Re(A, e, {
    ...r,
    path: [...r.path, a, S]
  })), h = i.rest ? Re(i.rest, e, {
    ...r,
    path: [...r.path, c, ...e.target === "openapi-3.0" ? [i.items.length] : []]
  }) : null;
  let m = i.items.length;
  for (; m > 0; ) {
    const A = i.items[m - 1];
    if (!(e.io === "input" ? Ci(A) !== void 0 : A._zod.optout === "optional"))
      break;
    m--;
  }
  const p = i.items.length, v = !i.rest;
  e.target === "draft-2020-12" ? (o.prefixItems = l, v ? o.items = !1 : h && (o.items = h), m > 0 && (o.minItems = m), v && (o.maxItems = p)) : e.target === "openapi-3.0" ? (o.items = {
    anyOf: l
  }, h && o.items.anyOf.push(h), m > 0 && (o.minItems = m), v && (o.maxItems = p)) : (o.items = l, v ? o.additionalItems = !1 : h && (o.additionalItems = h), m > 0 && (o.minItems = m), v && (o.maxItems = p));
  const { minimum: k, maximum: P } = Zt(t);
  typeof k == "number" && (o.minItems = k), typeof P == "number" && (o.maxItems = P);
};
function nc(t, e, n) {
  var P;
  if (e.$ref) {
    if (n.has(e))
      return e;
    n.add(e);
    const A = (P = t.get(e)) == null ? void 0 : P.def;
    if (!A)
      return e;
    const S = nc(t, A, n);
    return S === A ? e : S;
  }
  for (const A of ["anyOf", "oneOf"]) {
    const S = e[A];
    if (!Array.isArray(S))
      continue;
    const z = S.map((L) => nc(t, L, n));
    z.some((L, W) => L !== S[W]) && (e = { ...e, [A]: z });
  }
  const r = Array.isArray(e.type) ? e.type : [e.type], o = !r.includes("string") && r.some((A) => A === "number" || A === "integer"), i = e.enum ?? (e.const !== void 0 ? [e.const] : void 0);
  if (!o && !(i != null && i.some((A) => typeof A == "number")))
    return e;
  const { minimum: a, maximum: c, exclusiveMinimum: l, exclusiveMaximum: h, multipleOf: m, format: p, id: v, ...k } = e;
  return k.enum ? k.enum = k.enum.map((A) => typeof A == "number" ? String(A) : A) : typeof k.const == "number" && (k.const = String(k.const)), o && (k.type = "string", i || (k.pattern = (r.includes("number") ? cf : db).source)), k;
}
const rc = /* @__PURE__ */ new WeakMap();
function J0(t) {
  var r;
  const e = /* @__PURE__ */ new Map();
  for (const o of t.seen.values())
    o.def && !e.has(o.schema) && e.set(o.schema, o);
  const n = /* @__PURE__ */ new Map();
  for (const o of rc.get(t) ?? []) {
    const i = t.seen.get(o), a = (r = (i == null ? void 0 : i.def) ?? (i == null ? void 0 : i.schema)) == null ? void 0 : r.propertyNames;
    if (!a || a === !0 || n.has(a))
      continue;
    const c = nc(e, a, /* @__PURE__ */ new Set());
    c !== a && n.set(a, c);
  }
  if (n.size)
    for (const o of t.seen.values())
      for (const i of [o.schema, o.def]) {
        const a = i && n.get(i.propertyNames);
        a && (i.propertyNames = a);
      }
}
const ek = (t, e, n, r) => {
  const o = n, i = t._zod.def;
  o.type = "object";
  const a = i.keyType, c = Zt(a).patterns;
  if (i.mode === "loose" && c && c.size > 0) {
    const m = Re(i.valueType, e, {
      ...r,
      path: [...r.path, "patternProperties", "*"]
    });
    o.patternProperties = {};
    for (const p of c)
      Cn(o.patternProperties, Nf(p).source, m);
  } else {
    if (e.target === "draft-07" || e.target === "draft-2020-12") {
      o.propertyNames = Re(i.keyType, e, {
        ...r,
        path: [...r.path, "propertyNames"]
      });
      let m = rc.get(e);
      m || (m = [], rc.set(e, m), e.deferred.push(() => J0(e))), m.push(t);
    }
    o.additionalProperties = Re(i.valueType, e, {
      ...r,
      path: [...r.path, "additionalProperties"]
    });
  }
  const l = a._zod.values, h = e.io === "input" && Ci(i.valueType) !== void 0;
  if (l && !i.partial && !h) {
    const m = [...l].filter((p) => typeof p == "string" || typeof p == "number");
    m.length > 0 && (o.required = m.map(String));
  }
}, Qf = (t, e, n, r) => {
  const o = t._zod.def, i = Re(o.innerType, e, r), a = e.seen.get(t);
  e.target === "openapi-3.0" ? (a.ref = o.innerType, n.nullable = !0) : n.anyOf = [i, { type: "null" }];
}, Xf = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  i.ref = o.innerType;
}, Zc = Symbol();
function Jf(t, e, n, r, o) {
  let i = !1;
  const a = JSON.stringify(t, (c, l) => typeof l != "bigint" ? l : (i = !0, null));
  return i ? (ot(e, n, r, o, "BigInt defaults cannot be represented in JSON Schema"), Zc) : JSON.parse(a);
}
const em = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  i.ref = o.innerType;
  const a = Jf(o.defaultValue, t, e, n, r);
  a !== Zc && (n.default = a);
}, tm = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  if (i.ref = o.innerType, e.io !== "input")
    return;
  const a = Jf(o.defaultValue, t, e, n, r);
  a !== Zc && (n._prefault = a);
}, nm = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  i.ref = o.innerType;
  let a;
  try {
    a = o.catchValue(void 0);
  } catch {
    ot(t, e, n, r, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = a;
}, rm = (t, e, n, r) => {
  const o = t._zod.def, i = o.in._zod.traits.has("$ZodTransform"), a = e.io === "input" ? i ? o.out : o.in : o.out;
  Re(a, e, r);
  const c = e.seen.get(t);
  c.ref = a;
}, om = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  i.ref = o.innerType, n.readOnly = !0;
}, tk = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  i.ref = o.innerType;
}, qc = (t, e, n, r) => {
  const o = t._zod.def;
  Re(o.innerType, e, r);
  const i = e.seen.get(t);
  i.ref = o.innerType;
}, nk = (t, e, n, r) => {
  const o = t._zod.innerType;
  Re(o, e, r);
  const i = e.seen.get(t);
  i.ref = o;
}, Fd = {
  string: jf,
  number: Lf,
  boolean: Gf,
  bigint: j0,
  symbol: L0,
  null: G0,
  undefined: F0,
  void: U0,
  never: Ff,
  any: Z0,
  unknown: Uf,
  date: q0,
  enum: Zf,
  literal: qf,
  nan: K0,
  template_literal: W0,
  file: Y0,
  success: V0,
  custom: Kf,
  function: B0,
  transform: Wf,
  map: H0,
  set: Q0,
  array: Yf,
  object: Vf,
  union: Bf,
  intersection: Hf,
  tuple: X0,
  record: ek,
  nullable: Qf,
  nonoptional: Xf,
  default: em,
  prefault: tm,
  catch: nm,
  pipe: rm,
  readonly: om,
  promise: tk,
  optional: qc,
  lazy: nk
};
function rk(t, e) {
  if ("_idmap" in t) {
    const r = t, o = Qa({ ...e, processors: Fd }), i = {};
    for (const l of r._idmap.entries()) {
      const [h, m] = l;
      Re(m, o);
    }
    const a = {}, c = {
      registry: r,
      uri: e == null ? void 0 : e.uri,
      defs: i
    };
    o.external = c;
    for (const l of r._idmap.entries()) {
      const [h, m] = l;
      Xa(o, m), Cn(a, h, Ja(o, m));
    }
    if (Object.keys(i).length > 0) {
      const l = o.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [l]: i
      };
    }
    return { schemas: a };
  }
  const n = Qa({ ...e, processors: Fd });
  return Re(t, n), Xa(n, t), Ja(n, t);
}
const Ud = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Ma(t, e, n) {
  Object.defineProperty(t, e, {
    configurable: !0,
    enumerable: !1,
    get() {
      const r = n(this);
      return Object.defineProperty(this, e, { value: r, configurable: !0, writable: !0 }), r;
    },
    set(r) {
      Object.defineProperty(this, e, { value: r, configurable: !0, writable: !0 });
    }
  });
}
const ok = (t, e) => {
  Ty.init(t, e), t.name = "ZodError";
  const n = Object.getPrototypeOf(t);
  Ud.has(n) || (Ud.add(n), Ma(n, "format", (r) => (o) => Ay(r, o)), Ma(n, "flatten", (r) => (o) => Py(r, o)), Ma(n, "addIssue", (r) => (o) => {
    r.issues.push(o), r.message = JSON.stringify(r.issues, Hu, 2);
  }), Ma(n, "addIssues", (r) => (o) => {
    r.issues.push(...o), r.message = JSON.stringify(r.issues, Hu, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, on = /* @__PURE__ */ F("ZodError", ok, void 0, {
  Parent: Error
}), ik = /* @__PURE__ */ $c(on), ak = /* @__PURE__ */ Nc(on), sk = /* @__PURE__ */ jc(on), uk = /* @__PURE__ */ Lc(on), ck = /* @__PURE__ */ Ry(on), lk = /* @__PURE__ */ xy(on), dk = /* @__PURE__ */ Oy(on), hk = /* @__PURE__ */ My(on), fk = /* @__PURE__ */ $y(on), mk = /* @__PURE__ */ Ny(on), pk = /* @__PURE__ */ jy(on), gk = /* @__PURE__ */ Ly(on);
function vk() {
  wn.localeError || pr(Gw());
}
function Kc() {
  wn.memoizer || pr({ memoizer: Nw() });
}
const qe = /* @__PURE__ */ F("ZodType", (t, e) => (vk(), Ze.init(t, e), t.def = e, t.type = e.type, t), {
  check(...t) {
    const e = this.def;
    return this.clone(Ft(e, {
      checks: [
        ...e.checks ?? [],
        ...t.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...t) {
    return this.check(...t);
  },
  clone(t, e) {
    return mr(this, t, e);
  },
  brand() {
    return this;
  },
  register(t, e) {
    return t.add(this, e), this;
  },
  refine(t, e) {
    return this.check(d_(t, e));
  },
  superRefine(t, e) {
    return this.check(h_(t, e));
  },
  overwrite(t) {
    return this.check(/* @__PURE__ */ zo(t));
  },
  optional() {
    return Kd(this);
  },
  exactOptional() {
    return Xk(this);
  },
  nullable() {
    return Wd(this);
  },
  nullish() {
    return Kd(Wd(this));
  },
  nonoptional(t) {
    return o_(this, t);
  },
  array() {
    return wo(this);
  },
  or(t) {
    return qk([this, t]);
  },
  and(t) {
    return Vk(this, t);
  },
  transform(t) {
    return Yd(this, Qk(t));
  },
  default(t) {
    return t_(this, t);
  },
  prefault(t) {
    return r_(this, t);
  },
  catch(t) {
    return a_(this, t);
  },
  pipe(t) {
    return Yd(this, t);
  },
  readonly() {
    return c_(this);
  },
  describe(t) {
    const e = this.clone();
    return ni.add(e, { description: t }), e;
  },
  meta(...t) {
    if (t.length === 0)
      return ni.get(this);
    const e = this.clone();
    return ni.add(e, t[0]), e;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(t, ...e) {
    return e.length === 0 ? t(this) : t(this, ...e);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return rf(this, "~standard", {
      ...ff(this),
      jsonSchema: {
        input: es(this, "input"),
        output: es(this, "output")
      }
    });
  },
  set "~standard"(t) {
    lr(this, "~standard", t);
  },
  parse: function t(e, n) {
    return ik(this, e, n, { callee: t });
  },
  parseAsync: async function t(e, n) {
    return await ak(this, e, n, { callee: t });
  },
  safeParse(t, e) {
    return sk(this, t, e);
  },
  async safeParseAsync(t, e) {
    return uk(this, t, e);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this == null ? void 0 : this.safeParseAsync;
  },
  set spa(t) {
    lr(this, "spa", t);
  },
  validate(t, e) {
    return Dy(this, t, e);
  },
  validateAsync(t, e) {
    return zy(this, t, e);
  },
  encode: function t(e, n) {
    return ck(this, e, n, { callee: t });
  },
  decode: function t(e, n) {
    return lk(this, e, n, { callee: t });
  },
  encodeAsync: async function t(e, n) {
    return await dk(this, e, n, { callee: t });
  },
  decodeAsync: async function t(e, n) {
    return await hk(this, e, n, { callee: t });
  },
  safeEncode(t, e) {
    return fk(this, t, e);
  },
  safeDecode(t, e) {
    return mk(this, t, e);
  },
  async safeEncodeAsync(t, e) {
    return pk(this, t, e);
  },
  async safeDecodeAsync(t, e) {
    return gk(this, t, e);
  },
  toJSONSchema(t) {
    return M0(this, {})(t);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    var t;
    return (t = ni.get(this)) == null ? void 0 : t.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), im = /* @__PURE__ */ F(
  "_ZodString",
  (t, e) => {
    Fc.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => jf(t, n, r);
  },
  /* @__PURE__ */ of({
    format: (t) => Zt(t).format ?? null,
    minLength: (t) => Zt(t).minimum ?? null,
    maxLength: (t) => Zt(t).maximum ?? null
  }, {
    regex(...t) {
      return this.check(/* @__PURE__ */ b0(...t));
    },
    includes(...t) {
      return this.check(/* @__PURE__ */ _0(...t));
    },
    startsWith(...t) {
      return this.check(/* @__PURE__ */ T0(...t));
    },
    endsWith(...t) {
      return this.check(/* @__PURE__ */ C0(...t));
    },
    min(...t) {
      return this.check(/* @__PURE__ */ Ha(...t));
    },
    max(...t) {
      return this.check(/* @__PURE__ */ Df(...t));
    },
    length(...t) {
      return this.check(/* @__PURE__ */ If(...t));
    },
    nonempty(...t) {
      return this.check(/* @__PURE__ */ Ha(1, ...t));
    },
    lowercase(t) {
      return this.check(/* @__PURE__ */ w0(t));
    },
    uppercase(t) {
      return this.check(/* @__PURE__ */ k0(t));
    },
    trim() {
      return this.check(/* @__PURE__ */ A0());
    },
    normalize(...t) {
      return this.check(/* @__PURE__ */ P0(...t));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ E0());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ S0());
    },
    slugify() {
      return this.check(/* @__PURE__ */ D0());
    }
  })
), yk = /* @__PURE__ */ F("ZodString", (t, e) => {
  Fc.init(t, e), im.init(t, e);
}, {
  email(t) {
    return this.check(/* @__PURE__ */ qw(kk, t));
  },
  url(t) {
    return this.check(/* @__PURE__ */ Hw(Tk, t));
  },
  jwt(t) {
    return this.check(/* @__PURE__ */ d0(jk, t));
  },
  emoji(t) {
    return this.check(/* @__PURE__ */ Qw(Ck, t));
  },
  guid(t) {
    return this.check(/* @__PURE__ */ Kw(_k, t));
  },
  uuid(t) {
    return this.check(/* @__PURE__ */ Ww($a, t));
  },
  uuidv4(t) {
    return this.check(/* @__PURE__ */ Yw($a, t));
  },
  uuidv6(t) {
    return this.check(/* @__PURE__ */ Vw($a, t));
  },
  uuidv7(t) {
    return this.check(/* @__PURE__ */ Bw($a, t));
  },
  nanoid(t) {
    return this.check(/* @__PURE__ */ Xw(Pk, t));
  },
  cuid(t) {
    return this.check(/* @__PURE__ */ Jw(Ak, t));
  },
  cuid2(t) {
    return this.check(/* @__PURE__ */ e0(Ek, t));
  },
  ulid(t) {
    return this.check(/* @__PURE__ */ t0(Sk, t));
  },
  base64(t) {
    return this.check(/* @__PURE__ */ u0(Mk, t));
  },
  base64url(t) {
    return this.check(/* @__PURE__ */ c0($k, t));
  },
  xid(t) {
    return this.check(/* @__PURE__ */ n0(Dk, t));
  },
  ksuid(t) {
    return this.check(/* @__PURE__ */ r0(Ik, t));
  },
  ipv4(t) {
    return this.check(/* @__PURE__ */ o0(zk, t));
  },
  ipv6(t) {
    return this.check(/* @__PURE__ */ i0(Rk, t));
  },
  cidrv4(t) {
    return this.check(/* @__PURE__ */ a0(xk, t));
  },
  cidrv6(t) {
    return this.check(/* @__PURE__ */ s0(Ok, t));
  },
  e164(t) {
    return this.check(/* @__PURE__ */ l0(Nk, t));
  },
  datetime(t) {
    return this.check(/* @__PURE__ */ Ef(am, t));
  },
  date(t) {
    return this.check(/* @__PURE__ */ Sf(sm, t));
  },
  time(t) {
    return this.check(/* @__PURE__ */ h0(bk, t));
  },
  duration(t) {
    return this.check(/* @__PURE__ */ f0(wk, t));
  }
});
function Ue(t) {
  return /* @__PURE__ */ Zw(yk, t);
}
const Ge = /* @__PURE__ */ F("ZodStringFormat", (t, e) => {
  Me.init(t, e), im.init(t, e);
}), am = /* @__PURE__ */ F("ZodISODateTime", (t, e) => {
  Wb.init(t, e), Ge.init(t, e);
}), sm = /* @__PURE__ */ F("ZodISODate", (t, e) => {
  Yb.init(t, e), Ge.init(t, e);
}), bk = /* @__PURE__ */ F("ZodISOTime", (t, e) => {
  Vb.init(t, e), Ge.init(t, e);
}), wk = /* @__PURE__ */ F("ZodISODuration", (t, e) => {
  Bb.init(t, e), Ge.init(t, e);
}), kk = /* @__PURE__ */ F("ZodEmail", (t, e) => {
  Rb.init(t, e), Ge.init(t, e);
}), _k = /* @__PURE__ */ F("ZodGUID", (t, e) => {
  Ib.init(t, e), Ge.init(t, e);
}), $a = /* @__PURE__ */ F("ZodUUID", (t, e) => {
  zb.init(t, e), Ge.init(t, e);
}), Tk = /* @__PURE__ */ F("ZodURL", (t, e) => {
  jb.init(t, e), Ge.init(t, e);
}), Ck = /* @__PURE__ */ F("ZodEmoji", (t, e) => {
  Lb.init(t, e), Ge.init(t, e);
}), Pk = /* @__PURE__ */ F("ZodNanoID", (t, e) => {
  Gb.init(t, e), Ge.init(t, e);
}), Ak = /* @__PURE__ */ F("ZodCUID", (t, e) => {
  Fb.init(t, e), Ge.init(t, e);
}), Ek = /* @__PURE__ */ F("ZodCUID2", (t, e) => {
  Ub.init(t, e), Ge.init(t, e);
}), Sk = /* @__PURE__ */ F("ZodULID", (t, e) => {
  Zb.init(t, e), Ge.init(t, e);
}), Dk = /* @__PURE__ */ F("ZodXID", (t, e) => {
  qb.init(t, e), Ge.init(t, e);
}), Ik = /* @__PURE__ */ F("ZodKSUID", (t, e) => {
  Kb.init(t, e), Ge.init(t, e);
}), zk = /* @__PURE__ */ F("ZodIPv4", (t, e) => {
  Hb.init(t, e), Ge.init(t, e);
}), Rk = /* @__PURE__ */ F("ZodIPv6", (t, e) => {
  Xb.init(t, e), Ge.init(t, e);
}), xk = /* @__PURE__ */ F("ZodCIDRv4", (t, e) => {
  Jb.init(t, e), Ge.init(t, e);
}), Ok = /* @__PURE__ */ F("ZodCIDRv6", (t, e) => {
  tw.init(t, e), Ge.init(t, e);
}), Mk = /* @__PURE__ */ F("ZodBase64", (t, e) => {
  nw.init(t, e), Ge.init(t, e);
}), $k = /* @__PURE__ */ F("ZodBase64URL", (t, e) => {
  ow.init(t, e), Ge.init(t, e);
}), Nk = /* @__PURE__ */ F("ZodE164", (t, e) => {
  iw.init(t, e), Ge.init(t, e);
}), jk = /* @__PURE__ */ F("ZodJWT", (t, e) => {
  sw.init(t, e), Ge.init(t, e);
}), um = /* @__PURE__ */ F(
  "ZodNumber",
  (t, e) => {
    bf.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Lf(t, n, r, o), t.isFinite = !0;
  },
  /* @__PURE__ */ of({
    minValue: (t) => {
      const { minimum: e, exclusiveMinimum: n } = Zt(t);
      return Math.max(e ?? Number.NEGATIVE_INFINITY, n ?? Number.NEGATIVE_INFINITY);
    },
    maxValue: (t) => {
      const { maximum: e, exclusiveMaximum: n } = Zt(t);
      return Math.min(e ?? Number.POSITIVE_INFINITY, n ?? Number.POSITIVE_INFINITY);
    },
    isInt: (t) => {
      const { isInt: e, multipleOf: n } = Zt(t);
      return !!e || !!(n != null && n.some(Number.isSafeInteger));
    },
    format: (t) => Zt(t).format ?? null
  }, {
    gt(t, e) {
      return this.check(/* @__PURE__ */ Rd(t, e));
    },
    gte(t, e) {
      return this.check(/* @__PURE__ */ $u(t, e));
    },
    min(t, e) {
      return this.check(/* @__PURE__ */ $u(t, e));
    },
    lt(t, e) {
      return this.check(/* @__PURE__ */ zd(t, e));
    },
    lte(t, e) {
      return this.check(/* @__PURE__ */ Mu(t, e));
    },
    max(t, e) {
      return this.check(/* @__PURE__ */ Mu(t, e));
    },
    int(t) {
      return this.check(Zd(t));
    },
    safe(t) {
      return this.check(Zd(t));
    },
    positive(t) {
      return this.check(/* @__PURE__ */ Rd(0, t));
    },
    nonnegative(t) {
      return this.check(/* @__PURE__ */ $u(0, t));
    },
    negative(t) {
      return this.check(/* @__PURE__ */ zd(0, t));
    },
    nonpositive(t) {
      return this.check(/* @__PURE__ */ Mu(0, t));
    },
    multipleOf(t, e) {
      return this.check(/* @__PURE__ */ xd(t, e));
    },
    step(t, e) {
      return this.check(/* @__PURE__ */ xd(t, e));
    },
    finite() {
      return this;
    }
  })
);
function jn(t) {
  return /* @__PURE__ */ m0(um, t);
}
const Lk = /* @__PURE__ */ F("ZodNumberFormat", (t, e) => {
  uw.init(t, e), um.init(t, e);
});
function Zd(t) {
  return /* @__PURE__ */ p0(Lk, t);
}
const Gk = /* @__PURE__ */ F("ZodBoolean", (t, e) => {
  cw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Gf(t, n, r);
});
function hn(t) {
  return /* @__PURE__ */ g0(Gk, t);
}
const Fk = /* @__PURE__ */ F("ZodUnknown", (t, e) => {
  lw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Uf();
});
function qd() {
  return /* @__PURE__ */ v0(Fk);
}
const Uk = /* @__PURE__ */ F("ZodNever", (t, e) => {
  dw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Ff(t, n, r);
});
function cm(t) {
  return /* @__PURE__ */ y0(Uk, t);
}
const Zk = /* @__PURE__ */ F("ZodArray", (t, e) => {
  Kc(), mw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Yf(t, n, r, o), t.element = e.element;
}, {
  min(t, e) {
    return this.check(/* @__PURE__ */ Ha(t, e));
  },
  nonempty(t) {
    return this.check(/* @__PURE__ */ Ha(1, t));
  },
  max(t, e) {
    return this.check(/* @__PURE__ */ Df(t, e));
  },
  length(t, e) {
    return this.check(/* @__PURE__ */ If(t, e));
  },
  unwrap() {
    return this.element;
  }
});
function wo(t, e) {
  return /* @__PURE__ */ I0(Zk, t, e);
}
const lm = /* @__PURE__ */ F("ZodObject", (t, e) => {
  Kc(), vw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Vf(t, n, r, o), py(t, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return ko(Object.keys(this._zod.def.shape));
  },
  catchall(t) {
    return this.clone(Ft(this._zod.def, { catchall: t }));
  },
  passthrough() {
    return this.clone(Ft(this._zod.def, { catchall: qd() }));
  },
  loose() {
    return this.clone(Ft(this._zod.def, { catchall: qd() }));
  },
  strict() {
    return this.clone(Ft(this._zod.def, { catchall: cm() }));
  },
  strip() {
    return this.clone(Ft(this._zod.def, { catchall: void 0 }));
  },
  extend(t) {
    return oy(this, t);
  },
  safeExtend(t) {
    return iy(this, t);
  },
  merge(t) {
    return ay(this, t);
  },
  pick(t) {
    return ny(this, t);
  },
  omit(t) {
    return ry(this, t);
  },
  partial(...t) {
    return fd(hm, this, t[0]);
  },
  exactPartial(...t) {
    return fd(fm, this, t[0], "exactPartial");
  },
  required(...t) {
    return sy(mm, this, t[0]);
  }
});
function ys(t, e) {
  const n = {
    type: "object",
    shape: t ?? {},
    ...ne(e)
  };
  return new lm(n);
}
function Qt(t, e) {
  return new lm({
    type: "object",
    shape: t,
    catchall: cm(),
    ...ne(e)
  });
}
const dm = /* @__PURE__ */ F("ZodUnion", (t, e) => {
  _f.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Bf(t, n, r, o), t.options = e.options;
});
function qk(t, e) {
  return new dm({
    type: "union",
    options: t,
    ...ne(e)
  });
}
const Kk = /* @__PURE__ */ F("ZodDiscriminatedUnion", (t, e) => {
  dm.init(t, e), bw.init(t, e);
});
function Wk(t, e, n) {
  return new Kk({
    type: "union",
    options: e,
    discriminator: t,
    ...ne(n)
  });
}
const Yk = /* @__PURE__ */ F("ZodIntersection", (t, e) => {
  ww.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Hf(t, n, r, o);
});
function Vk(t, e) {
  return new Yk({
    type: "intersection",
    left: t,
    right: e
  });
}
const oc = /* @__PURE__ */ F("ZodEnum", (t, e) => {
  kw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (r, o, i) => Zf(t, r, o), t.enum = e.entries, t.options = [...t._zod.values];
  const n = new Set(Object.keys(e.entries));
  t.extract = (r, o) => {
    const i = {};
    for (const a of r)
      if (n.has(a))
        i[a] = e.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new oc({
      ...e,
      checks: [],
      ...ne(o),
      entries: i
    });
  }, t.exclude = (r, o) => {
    const i = { ...e.entries };
    for (const a of r)
      if (n.has(a))
        delete i[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new oc({
      ...e,
      checks: [],
      ...ne(o),
      entries: i
    });
  };
});
function ko(t, e) {
  const n = Array.isArray(t) ? Object.fromEntries(t.map((r) => [r, r])) : t;
  return new oc({
    type: "enum",
    entries: n,
    ...ne(e)
  });
}
const Bk = /* @__PURE__ */ F("ZodLiteral", (t, e) => {
  _w.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => qf(t, n, r, o), t.values = new Set(e.values), Object.defineProperty(t, "value", {
    get() {
      if (e.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return e.values[0];
    }
  });
});
function un(t, e) {
  return new Bk({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...ne(e)
  });
}
const Hk = /* @__PURE__ */ F("ZodTransform", (t, e) => {
  Kc(), Tw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Wf(t, n, r, o), t._zod.parse = (n, r) => {
    if (r.direction === "backward")
      throw new af(t.constructor.name);
    n.addIssue = (i) => {
      if (typeof i == "string")
        n.issues.push(Ti(i, n.value, e));
      else {
        const a = i;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = n.value), a.inst ?? (a.inst = t), n.issues.push(Ti(a));
      }
    };
    const o = e.transform(n.value, n);
    return o instanceof Promise ? o.then((i) => (n.value = i, n)) : (n.value = o, n);
  };
});
function Qk(t) {
  return new Hk({
    type: "transform",
    transform: t
  });
}
const hm = /* @__PURE__ */ F("ZodOptional", (t, e) => {
  Tf.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => qc(t, n, r, o), t.unwrap = () => t._zod.def.innerType;
});
function Kd(t) {
  return new hm({
    type: "optional",
    innerType: t
  });
}
const fm = /* @__PURE__ */ F("ZodExactOptional", (t, e) => {
  Cw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => qc(t, n, r, o), t.unwrap = () => t._zod.def.innerType;
});
function Xk(t) {
  return new fm({
    type: "optional",
    innerType: t
  });
}
const Jk = /* @__PURE__ */ F("ZodNullable", (t, e) => {
  Pw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Qf(t, n, r, o), t.unwrap = () => t._zod.def.innerType;
});
function Wd(t) {
  return new Jk({
    type: "nullable",
    innerType: t
  });
}
const e_ = /* @__PURE__ */ F("ZodDefault", (t, e) => {
  Aw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => em(t, n, r, o), t.unwrap = () => t._zod.def.innerType, t.removeDefault = t.unwrap;
});
function t_(t, e) {
  return new e_({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof e == "function" ? e() : Xh(e);
    }
  });
}
const n_ = /* @__PURE__ */ F("ZodPrefault", (t, e) => {
  Ew.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => tm(t, n, r, o), t.unwrap = () => t._zod.def.innerType;
});
function r_(t, e) {
  return new n_({
    type: "prefault",
    innerType: t,
    get defaultValue() {
      return typeof e == "function" ? e() : Xh(e);
    }
  });
}
const mm = /* @__PURE__ */ F("ZodNonOptional", (t, e) => {
  Sw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Xf(t, n, r, o), t.unwrap = () => t._zod.def.innerType;
});
function o_(t, e) {
  return new mm({
    type: "nonoptional",
    innerType: t,
    ...ne(e)
  });
}
const i_ = /* @__PURE__ */ F("ZodCatch", (t, e) => {
  Dw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => nm(t, n, r, o), t.unwrap = () => t._zod.def.innerType, t.removeCatch = t.unwrap;
});
function a_(t, e) {
  return new i_({
    type: "catch",
    innerType: t,
    catchValue: typeof e == "function" ? e : vy(e)
  });
}
const s_ = /* @__PURE__ */ F("ZodPipe", (t, e) => {
  Iw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => rm(t, n, r, o), t.in = e.in, t.out = e.out;
});
function Yd(t, e) {
  return new s_({
    type: "pipe",
    in: t,
    out: e
    // ...util.normalizeParams(params),
  });
}
const u_ = /* @__PURE__ */ F("ZodReadonly", (t, e) => {
  zw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => om(t, n, r, o), t.unwrap = () => t._zod.def.innerType;
});
function c_(t) {
  return new u_({
    type: "readonly",
    innerType: t
  });
}
const l_ = /* @__PURE__ */ F("ZodCustom", (t, e) => {
  Rw.init(t, e), qe.init(t, e), t._zod.processJSONSchema = (n, r, o) => Kf(t, n, r, o);
});
function d_(t, e = {}) {
  return /* @__PURE__ */ z0(l_, t, e);
}
function h_(t, e) {
  return /* @__PURE__ */ R0(t, e);
}
function ic(t) {
  return /* @__PURE__ */ Ef(am, t);
}
function Wc(t) {
  return /* @__PURE__ */ Sf(sm, t);
}
const Yc = ko(["development", "review", "writing", "planning", "communication", "other"]), nr = Ue().min(1).max(100), ac = Wc().nullable(), pm = ic().nullable(), Na = Ue().regex(/^\d{4}-\d{2}-\d{2}T([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?$/), f_ = Qt({
  title: Ue().trim().min(1).max(200).nullable(),
  description: Ue().max(5e3).nullable(),
  estimatedMinutes: jn().int().min(1).max(1440).nullable(),
  priority: ko(["high", "medium", "low"]).nullable(),
  category: Yc.nullable(),
  scheduledDate: ac,
  clearScheduledDate: hn(),
  deadline: pm,
  clearDeadline: hn()
}), m_ = Wk("type", [
  Qt({ type: un("create_task"), clientId: Ue().regex(/^[a-z][a-z0-9_-]{0,39}$/), title: Ue().trim().min(1).max(200), description: Ue().max(5e3), estimatedMinutes: jn().int().min(1).max(1440), priority: ko(["high", "medium", "low"]), category: Yc, scheduledDate: ac, deadline: pm, dependencyIds: wo(nr).max(24) }),
  Qt({ type: un("update_task"), taskId: nr, patch: f_ }),
  Qt({ type: un("complete_task"), taskId: nr }),
  Qt({ type: un("defer_task"), taskId: nr, scheduledDate: ac }),
  Qt({ type: un("extend_task"), taskId: nr, minutes: jn().int().min(1).max(480) }),
  Qt({ type: un("create_meeting"), title: Ue().trim().min(1).max(200), startLocal: Na, endLocal: Na }),
  Qt({ type: un("update_meeting"), meetingId: nr, title: Ue().trim().min(1).max(200).nullable(), startLocal: Na.nullable(), endLocal: Na.nullable() }),
  Qt({ type: un("delete_meeting"), meetingId: nr }),
  Qt({ type: un("add_note"), taskId: nr, note: Ue().trim().min(1).max(1e3) }),
  Qt({ type: un("reschedule"), date: Wc() })
]), p_ = Qt({ reply: Ue().trim().min(1).max(4e3), actions: wo(m_).max(24) });
rk(p_, { target: "draft-7" });
class Ye extends Error {
  constructor(e, n, r) {
    super(n), this.code = e, this.retryAfterSeconds = r, this.name = "AIError";
  }
}
const fi = "https://auth.openai.com", g_ = "https://api.openai.com/v1", gm = "workday.chatgpt.vault", Mr = "workday.chatgpt.pending", vm = "workday.chatgpt.result";
function ji() {
  var e;
  const t = (e = globalThis.chrome) == null ? void 0 : e.storage;
  if (!(t != null && t.local)) throw new Ye("configuration", "ChatGPT sign-in needs the installed extension. Load it in Edge, then retry.");
  return { local: t.local, session: t.session ?? t.local };
}
async function Pi(t, e) {
  return (await t.get(e))[e];
}
let Vd = Promise.resolve();
function ym(t) {
  var n;
  if ((n = globalThis.navigator) != null && n.locks) return navigator.locks.request("workday-chatgpt", t);
  const e = Vd.then(t, t);
  return Vd = e.catch(() => {
  }), e;
}
async function bm() {
  return await Pi(ji().local, gm) ?? { hostId: `urn:uuid:${crypto.randomUUID()}`, accounts: [] };
}
function v_(t) {
  return ym(async () => {
    const e = await bm();
    try {
      return await t(e);
    } finally {
      await ji().local.set({ [gm]: e });
    }
  });
}
function y_(t, e) {
  if (typeof t != "string" || t.length !== e.length) return !1;
  let n = 0;
  for (let r = 0; r < t.length; r++) n |= t.charCodeAt(r) ^ e.charCodeAt(r);
  return n === 0;
}
function b_(t, e) {
  const n = e && typeof e == "object" && "error" in e ? e.error : void 0, r = typeof n == "string" ? n : n && typeof n == "object" && "code" in n ? String(n.code) : "", o = t === 429 ? new Ye("rate_limit", "ChatGPT usage limit reached. Manage usage in ChatGPT, then retry here.") : t === 403 ? new Ye("auth", "ChatGPT plan access is unavailable for this account, workspace or region.") : t === 401 ? new Ye("auth", "ChatGPT authorization expired. Sign in again.") : new Ye("unavailable", "ChatGPT could not complete this request. Please retry later.");
  return o.terminal = ["invalid_grant", "invalid_refresh_token", "token_expired", "refresh_token_expired", "refresh_token_invalidated", "refresh_token_reused"].includes(r), o;
}
async function wm(t, e = {}, n) {
  let r, o;
  try {
    r = await fetch(t, { ...e, credentials: "omit", redirect: "error", referrerPolicy: "no-referrer", signal: n ?? AbortSignal.timeout(3e4) }), o = await r.text();
  } catch {
    throw new Ye("network", "ChatGPT could not be reached. Your saved sign-in is kept.");
  }
  if (o.length > 2e6) throw new Ye("invalid_response", "ChatGPT returned an oversized response.");
  let i = null;
  try {
    i = JSON.parse(o);
  } catch {
  }
  if (!r.ok) throw b_(r.status, i);
  if (!i || typeof i != "object") throw new Ye("invalid_response", "ChatGPT returned an unreadable response.");
  return i;
}
let ju;
async function w_() {
  ju ?? (ju = wm(`${fi}/.well-known/openid-configuration`).catch((e) => {
    throw ju = void 0, e;
  }));
  const t = await ju;
  if (t.issuer !== fi) throw new Ye("auth", "ChatGPT identity discovery failed.");
  for (const e of ["jwks_uri", "revocation_endpoint"]) if (typeof t[e] == "string" && new URL(t[e]).origin !== fi) throw new Ye("auth", "ChatGPT identity endpoint could not be verified.");
  return t;
}
let k_;
async function __(t, e, n, r) {
  if (typeof t != "string") throw new Ye("auth", "ChatGPT did not return an identity. Sign in again.");
  let o;
  try {
    const i = k_ ?? Kv(new URL(String((await w_()).jwks_uri)));
    ({ payload: o } = await Lv(t, i, { issuer: fi, audience: e, algorithms: ["RS256", "ES256"], requiredClaims: ["exp", "sub"] }));
  } catch (i) {
    throw i instanceof Ye ? i : new Ye("auth", "ChatGPT identity verification failed. Please retry sign-in.");
  }
  if (!o.sub || n && o.nonce !== n || r && o.sub !== r) throw new Ye("auth", "ChatGPT identity did not match the selected sign-in.");
  return { subject: o.sub, email: typeof o.email == "string" ? o.email.slice(0, 200) : "ChatGPT account" };
}
function T_(t, e, n = !1) {
  if (typeof e.access_token != "string" || String(e.token_type).toLowerCase() !== "bearer" || typeof e.expires_in != "number" || !(e.expires_in > 0)) throw new Ye("auth", "ChatGPT returned incomplete credentials. Sign in again.");
  const r = n ? t.tokens : void 0;
  t.tokens = {
    access: e.access_token,
    refresh: typeof e.refresh_token == "string" ? e.refresh_token : r == null ? void 0 : r.refresh,
    id: typeof e.id_token == "string" ? e.id_token : r == null ? void 0 : r.id,
    expires: Date.now() + e.expires_in * 1e3,
    scopes: typeof e.scope == "string" ? e.scope.split(" ") : (r == null ? void 0 : r.scopes) ?? []
  };
}
async function C_() {
  const { session: t } = ji(), e = await Pi(t, Mr);
  if (e && e.expires < Date.now()) {
    await t.remove(Mr), await t.set({ [vm]: { id: e.id, error: "ChatGPT sign-in timed out. Please try again." } });
    return;
  }
  return e;
}
async function P_(t) {
  if (!t.startsWith("http://127.0.0.1:")) return !1;
  const e = await Pi(ji().session, Mr);
  return !!e && t.startsWith(`${e.redirect}?`);
}
async function A_(t) {
  var o;
  const { session: e } = ji(), n = await ym(async () => {
    const i = await C_();
    if (!(!i || i.consumed || !t.startsWith(`${i.redirect}?`)) && y_(new URL(t).searchParams.get("state"), i.state))
      return await e.set({ [Mr]: { ...i, consumed: !0 } }), i;
  });
  if (!n) return !1;
  let r;
  try {
    const i = new URL(t).searchParams;
    if (i.has("error")) throw new Ye("auth", "ChatGPT sign-in was not authorized.");
    const a = n.accountId ? (await bm()).accounts.find((v) => v.id === n.accountId) : void 0;
    if (n.accountId && !a) throw new Ye("auth", "The selected ChatGPT account no longer exists.");
    const c = i.get("client_id") || (a == null ? void 0 : a.clientId), l = i.get("code");
    if (!l || !c || c === "dynamic_agent_client" || c.length > 256 || a && c !== a.clientId) throw new Ye("auth", "ChatGPT registration could not be verified.");
    const h = await wm(`${fi}/api/accounts/oauth/token`, { method: "POST", body: new URLSearchParams({ grant_type: "authorization_code", client_id: c, code: l, code_verifier: n.verifier, redirect_uri: n.redirect, resource: g_ }) }), m = await __(h.id_token, c, n.nonce, a == null ? void 0 : a.subject), p = await v_(async (v) => {
      var A;
      if (((A = await Pi(e, Mr)) == null ? void 0 : A.id) !== n.id) throw new Ye("cancelled", "ChatGPT sign-in was cancelled.");
      let k = v.accounts.find((S) => S.id === n.accountId);
      k || (k = { id: crypto.randomUUID(), clientId: c }, v.accounts = [k]);
      const P = { ...k, ...m };
      return T_(P, h), Object.assign(k, P), k.id;
    });
    r = { id: n.id, accountId: p };
  } catch (i) {
    r = { id: n.id, error: i instanceof Ye ? i.message : "ChatGPT sign-in did not complete. Please retry." };
  }
  return ((o = await Pi(e, Mr)) == null ? void 0 : o.id) === n.id && (await e.remove(Mr), await e.set({ [vm]: r })), !0;
}
var E_ = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function S_(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var Ua = { exports: {} }, D_ = Ua.exports, Bd;
function I_() {
  return Bd || (Bd = 1, (function(t, e) {
    (function(n, r) {
      t.exports = r();
    })(D_, (function() {
      var n = function(s, u) {
        return n = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, f) {
          d.__proto__ = f;
        } || function(d, f) {
          for (var g in f) Object.prototype.hasOwnProperty.call(f, g) && (d[g] = f[g]);
        }, n(s, u);
      };
      function r(s, u) {
        if (typeof u != "function" && u !== null)
          throw new TypeError("Class extends value " + String(u) + " is not a constructor or null");
        n(s, u);
        function d() {
          this.constructor = s;
        }
        s.prototype = u === null ? Object.create(u) : (d.prototype = u.prototype, new d());
      }
      var o = function() {
        return o = Object.assign || function(u) {
          for (var d, f = 1, g = arguments.length; f < g; f++) {
            d = arguments[f];
            for (var b in d) Object.prototype.hasOwnProperty.call(d, b) && (u[b] = d[b]);
          }
          return u;
        }, o.apply(this, arguments);
      };
      function i(s, u, d) {
        for (var f = 0, g = u.length, b; f < g; f++)
          (b || !(f in u)) && (b || (b = Array.prototype.slice.call(u, 0, f)), b[f] = u[f]);
        return s.concat(b || Array.prototype.slice.call(u));
      }
      typeof SuppressedError == "function" && SuppressedError;
      var a = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : E_, c = Object.keys, l = Array.isArray;
      typeof Promise < "u" && !a.Promise && (a.Promise = Promise);
      function h(s, u) {
        return typeof u != "object" || c(u).forEach(function(d) {
          s[d] = u[d];
        }), s;
      }
      var m = Object.getPrototypeOf, p = {}.hasOwnProperty;
      function v(s, u) {
        return p.call(s, u);
      }
      function k(s, u) {
        typeof u == "function" && (u = u(m(s))), (typeof Reflect > "u" ? c : Reflect.ownKeys)(u).forEach(function(d) {
          A(s, d, u[d]);
        });
      }
      var P = Object.defineProperty;
      function A(s, u, d, f) {
        P(s, u, h(d && v(d, "get") && typeof d.get == "function" ? {
          get: d.get,
          set: d.set,
          configurable: !0
        } : { value: d, configurable: !0, writable: !0 }, f));
      }
      function S(s) {
        return {
          from: function(u) {
            return s.prototype = Object.create(u.prototype), A(s.prototype, "constructor", s), {
              extend: k.bind(null, s.prototype)
            };
          }
        };
      }
      var z = Object.getOwnPropertyDescriptor;
      function L(s, u) {
        var d = z(s, u), f;
        return d || (f = m(s)) && L(f, u);
      }
      var W = [].slice;
      function H(s, u, d) {
        return W.call(s, u, d);
      }
      function re(s, u) {
        return u(s);
      }
      function Ee(s) {
        if (!s)
          throw new Error("Assertion Failed");
      }
      function ye(s) {
        a.setImmediate ? setImmediate(s) : setTimeout(s, 0);
      }
      function ue(s, u) {
        return s.reduce(function(d, f, g) {
          var b = u(f, g);
          return b && (d[b[0]] = b[1]), d;
        }, {});
      }
      function he(s, u) {
        if (typeof u == "string" && v(s, u))
          return s[u];
        if (!u)
          return s;
        if (typeof u != "string") {
          for (var d = [], f = 0, g = u.length; f < g; ++f) {
            var b = he(s, u[f]);
            d.push(b);
          }
          return d;
        }
        var _ = u.indexOf(".");
        if (_ !== -1) {
          var T = s[u.substr(0, _)];
          return T == null ? void 0 : he(T, u.substr(_ + 1));
        }
      }
      function _e(s, u, d) {
        if (!(!s || u === void 0) && !("isFrozen" in Object && Object.isFrozen(s)))
          if (typeof u != "string" && "length" in u) {
            Ee(typeof d != "string" && "length" in d);
            for (var f = 0, g = u.length; f < g; ++f)
              _e(s, u[f], d[f]);
          } else {
            var b = u.indexOf(".");
            if (b !== -1) {
              var _ = u.substr(0, b), T = u.substr(b + 1);
              if (T === "")
                d === void 0 ? l(s) && !isNaN(parseInt(_)) ? s.splice(_, 1) : delete s[_] : s[_] = d;
              else {
                var C = s[_];
                if (!C || !v(s, _)) {
                  if (d === void 0)
                    return;
                  C = s[_] = {};
                }
                _e(C, T, d);
              }
            } else
              d === void 0 ? l(s) && !isNaN(parseInt(u)) ? s.splice(u, 1) : delete s[u] : s[u] = d;
          }
      }
      function De(s, u) {
        typeof u == "string" ? _e(s, u, void 0) : "length" in u && [].map.call(u, function(d) {
          _e(s, d, void 0);
        });
      }
      function Ce(s) {
        var u = {};
        for (var d in s)
          v(s, d) && (u[d] = s[d]);
        return u;
      }
      var We = [].concat;
      function He(s) {
        return We.apply([], s);
      }
      var Yt = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(He([8, 16, 32, 64].map(function(s) {
        return ["Int", "Uint", "Float"].map(function(u) {
          return u + s + "Array";
        });
      }))).filter(function(s) {
        return a[s];
      }), An = new Set(Yt.map(function(s) {
        return a[s];
      }));
      function En(s) {
        var u = {};
        for (var d in s)
          if (v(s, d)) {
            var f = s[d];
            u[d] = !f || typeof f != "object" || An.has(f.constructor) ? f : En(f);
          }
        return u;
      }
      var yr = null;
      function Sn(s) {
        yr = /* @__PURE__ */ new WeakMap();
        var u = xs(s);
        return yr = null, u;
      }
      function xs(s) {
        if (!s || typeof s != "object")
          return s;
        var u = yr.get(s);
        if (u)
          return u;
        if (l(s)) {
          u = [], yr.set(s, u);
          for (var d = 0, f = s.length; d < f; ++d)
            u.push(xs(s[d]));
        } else if (An.has(s.constructor))
          u = s;
        else {
          var g = m(s);
          u = g === Object.prototype ? {} : Object.create(g), yr.set(s, u);
          for (var b in s)
            v(s, b) && (u[b] = xs(s[b]));
        }
        return u;
      }
      var Ap = {}.toString;
      function Os(s) {
        return Ap.call(s).slice(8, -1);
      }
      var Ms = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", Ep = typeof Ms == "symbol" ? function(s) {
        var u;
        return s != null && (u = s[Ms]) && u.apply(s);
      } : function() {
        return null;
      };
      function br(s, u) {
        var d = s.indexOf(u);
        return d >= 0 && s.splice(d, 1), d >= 0;
      }
      var Hr = {};
      function Dn(s) {
        var u, d, f, g;
        if (arguments.length === 1) {
          if (l(s))
            return s.slice();
          if (this === Hr && typeof s == "string")
            return [s];
          if (g = Ep(s)) {
            for (d = []; f = g.next(), !f.done; )
              d.push(f.value);
            return d;
          }
          if (s == null)
            return [s];
          if (u = s.length, typeof u == "number") {
            for (d = new Array(u); u--; )
              d[u] = s[u];
            return d;
          }
          return [s];
        }
        for (u = arguments.length, d = new Array(u); u--; )
          d[u] = arguments[u];
        return d;
      }
      var $s = typeof Symbol < "u" ? function(s) {
        return s[Symbol.toStringTag] === "AsyncFunction";
      } : function() {
        return !1;
      }, Sp = [
        "Modify",
        "Bulk",
        "OpenFailed",
        "VersionChange",
        "Schema",
        "Upgrade",
        "InvalidTable",
        "MissingAPI",
        "NoSuchDatabase",
        "InvalidArgument",
        "SubTransaction",
        "Unsupported",
        "Internal",
        "DatabaseClosed",
        "PrematureCommit",
        "ForeignAwait"
      ], gl = [
        "Unknown",
        "Constraint",
        "Data",
        "TransactionInactive",
        "ReadOnly",
        "Version",
        "NotFound",
        "InvalidState",
        "InvalidAccess",
        "Abort",
        "Timeout",
        "QuotaExceeded",
        "Syntax",
        "DataClone"
      ], Ns = Sp.concat(gl), Dp = {
        VersionChanged: "Database version changed by other database connection",
        DatabaseClosed: "Database has been closed",
        Abort: "Transaction aborted",
        TransactionInactive: "Transaction has already completed or failed",
        MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
      };
      function Qr(s, u) {
        this.name = s, this.message = u;
      }
      S(Qr).from(Error).extend({
        toString: function() {
          return this.name + ": " + this.message;
        }
      });
      function vl(s, u) {
        return s + ". Errors: " + Object.keys(u).map(function(d) {
          return u[d].toString();
        }).filter(function(d, f, g) {
          return g.indexOf(d) === f;
        }).join(`
`);
      }
      function na(s, u, d, f) {
        this.failures = u, this.failedKeys = f, this.successCount = d, this.message = vl(s, u);
      }
      S(na).from(Qr);
      function Xr(s, u) {
        this.name = "BulkError", this.failures = Object.keys(u).map(function(d) {
          return u[d];
        }), this.failuresByPos = u, this.message = vl(s, this.failures);
      }
      S(Xr).from(Qr);
      var js = Ns.reduce(function(s, u) {
        return s[u] = u + "Error", s;
      }, {}), Ip = Qr, ae = Ns.reduce(function(s, u) {
        var d = u + "Error";
        function f(g, b) {
          this.name = d, g ? typeof g == "string" ? (this.message = "".concat(g).concat(b ? `
 ` + b : ""), this.inner = b || null) : typeof g == "object" && (this.message = "".concat(g.name, " ").concat(g.message), this.inner = g) : (this.message = Dp[u] || d, this.inner = null);
        }
        return S(f).from(Ip), s[u] = f, s;
      }, {});
      ae.Syntax = SyntaxError, ae.Type = TypeError, ae.Range = RangeError;
      var yl = gl.reduce(function(s, u) {
        return s[u + "Error"] = ae[u], s;
      }, {});
      function zp(s, u) {
        if (!s || s instanceof Qr || s instanceof TypeError || s instanceof SyntaxError || !s.name || !yl[s.name])
          return s;
        var d = new yl[s.name](u || s.message, s);
        return "stack" in s && A(d, "stack", {
          get: function() {
            return this.inner.stack;
          }
        }), d;
      }
      var ra = Ns.reduce(function(s, u) {
        return ["Syntax", "Type", "Range"].indexOf(u) === -1 && (s[u + "Error"] = ae[u]), s;
      }, {});
      ra.ModifyError = na, ra.DexieError = Qr, ra.BulkError = Xr;
      function Se() {
      }
      function jo(s) {
        return s;
      }
      function Rp(s, u) {
        return s == null || s === jo ? u : function(d) {
          return u(s(d));
        };
      }
      function wr(s, u) {
        return function() {
          s.apply(this, arguments), u.apply(this, arguments);
        };
      }
      function xp(s, u) {
        return s === Se ? u : function() {
          var d = s.apply(this, arguments);
          d !== void 0 && (arguments[0] = d);
          var f = this.onsuccess, g = this.onerror;
          this.onsuccess = null, this.onerror = null;
          var b = u.apply(this, arguments);
          return f && (this.onsuccess = this.onsuccess ? wr(f, this.onsuccess) : f), g && (this.onerror = this.onerror ? wr(g, this.onerror) : g), b !== void 0 ? b : d;
        };
      }
      function Op(s, u) {
        return s === Se ? u : function() {
          s.apply(this, arguments);
          var d = this.onsuccess, f = this.onerror;
          this.onsuccess = this.onerror = null, u.apply(this, arguments), d && (this.onsuccess = this.onsuccess ? wr(d, this.onsuccess) : d), f && (this.onerror = this.onerror ? wr(f, this.onerror) : f);
        };
      }
      function Mp(s, u) {
        return s === Se ? u : function() {
          var d = s.apply(this, arguments), f = arguments[0];
          h(f, d);
          var g = this.onsuccess, b = this.onerror;
          this.onsuccess = null, this.onerror = null;
          var _ = u.apply(this, arguments);
          return g && (this.onsuccess = this.onsuccess ? wr(g, this.onsuccess) : g), b && (this.onerror = this.onerror ? wr(b, this.onerror) : b), d === void 0 ? _ === void 0 ? void 0 : _ : h(d, _);
        };
      }
      function $p(s, u) {
        return s === Se ? u : function() {
          return u.apply(this, arguments) === !1 ? !1 : s.apply(this, arguments);
        };
      }
      function Ls(s, u) {
        return s === Se ? u : function() {
          var d = s.apply(this, arguments);
          if (d && typeof d.then == "function") {
            for (var f = this, g = arguments.length, b = new Array(g); g--; )
              b[g] = arguments[g];
            return d.then(function() {
              return u.apply(f, b);
            });
          }
          return u.apply(this, arguments);
        };
      }
      var dn = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
      function bl(s, u) {
        dn = s;
      }
      var Lo = {}, wl = 100, Gs = typeof Promise > "u" ? [] : (function() {
        var s = Promise.resolve();
        if (typeof crypto > "u" || !crypto.subtle)
          return [s, m(s), s];
        var u = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
        return [u, m(u), s];
      })(), kl = Gs[0], _l = Gs[1], Np = Gs[2], jp = _l && _l.then, kr = kl && kl.constructor, Fs = !!Np;
      function Lp() {
        queueMicrotask(Fp);
      }
      var Go = function(s, u) {
        Fo.push([s, u]), oa && (Lp(), oa = !1);
      }, Us = !0, oa = !0, _r = [], ia = [], Zs = jo, In = {
        id: "global",
        global: !0,
        ref: 0,
        unhandleds: [],
        onunhandled: Se,
        pgp: !1,
        env: {},
        finalize: Se
      }, ee = In, Fo = [], Tr = 0, aa = [];
      function Q(s) {
        if (typeof this != "object")
          throw new TypeError("Promises must be constructed via new");
        this._listeners = [], this._lib = !1;
        var u = this._PSD = ee;
        if (typeof s != "function") {
          if (s !== Lo)
            throw new TypeError("Not a function");
          this._state = arguments[1], this._value = arguments[2], this._state === !1 && Ks(this, this._value);
          return;
        }
        this._state = null, this._value = null, ++u.ref, Cl(this, s);
      }
      var qs = {
        get: function() {
          var s = ee, u = la;
          function d(f, g) {
            var b = this, _ = !s.global && (s !== ee || u !== la), T = _ && !Hn(), C = new Q(function(E, D) {
              Ws(b, new Tl(El(f, s, _, T), El(g, s, _, T), E, D, s));
            });
            return this._consoleTask && (C._consoleTask = this._consoleTask), C;
          }
          return d.prototype = Lo, d;
        },
        set: function(s) {
          A(this, "then", s && s.prototype === Lo ? qs : {
            get: function() {
              return s;
            },
            set: qs.set
          });
        }
      };
      k(Q.prototype, {
        then: qs,
        _then: function(s, u) {
          Ws(this, new Tl(null, null, s, u, ee));
        },
        catch: function(s) {
          if (arguments.length === 1)
            return this.then(null, s);
          var u = arguments[0], d = arguments[1];
          return typeof u == "function" ? this.then(null, function(f) {
            return f instanceof u ? d(f) : sa(f);
          }) : this.then(null, function(f) {
            return f && f.name === u ? d(f) : sa(f);
          });
        },
        finally: function(s) {
          return this.then(function(u) {
            return Q.resolve(s()).then(function() {
              return u;
            });
          }, function(u) {
            return Q.resolve(s()).then(function() {
              return sa(u);
            });
          });
        },
        timeout: function(s, u) {
          var d = this;
          return s < 1 / 0 ? new Q(function(f, g) {
            var b = setTimeout(function() {
              return g(new ae.Timeout(u));
            }, s);
            d.then(f, g).finally(clearTimeout.bind(null, b));
          }) : this;
        }
      }), typeof Symbol < "u" && Symbol.toStringTag && A(Q.prototype, Symbol.toStringTag, "Dexie.Promise"), In.env = Al();
      function Tl(s, u, d, f, g) {
        this.onFulfilled = typeof s == "function" ? s : null, this.onRejected = typeof u == "function" ? u : null, this.resolve = d, this.reject = f, this.psd = g;
      }
      k(Q, {
        all: function() {
          var s = Dn.apply(null, arguments).map(da);
          return new Q(function(u, d) {
            s.length === 0 && u([]);
            var f = s.length;
            s.forEach(function(g, b) {
              return Q.resolve(g).then(function(_) {
                s[b] = _, --f || u(s);
              }, d);
            });
          });
        },
        resolve: function(s) {
          if (s instanceof Q)
            return s;
          if (s && typeof s.then == "function")
            return new Q(function(d, f) {
              s.then(d, f);
            });
          var u = new Q(Lo, !0, s);
          return u;
        },
        reject: sa,
        race: function() {
          var s = Dn.apply(null, arguments).map(da);
          return new Q(function(u, d) {
            s.map(function(f) {
              return Q.resolve(f).then(u, d);
            });
          });
        },
        PSD: {
          get: function() {
            return ee;
          },
          set: function(s) {
            return ee = s;
          }
        },
        totalEchoes: { get: function() {
          return la;
        } },
        newPSD: Bn,
        usePSD: Cr,
        scheduler: {
          get: function() {
            return Go;
          },
          set: function(s) {
            Go = s;
          }
        },
        rejectionMapper: {
          get: function() {
            return Zs;
          },
          set: function(s) {
            Zs = s;
          }
        },
        follow: function(s, u) {
          return new Q(function(d, f) {
            return Bn(function(g, b) {
              var _ = ee;
              _.unhandleds = [], _.onunhandled = b, _.finalize = wr(function() {
                var T = this;
                Up(function() {
                  T.unhandleds.length === 0 ? g() : b(T.unhandleds[0]);
                });
              }, _.finalize), s();
            }, u, d, f);
          });
        }
      }), kr && (kr.allSettled && A(Q, "allSettled", function() {
        var s = Dn.apply(null, arguments).map(da);
        return new Q(function(u) {
          s.length === 0 && u([]);
          var d = s.length, f = new Array(d);
          s.forEach(function(g, b) {
            return Q.resolve(g).then(function(_) {
              return f[b] = { status: "fulfilled", value: _ };
            }, function(_) {
              return f[b] = { status: "rejected", reason: _ };
            }).then(function() {
              return --d || u(f);
            });
          });
        });
      }), kr.any && typeof AggregateError < "u" && A(Q, "any", function() {
        var s = Dn.apply(null, arguments).map(da);
        return new Q(function(u, d) {
          s.length === 0 && d(new AggregateError([]));
          var f = s.length, g = new Array(f);
          s.forEach(function(b, _) {
            return Q.resolve(b).then(function(T) {
              return u(T);
            }, function(T) {
              g[_] = T, --f || d(new AggregateError(g));
            });
          });
        });
      }), kr.withResolvers && (Q.withResolvers = kr.withResolvers));
      function Cl(s, u) {
        try {
          u(function(d) {
            if (s._state === null) {
              if (d === s)
                throw new TypeError("A promise cannot be resolved with itself.");
              var f = s._lib && Jr();
              d && typeof d.then == "function" ? Cl(s, function(g, b) {
                d instanceof Q ? d._then(g, b) : d.then(g, b);
              }) : (s._state = !0, s._value = d, Pl(s)), f && eo();
            }
          }, Ks.bind(null, s));
        } catch (d) {
          Ks(s, d);
        }
      }
      function Ks(s, u) {
        if (ia.push(u), s._state === null) {
          var d = s._lib && Jr();
          u = Zs(u), s._state = !1, s._value = u, Zp(s), Pl(s), d && eo();
        }
      }
      function Pl(s) {
        var u = s._listeners;
        s._listeners = [];
        for (var d = 0, f = u.length; d < f; ++d)
          Ws(s, u[d]);
        var g = s._PSD;
        --g.ref || g.finalize(), Tr === 0 && (++Tr, Go(function() {
          --Tr === 0 && Ys();
        }, []));
      }
      function Ws(s, u) {
        if (s._state === null) {
          s._listeners.push(u);
          return;
        }
        var d = s._state ? u.onFulfilled : u.onRejected;
        if (d === null)
          return (s._state ? u.resolve : u.reject)(s._value);
        ++u.psd.ref, ++Tr, Go(Gp, [d, s, u]);
      }
      function Gp(s, u, d) {
        try {
          var f, g = u._value;
          !u._state && ia.length && (ia = []), f = dn && u._consoleTask ? u._consoleTask.run(function() {
            return s(g);
          }) : s(g), !u._state && ia.indexOf(g) === -1 && qp(u), d.resolve(f);
        } catch (b) {
          d.reject(b);
        } finally {
          --Tr === 0 && Ys(), --d.psd.ref || d.psd.finalize();
        }
      }
      function Fp() {
        Cr(In, function() {
          Jr() && eo();
        });
      }
      function Jr() {
        var s = Us;
        return Us = !1, oa = !1, s;
      }
      function eo() {
        var s, u, d;
        do
          for (; Fo.length > 0; )
            for (s = Fo, Fo = [], d = s.length, u = 0; u < d; ++u) {
              var f = s[u];
              f[0].apply(null, f[1]);
            }
        while (Fo.length > 0);
        Us = !0, oa = !0;
      }
      function Ys() {
        var s = _r;
        _r = [], s.forEach(function(f) {
          f._PSD.onunhandled.call(null, f._value, f);
        });
        for (var u = aa.slice(0), d = u.length; d; )
          u[--d]();
      }
      function Up(s) {
        function u() {
          s(), aa.splice(aa.indexOf(u), 1);
        }
        aa.push(u), ++Tr, Go(function() {
          --Tr === 0 && Ys();
        }, []);
      }
      function Zp(s) {
        _r.some(function(u) {
          return u._value === s._value;
        }) || _r.push(s);
      }
      function qp(s) {
        for (var u = _r.length; u; )
          if (_r[--u]._value === s._value) {
            _r.splice(u, 1);
            return;
          }
      }
      function sa(s) {
        return new Q(Lo, !1, s);
      }
      function Oe(s, u) {
        var d = ee;
        return function() {
          var f = Jr(), g = ee;
          try {
            return Qn(d, !0), s.apply(this, arguments);
          } catch (b) {
            u && u(b);
          } finally {
            Qn(g, !1), f && eo();
          }
        };
      }
      var Qe = { awaits: 0, echoes: 0, id: 0 }, Kp = 0, ua = [], ca = 0, la = 0, Wp = 0;
      function Bn(s, u, d, f) {
        var g = ee, b = Object.create(g);
        b.parent = g, b.ref = 0, b.global = !1, b.id = ++Wp, In.env, b.env = Fs ? {
          Promise: Q,
          PromiseProp: {
            value: Q,
            configurable: !0,
            writable: !0
          },
          all: Q.all,
          race: Q.race,
          allSettled: Q.allSettled,
          any: Q.any,
          resolve: Q.resolve,
          reject: Q.reject
        } : {}, u && h(b, u), ++g.ref, b.finalize = function() {
          --this.parent.ref || this.parent.finalize();
        };
        var _ = Cr(b, s, d, f);
        return b.ref === 0 && b.finalize(), _;
      }
      function to() {
        return Qe.id || (Qe.id = ++Kp), ++Qe.awaits, Qe.echoes += wl, Qe.id;
      }
      function Hn() {
        return Qe.awaits ? (--Qe.awaits === 0 && (Qe.id = 0), Qe.echoes = Qe.awaits * wl, !0) : !1;
      }
      ("" + jp).indexOf("[native code]") === -1 && (to = Hn = Se);
      function da(s) {
        return Qe.echoes && s && s.constructor === kr ? (to(), s.then(function(u) {
          return Hn(), u;
        }, function(u) {
          return Hn(), Ke(u);
        })) : s;
      }
      function Yp(s) {
        ++la, (!Qe.echoes || --Qe.echoes === 0) && (Qe.echoes = Qe.awaits = Qe.id = 0), ua.push(ee), Qn(s, !0);
      }
      function Vp() {
        var s = ua[ua.length - 1];
        ua.pop(), Qn(s, !1);
      }
      function Qn(s, u) {
        var d = ee;
        if ((u ? Qe.echoes && (!ca++ || s !== ee) : ca && (!--ca || s !== ee)) && queueMicrotask(u ? Yp.bind(null, s) : Vp), s !== ee && (ee = s, d === In && (In.env = Al()), Fs)) {
          var f = In.env.Promise, g = s.env;
          (d.global || s.global) && (Object.defineProperty(a, "Promise", g.PromiseProp), f.all = g.all, f.race = g.race, f.resolve = g.resolve, f.reject = g.reject, g.allSettled && (f.allSettled = g.allSettled), g.any && (f.any = g.any));
        }
      }
      function Al() {
        var s = a.Promise;
        return Fs ? {
          Promise: s,
          PromiseProp: Object.getOwnPropertyDescriptor(a, "Promise"),
          all: s.all,
          race: s.race,
          allSettled: s.allSettled,
          any: s.any,
          resolve: s.resolve,
          reject: s.reject
        } : {};
      }
      function Cr(s, u, d, f, g) {
        var b = ee;
        try {
          return Qn(s, !0), u(d, f, g);
        } finally {
          Qn(b, !1);
        }
      }
      function El(s, u, d, f) {
        return typeof s != "function" ? s : function() {
          var g = ee;
          d && to(), Qn(u, !0);
          try {
            return s.apply(this, arguments);
          } finally {
            Qn(g, !1), f && queueMicrotask(Hn);
          }
        };
      }
      function Vs(s) {
        Promise === kr && Qe.echoes === 0 ? ca === 0 ? s() : enqueueNativeMicroTask(s) : setTimeout(s, 0);
      }
      var Ke = Q.reject;
      function Bs(s, u, d, f) {
        if (!s.idbdb || !s._state.openComplete && !ee.letThrough && !s._vip) {
          if (s._state.openComplete)
            return Ke(new ae.DatabaseClosed(s._state.dbOpenError));
          if (!s._state.isBeingOpened) {
            if (!s._state.autoOpen)
              return Ke(new ae.DatabaseClosed());
            s.open().catch(Se);
          }
          return s._state.dbReadyPromise.then(function() {
            return Bs(s, u, d, f);
          });
        } else {
          var g = s._createTransaction(u, d, s._dbSchema);
          try {
            g.create(), s._state.PR1398_maxLoop = 3;
          } catch (b) {
            return b.name === js.InvalidState && s.isOpen() && --s._state.PR1398_maxLoop > 0 ? (console.warn("Dexie: Need to reopen db"), s.close({ disableAutoOpen: !1 }), s.open().then(function() {
              return Bs(s, u, d, f);
            })) : Ke(b);
          }
          return g._promise(u, function(b, _) {
            return Bn(function() {
              return ee.trans = g, f(b, _, g);
            });
          }).then(function(b) {
            if (u === "readwrite")
              try {
                g.idbtrans.commit();
              } catch {
              }
            return u === "readonly" ? b : g._completion.then(function() {
              return b;
            });
          });
        }
      }
      var Sl = "4.4.7", Pr = "￿", Hs = -1 / 0, zn = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", Dl = "String expected.", Il = 1e3, ha = "__dbnames", Qs = "readonly", Xs = "readwrite";
      function Ar(s, u) {
        return s ? u ? function() {
          return s.apply(this, arguments) && u.apply(this, arguments);
        } : s : u;
      }
      var zl = {
        type: 3,
        lower: -1 / 0,
        lowerOpen: !1,
        upper: [[]],
        upperOpen: !1
      };
      function fa(s) {
        return typeof s == "string" && !/\./.test(s) ? function(u) {
          return u[s] === void 0 && s in u && (u = Sn(u), delete u[s]), u;
        } : function(u) {
          return u;
        };
      }
      function Rl() {
        throw ae.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
      }
      function we(s, u) {
        try {
          var d = xl(s), f = xl(u);
          if (d !== f)
            return d === "Array" ? 1 : f === "Array" ? -1 : d === "binary" ? 1 : f === "binary" ? -1 : d === "string" ? 1 : f === "string" ? -1 : d === "Date" ? 1 : f !== "Date" ? NaN : -1;
          switch (d) {
            case "number":
            case "Date":
            case "string":
              return s > u ? 1 : s < u ? -1 : 0;
            case "binary":
              return Hp(Ol(s), Ol(u));
            case "Array":
              return Bp(s, u);
          }
        } catch {
        }
        return NaN;
      }
      function Bp(s, u) {
        for (var d = s.length, f = u.length, g = d < f ? d : f, b = 0; b < g; ++b) {
          var _ = we(s[b], u[b]);
          if (_ !== 0)
            return _;
        }
        return d === f ? 0 : d < f ? -1 : 1;
      }
      function Hp(s, u) {
        for (var d = s.length, f = u.length, g = d < f ? d : f, b = 0; b < g; ++b)
          if (s[b] !== u[b])
            return s[b] < u[b] ? -1 : 1;
        return d === f ? 0 : d < f ? -1 : 1;
      }
      function xl(s) {
        var u = typeof s;
        if (u !== "object")
          return u;
        if (ArrayBuffer.isView(s))
          return "binary";
        var d = Os(s);
        return d === "ArrayBuffer" ? "binary" : d;
      }
      function Ol(s) {
        return s instanceof Uint8Array ? s : ArrayBuffer.isView(s) ? new Uint8Array(s.buffer, s.byteOffset, s.byteLength) : new Uint8Array(s);
      }
      function ma(s, u, d) {
        var f = s.schema.yProps;
        return f ? (u && d.numFailures > 0 && (u = u.filter(function(g, b) {
          return !d.failures[b];
        })), Promise.all(f.map(function(g) {
          var b = g.updatesTable;
          return u ? s.db.table(b).where("k").anyOf(u).delete() : s.db.table(b).clear();
        })).then(function() {
          return d;
        })) : d;
      }
      var Uo = (function() {
        function s(u) {
          this["@@propmod"] = u;
        }
        return s.prototype.execute = function(u) {
          var d, f = this["@@propmod"];
          if (f.add !== void 0) {
            var g = f.add;
            if (l(g))
              return i(i([], l(u) ? u : [], !0), g).sort();
            if (typeof g == "number")
              return (Number(u) || 0) + g;
            if (typeof g == "bigint")
              try {
                return BigInt(u) + g;
              } catch {
                return BigInt(0) + g;
              }
            throw new TypeError("Invalid term ".concat(g));
          }
          if (f.remove !== void 0) {
            var b = f.remove;
            if (l(b))
              return l(u) ? u.filter(function(T) {
                return !b.includes(T);
              }).sort() : [];
            if (typeof b == "number")
              return Number(u) - b;
            if (typeof b == "bigint")
              try {
                return BigInt(u) - b;
              } catch {
                return BigInt(0) - b;
              }
            throw new TypeError("Invalid subtrahend ".concat(b));
          }
          var _ = (d = f.replacePrefix) === null || d === void 0 ? void 0 : d[0];
          return _ && typeof u == "string" && u.startsWith(_) ? f.replacePrefix[1] + u.substring(_.length) : u;
        }, s;
      })();
      function Ml(s, u) {
        for (var d = c(u), f = d.length, g = !1, b = 0; b < f; ++b) {
          var _ = d[b], T = u[_], C = he(s, _);
          T instanceof Uo ? (_e(s, _, T.execute(C)), g = !0) : C !== T && (_e(s, _, T), g = !0);
        }
        return g;
      }
      var $l = (function() {
        function s() {
        }
        return s.prototype._trans = function(u, d, f) {
          var g = this._tx || ee.trans, b = this.name, _ = dn && typeof console < "u" && console.createTask && console.createTask("Dexie: ".concat(u === "readonly" ? "read" : "write", " ").concat(this.name));
          function T(D, x, O) {
            if (!O.schema[b])
              throw new ae.NotFound("Table " + b + " not part of transaction");
            return d(O.idbtrans, O);
          }
          var C = Jr();
          try {
            var E = g && g.db._novip === this.db._novip ? g === ee.trans ? g._promise(u, T, f) : Bn(function() {
              return g._promise(u, T, f);
            }, { trans: g, transless: ee.transless || ee }) : Bs(this.db, u, [this.name], T);
            return _ && (E._consoleTask = _, E = E.catch(function(D) {
              return console.trace(D), Ke(D);
            })), E;
          } finally {
            C && eo();
          }
        }, s.prototype.get = function(u, d) {
          var f = this;
          return u && u.constructor === Object ? this.where(u).first(d) : u == null ? Ke(new ae.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(g) {
            return f.core.get({ trans: g, key: u }).then(function(b) {
              return f.hook.reading.fire(b);
            });
          }).then(d);
        }, s.prototype.where = function(u) {
          if (typeof u == "string")
            return new this.db.WhereClause(this, u);
          if (l(u))
            return new this.db.WhereClause(this, "[".concat(u.join("+"), "]"));
          var d = c(u);
          if (d.length === 1)
            return this.where(d[0]).equals(u[d[0]]);
          var f = this.schema.indexes.concat(this.schema.primKey).filter(function(D) {
            if (D.compound && d.every(function(O) {
              return D.keyPath.indexOf(O) >= 0;
            })) {
              for (var x = 0; x < d.length; ++x)
                if (d.indexOf(D.keyPath[x]) === -1)
                  return !1;
              return !0;
            }
            return !1;
          }).sort(function(D, x) {
            return D.keyPath.length - x.keyPath.length;
          })[0];
          if (f && this.db._maxKey !== Pr) {
            var g = f.keyPath.slice(0, d.length);
            return this.where(g).equals(g.map(function(D) {
              return u[D];
            }));
          }
          !f && dn && console.warn("The query ".concat(JSON.stringify(u), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(d.join("+"), "]"));
          var b = this.schema.idxByName;
          function _(D, x) {
            return we(D, x) === 0;
          }
          var T = d.reduce(function(D, x) {
            var O = D[0], U = D[1], I = b[x], R = u[x];
            return [
              O || I,
              O || !I ? Ar(U, I && I.multi ? function(N) {
                var $ = he(N, x);
                return l($) && $.some(function(q) {
                  return _(R, q);
                });
              } : function(N) {
                return _(R, he(N, x));
              }) : U
            ];
          }, [null, null]), C = T[0], E = T[1];
          return C ? this.where(C.name).equals(u[C.keyPath]).filter(E) : f ? this.filter(E) : this.where(d).equals("");
        }, s.prototype.filter = function(u) {
          return this.toCollection().and(u);
        }, s.prototype.count = function(u) {
          return this.toCollection().count(u);
        }, s.prototype.offset = function(u) {
          return this.toCollection().offset(u);
        }, s.prototype.limit = function(u) {
          return this.toCollection().limit(u);
        }, s.prototype.each = function(u) {
          return this.toCollection().each(u);
        }, s.prototype.toArray = function(u) {
          return this.toCollection().toArray(u);
        }, s.prototype.toCollection = function() {
          return new this.db.Collection(new this.db.WhereClause(this));
        }, s.prototype.orderBy = function(u) {
          return new this.db.Collection(new this.db.WhereClause(this, l(u) ? "[".concat(u.join("+"), "]") : u));
        }, s.prototype.reverse = function() {
          return this.toCollection().reverse();
        }, s.prototype.mapToClass = function(u) {
          var d = this, f = d.db, g = d.name;
          this.schema.mappedClass = u, u.prototype instanceof Rl && (u = (function(C) {
            r(E, C);
            function E() {
              return C !== null && C.apply(this, arguments) || this;
            }
            return Object.defineProperty(E.prototype, "db", {
              get: function() {
                return f;
              },
              enumerable: !1,
              configurable: !0
            }), E.prototype.table = function() {
              return g;
            }, E;
          })(u));
          for (var b = /* @__PURE__ */ new Set(), _ = u.prototype; _; _ = m(_))
            Object.getOwnPropertyNames(_).forEach(function(C) {
              return b.add(C);
            });
          var T = function(C) {
            if (!C)
              return C;
            var E = Object.create(u.prototype);
            for (var D in C)
              if (!b.has(D))
                try {
                  E[D] = C[D];
                } catch {
                }
            return E;
          };
          return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = T, this.hook("reading", T), u;
        }, s.prototype.defineClass = function() {
          function u(d) {
            h(this, d);
          }
          return this.mapToClass(u);
        }, s.prototype.add = function(u, d) {
          var f = this, g = this.schema.primKey, b = g.auto, _ = g.keyPath, T = u;
          return _ && b && (T = fa(_)(u)), this._trans("readwrite", function(C) {
            return f.core.mutate({
              trans: C,
              type: "add",
              keys: d != null ? [d] : null,
              values: [T]
            });
          }).then(function(C) {
            return C.numFailures ? Q.reject(C.failures[0]) : C.lastResult;
          }).then(function(C) {
            if (_)
              try {
                _e(u, _, C);
              } catch {
              }
            return C;
          });
        }, s.prototype.upsert = function(u, d) {
          var f = this, g = this.schema.primKey.keyPath;
          return this._trans("readwrite", function(b) {
            return f.core.get({ trans: b, key: u }).then(function(_) {
              var T = _ ?? {};
              return Ml(T, d), g && _e(T, g, u), f.core.mutate({
                trans: b,
                type: "put",
                values: [T],
                keys: [u],
                upsert: !0,
                updates: { keys: [u], changeSpecs: [d] }
              }).then(function(C) {
                return C.numFailures ? Q.reject(C.failures[0]) : !!_;
              });
            });
          });
        }, s.prototype.update = function(u, d) {
          if (typeof u == "object" && !l(u)) {
            var f = he(u, this.schema.primKey.keyPath);
            return f === void 0 ? Ke(new ae.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(f).modify(d);
          } else
            return this.where(":id").equals(u).modify(d);
        }, s.prototype.put = function(u, d) {
          var f = this, g = this.schema.primKey, b = g.auto, _ = g.keyPath, T = u;
          return _ && b && (T = fa(_)(u)), this._trans("readwrite", function(C) {
            return f.core.mutate({
              trans: C,
              type: "put",
              values: [T],
              keys: d != null ? [d] : null
            });
          }).then(function(C) {
            return C.numFailures ? Q.reject(C.failures[0]) : C.lastResult;
          }).then(function(C) {
            if (_)
              try {
                _e(u, _, C);
              } catch {
              }
            return C;
          });
        }, s.prototype.delete = function(u) {
          var d = this;
          return this._trans("readwrite", function(f) {
            return d.core.mutate({ trans: f, type: "delete", keys: [u] }).then(function(g) {
              return ma(d, [u], g);
            }).then(function(g) {
              return g.numFailures ? Q.reject(g.failures[0]) : void 0;
            });
          });
        }, s.prototype.clear = function() {
          var u = this;
          return this._trans("readwrite", function(d) {
            return u.core.mutate({ trans: d, type: "deleteRange", range: zl }).then(function(f) {
              return ma(u, null, f);
            });
          }).then(function(d) {
            return d.numFailures ? Q.reject(d.failures[0]) : void 0;
          });
        }, s.prototype.bulkGet = function(u) {
          var d = this;
          return this._trans("readonly", function(f) {
            return d.core.getMany({
              keys: u,
              trans: f
            }).then(function(g) {
              return g.map(function(b) {
                return d.hook.reading.fire(b);
              });
            });
          });
        }, s.prototype.bulkAdd = function(u, d, f) {
          var g = this, b = Array.isArray(d) ? d : void 0;
          f = f || (b ? void 0 : d);
          var _ = f ? f.allKeys : void 0;
          return this._trans("readwrite", function(T) {
            var C = g.schema.primKey, E = C.auto, D = C.keyPath;
            if (D && b)
              throw new ae.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
            if (b && b.length !== u.length)
              throw new ae.InvalidArgument("Arguments objects and keys must have the same length");
            var x = u.length, O = D && E ? u.map(fa(D)) : u;
            return g.core.mutate({
              trans: T,
              type: "add",
              keys: b,
              values: O,
              wantResults: _
            }).then(function(U) {
              var I = U.numFailures, R = U.results, N = U.lastResult, $ = U.failures, q = _ ? R : N;
              if (I === 0)
                return q;
              throw new Xr("".concat(g.name, ".bulkAdd(): ").concat(I, " of ").concat(x, " operations failed"), $);
            });
          });
        }, s.prototype.bulkPut = function(u, d, f) {
          var g = this, b = Array.isArray(d) ? d : void 0;
          f = f || (b ? void 0 : d);
          var _ = f ? f.allKeys : void 0;
          return this._trans("readwrite", function(T) {
            var C = g.schema.primKey, E = C.auto, D = C.keyPath;
            if (D && b)
              throw new ae.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
            if (b && b.length !== u.length)
              throw new ae.InvalidArgument("Arguments objects and keys must have the same length");
            var x = u.length, O = D && E ? u.map(fa(D)) : u;
            return g.core.mutate({
              trans: T,
              type: "put",
              keys: b,
              values: O,
              wantResults: _
            }).then(function(U) {
              var I = U.numFailures, R = U.results, N = U.lastResult, $ = U.failures, q = _ ? R : N;
              if (I === 0)
                return q;
              throw new Xr("".concat(g.name, ".bulkPut(): ").concat(I, " of ").concat(x, " operations failed"), $);
            });
          });
        }, s.prototype.bulkUpdate = function(u) {
          var d = this, f = u.map(function(_) {
            return _.key;
          }), g = u.map(function(_) {
            return _.changes;
          }), b = [];
          return this._trans("readwrite", function(_) {
            var T = d.core;
            return T.getMany({ trans: _, keys: f, cache: "clone" }).then(function(C) {
              var E = T.schema.primaryKey, D = E.outbound, x = E.extractKey, O = [], U = [];
              u.forEach(function(R, N) {
                var $ = R.key, q = R.changes, Z = C[N];
                if (Z) {
                  for (var j = 0, G = Object.keys(q); j < G.length; j++) {
                    var B = G[j];
                    _e(Z, B, q[B]);
                  }
                  if (!D && we(x(Z), $) !== 0)
                    throw new ae.Constraint("Cannot update primary key in bulkUpdate()");
                  b.push(N), O.push($), U.push(Z);
                }
              });
              var I = O.length;
              return T.mutate({
                trans: _,
                type: "put",
                keys: O,
                values: U,
                updates: {
                  keys: f,
                  changeSpecs: g
                }
              }).then(function(R) {
                var N = R.numFailures, $ = R.failures;
                if (N === 0)
                  return I;
                for (var q = 0, Z = Object.keys($); q < Z.length; q++) {
                  var j = Z[q], G = b[Number(j)];
                  if (G != null) {
                    var B = $[j];
                    delete $[j], $[G] = B;
                  }
                }
                throw new Xr("".concat(d.name, ".bulkUpdate(): ").concat(N, " of ").concat(I, " operations failed"), $);
              });
            });
          });
        }, s.prototype.bulkDelete = function(u) {
          var d = this, f = u.length;
          return this._trans("readwrite", function(g) {
            return d.core.mutate({ trans: g, type: "delete", keys: u }).then(function(b) {
              return ma(d, u, b);
            });
          }).then(function(g) {
            var b = g.numFailures, _ = g.lastResult, T = g.failures;
            if (b === 0)
              return _;
            throw new Xr("".concat(d.name, ".bulkDelete(): ").concat(b, " of ").concat(f, " operations failed"), T);
          });
        }, s;
      })();
      function Zo(s) {
        var u = {}, d = function(T, C) {
          if (C) {
            for (var E = arguments.length, D = new Array(E - 1); --E; )
              D[E - 1] = arguments[E];
            return u[T].subscribe.apply(null, D), s;
          } else if (typeof T == "string")
            return u[T];
        };
        d.addEventType = b;
        for (var f = 1, g = arguments.length; f < g; ++f)
          b(arguments[f]);
        return d;
        function b(T, C, E) {
          if (typeof T == "object")
            return _(T);
          C || (C = $p), E || (E = Se);
          var D = {
            subscribers: [],
            fire: E,
            subscribe: function(x) {
              D.subscribers.indexOf(x) === -1 && (D.subscribers.push(x), D.fire = C(D.fire, x));
            },
            unsubscribe: function(x) {
              D.subscribers = D.subscribers.filter(function(O) {
                return O !== x;
              }), D.fire = D.subscribers.reduce(C, E);
            }
          };
          return u[T] = d[T] = D, D;
        }
        function _(T) {
          c(T).forEach(function(C) {
            var E = T[C];
            if (l(E))
              b(C, T[C][0], T[C][1]);
            else if (E === "asap")
              var D = b(C, jo, function() {
                for (var O = arguments.length, U = new Array(O); O--; )
                  U[O] = arguments[O];
                D.subscribers.forEach(function(I) {
                  ye(function() {
                    I.apply(null, U);
                  });
                });
              });
            else
              throw new ae.InvalidArgument("Invalid event config");
          });
        }
      }
      function qo(s, u) {
        return S(u).from({ prototype: s }), u;
      }
      function Qp(s) {
        return qo($l.prototype, function(d, f, g) {
          this.db = s, this._tx = g, this.name = d, this.schema = f, this.hook = s._allTables[d] ? s._allTables[d].hook : Zo(null, {
            creating: [xp, Se],
            reading: [Rp, jo],
            updating: [Mp, Se],
            deleting: [Op, Se]
          });
        });
      }
      function no(s, u) {
        return !(s.filter || s.algorithm || s.or) && (u ? s.justLimit : !s.replayFilter);
      }
      function Js(s, u) {
        s.filter = Ar(s.filter, u);
      }
      function eu(s, u, d) {
        var f = s.replayFilter;
        s.replayFilter = f ? function() {
          return Ar(f(), u());
        } : u, s.justLimit = d && !f;
      }
      function Xp(s, u) {
        s.isMatch = Ar(s.isMatch, u);
      }
      function pa(s, u) {
        if (s.isPrimKey)
          return u.primaryKey;
        var d = u.getIndexByKeyPath(s.index);
        if (!d)
          throw new ae.Schema("KeyPath " + s.index + " on object store " + u.name + " is not indexed");
        return d;
      }
      function Nl(s, u, d) {
        var f = pa(s, u.schema);
        return u.openCursor({
          trans: d,
          values: !s.keysOnly,
          reverse: s.dir === "prev",
          unique: !!s.unique,
          query: {
            index: f,
            range: s.range
          }
        });
      }
      function ga(s, u, d, f) {
        var g = s.replayFilter ? Ar(s.filter, s.replayFilter()) : s.filter;
        if (s.or) {
          var b = {}, _ = function(T, C, E) {
            if (!g || g(C, E, function(O) {
              return C.stop(O);
            }, function(O) {
              return C.fail(O);
            })) {
              var D = C.primaryKey, x = "" + D;
              x === "[object ArrayBuffer]" && (x = "" + new Uint8Array(D)), v(b, x) || (b[x] = !0, u(T, C, E));
            }
          };
          return Promise.all([
            s.or._iterate(_, d),
            jl(Nl(s, f, d), s.algorithm, _, !s.keysOnly && s.valueMapper)
          ]);
        } else
          return jl(Nl(s, f, d), Ar(s.algorithm, g), u, !s.keysOnly && s.valueMapper);
      }
      function jl(s, u, d, f) {
        var g = f ? function(_, T, C) {
          return d(f(_), T, C);
        } : d, b = Oe(g);
        return s.then(function(_) {
          if (_)
            return _.start(function() {
              var T = function() {
                return _.continue();
              };
              (!u || u(_, function(C) {
                return T = C;
              }, function(C) {
                _.stop(C), T = Se;
              }, function(C) {
                _.fail(C), T = Se;
              })) && b(_.value, _, function(C) {
                return T = C;
              }), T();
            });
        });
      }
      var Jp = (function() {
        function s() {
        }
        return s.prototype._read = function(u, d) {
          var f = this._ctx;
          return f.error ? f.table._trans(null, Ke.bind(null, f.error)) : f.table._trans("readonly", u).then(d);
        }, s.prototype._write = function(u) {
          var d = this._ctx;
          return d.error ? d.table._trans(null, Ke.bind(null, d.error)) : d.table._trans("readwrite", u, "locked");
        }, s.prototype._addAlgorithm = function(u) {
          var d = this._ctx;
          d.algorithm = Ar(d.algorithm, u);
        }, s.prototype._iterate = function(u, d) {
          return ga(this._ctx, u, d, this._ctx.table.core);
        }, s.prototype.clone = function(u) {
          var d = Object.create(this.constructor.prototype), f = Object.create(this._ctx);
          return u && h(f, u), d._ctx = f, d;
        }, s.prototype.raw = function() {
          return this._ctx.valueMapper = null, this;
        }, s.prototype.each = function(u) {
          var d = this._ctx;
          return this._read(function(f) {
            return ga(d, u, f, d.table.core);
          });
        }, s.prototype.count = function(u) {
          var d = this;
          return this._read(function(f) {
            var g = d._ctx, b = g.table.core;
            if (no(g, !0))
              return b.count({
                trans: f,
                query: {
                  index: pa(g, b.schema),
                  range: g.range
                }
              }).then(function(T) {
                return Math.min(T, g.limit);
              });
            var _ = 0;
            return ga(g, function() {
              return ++_, !1;
            }, f, b).then(function() {
              return _;
            });
          }).then(u);
        }, s.prototype.sortBy = function(u, d) {
          var f = u.split(".").reverse(), g = f[0], b = f.length - 1;
          function _(E, D) {
            return D ? _(E[f[D]], D - 1) : E[g];
          }
          var T = this._ctx.dir === "next" ? 1 : -1;
          function C(E, D) {
            var x = _(E, b), O = _(D, b);
            return we(x, O) * T;
          }
          return this.toArray(function(E) {
            return E.slice().sort(C);
          }).then(d);
        }, s.prototype.toArray = function(u) {
          var d = this;
          return this._read(function(f) {
            var g = d._ctx;
            if (no(g, !0) && g.limit > 0) {
              var b = g.valueMapper, _ = pa(g, g.table.core.schema);
              return g.table.core.query({
                trans: f,
                limit: g.limit,
                values: !0,
                direction: g.dir === "prev" ? "prev" : void 0,
                query: {
                  index: _,
                  range: g.range
                }
              }).then(function(C) {
                var E = C.result;
                return b ? E.map(b) : E;
              });
            } else {
              var T = [];
              return ga(g, function(C) {
                return T.push(C);
              }, f, g.table.core).then(function() {
                return T;
              });
            }
          }, u);
        }, s.prototype.offset = function(u) {
          var d = this._ctx;
          return u <= 0 ? this : (d.offset += u, no(d) ? eu(d, function() {
            var f = u;
            return function(g, b) {
              return f === 0 ? !0 : f === 1 ? (--f, !1) : (b(function() {
                g.advance(f), f = 0;
              }), !1);
            };
          }) : eu(d, function() {
            var f = u;
            return function() {
              return --f < 0;
            };
          }), this);
        }, s.prototype.limit = function(u) {
          return this._ctx.limit = Math.min(this._ctx.limit, u), eu(this._ctx, function() {
            var d = u;
            return function(f, g, b) {
              return --d <= 0 && g(b), d >= 0;
            };
          }, !0), this;
        }, s.prototype.until = function(u, d) {
          return Js(this._ctx, function(f, g, b) {
            return u(f.value) ? (g(b), d) : !0;
          }), this;
        }, s.prototype.first = function(u) {
          return this.limit(1).toArray(function(d) {
            return d[0];
          }).then(u);
        }, s.prototype.last = function(u) {
          return this.reverse().first(u);
        }, s.prototype.filter = function(u) {
          return Js(this._ctx, function(d) {
            return u(d.value);
          }), Xp(this._ctx, u), this;
        }, s.prototype.and = function(u) {
          return this.filter(u);
        }, s.prototype.or = function(u) {
          return new this.db.WhereClause(this._ctx.table, u, this);
        }, s.prototype.reverse = function() {
          return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
        }, s.prototype.desc = function() {
          return this.reverse();
        }, s.prototype.eachKey = function(u) {
          var d = this._ctx;
          return d.keysOnly = !d.isMatch, this.each(function(f, g) {
            u(g.key, g);
          });
        }, s.prototype.eachUniqueKey = function(u) {
          return this._ctx.unique = "unique", this.eachKey(u);
        }, s.prototype.eachPrimaryKey = function(u) {
          var d = this._ctx;
          return d.keysOnly = !d.isMatch, this.each(function(f, g) {
            u(g.primaryKey, g);
          });
        }, s.prototype.keys = function(u) {
          var d = this._ctx;
          d.keysOnly = !d.isMatch;
          var f = [];
          return this.each(function(g, b) {
            f.push(b.key);
          }).then(function() {
            return f;
          }).then(u);
        }, s.prototype.primaryKeys = function(u) {
          var d = this._ctx;
          if (no(d, !0) && d.limit > 0)
            return this._read(function(g) {
              var b = pa(d, d.table.core.schema);
              return d.table.core.query({
                trans: g,
                values: !1,
                limit: d.limit,
                direction: d.dir === "prev" ? "prev" : void 0,
                query: {
                  index: b,
                  range: d.range
                }
              });
            }).then(function(g) {
              var b = g.result;
              return b;
            }).then(u);
          d.keysOnly = !d.isMatch;
          var f = [];
          return this.each(function(g, b) {
            f.push(b.primaryKey);
          }).then(function() {
            return f;
          }).then(u);
        }, s.prototype.uniqueKeys = function(u) {
          return this._ctx.unique = "unique", this.keys(u);
        }, s.prototype.firstKey = function(u) {
          return this.limit(1).keys(function(d) {
            return d[0];
          }).then(u);
        }, s.prototype.lastKey = function(u) {
          return this.reverse().firstKey(u);
        }, s.prototype.distinct = function() {
          var u = this._ctx, d = u.index && u.table.schema.idxByName[u.index];
          if (!d || !d.multi)
            return this;
          var f = {};
          return Js(this._ctx, function(g) {
            var b = g.primaryKey.toString(), _ = v(f, b);
            return f[b] = !0, !_;
          }), this;
        }, s.prototype.modify = function(u) {
          var d = this, f = this._ctx;
          return this._write(function(g) {
            var b;
            typeof u == "function" ? b = u : b = function($) {
              return Ml($, u);
            };
            var _ = f.table.core, T = _.schema.primaryKey, C = T.outbound, E = T.extractKey, D = 200, x = d.db._options.modifyChunkSize;
            x && (typeof x == "object" ? D = x[_.name] || x["*"] || 200 : D = x);
            var O = [], U = 0, I = [], R = function($, q) {
              var Z = q.failures, j = q.numFailures;
              U += $ - j;
              for (var G = 0, B = c(Z); G < B.length; G++) {
                var Y = B[G];
                O.push(Z[Y]);
              }
            }, N = u === Ll;
            return d.clone().primaryKeys().then(function($) {
              var q = no(f) && f.limit === 1 / 0 && (typeof u != "function" || N) && {
                index: f.index,
                range: f.range
              }, Z = function(j) {
                var G = Math.min(D, $.length - j), B = $.slice(j, j + G);
                return (N ? Promise.resolve([]) : _.getMany({
                  trans: g,
                  keys: B,
                  cache: "immutable"
                })).then(function(Y) {
                  var V = [], X = [], be = C ? [] : null, oe = N ? B : [];
                  if (!N)
                    for (var J = 0; J < G; ++J) {
                      var se = Y[J], ce = {
                        value: Sn(se),
                        primKey: $[j + J]
                      };
                      b.call(ce, ce.value, ce) !== !1 && (ce.value == null ? oe.push($[j + J]) : !C && we(E(se), E(ce.value)) !== 0 ? (oe.push($[j + J]), V.push(ce.value)) : (X.push(ce.value), C && be.push($[j + J])));
                    }
                  return Promise.resolve(V.length > 0 && _.mutate({ trans: g, type: "add", values: V }).then(function(Ie) {
                    for (var ie in Ie.failures)
                      oe.splice(parseInt(ie), 1);
                    R(V.length, Ie);
                  })).then(function() {
                    return (X.length > 0 || q && typeof u == "object") && _.mutate({
                      trans: g,
                      type: "put",
                      keys: be,
                      values: X,
                      criteria: q,
                      changeSpec: typeof u != "function" && u,
                      isAdditionalChunk: j > 0
                    }).then(function(Ie) {
                      return R(X.length, Ie);
                    });
                  }).then(function() {
                    return (oe.length > 0 || q && N) && _.mutate({
                      trans: g,
                      type: "delete",
                      keys: oe,
                      criteria: q,
                      isAdditionalChunk: j > 0
                    }).then(function(Ie) {
                      return ma(f.table, oe, Ie);
                    }).then(function(Ie) {
                      return R(oe.length, Ie);
                    });
                  }).then(function() {
                    return $.length > j + G && Z(j + D);
                  });
                });
              };
              return Z(0).then(function() {
                if (O.length > 0)
                  throw new na("Error modifying one or more objects", O, U, I);
                return $.length;
              });
            });
          });
        }, s.prototype.delete = function() {
          var u = this._ctx, d = u.range;
          return no(u) && !u.table.schema.yProps && (u.isPrimKey || d.type === 3) ? this._write(function(f) {
            var g = u.table.core.schema.primaryKey, b = d;
            return u.table.core.count({ trans: f, query: { index: g, range: b } }).then(function(_) {
              return u.table.core.mutate({ trans: f, type: "deleteRange", range: b }).then(function(T) {
                var C = T.failures, E = T.numFailures;
                if (E)
                  throw new na("Could not delete some values", Object.keys(C).map(function(D) {
                    return C[D];
                  }), _ - E);
                return _ - E;
              });
            });
          }) : this.modify(Ll);
        }, s;
      })(), Ll = function(s, u) {
        return u.value = null;
      };
      function eg(s) {
        return qo(Jp.prototype, function(d, f) {
          this.db = s;
          var g = zl, b = null;
          if (f)
            try {
              g = f();
            } catch (E) {
              b = E;
            }
          var _ = d._ctx, T = _.table, C = T.hook.reading.fire;
          this._ctx = {
            table: T,
            index: _.index,
            isPrimKey: !_.index || T.schema.primKey.keyPath && _.index === T.schema.primKey.name,
            range: g,
            keysOnly: !1,
            dir: "next",
            unique: "",
            algorithm: null,
            filter: null,
            replayFilter: null,
            justLimit: !0,
            isMatch: null,
            offset: 0,
            limit: 1 / 0,
            error: b,
            or: _.or,
            valueMapper: C !== jo ? C : null
          };
        });
      }
      function tg(s, u) {
        return s < u ? -1 : s === u ? 0 : 1;
      }
      function ng(s, u) {
        return s > u ? -1 : s === u ? 0 : 1;
      }
      function Lt(s, u, d) {
        var f = s instanceof Fl ? new s.Collection(s) : s;
        return f._ctx.error = d ? new d(u) : new TypeError(u), f;
      }
      function ro(s) {
        var u = new s.Collection(s, function() {
          return Gl("");
        });
        return u._addAlgorithm(function() {
          return !1;
        }), u;
      }
      function rg(s) {
        return s === "next" ? function(u) {
          return u.toUpperCase();
        } : function(u) {
          return u.toLowerCase();
        };
      }
      function og(s) {
        return s === "next" ? function(u) {
          return u.toLowerCase();
        } : function(u) {
          return u.toUpperCase();
        };
      }
      function ig(s, u, d, f, g, b) {
        for (var _ = Math.min(s.length, f.length), T = -1, C = 0; C < _; ++C) {
          var E = u[C];
          if (E !== f[C])
            return g(s[C], d[C]) < 0 ? s.substr(0, C) + d[C] + d.substr(C + 1) : g(s[C], f[C]) < 0 ? s.substr(0, C) + f[C] + d.substr(C + 1) : T >= 0 ? s.substr(0, T) + u[T] + d.substr(T + 1) : null;
          g(s[C], E) < 0 && (T = C);
        }
        return _ < f.length && b === "next" ? s + d.substr(s.length) : _ < s.length && b === "prev" ? s.substr(0, d.length) : T < 0 ? null : s.substr(0, T) + f[T] + d.substr(T + 1);
      }
      function va(s, u, d, f) {
        var g, b, _, T, C, E, D, x = d.length;
        if (!d.every(function(R) {
          return typeof R == "string";
        }))
          return Lt(s, Dl);
        function O(R) {
          g = rg(R), b = og(R), _ = R === "next" ? tg : ng;
          var N = d.map(function($) {
            return { lower: b($), upper: g($) };
          }).sort(function($, q) {
            return _($.lower, q.lower);
          });
          T = N.map(function($) {
            return $.upper;
          }), C = N.map(function($) {
            return $.lower;
          }), E = R, D = R === "next" ? "" : f;
        }
        O("next");
        var U = new s.Collection(s, function() {
          return Xn(T[0], C[x - 1] + f);
        });
        U._ondirectionchange = function(R) {
          O(R);
        };
        var I = 0;
        return U._addAlgorithm(function(R, N, $) {
          var q = R.key;
          if (typeof q != "string")
            return !1;
          var Z = b(q);
          if (u(Z, C, I))
            return !0;
          for (var j = null, G = I; G < x; ++G) {
            var B = ig(q, Z, T[G], C[G], _, E);
            B === null && j === null ? I = G + 1 : (j === null || _(j, B) > 0) && (j = B);
          }
          return N(j !== null ? function() {
            R.continue(j + D);
          } : $), !1;
        }), U;
      }
      function Xn(s, u, d, f) {
        return {
          type: 2,
          lower: s,
          upper: u,
          lowerOpen: d,
          upperOpen: f
        };
      }
      function Gl(s) {
        return {
          type: 1,
          lower: s,
          upper: s
        };
      }
      var Fl = (function() {
        function s() {
        }
        return Object.defineProperty(s.prototype, "Collection", {
          get: function() {
            return this._ctx.table.db.Collection;
          },
          enumerable: !1,
          configurable: !0
        }), s.prototype.between = function(u, d, f, g) {
          f = f !== !1, g = g === !0;
          try {
            return this._cmp(u, d) > 0 || this._cmp(u, d) === 0 && (f || g) && !(f && g) ? ro(this) : new this.Collection(this, function() {
              return Xn(u, d, !f, !g);
            });
          } catch {
            return Lt(this, zn);
          }
        }, s.prototype.equals = function(u) {
          return u == null ? Lt(this, zn) : new this.Collection(this, function() {
            return Gl(u);
          });
        }, s.prototype.above = function(u) {
          return u == null ? Lt(this, zn) : new this.Collection(this, function() {
            return Xn(u, void 0, !0);
          });
        }, s.prototype.aboveOrEqual = function(u) {
          return u == null ? Lt(this, zn) : new this.Collection(this, function() {
            return Xn(u, void 0, !1);
          });
        }, s.prototype.below = function(u) {
          return u == null ? Lt(this, zn) : new this.Collection(this, function() {
            return Xn(void 0, u, !1, !0);
          });
        }, s.prototype.belowOrEqual = function(u) {
          return u == null ? Lt(this, zn) : new this.Collection(this, function() {
            return Xn(void 0, u);
          });
        }, s.prototype.startsWith = function(u) {
          return typeof u != "string" ? Lt(this, Dl) : this.between(u, u + Pr, !0, !0);
        }, s.prototype.startsWithIgnoreCase = function(u) {
          return u === "" ? this.startsWith(u) : va(this, function(d, f) {
            return d.indexOf(f[0]) === 0;
          }, [u], Pr);
        }, s.prototype.equalsIgnoreCase = function(u) {
          return va(this, function(d, f) {
            return d === f[0];
          }, [u], "");
        }, s.prototype.anyOfIgnoreCase = function() {
          var u = Dn.apply(Hr, arguments);
          return u.length === 0 ? ro(this) : va(this, function(d, f) {
            return f.indexOf(d) !== -1;
          }, u, "");
        }, s.prototype.startsWithAnyOfIgnoreCase = function() {
          var u = Dn.apply(Hr, arguments);
          return u.length === 0 ? ro(this) : va(this, function(d, f) {
            return f.some(function(g) {
              return d.indexOf(g) === 0;
            });
          }, u, Pr);
        }, s.prototype.anyOf = function() {
          var u = this, d = Dn.apply(Hr, arguments), f = this._cmp;
          try {
            d.sort(f);
          } catch {
            return Lt(this, zn);
          }
          if (d.length === 0)
            return ro(this);
          var g = new this.Collection(this, function() {
            return Xn(d[0], d[d.length - 1]);
          });
          g._ondirectionchange = function(_) {
            f = _ === "next" ? u._ascending : u._descending, d.sort(f);
          };
          var b = 0;
          return g._addAlgorithm(function(_, T, C) {
            for (var E = _.key; f(E, d[b]) > 0; )
              if (++b, b === d.length)
                return T(C), !1;
            return f(E, d[b]) === 0 ? !0 : (T(function() {
              _.continue(d[b]);
            }), !1);
          }), g;
        }, s.prototype.notEqual = function(u) {
          return this.inAnyRange([
            [Hs, u],
            [u, this.db._maxKey]
          ], { includeLowers: !1, includeUppers: !1 });
        }, s.prototype.noneOf = function() {
          var u = Dn.apply(Hr, arguments);
          if (u.length === 0)
            return new this.Collection(this);
          try {
            u.sort(this._ascending);
          } catch {
            return Lt(this, zn);
          }
          var d = u.reduce(function(f, g) {
            return f ? f.concat([[f[f.length - 1][1], g]]) : [[Hs, g]];
          }, null);
          return d.push([u[u.length - 1], this.db._maxKey]), this.inAnyRange(d, {
            includeLowers: !1,
            includeUppers: !1
          });
        }, s.prototype.inAnyRange = function(u, d) {
          var f = this, g = this._cmp, b = this._ascending, _ = this._descending, T = this._min, C = this._max;
          if (u.length === 0)
            return ro(this);
          if (!u.every(function(G) {
            return G[0] !== void 0 && G[1] !== void 0 && b(G[0], G[1]) <= 0;
          }))
            return Lt(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", ae.InvalidArgument);
          var E = !d || d.includeLowers !== !1, D = d && d.includeUppers === !0;
          function x(G, B) {
            for (var Y = 0, V = G.length; Y < V; ++Y) {
              var X = G[Y];
              if (g(B[0], X[1]) < 0 && g(B[1], X[0]) > 0) {
                X[0] = T(X[0], B[0]), X[1] = C(X[1], B[1]);
                break;
              }
            }
            return Y === V && G.push(B), G;
          }
          var O = b;
          function U(G, B) {
            return O(G[0], B[0]);
          }
          var I;
          try {
            I = u.reduce(x, []), I.sort(U);
          } catch {
            return Lt(this, zn);
          }
          var R = 0, N = D ? function(G) {
            return b(G, I[R][1]) > 0;
          } : function(G) {
            return b(G, I[R][1]) >= 0;
          }, $ = E ? function(G) {
            return _(G, I[R][0]) > 0;
          } : function(G) {
            return _(G, I[R][0]) >= 0;
          };
          function q(G) {
            return !N(G) && !$(G);
          }
          var Z = N, j = new this.Collection(this, function() {
            return Xn(I[0][0], I[I.length - 1][1], !E, !D);
          });
          return j._ondirectionchange = function(G) {
            G === "next" ? (Z = N, O = b) : (Z = $, O = _), I.sort(U);
          }, j._addAlgorithm(function(G, B, Y) {
            for (var V = G.key; Z(V); )
              if (++R, R === I.length)
                return B(Y), !1;
            return q(V) ? !0 : (f._cmp(V, I[R][1]) === 0 || f._cmp(V, I[R][0]) === 0 || B(function() {
              O === b ? G.continue(I[R][0]) : G.continue(I[R][1]);
            }), !1);
          }), j;
        }, s.prototype.startsWithAnyOf = function() {
          var u = Dn.apply(Hr, arguments);
          return u.every(function(d) {
            return typeof d == "string";
          }) ? u.length === 0 ? ro(this) : this.inAnyRange(u.map(function(d) {
            return [d, d + Pr];
          })) : Lt(this, "startsWithAnyOf() only works with strings");
        }, s;
      })();
      function ag(s) {
        return qo(Fl.prototype, function(d, f, g) {
          if (this.db = s, this._ctx = {
            table: d,
            index: f === ":id" ? null : f,
            or: g
          }, this._cmp = this._ascending = we, this._descending = function(b, _) {
            return we(_, b);
          }, this._max = function(b, _) {
            return we(b, _) > 0 ? b : _;
          }, this._min = function(b, _) {
            return we(b, _) < 0 ? b : _;
          }, this._IDBKeyRange = s._deps.IDBKeyRange, !this._IDBKeyRange)
            throw new ae.MissingAPI();
        });
      }
      function an(s) {
        return Oe(function(u) {
          return Ko(u), s(u.target.error), !1;
        });
      }
      function Ko(s) {
        s.stopPropagation && s.stopPropagation(), s.preventDefault && s.preventDefault();
      }
      var ya = "storagemutated", tu = "x-storagemutated-1", Jn = Zo(null, ya), sg = (function() {
        function s() {
        }
        return s.prototype._lock = function() {
          return Ee(!ee.global), ++this._reculock, this._reculock === 1 && !ee.global && (ee.lockOwnerFor = this), this;
        }, s.prototype._unlock = function() {
          if (Ee(!ee.global), --this._reculock === 0)
            for (ee.global || (ee.lockOwnerFor = null); this._blockedFuncs.length > 0 && !this._locked(); ) {
              var u = this._blockedFuncs.shift();
              try {
                Cr(u[1], u[0]);
              } catch {
              }
            }
          return this;
        }, s.prototype._locked = function() {
          return this._reculock && ee.lockOwnerFor !== this;
        }, s.prototype.create = function(u) {
          var d = this;
          if (!this.mode)
            return this;
          var f = this.db.idbdb, g = this.db._state.dbOpenError;
          if (Ee(!this.idbtrans), !u && !f)
            switch (g && g.name) {
              case "DatabaseClosedError":
                throw new ae.DatabaseClosed(g);
              case "MissingAPIError":
                throw new ae.MissingAPI(g.message, g);
              default:
                throw new ae.OpenFailed(g);
            }
          if (!this.active)
            throw new ae.TransactionInactive();
          return Ee(this._completion._state === null), u = this.idbtrans = u || (this.db.core ? this.db.core.transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability }) : f.transaction(this.storeNames, this.mode, {
            durability: this.chromeTransactionDurability
          })), u.onerror = Oe(function(b) {
            Ko(b), d._reject(u.error);
          }), u.onabort = Oe(function(b) {
            Ko(b), d.active && d._reject(new ae.Abort(u.error)), d.active = !1, d.on("abort").fire(b);
          }), u.oncomplete = Oe(function() {
            d.active = !1, d._resolve(), "mutatedParts" in u && Jn.storagemutated.fire(u.mutatedParts);
          }), this;
        }, s.prototype._promise = function(u, d, f) {
          var g = this;
          if (u === "readwrite" && this.mode !== "readwrite")
            return Ke(new ae.ReadOnly("Transaction is readonly"));
          if (!this.active)
            return Ke(new ae.TransactionInactive());
          if (this._locked())
            return new Q(function(_, T) {
              g._blockedFuncs.push([
                function() {
                  g._promise(u, d, f).then(_, T);
                },
                ee
              ]);
            });
          if (f)
            return Bn(function() {
              var _ = new Q(function(T, C) {
                g._lock();
                var E = d(T, C, g);
                E && E.then && E.then(T, C);
              });
              return _.finally(function() {
                return g._unlock();
              }), _._lib = !0, _;
            });
          var b = new Q(function(_, T) {
            var C = d(_, T, g);
            C && C.then && C.then(_, T);
          });
          return b._lib = !0, b;
        }, s.prototype._root = function() {
          return this.parent ? this.parent._root() : this;
        }, s.prototype.waitFor = function(u) {
          var d = this._root(), f = Q.resolve(u);
          if (d._waitingFor)
            d._waitingFor = d._waitingFor.then(function() {
              return f;
            });
          else {
            d._waitingFor = f, d._waitingQueue = [];
            var g = d.idbtrans.objectStore(d.storeNames[0]);
            (function _() {
              for (++d._spinCount; d._waitingQueue.length; )
                d._waitingQueue.shift()();
              d._waitingFor && (g.get(-1 / 0).onsuccess = _);
            })();
          }
          var b = d._waitingFor;
          return new Q(function(_, T) {
            f.then(function(C) {
              return d._waitingQueue.push(Oe(_.bind(null, C)));
            }, function(C) {
              return d._waitingQueue.push(Oe(T.bind(null, C)));
            }).finally(function() {
              d._waitingFor === b && (d._waitingFor = null);
            });
          });
        }, s.prototype.abort = function() {
          this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new ae.Abort()));
        }, s.prototype.table = function(u) {
          var d = this._memoizedTables || (this._memoizedTables = {});
          if (v(d, u))
            return d[u];
          var f = this.schema[u];
          if (!f)
            throw new ae.NotFound("Table " + u + " not part of transaction");
          var g = new this.db.Table(u, f, this);
          return g.core = this.db.core.table(u), d[u] = g, g;
        }, s;
      })();
      function ug(s) {
        return qo(sg.prototype, function(d, f, g, b, _) {
          var T = this;
          d !== "readonly" && f.forEach(function(C) {
            var E, D = (E = g[C]) === null || E === void 0 ? void 0 : E.yProps;
            D && (f = f.concat(D.map(function(x) {
              return x.updatesTable;
            })));
          }), this.db = s, this.mode = d, this.storeNames = f, this.schema = g, this.chromeTransactionDurability = b, this.idbtrans = null, this.on = Zo(this, "complete", "error", "abort"), this.parent = _ || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new Q(function(C, E) {
            T._resolve = C, T._reject = E;
          }), this._completion.then(function() {
            T.active = !1, T.on.complete.fire();
          }, function(C) {
            var E = T.active;
            return T.active = !1, T.on.error.fire(C), T.parent ? T.parent._reject(C) : E && T.idbtrans && T.idbtrans.abort(), Ke(C);
          });
        });
      }
      function nu(s, u, d, f, g, b, _, T) {
        return {
          name: s,
          keyPath: u,
          unique: d,
          multi: f,
          auto: g,
          compound: b,
          src: (d && !_ ? "&" : "") + (f ? "*" : "") + (g ? "++" : "") + Ul(u),
          type: T
        };
      }
      function Ul(s) {
        return typeof s == "string" ? s : s ? "[" + [].join.call(s, "+") + "]" : "";
      }
      function ru(s, u, d) {
        return {
          name: s,
          primKey: u,
          indexes: d,
          mappedClass: null,
          idxByName: ue(d, function(f) {
            return [f.name, f];
          })
        };
      }
      function cg(s) {
        return s.length === 1 ? s[0] : s;
      }
      var Wo = function(s) {
        try {
          return s.only([[]]), Wo = function() {
            return [[]];
          }, [[]];
        } catch {
          return Wo = function() {
            return Pr;
          }, Pr;
        }
      };
      function ou(s) {
        return s == null ? function() {
        } : typeof s == "string" ? lg(s) : function(u) {
          return he(u, s);
        };
      }
      function lg(s) {
        var u = s.split(".");
        return u.length === 1 ? function(d) {
          return d[s];
        } : function(d) {
          return he(d, s);
        };
      }
      function Zl(s) {
        return [].slice.call(s);
      }
      var dg = 0;
      function Yo(s) {
        return s == null ? ":id" : typeof s == "string" ? s : "[".concat(s.join("+"), "]");
      }
      function hg(s, u, d) {
        function f(O, U) {
          var I = Zl(O.objectStoreNames), R = I.length > 0 ? U.objectStore(I[0]) : {};
          return {
            schema: {
              name: O.name,
              tables: I.map(function(N) {
                return U.objectStore(N);
              }).map(function(N) {
                var $ = N.keyPath, q = N.autoIncrement, Z = l($), j = $ == null, G = {}, B = {
                  name: N.name,
                  primaryKey: {
                    name: null,
                    isPrimaryKey: !0,
                    outbound: j,
                    compound: Z,
                    keyPath: $,
                    autoIncrement: q,
                    unique: !0,
                    extractKey: ou($)
                  },
                  indexes: Zl(N.indexNames).map(function(Y) {
                    return N.index(Y);
                  }).map(function(Y) {
                    var V = Y.name, X = Y.unique, be = Y.multiEntry, oe = Y.keyPath, J = l(oe), se = {
                      name: V,
                      compound: J,
                      keyPath: oe,
                      unique: X,
                      multiEntry: be,
                      extractKey: ou(oe)
                    };
                    return G[Yo(oe)] = se, se;
                  }),
                  getIndexByKeyPath: function(Y) {
                    return G[Yo(Y)];
                  }
                };
                return G[":id"] = B.primaryKey, $ != null && (G[Yo($)] = B.primaryKey), B;
              })
            },
            hasGetAll: I.length > 0 && "getAll" in R && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604),
            hasIdb3Features: "getAllRecords" in R
          };
        }
        function g(O) {
          if (O.type === 3)
            return null;
          if (O.type === 4)
            throw new Error("Cannot convert never type to IDBKeyRange");
          var U = O.lower, I = O.upper, R = O.lowerOpen, N = O.upperOpen, $ = U === void 0 ? I === void 0 ? null : u.upperBound(I, !!N) : I === void 0 ? u.lowerBound(U, !!R) : u.bound(U, I, !!R, !!N);
          return $;
        }
        function b(O) {
          var U = O.name;
          function I($) {
            var q = $.trans, Z = $.type, j = $.keys, G = $.values, B = $.range;
            return new Promise(function(Y, V) {
              Y = Oe(Y);
              var X = q.objectStore(U), be = X.keyPath == null, oe = Z === "put" || Z === "add";
              if (!oe && Z !== "delete" && Z !== "deleteRange")
                throw new Error("Invalid operation type: " + Z);
              var J = (j || G || { length: 1 }).length;
              if (j && G && j.length !== G.length)
                throw new Error("Given keys array must have same length as given values array.");
              if (J === 0)
                return Y({
                  numFailures: 0,
                  failures: {},
                  results: [],
                  lastResult: void 0
                });
              var se, ce = [], Ie = [], ie = 0, Ve = function(et) {
                ++ie, Ko(et);
              };
              if (Z === "deleteRange") {
                if (B.type === 4)
                  return Y({
                    numFailures: ie,
                    failures: Ie,
                    results: [],
                    lastResult: void 0
                  });
                B.type === 3 ? ce.push(se = X.clear()) : ce.push(se = X.delete(g(B)));
              } else {
                var Vt = oe ? be ? [G, j] : [G, null] : [j, null], dt = Vt[0], Dr = Vt[1];
                if (oe)
                  for (var st = 0; st < J; ++st)
                    ce.push(se = Dr && Dr[st] !== void 0 ? X[Z](dt[st], Dr[st]) : X[Z](dt[st])), se.onerror = Ve;
                else
                  for (var st = 0; st < J; ++st)
                    ce.push(se = X[Z](dt[st])), se.onerror = Ve;
              }
              var Bt = function(et) {
                var Ir = et.target.result;
                ce.forEach(function(sn, Ia) {
                  return sn.error != null && (Ie[Ia] = sn.error);
                }), Y({
                  numFailures: ie,
                  failures: Ie,
                  results: Z === "delete" ? j : ce.map(function(sn) {
                    return sn.result;
                  }),
                  lastResult: Ir
                });
              };
              se.onerror = function(et) {
                Ve(et), Bt(et);
              }, se.onsuccess = Bt;
            });
          }
          function R($) {
            var q = $.trans, Z = $.values, j = $.query, G = $.reverse, B = $.unique;
            return new Promise(function(Y, V) {
              Y = Oe(Y);
              var X = j.index, be = j.range, oe = q.objectStore(U), J = X.isPrimaryKey ? oe : oe.index(X.name), se = G ? B ? "prevunique" : "prev" : B ? "nextunique" : "next", ce = Z || !("openKeyCursor" in J) ? J.openCursor(g(be), se) : J.openKeyCursor(g(be), se);
              ce.onerror = an(V), ce.onsuccess = Oe(function(Ie) {
                var ie = ce.result;
                if (!ie) {
                  Y(null);
                  return;
                }
                ie.___id = ++dg, ie.done = !1;
                var Ve = ie.continue.bind(ie), Vt = ie.continuePrimaryKey;
                Vt && (Vt = Vt.bind(ie));
                var dt = ie.advance.bind(ie), Dr = function() {
                  throw new Error("Cursor not started");
                }, st = function() {
                  throw new Error("Cursor not stopped");
                };
                ie.trans = q, ie.stop = ie.continue = ie.continuePrimaryKey = ie.advance = Dr, ie.fail = Oe(V), ie.next = function() {
                  var Bt = this, et = 1;
                  return this.start(function() {
                    return et-- ? Bt.continue() : Bt.stop();
                  }).then(function() {
                    return Bt;
                  });
                }, ie.start = function(Bt) {
                  var et = new Promise(function(sn, Ia) {
                    sn = Oe(sn), ce.onerror = an(Ia), ie.fail = Ia, ie.stop = function(ev) {
                      ie.stop = ie.continue = ie.continuePrimaryKey = ie.advance = st, sn(ev);
                    };
                  }), Ir = function() {
                    if (ce.result)
                      try {
                        Bt();
                      } catch (sn) {
                        ie.fail(sn);
                      }
                    else
                      ie.done = !0, ie.start = function() {
                        throw new Error("Cursor behind last entry");
                      }, ie.stop();
                  };
                  return ce.onsuccess = Oe(function(sn) {
                    ce.onsuccess = Ir, Ir();
                  }), ie.continue = Ve, ie.continuePrimaryKey = Vt, ie.advance = dt, Ir(), et;
                }, Y(ie);
              }, V);
            });
          }
          function N($, q) {
            return function(Z) {
              return new Promise(function(j, G) {
                var B;
                j = Oe(j);
                var Y = Z.trans, V = Z.values, X = Z.limit, be = Z.query, oe = (B = Z.direction) !== null && B !== void 0 ? B : "next", J = X === 1 / 0 ? void 0 : X, se = be.index, ce = be.range, Ie = Y.objectStore(U), ie = se.isPrimaryKey ? Ie : Ie.index(se.name), Ve = g(ce);
                if (X === 0)
                  return j({ result: [] });
                if (q) {
                  var Vt = {
                    query: Ve,
                    count: J,
                    direction: oe
                  }, dt = V ? ie.getAll(Vt) : ie.getAllKeys(Vt);
                  dt.onsuccess = function(et) {
                    return j({ result: et.target.result });
                  }, dt.onerror = an(G);
                } else if ($ && oe === "next") {
                  var dt = V ? ie.getAll(Ve, J) : ie.getAllKeys(Ve, J);
                  dt.onsuccess = function(Ir) {
                    return j({ result: Ir.target.result });
                  }, dt.onerror = an(G);
                } else {
                  var Dr = 0, st = V || !("openKeyCursor" in ie) ? ie.openCursor(Ve, oe) : ie.openKeyCursor(Ve, oe), Bt = [];
                  st.onsuccess = function() {
                    var et = st.result;
                    if (!et)
                      return j({ result: Bt });
                    if (Bt.push(V ? et.value : et.primaryKey), ++Dr === X)
                      return j({ result: Bt });
                    et.continue();
                  }, st.onerror = an(G);
                }
              });
            };
          }
          return {
            name: U,
            schema: O,
            mutate: I,
            getMany: function($) {
              var q = $.trans, Z = $.keys;
              return new Promise(function(j, G) {
                j = Oe(j);
                for (var B = q.objectStore(U), Y = Z.length, V = new Array(Y), X = 0, be = 0, oe, J = function(ie) {
                  var Ve = ie.target;
                  (V[Ve._pos] = Ve.result) != null, ++be === X && j(V);
                }, se = an(G), ce = 0; ce < Y; ++ce) {
                  var Ie = Z[ce];
                  Ie != null && (oe = B.get(Z[ce]), oe._pos = ce, oe.onsuccess = J, oe.onerror = se, ++X);
                }
                X === 0 && j(V);
              });
            },
            get: function($) {
              var q = $.trans, Z = $.key;
              return new Promise(function(j, G) {
                j = Oe(j);
                var B = q.objectStore(U), Y = B.get(Z);
                Y.onsuccess = function(V) {
                  return j(V.target.result);
                }, Y.onerror = an(G);
              });
            },
            query: N(C, E),
            openCursor: R,
            count: function($) {
              var q = $.query, Z = $.trans, j = q.index, G = q.range;
              return new Promise(function(B, Y) {
                var V = Z.objectStore(U), X = j.isPrimaryKey ? V : V.index(j.name), be = g(G), oe = be ? X.count(be) : X.count();
                oe.onsuccess = Oe(function(J) {
                  return B(J.target.result);
                }), oe.onerror = an(Y);
              });
            }
          };
        }
        var _ = f(s, d), T = _.schema, C = _.hasGetAll, E = _.hasIdb3Features, D = T.tables.map(function(O) {
          return b(O);
        }), x = {};
        return D.forEach(function(O) {
          return x[O.name] = O;
        }), {
          stack: "dbcore",
          transaction: s.transaction.bind(s),
          table: function(O) {
            var U = x[O];
            if (!U)
              throw new Error("Table '".concat(O, "' not found"));
            return x[O];
          },
          MIN_KEY: -1 / 0,
          MAX_KEY: Wo(u),
          schema: T
        };
      }
      function fg(s, u) {
        return u.reduce(function(d, f) {
          var g = f.create;
          return o(o({}, d), g(d));
        }, s);
      }
      function mg(s, u, d, f) {
        var g = d.IDBKeyRange;
        d.indexedDB;
        var b = fg(hg(u, g, f), s.dbcore);
        return {
          dbcore: b
        };
      }
      function ba(s, u) {
        var d = u.db, f = mg(s._middlewares, d, s._deps, u);
        s.core = f.dbcore, s.tables.forEach(function(g) {
          var b = g.name;
          s.core.schema.tables.some(function(_) {
            return _.name === b;
          }) && (g.core = s.core.table(b), s[b] instanceof s.Table && (s[b].core = g.core));
        });
      }
      function wa(s, u, d, f) {
        d.forEach(function(g) {
          var b = f[g];
          u.forEach(function(_) {
            var T = L(_, g);
            (!T || "value" in T && T.value === void 0) && (_ === s.Transaction.prototype || _ instanceof s.Transaction ? A(_, g, {
              get: function() {
                return this.table(g);
              },
              set: function(C) {
                P(this, g, {
                  value: C,
                  writable: !0,
                  configurable: !0,
                  enumerable: !0
                });
              }
            }) : _[g] = new s.Table(g, b));
          });
        });
      }
      function iu(s, u) {
        u.forEach(function(d) {
          for (var f in d)
            d[f] instanceof s.Table && delete d[f];
        });
      }
      function pg(s, u) {
        return s._cfg.version - u._cfg.version;
      }
      function gg(s, u, d, f) {
        var g = s._dbSchema;
        d.objectStoreNames.contains("$meta") && !g.$meta && (g.$meta = ru("$meta", Kl("")[0], []), s._storeNames.push("$meta"));
        var b = s._createTransaction("readwrite", s._storeNames, g);
        b.create(d), b._completion.catch(f);
        var _ = b._reject.bind(b), T = ee.transless || ee;
        Bn(function() {
          if (ee.trans = b, ee.transless = T, u === 0)
            c(g).forEach(function(C) {
              su(d, C, g[C].primKey, g[C].indexes);
            }), ba(s, d), Q.follow(function() {
              return s.on.populate.fire(b);
            }).catch(_);
          else
            return ba(s, d), yg(s, b, u).then(function(C) {
              return bg(s, C, b, d);
            }).catch(_);
        });
      }
      function vg(s, u) {
        ql(s._dbSchema, u), u.db.version % 10 === 0 && !u.objectStoreNames.contains("$meta") && u.db.createObjectStore("$meta").add(Math.ceil(u.db.version / 10 - 1), "version");
        var d = _a(s, s.idbdb, u);
        Ta(s, s._dbSchema, u);
        for (var f = au(d, s._dbSchema), g = function(E) {
          if (E.change.length || E.recreate)
            return console.warn("Unable to patch indexes of table ".concat(E.name, " because it has changes on the type of index or primary key.")), { value: void 0 };
          var D = u.objectStore(E.name);
          E.add.forEach(function(x) {
            dn && console.debug("Dexie upgrade patch: Creating missing index ".concat(E.name, ".").concat(x.src)), ka(D, x);
          });
        }, b = 0, _ = f.change; b < _.length; b++) {
          var T = _[b], C = g(T);
          if (typeof C == "object")
            return C.value;
        }
      }
      function yg(s, u, d) {
        return u.storeNames.includes("$meta") ? u.table("$meta").get("version").then(function(f) {
          return f ?? d;
        }) : Q.resolve(d);
      }
      function bg(s, u, d, f) {
        var g = [], b = s._versions, _ = s._dbSchema = _a(s, s.idbdb, f), T = b.filter(function(E) {
          return E._cfg.version >= u;
        });
        if (T.length === 0)
          return Q.resolve();
        T.forEach(function(E) {
          g.push(function() {
            var D = _, x = E._cfg.dbschema;
            Ta(s, D, f), Ta(s, x, f), _ = s._dbSchema = x;
            var O = au(D, x);
            O.add.forEach(function(q) {
              su(f, q[0], q[1].primKey, q[1].indexes);
            }), O.change.forEach(function(q) {
              if (q.recreate)
                throw new ae.Upgrade("Not yet support for changing primary key");
              var Z = f.objectStore(q.name);
              q.add.forEach(function(j) {
                return ka(Z, j);
              }), q.change.forEach(function(j) {
                Z.deleteIndex(j.name), ka(Z, j);
              }), q.del.forEach(function(j) {
                return Z.deleteIndex(j);
              });
            });
            var U = E._cfg.contentUpgrade;
            if (U && E._cfg.version > u) {
              ba(s, f), d._memoizedTables = {};
              var I = Ce(x);
              O.del.forEach(function(q) {
                I[q] = D[q];
              }), iu(s, [s.Transaction.prototype]), wa(s, [s.Transaction.prototype], c(I), I), d.schema = I;
              var R = $s(U);
              R && to();
              var N, $ = Q.follow(function() {
                if (N = U(d), N && R) {
                  var q = Hn.bind(null, null);
                  N.then(q, q);
                }
              });
              return N && typeof N.then == "function" ? Q.resolve(N) : $.then(function() {
                return N;
              });
            }
          }), g.push(function(D) {
            var x = E._cfg.dbschema;
            wg(x, D), iu(s, [s.Transaction.prototype]), wa(s, [s.Transaction.prototype], s._storeNames, s._dbSchema), d.schema = s._dbSchema;
          }), g.push(function(D) {
            s.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(s.idbdb.version / 10) === E._cfg.version ? (s.idbdb.deleteObjectStore("$meta"), delete s._dbSchema.$meta, s._storeNames = s._storeNames.filter(function(x) {
              return x !== "$meta";
            })) : D.objectStore("$meta").put(E._cfg.version, "version"));
          });
        });
        function C() {
          return g.length ? Q.resolve(g.shift()(d.idbtrans)).then(C) : Q.resolve();
        }
        return C().then(function() {
          ql(_, f);
        });
      }
      function au(s, u) {
        var d = {
          del: [],
          add: [],
          change: []
        }, f;
        for (f in s)
          u[f] || d.del.push(f);
        for (f in u) {
          var g = s[f], b = u[f];
          if (!g)
            d.add.push([f, b]);
          else {
            var _ = {
              name: f,
              def: b,
              recreate: !1,
              del: [],
              add: [],
              change: []
            };
            if ("" + (g.primKey.keyPath || "") != "" + (b.primKey.keyPath || "") || g.primKey.auto !== b.primKey.auto)
              _.recreate = !0, d.change.push(_);
            else {
              var T = g.idxByName, C = b.idxByName, E = void 0;
              for (E in T)
                C[E] || _.del.push(E);
              for (E in C) {
                var D = T[E], x = C[E];
                D ? D.src !== x.src && _.change.push(x) : _.add.push(x);
              }
              (_.del.length > 0 || _.add.length > 0 || _.change.length > 0) && d.change.push(_);
            }
          }
        }
        return d;
      }
      function su(s, u, d, f) {
        var g = s.db.createObjectStore(u, d.keyPath ? { keyPath: d.keyPath, autoIncrement: d.auto } : { autoIncrement: d.auto });
        return f.forEach(function(b) {
          return ka(g, b);
        }), g;
      }
      function ql(s, u) {
        c(s).forEach(function(d) {
          u.db.objectStoreNames.contains(d) || (dn && console.debug("Dexie: Creating missing table", d), su(u, d, s[d].primKey, s[d].indexes));
        });
      }
      function wg(s, u) {
        [].slice.call(u.db.objectStoreNames).forEach(function(d) {
          return s[d] == null && u.db.deleteObjectStore(d);
        });
      }
      function ka(s, u) {
        s.createIndex(u.name, u.keyPath, {
          unique: u.unique,
          multiEntry: u.multi
        });
      }
      function _a(s, u, d) {
        var f = {}, g = H(u.objectStoreNames, 0);
        return g.forEach(function(b) {
          for (var _ = d.objectStore(b), T = _.keyPath, C = nu(Ul(T), T || "", !0, !1, !!_.autoIncrement, T && typeof T != "string", !0), E = [], D = 0; D < _.indexNames.length; ++D) {
            var x = _.index(_.indexNames[D]);
            T = x.keyPath;
            var O = nu(x.name, T, !!x.unique, !!x.multiEntry, !1, T && typeof T != "string", !1);
            E.push(O);
          }
          f[b] = ru(b, C, E);
        }), f;
      }
      function kg(s, u, d) {
        s.verno = u.version / 10;
        var f = s._dbSchema = _a(s, u, d);
        s._storeNames = H(u.objectStoreNames, 0), wa(s, [s._allTables], c(f), f);
      }
      function _g(s, u) {
        var d = _a(s, s.idbdb, u), f = au(d, s._dbSchema);
        return !(f.add.length || f.change.some(function(g) {
          return g.add.length || g.change.length;
        }));
      }
      function Ta(s, u, d) {
        for (var f = d.db.objectStoreNames, g = 0; g < f.length; ++g) {
          var b = f[g], _ = d.objectStore(b);
          s._hasGetAll = "getAll" in _;
          for (var T = 0; T < _.indexNames.length; ++T) {
            var C = _.indexNames[T], E = _.index(C).keyPath, D = typeof E == "string" ? E : "[" + H(E).join("+") + "]";
            if (u[b]) {
              var x = u[b].idxByName[D];
              x && (x.name = C, delete u[b].idxByName[D], u[b].idxByName[C] = x);
            }
          }
        }
        typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && a.WorkerGlobalScope && a instanceof a.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (s._hasGetAll = !1);
      }
      function Kl(s) {
        return s.split(",").map(function(u, d) {
          var f, g = u.split(":"), b = (f = g[1]) === null || f === void 0 ? void 0 : f.trim();
          u = g[0].trim();
          var _ = u.replace(/([&*]|\+\+)/g, ""), T = /^\[/.test(_) ? _.match(/^\[(.*)\]$/)[1].split("+") : _;
          return nu(_, T || null, /\&/.test(u), /\*/.test(u), /\+\+/.test(u), l(T), d === 0, b);
        });
      }
      var Tg = (function() {
        function s() {
        }
        return s.prototype._createTableSchema = function(u, d, f) {
          return ru(u, d, f);
        }, s.prototype._parseIndexSyntax = function(u) {
          return Kl(u);
        }, s.prototype._parseStoresSpec = function(u, d) {
          var f = this;
          c(u).forEach(function(g) {
            if (u[g] !== null) {
              var b = f._parseIndexSyntax(u[g]), _ = b.shift();
              if (!_)
                throw new ae.Schema("Invalid schema for table " + g + ": " + u[g]);
              if (_.unique = !0, _.multi)
                throw new ae.Schema("Primary key cannot be multiEntry*");
              b.forEach(function(C) {
                if (C.auto)
                  throw new ae.Schema("Only primary key can be marked as autoIncrement (++)");
                if (!C.keyPath)
                  throw new ae.Schema("Index must have a name and cannot be an empty string");
              });
              var T = f._createTableSchema(g, _, b);
              d[g] = T;
            }
          });
        }, s.prototype.stores = function(u) {
          var d = this.db;
          this._cfg.storesSource = this._cfg.storesSource ? h(this._cfg.storesSource, u) : u;
          var f = d._versions, g = {}, b = {};
          return f.forEach(function(_) {
            h(g, _._cfg.storesSource), b = _._cfg.dbschema = {}, _._parseStoresSpec(g, b);
          }), d._dbSchema = b, iu(d, [d._allTables, d, d.Transaction.prototype]), wa(d, [d._allTables, d, d.Transaction.prototype, this._cfg.tables], c(b), b), d._storeNames = c(b), this;
        }, s.prototype.upgrade = function(u) {
          return this._cfg.contentUpgrade = Ls(this._cfg.contentUpgrade || Se, u), this;
        }, s;
      })();
      function Cg(s) {
        return qo(Tg.prototype, function(d) {
          this.db = s, this._cfg = {
            version: d,
            storesSource: null,
            dbschema: {},
            tables: {},
            contentUpgrade: null
          };
        });
      }
      var Vo = Pg();
      function Pg() {
        if (typeof FinalizationRegistry < "u" && typeof WeakRef < "u") {
          var s = /* @__PURE__ */ new Set(), u = new FinalizationRegistry(function(_) {
            s.delete(_);
          }), d = function() {
            return Array.from(s).map(function(_) {
              return _.deref();
            }).filter(function(_) {
              return _ !== void 0;
            });
          }, f = function(_) {
            var T = new WeakRef(_._novip);
            if (s.add(T), u.register(_._novip, T, T), s.size > _._options.maxConnections) {
              var C = s.values().next().value;
              s.delete(C), u.unregister(C);
            }
          }, g = function(_) {
            if (_)
              for (var T = s.values(), C = T.next(); !C.done; ) {
                var E = C.value;
                if (E.deref() === _._novip) {
                  s.delete(E), u.unregister(E);
                  return;
                }
                C = T.next();
              }
          };
          return { toArray: d, add: f, remove: g };
        } else {
          var b = [], d = function() {
            return b;
          }, f = function(E) {
            b.push(E._novip);
          }, g = function(E) {
            if (E) {
              var D = b.indexOf(E._novip);
              D !== -1 && b.splice(D, 1);
            }
          };
          return { toArray: d, add: f, remove: g };
        }
      }
      function uu(s, u) {
        var d = s._dbNamesDB;
        return d || (d = s._dbNamesDB = new Rn(ha, {
          addons: [],
          indexedDB: s,
          IDBKeyRange: u
        }), d.version(1).stores({ dbnames: "name" })), d.table("dbnames");
      }
      function cu(s) {
        return s && typeof s.databases == "function";
      }
      function Ag(s) {
        var u = s.indexedDB, d = s.IDBKeyRange;
        return cu(u) ? Promise.resolve(u.databases()).then(function(f) {
          return f.map(function(g) {
            return g.name;
          }).filter(function(g) {
            return g !== ha;
          });
        }) : uu(u, d).toCollection().primaryKeys();
      }
      function Eg(s, u) {
        var d = s.indexedDB, f = s.IDBKeyRange;
        !cu(d) && u !== ha && uu(d, f).put({ name: u }).catch(Se);
      }
      function Sg(s, u) {
        var d = s.indexedDB, f = s.IDBKeyRange;
        !cu(d) && u !== ha && uu(d, f).delete(u).catch(Se);
      }
      function lu(s) {
        return Bn(function() {
          return ee.letThrough = !0, s();
        });
      }
      function Dg() {
        var s = !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent);
        if (!s || !indexedDB.databases)
          return Promise.resolve();
        var u;
        return new Promise(function(d) {
          var f = function() {
            return indexedDB.databases().finally(d);
          };
          u = setInterval(f, 100), f();
        }).finally(function() {
          return clearInterval(u);
        });
      }
      var du;
      function hu(s) {
        return !("from" in s);
      }
      var at = function(s, u) {
        if (this)
          h(this, arguments.length ? { d: 1, from: s, to: arguments.length > 1 ? u : s } : { d: 0 });
        else {
          var d = new at();
          return s && "d" in s && h(d, s), d;
        }
      };
      k(at.prototype, (du = {
        add: function(s) {
          return Ho(this, s), this;
        },
        addKey: function(s) {
          return Bo(this, s, s), this;
        },
        addKeys: function(s) {
          var u = this;
          return s.forEach(function(d) {
            return Bo(u, d, d);
          }), this;
        },
        hasKey: function(s) {
          var u = Ca(this).next(s).value;
          return u && we(u.from, s) <= 0 && we(u.to, s) >= 0;
        }
      }, du[Ms] = function() {
        return Ca(this);
      }, du));
      function Bo(s, u, d) {
        var f = we(u, d);
        if (!isNaN(f)) {
          if (f > 0)
            throw RangeError();
          if (hu(s))
            return h(s, { from: u, to: d, d: 1 });
          var g = s.l, b = s.r;
          if (we(d, s.from) < 0)
            return g ? Bo(g, u, d) : s.l = { from: u, to: d, d: 1, l: null, r: null }, Yl(s);
          if (we(u, s.to) > 0)
            return b ? Bo(b, u, d) : s.r = { from: u, to: d, d: 1, l: null, r: null }, Yl(s);
          we(u, s.from) < 0 && (s.from = u, s.l = null, s.d = b ? b.d + 1 : 1), we(d, s.to) > 0 && (s.to = d, s.r = null, s.d = s.l ? s.l.d + 1 : 1);
          var _ = !s.r;
          g && !s.l && Ho(s, g), b && _ && Ho(s, b);
        }
      }
      function Ho(s, u) {
        function d(f, g) {
          var b = g.from, _ = g.to, T = g.l, C = g.r;
          Bo(f, b, _), T && d(f, T), C && d(f, C);
        }
        hu(u) || d(s, u);
      }
      function Wl(s, u) {
        var d = Ca(u), f = d.next();
        if (f.done)
          return !1;
        for (var g = f.value, b = Ca(s), _ = b.next(g.from), T = _.value; !f.done && !_.done; ) {
          if (we(T.from, g.to) <= 0 && we(T.to, g.from) >= 0)
            return !0;
          we(g.from, T.from) < 0 ? g = (f = d.next(T.from)).value : T = (_ = b.next(g.from)).value;
        }
        return !1;
      }
      function Ca(s) {
        var u = hu(s) ? null : { s: 0, n: s };
        return {
          next: function(d) {
            for (var f = arguments.length > 0; u; )
              switch (u.s) {
                case 0:
                  if (u.s = 1, f)
                    for (; u.n.l && we(d, u.n.from) < 0; )
                      u = { up: u, n: u.n.l, s: 1 };
                  else
                    for (; u.n.l; )
                      u = { up: u, n: u.n.l, s: 1 };
                case 1:
                  if (u.s = 2, !f || we(d, u.n.to) <= 0)
                    return { value: u.n, done: !1 };
                case 2:
                  if (u.n.r) {
                    u.s = 3, u = { up: u, n: u.n.r, s: 0 };
                    continue;
                  }
                case 3:
                  u = u.up;
              }
            return { done: !0 };
          }
        };
      }
      function Yl(s) {
        var u, d, f = (((u = s.r) === null || u === void 0 ? void 0 : u.d) || 0) - (((d = s.l) === null || d === void 0 ? void 0 : d.d) || 0), g = f > 1 ? "r" : f < -1 ? "l" : "";
        if (g) {
          var b = g === "r" ? "l" : "r", _ = o({}, s), T = s[g];
          s.from = T.from, s.to = T.to, s[g] = T[g], _[g] = T[b], s[b] = _, _.d = Vl(_);
        }
        s.d = Vl(s);
      }
      function Vl(s) {
        var u = s.r, d = s.l;
        return (u ? d ? Math.max(u.d, d.d) : u.d : d ? d.d : 0) + 1;
      }
      function Pa(s, u) {
        return c(u).forEach(function(d) {
          s[d] ? Ho(s[d], u[d]) : s[d] = En(u[d]);
        }), s;
      }
      function fu(s, u) {
        return s.all || u.all || Object.keys(s).some(function(d) {
          return u[d] && Wl(u[d], s[d]);
        });
      }
      var Er = {}, mu = {}, pu = !1;
      function Aa(s, u) {
        Pa(mu, s), pu || (pu = !0, setTimeout(function() {
          pu = !1;
          var d = mu;
          mu = {}, gu(d, !1);
        }, 0));
      }
      function gu(s, u) {
        u === void 0 && (u = !1);
        var d = /* @__PURE__ */ new Set();
        if (s.all)
          for (var f = 0, g = Object.values(Er); f < g.length; f++) {
            var b = g[f];
            Bl(b, s, d, u);
          }
        else
          for (var _ in s) {
            var T = /^idb\:\/\/(.*)\/(.*)\//.exec(_);
            if (T) {
              var C = T[1], E = T[2], b = Er["idb://".concat(C, "/").concat(E)];
              b && Bl(b, s, d, u);
            }
          }
        d.forEach(function(D) {
          return D();
        });
      }
      function Bl(s, u, d, f) {
        for (var g = [], b = 0, _ = Object.entries(s.queries.query); b < _.length; b++) {
          for (var T = _[b], C = T[0], E = T[1], D = [], x = 0, O = E; x < O.length; x++) {
            var U = O[x];
            fu(u, U.obsSet) ? U.subscribers.forEach(function($) {
              return d.add($);
            }) : f && D.push(U);
          }
          f && g.push([C, D]);
        }
        if (f)
          for (var I = 0, R = g; I < R.length; I++) {
            var N = R[I], C = N[0], D = N[1];
            s.queries.query[C] = D;
          }
      }
      function Ig(s) {
        var u = s._state, d = s._deps.indexedDB;
        if (u.isBeingOpened || s.idbdb)
          return u.dbReadyPromise.then(function() {
            return u.dbOpenError ? Ke(u.dbOpenError) : s;
          });
        u.isBeingOpened = !0, u.dbOpenError = null, u.openComplete = !1;
        var f = u.openCanceller, g = Math.round(s.verno * 10), b = !1;
        function _() {
          if (u.openCanceller !== f)
            throw new ae.DatabaseClosed("db.open() was cancelled");
        }
        var T = u.dbReadyResolve, C = null, E = !1, D = function() {
          return new Q(function(O, U) {
            if (_(), !d)
              throw new ae.MissingAPI();
            var I = s.name, R = u.autoSchema || !g ? d.open(I) : d.open(I, g);
            if (!R)
              throw new ae.MissingAPI();
            R.onerror = an(U), R.onblocked = Oe(s._fireOnBlocked), R.onupgradeneeded = Oe(function(N) {
              if (C = R.transaction, u.autoSchema && !s._options.allowEmptyDB) {
                R.onerror = Ko, C.abort(), R.result.close();
                var $ = d.deleteDatabase(I);
                $.onsuccess = $.onerror = Oe(function() {
                  U(new ae.NoSuchDatabase("Database ".concat(I, " doesnt exist")));
                });
              } else {
                C.onerror = an(U);
                var q = N.oldVersion > Math.pow(2, 62) ? 0 : N.oldVersion;
                E = q < 1, s.idbdb = R.result, b && vg(s, C), gg(s, q / 10, C, U);
              }
            }, U), R.onsuccess = Oe(function() {
              C = null;
              var N = s.idbdb = R.result, $ = H(N.objectStoreNames);
              if ($.length > 0)
                try {
                  var q = N.transaction(cg($), "readonly");
                  if (u.autoSchema)
                    kg(s, N, q);
                  else if (Ta(s, s._dbSchema, q), !_g(s, q) && !b)
                    return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), N.close(), g = N.version + 1, b = !0, O(D());
                  ba(s, q);
                } catch {
                }
              Vo.add(s), N.onversionchange = Oe(function(Z) {
                u.vcFired = !0, s.on("versionchange").fire(Z);
              }), N.onclose = Oe(function() {
                s.close({ disableAutoOpen: !1 });
              }), E && Eg(s._deps, I), O();
            }, U);
          }).catch(function(O) {
            switch (O == null ? void 0 : O.name) {
              case "UnknownError":
                if (u.PR1398_maxLoop > 0)
                  return u.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), D();
                break;
              case "VersionError":
                if (g > 0)
                  return g = 0, D();
                break;
            }
            return Q.reject(O);
          });
        }, x = typeof navigator < "u" && !!d && d === a.indexedDB;
        return Q.race([
          f,
          (x ? Dg() : Q.resolve()).then(D)
        ]).then(function() {
          return _(), u.onReadyBeingFired = [], Q.resolve(lu(function() {
            return s.on.ready.fire(s.vip);
          })).then(function O() {
            if (u.onReadyBeingFired.length > 0) {
              var U = u.onReadyBeingFired.reduce(Ls, Se);
              return u.onReadyBeingFired = [], Q.resolve(lu(function() {
                return U(s.vip);
              })).then(O);
            }
          });
        }).finally(function() {
          u.openCanceller === f && (u.onReadyBeingFired = null, u.isBeingOpened = !1);
        }).catch(function(O) {
          u.dbOpenError = O;
          try {
            C && C.abort();
          } catch {
          }
          return f === u.openCanceller && s._close(), Ke(O);
        }).finally(function() {
          u.openComplete = !0, T();
        }).then(function() {
          if (E) {
            var O = {};
            s.tables.forEach(function(U) {
              U.schema.indexes.forEach(function(I) {
                I.name && (O["idb://".concat(s.name, "/").concat(U.name, "/").concat(I.name)] = new at(-1 / 0, [[[]]]));
              }), O["idb://".concat(s.name, "/").concat(U.name, "/")] = O["idb://".concat(s.name, "/").concat(U.name, "/:dels")] = new at(-1 / 0, [[[]]]);
            }), Jn(ya).fire(O), gu(O, !0);
          }
          return s;
        });
      }
      function vu(s) {
        var u = function(_) {
          return s.next(_);
        }, d = function(_) {
          return s.throw(_);
        }, f = b(u), g = b(d);
        function b(_) {
          return function(T) {
            var C = _(T), E = C.value;
            return C.done ? E : !E || typeof E.then != "function" ? l(E) ? Promise.all(E).then(f, g) : f(E) : E.then(f, g);
          };
        }
        return b(u)();
      }
      function zg(s, u, d) {
        var f = arguments.length;
        if (f < 2)
          throw new ae.InvalidArgument("Too few arguments");
        for (var g = new Array(f - 1); --f; )
          g[f - 1] = arguments[f];
        d = g.pop();
        var b = He(g);
        return [s, b, d];
      }
      function Hl(s, u, d, f, g) {
        return Q.resolve().then(function() {
          var b = ee.transless || ee, _ = s._createTransaction(u, d, s._dbSchema, f);
          _.explicit = !0;
          var T = {
            trans: _,
            transless: b
          };
          if (f)
            _.idbtrans = f.idbtrans;
          else
            try {
              _.create(), _.idbtrans._explicit = !0, s._state.PR1398_maxLoop = 3;
            } catch (x) {
              return x.name === js.InvalidState && s.isOpen() && --s._state.PR1398_maxLoop > 0 ? (console.warn("Dexie: Need to reopen db"), s.close({ disableAutoOpen: !1 }), s.open().then(function() {
                return Hl(s, u, d, null, g);
              })) : Ke(x);
            }
          var C = $s(g);
          C && to();
          var E, D = Q.follow(function() {
            if (E = g.call(_, _), E)
              if (C) {
                var x = Hn.bind(null, null);
                E.then(x, x);
              } else typeof E.next == "function" && typeof E.throw == "function" && (E = vu(E));
          }, T);
          return (E && typeof E.then == "function" ? Q.resolve(E).then(function(x) {
            return _.active ? x : Ke(new ae.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
          }) : D.then(function() {
            return E;
          })).then(function(x) {
            return f && _._resolve(), _._completion.then(function() {
              return x;
            });
          }).catch(function(x) {
            return _._reject(x), Ke(x);
          });
        });
      }
      function Ea(s, u, d) {
        for (var f = l(s) ? s.slice() : [s], g = 0; g < d; ++g)
          f.push(u);
        return f;
      }
      function Rg(s) {
        return o(o({}, s), { table: function(u) {
          var d = s.table(u), f = d.schema, g = /* @__PURE__ */ Object.create(null), b = [];
          function _(R, N, $) {
            var q = Yo(R), Z = g[q] = g[q] || [], j = R == null ? 0 : typeof R == "string" ? 1 : R.length, G = N > 0, B = o(o({}, $), { name: G ? "".concat(q, "(virtual-from:").concat($.name, ")") : $.name, lowLevelIndex: $, isVirtual: G, keyTail: N, keyLength: j, extractKey: ou(R), unique: !G && $.unique });
            if (Z.push(B), B.isPrimaryKey || b.push(B), j > 1) {
              var Y = j === 2 ? R[0] : R.slice(0, j - 1);
              _(Y, N + 1, $);
            }
            return Z.sort(function(V, X) {
              return V.keyTail - X.keyTail;
            }), B;
          }
          var T = _(f.primaryKey.keyPath, 0, f.primaryKey);
          g[":id"] = [T];
          for (var C = 0, E = f.indexes; C < E.length; C++) {
            var D = E[C];
            _(D.keyPath, 0, D);
          }
          function x(R) {
            var N = g[Yo(R)];
            return N && N[0];
          }
          function O(R, N) {
            return {
              type: R.type === 1 ? 2 : R.type,
              lower: Ea(R.lower, R.lowerOpen ? s.MAX_KEY : s.MIN_KEY, N),
              lowerOpen: !0,
              upper: Ea(R.upper, R.upperOpen ? s.MIN_KEY : s.MAX_KEY, N),
              upperOpen: !0
            };
          }
          function U(R) {
            var N = R.query.index;
            return N.isVirtual ? o(o({}, R), { query: {
              index: N.lowLevelIndex,
              range: O(R.query.range, N.keyTail)
            } }) : R;
          }
          var I = o(o({}, d), { schema: o(o({}, f), { primaryKey: T, indexes: b, getIndexByKeyPath: x }), count: function(R) {
            return d.count(U(R));
          }, query: function(R) {
            return d.query(U(R));
          }, openCursor: function(R) {
            var N = R.query.index, $ = N.keyTail, q = N.isVirtual, Z = N.keyLength;
            if (!q)
              return d.openCursor(R);
            function j(G) {
              function B(V) {
                V != null ? G.continue(Ea(V, R.reverse ? s.MAX_KEY : s.MIN_KEY, $)) : R.unique ? G.continue(G.key.slice(0, Z).concat(R.reverse ? s.MIN_KEY : s.MAX_KEY, $)) : G.continue();
              }
              var Y = Object.create(G, {
                continue: { value: B },
                continuePrimaryKey: {
                  value: function(V, X) {
                    G.continuePrimaryKey(Ea(V, s.MAX_KEY, $), X);
                  }
                },
                primaryKey: {
                  get: function() {
                    return G.primaryKey;
                  }
                },
                key: {
                  get: function() {
                    var V = G.key;
                    return Z === 1 ? V[0] : V.slice(0, Z);
                  }
                },
                value: {
                  get: function() {
                    return G.value;
                  }
                }
              });
              return Y;
            }
            return d.openCursor(U(R)).then(function(G) {
              return G && j(G);
            });
          } });
          return I;
        } });
      }
      var xg = {
        stack: "dbcore",
        name: "VirtualIndexMiddleware",
        level: 1,
        create: Rg
      };
      function yu(s, u, d, f) {
        return d = d || {}, f = f || "", c(s).forEach(function(g) {
          if (!v(u, g))
            d[f + g] = void 0;
          else {
            var b = s[g], _ = u[g];
            if (typeof b == "object" && typeof _ == "object" && b && _) {
              var T = Os(b), C = Os(_);
              T !== C ? d[f + g] = u[g] : T === "Object" ? yu(b, _, d, f + g + ".") : b !== _ && (d[f + g] = u[g]);
            } else b !== _ && (d[f + g] = u[g]);
          }
        }), c(u).forEach(function(g) {
          v(s, g) || (d[f + g] = u[g]);
        }), d;
      }
      function bu(s, u) {
        return u.type === "delete" ? u.keys : u.keys || u.values.map(s.extractKey);
      }
      var Og = {
        stack: "dbcore",
        name: "HooksMiddleware",
        level: 2,
        create: function(s) {
          return o(o({}, s), { table: function(u) {
            var d = s.table(u), f = d.schema.primaryKey, g = o(o({}, d), { mutate: function(b) {
              var _ = ee.trans, T = _.table(u).hook, C = T.deleting, E = T.creating, D = T.updating;
              switch (b.type) {
                case "add":
                  if (E.fire === Se)
                    break;
                  return _._promise("readwrite", function() {
                    return x(b);
                  }, !0);
                case "put":
                  if (E.fire === Se && D.fire === Se)
                    break;
                  return _._promise("readwrite", function() {
                    return x(b);
                  }, !0);
                case "delete":
                  if (C.fire === Se)
                    break;
                  return _._promise("readwrite", function() {
                    return x(b);
                  }, !0);
                case "deleteRange":
                  if (C.fire === Se)
                    break;
                  return _._promise("readwrite", function() {
                    return O(b);
                  }, !0);
              }
              return d.mutate(b);
              function x(I) {
                var R = ee.trans, N = I.keys || bu(f, I);
                if (!N)
                  throw new Error("Keys missing");
                return I = I.type === "add" || I.type === "put" ? o(o({}, I), { keys: N }) : o({}, I), I.type !== "delete" && (I.values = i([], I.values)), I.keys && (I.keys = i([], I.keys)), Mg(d, I, N).then(function($) {
                  var q = N.map(function(Z, j) {
                    var G = $[j], B = { onerror: null, onsuccess: null };
                    if (I.type === "delete")
                      C.fire.call(B, Z, G, R);
                    else if (I.type === "add" || G === void 0) {
                      var Y = E.fire.call(B, Z, I.values[j], R);
                      Z == null && Y != null && (Z = Y, I.keys[j] = Z, f.outbound || _e(I.values[j], f.keyPath, Z));
                    } else {
                      var V = yu(G, I.values[j]), X = D.fire.call(B, V, Z, G, R);
                      if (X) {
                        var be = I.values[j];
                        Object.keys(X).forEach(function(oe) {
                          v(be, oe) ? be[oe] = X[oe] : _e(be, oe, X[oe]);
                        });
                      }
                    }
                    return B;
                  });
                  return d.mutate(I).then(function(Z) {
                    for (var j = Z.failures, G = Z.results, B = Z.numFailures, Y = Z.lastResult, V = 0; V < N.length; ++V) {
                      var X = G ? G[V] : N[V], be = q[V];
                      X == null ? be.onerror && be.onerror(j[V]) : be.onsuccess && be.onsuccess(
                        I.type === "put" && $[V] ? I.values[V] : X
                      );
                    }
                    return { failures: j, results: G, numFailures: B, lastResult: Y };
                  }).catch(function(Z) {
                    return q.forEach(function(j) {
                      return j.onerror && j.onerror(Z);
                    }), Promise.reject(Z);
                  });
                });
              }
              function O(I) {
                return U(I.trans, I.range, 1e4);
              }
              function U(I, R, N) {
                return d.query({
                  trans: I,
                  values: !1,
                  query: { index: f, range: R },
                  limit: N
                }).then(function($) {
                  var q = $.result;
                  return x({
                    type: "delete",
                    keys: q,
                    trans: I
                  }).then(function(Z) {
                    return Z.numFailures > 0 ? Promise.reject(Z.failures[0]) : q.length < N ? {
                      failures: [],
                      numFailures: 0,
                      lastResult: void 0
                    } : U(I, o(o({}, R), { lower: q[q.length - 1], lowerOpen: !0 }), N);
                  });
                });
              }
            } });
            return g;
          } });
        }
      };
      function Mg(s, u, d) {
        return u.type === "add" ? Promise.resolve([]) : s.getMany({
          trans: u.trans,
          keys: d,
          cache: "immutable"
        });
      }
      function Ql(s, u, d) {
        try {
          if (!u || u.keys.length < s.length)
            return null;
          for (var f = [], g = 0, b = 0; g < u.keys.length && b < s.length; ++g)
            we(u.keys[g], s[b]) === 0 && (f.push(d ? Sn(u.values[g]) : u.values[g]), ++b);
          return f.length === s.length ? f : null;
        } catch {
          return null;
        }
      }
      var $g = {
        stack: "dbcore",
        level: -1,
        create: function(s) {
          return {
            table: function(u) {
              var d = s.table(u);
              return o(o({}, d), { getMany: function(f) {
                if (!f.cache)
                  return d.getMany(f);
                var g = Ql(f.keys, f.trans._cache, f.cache === "clone");
                return g ? Q.resolve(g) : d.getMany(f).then(function(b) {
                  return f.trans._cache = {
                    keys: f.keys,
                    values: f.cache === "clone" ? Sn(b) : b
                  }, b;
                });
              }, mutate: function(f) {
                return f.type !== "add" && (f.trans._cache = null), d.mutate(f);
              } });
            }
          };
        }
      };
      function Xl(s, u) {
        return s.trans.mode === "readonly" && !!s.subscr && !s.trans.explicit && s.trans.db._options.cache !== "disabled" && !u.schema.primaryKey.outbound;
      }
      function Jl(s, u) {
        switch (s) {
          case "query":
            return u.values && !u.unique;
          case "get":
            return !1;
          case "getMany":
            return !1;
          case "count":
            return !1;
          case "openCursor":
            return !1;
        }
      }
      var Ng = {
        stack: "dbcore",
        level: 0,
        name: "Observability",
        create: function(s) {
          var u = s.schema.name, d = new at(s.MIN_KEY, s.MAX_KEY);
          return o(o({}, s), { transaction: function(f, g, b) {
            if (ee.subscr && g !== "readonly")
              throw new ae.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(ee.querier));
            return s.transaction(f, g, b);
          }, table: function(f) {
            var g = s.table(f), b = g.schema, _ = b.primaryKey, T = b.indexes, C = _.extractKey, E = _.outbound, D = _.autoIncrement && T.filter(function(I) {
              return I.compound && I.keyPath.includes(_.keyPath);
            }), x = o(o({}, g), { mutate: function(I) {
              var R, N, $ = I.trans, q = I.mutatedParts || (I.mutatedParts = {}), Z = function(se) {
                var ce = "idb://".concat(u, "/").concat(f, "/").concat(se);
                return q[ce] || (q[ce] = new at());
              }, j = Z(""), G = Z(":dels"), B = I.type, Y = I.type === "deleteRange" ? [I.range] : I.type === "delete" ? [I.keys] : I.values.length < 50 ? [
                bu(_, I).filter(function(se) {
                  return se != null;
                }),
                I.values
              ] : [], V = Y[0], X = Y[1], be = I.trans._cache;
              if (l(V)) {
                j.addKeys(V);
                var oe = B === "delete" || V.length === X.length ? Ql(V, be) : null;
                oe || G.addKeys(V), (oe || X) && jg(Z, b, oe, X);
              } else if (V) {
                var J = {
                  from: (R = V.lower) !== null && R !== void 0 ? R : s.MIN_KEY,
                  to: (N = V.upper) !== null && N !== void 0 ? N : s.MAX_KEY
                };
                G.add(J), j.add(J);
              } else
                j.add(d), G.add(d), b.indexes.forEach(function(se) {
                  return Z(se.name).add(d);
                });
              return g.mutate(I).then(function(se) {
                return V && (I.type === "add" || I.type === "put") && (j.addKeys(se.results), D && D.forEach(function(ce) {
                  for (var Ie = I.values.map(function(dt) {
                    return ce.extractKey(dt);
                  }), ie = ce.keyPath.findIndex(function(dt) {
                    return dt === _.keyPath;
                  }), Ve = 0, Vt = se.results.length; Ve < Vt; ++Ve)
                    Ie[Ve][ie] = se.results[Ve];
                  Z(ce.name).addKeys(Ie);
                })), $.mutatedParts = Pa($.mutatedParts || {}, q), se;
              });
            } }), O = function(I) {
              var R, N, $ = I.query, q = $.index, Z = $.range;
              return [
                q,
                new at((R = Z.lower) !== null && R !== void 0 ? R : s.MIN_KEY, (N = Z.upper) !== null && N !== void 0 ? N : s.MAX_KEY)
              ];
            }, U = {
              get: function(I) {
                return [_, new at(I.key)];
              },
              getMany: function(I) {
                return [_, new at().addKeys(I.keys)];
              },
              count: O,
              query: O,
              openCursor: O
            };
            return c(U).forEach(function(I) {
              x[I] = function(R) {
                var N = ee.subscr, $ = !!N, q = Xl(ee, g) && Jl(I, R), Z = q ? R.obsSet = {} : N;
                if ($) {
                  var j = function(oe) {
                    var J = "idb://".concat(u, "/").concat(f, "/").concat(oe);
                    return Z[J] || (Z[J] = new at());
                  }, G = j(""), B = j(":dels"), Y = U[I](R), V = Y[0], X = Y[1];
                  if (I === "query" && V.isPrimaryKey && !R.values ? B.add(X) : j(V.name || "").add(X), !V.isPrimaryKey)
                    if (I === "count")
                      B.add(d);
                    else {
                      var be = I === "query" && E && R.values && g.query(o(o({}, R), { values: !1 }));
                      return g[I].apply(this, arguments).then(function(oe) {
                        if (I === "query") {
                          if (E && R.values)
                            return be.then(function(Ie) {
                              var ie = Ie.result;
                              return G.addKeys(ie), oe;
                            });
                          var J = R.values ? oe.result.map(C) : oe.result;
                          R.values ? G.addKeys(J) : B.addKeys(J);
                        } else if (I === "openCursor") {
                          var se = oe, ce = R.values;
                          return se && Object.create(se, {
                            key: {
                              get: function() {
                                return B.addKey(se.primaryKey), se.key;
                              }
                            },
                            primaryKey: {
                              get: function() {
                                var Ie = se.primaryKey;
                                return B.addKey(Ie), Ie;
                              }
                            },
                            value: {
                              get: function() {
                                return ce && G.addKey(se.primaryKey), se.value;
                              }
                            }
                          });
                        }
                        return oe;
                      });
                    }
                }
                return g[I].apply(this, arguments);
              };
            }), x;
          } });
        }
      };
      function jg(s, u, d, f) {
        function g(b) {
          var _ = s(b.name || "");
          function T(E) {
            return E != null ? b.extractKey(E) : null;
          }
          var C = function(E) {
            return b.multiEntry && l(E) ? E.forEach(function(D) {
              return _.addKey(D);
            }) : _.addKey(E);
          };
          (d || f).forEach(function(E, D) {
            var x = d && T(d[D]), O = f && T(f[D]);
            we(x, O) !== 0 && (x != null && C(x), O != null && C(O));
          });
        }
        u.indexes.forEach(g);
      }
      function ed(s, u, d) {
        if (d.numFailures === 0)
          return u;
        if (u.type === "deleteRange")
          return null;
        var f = u.keys ? u.keys.length : "values" in u && u.values ? u.values.length : 1;
        if (d.numFailures === f)
          return null;
        var g = o({}, u);
        return l(g.keys) && (g.keys = g.keys.filter(function(b, _) {
          return !(_ in d.failures);
        })), "values" in g && l(g.values) && (g.values = g.values.filter(function(b, _) {
          return !(_ in d.failures);
        })), g;
      }
      function Lg(s, u) {
        return u.lower === void 0 ? !0 : u.lowerOpen ? we(s, u.lower) > 0 : we(s, u.lower) >= 0;
      }
      function Gg(s, u) {
        return u.upper === void 0 ? !0 : u.upperOpen ? we(s, u.upper) < 0 : we(s, u.upper) <= 0;
      }
      function wu(s, u) {
        return Lg(s, u) && Gg(s, u);
      }
      function td(s, u, d, f, g, b) {
        if (!d || d.length === 0)
          return s;
        var _ = u.query.index, T = _.multiEntry, C = u.query.range, E = f.schema.primaryKey, D = E.extractKey, x = _.extractKey, O = (_.lowLevelIndex || _).extractKey, U = d.reduce(function(R, N) {
          var $ = R, q = [];
          if (N.type === "add" || N.type === "put")
            for (var Z = new at(), j = N.values.length - 1; j >= 0; --j) {
              var G = N.values[j], B = D(G);
              if (!Z.hasKey(B)) {
                var Y = x(G);
                (T && l(Y) ? Y.some(function(J) {
                  return wu(J, C);
                }) : wu(Y, C)) && (Z.addKey(B), q.push(G));
              }
            }
          switch (N.type) {
            case "add": {
              var V = new at().addKeys(u.values ? R.map(function(J) {
                return D(J);
              }) : R);
              $ = R.concat(u.values ? q.filter(function(J) {
                var se = D(J);
                return V.hasKey(se) ? !1 : (V.addKey(se), !0);
              }) : q.map(function(J) {
                return D(J);
              }).filter(function(J) {
                return V.hasKey(J) ? !1 : (V.addKey(J), !0);
              }));
              break;
            }
            case "put": {
              var X = new at().addKeys(N.values.map(function(J) {
                return D(J);
              }));
              $ = R.filter(
                function(J) {
                  return !X.hasKey(u.values ? D(J) : J);
                }
              ).concat(
                u.values ? q : q.map(function(J) {
                  return D(J);
                })
              );
              break;
            }
            case "delete":
              var be = new at().addKeys(N.keys);
              $ = R.filter(function(J) {
                return !be.hasKey(u.values ? D(J) : J);
              });
              break;
            case "deleteRange":
              var oe = N.range;
              $ = R.filter(function(J) {
                return !wu(D(J), oe);
              });
              break;
          }
          return $;
        }, s);
        if (U === s)
          return s;
        var I = function(R, N) {
          return we(O(R), O(N)) || we(D(R), D(N));
        };
        return U.sort(u.direction === "prev" || u.direction === "prevunique" ? function(R, N) {
          return I(N, R);
        } : I), u.limit && u.limit < 1 / 0 && (U.length > u.limit ? U.length = u.limit : s.length === u.limit && U.length < u.limit && (g.dirty = !0)), b ? Object.freeze(U) : U;
      }
      function nd(s, u) {
        return we(s.lower, u.lower) === 0 && we(s.upper, u.upper) === 0 && !!s.lowerOpen == !!u.lowerOpen && !!s.upperOpen == !!u.upperOpen;
      }
      function Fg(s, u, d, f) {
        if (s === void 0)
          return u !== void 0 ? -1 : 0;
        if (u === void 0)
          return 1;
        var g = we(s, u);
        if (g === 0) {
          if (d && f)
            return 0;
          if (d)
            return 1;
          if (f)
            return -1;
        }
        return g;
      }
      function Ug(s, u, d, f) {
        if (s === void 0)
          return u !== void 0 ? 1 : 0;
        if (u === void 0)
          return -1;
        var g = we(s, u);
        if (g === 0) {
          if (d && f)
            return 0;
          if (d)
            return -1;
          if (f)
            return 1;
        }
        return g;
      }
      function Zg(s, u) {
        return Fg(s.lower, u.lower, s.lowerOpen, u.lowerOpen) <= 0 && Ug(s.upper, u.upper, s.upperOpen, u.upperOpen) >= 0;
      }
      function qg(s, u, d, f) {
        var g, b = Er["idb://".concat(s, "/").concat(u)];
        if (!b)
          return [];
        var _ = b.queries[d];
        if (!_)
          return [null, !1, b, null];
        var T = f.query ? f.query.index.name : null, C = _[T || ""];
        if (!C)
          return [null, !1, b, null];
        switch (d) {
          case "query":
            var E = (g = f.direction) !== null && g !== void 0 ? g : "next", D = C.find(function(U) {
              var I;
              return U.req.limit === f.limit && U.req.values === f.values && ((I = U.req.direction) !== null && I !== void 0 ? I : "next") === E && nd(U.req.query.range, f.query.range);
            });
            if (D)
              return [
                D,
                !0,
                b,
                C
              ];
            var x = C.find(function(U) {
              var I, R = "limit" in U.req ? U.req.limit : 1 / 0;
              return R >= f.limit && ((I = U.req.direction) !== null && I !== void 0 ? I : "next") === E && (f.values ? U.req.values : !0) && Zg(U.req.query.range, f.query.range);
            });
            return [x, !1, b, C];
          case "count":
            var O = C.find(function(U) {
              return nd(U.req.query.range, f.query.range);
            });
            return [O, !!O, b, C];
        }
      }
      function Kg(s, u, d, f) {
        s.subscribers.add(d), f.addEventListener("abort", function() {
          s.subscribers.delete(d), s.subscribers.size === 0 && Wg(s, u);
        });
      }
      function Wg(s, u) {
        setTimeout(function() {
          s.subscribers.size === 0 && br(u, s);
        }, 3e3);
      }
      var Yg = {
        stack: "dbcore",
        level: 0,
        name: "Cache",
        create: function(s) {
          var u = s.schema.name, d = o(o({}, s), { transaction: function(f, g, b) {
            var _ = s.transaction(f, g, b);
            if (g === "readwrite") {
              var T = new AbortController(), C = T.signal, E = function(D) {
                return function() {
                  if (T.abort(), g === "readwrite") {
                    for (var x = /* @__PURE__ */ new Set(), O = 0, U = f; O < U.length; O++) {
                      var I = U[O], R = Er["idb://".concat(u, "/").concat(I)];
                      if (R) {
                        var N = s.table(I), $ = R.optimisticOps.filter(function(ce) {
                          return ce.trans === _;
                        });
                        if (_._explicit && D && _.mutatedParts)
                          for (var q = 0, Z = Object.values(R.queries.query); q < Z.length; q++)
                            for (var j = Z[q], G = 0, B = j.slice(); G < B.length; G++) {
                              var Y = B[G];
                              fu(Y.obsSet, _.mutatedParts) && (br(j, Y), Y.subscribers.forEach(function(ce) {
                                return x.add(ce);
                              }));
                            }
                        else if ($.length > 0) {
                          R.optimisticOps = R.optimisticOps.filter(function(ce) {
                            return ce.trans !== _;
                          });
                          for (var V = 0, X = Object.values(R.queries.query); V < X.length; V++)
                            for (var j = X[V], be = 0, oe = j.slice(); be < oe.length; be++) {
                              var Y = oe[be];
                              if (Y.res != null && _.mutatedParts)
                                if (D && !Y.dirty) {
                                  var J = Object.isFrozen(Y.res), se = td(Y.res, Y.req, $, N, Y, J);
                                  Y.dirty ? (br(j, Y), Y.subscribers.forEach(function(ie) {
                                    return x.add(ie);
                                  })) : se !== Y.res && (Y.res = se, Y.promise = Q.resolve({
                                    result: se
                                  }));
                                } else
                                  Y.dirty && br(j, Y), Y.subscribers.forEach(function(ie) {
                                    return x.add(ie);
                                  });
                            }
                        }
                      }
                    }
                    x.forEach(function(ce) {
                      return ce();
                    });
                  }
                };
              };
              _.addEventListener("abort", E(!1), {
                signal: C
              }), _.addEventListener("error", E(!1), {
                signal: C
              }), _.addEventListener("complete", E(!0), {
                signal: C
              });
            }
            return _;
          }, table: function(f) {
            var g = s.table(f), b = g.schema.primaryKey, _ = o(o({}, g), { mutate: function(T) {
              var C = ee.trans;
              if (b.outbound || C.db._options.cache === "disabled" || C.explicit || C.idbtrans.mode !== "readwrite")
                return g.mutate(T);
              var E = Er["idb://".concat(u, "/").concat(f)];
              if (!E)
                return g.mutate(T);
              var D = g.mutate(T);
              return (T.type === "add" || T.type === "put") && (T.values.length >= 50 || bu(b, T).some(function(x) {
                return x == null;
              })) ? D.then(function(x) {
                var O = o(o({}, T), { values: T.values.map(function(I, R) {
                  var N;
                  if (x.failures[R])
                    return I;
                  var $ = !((N = b.keyPath) === null || N === void 0) && N.includes(".") ? Sn(I) : o({}, I);
                  return _e($, b.keyPath, x.results[R]), $;
                }) }), U = ed(E, O, x);
                E.optimisticOps.push(U), queueMicrotask(function() {
                  return T.mutatedParts && Aa(T.mutatedParts);
                });
              }) : (E.optimisticOps.push(T), T.mutatedParts && Aa(T.mutatedParts), D.then(function(x) {
                if (x.numFailures > 0) {
                  br(E.optimisticOps, T);
                  var O = ed(E, T, x);
                  O && E.optimisticOps.push(O), T.mutatedParts && Aa(T.mutatedParts);
                }
              }), D.catch(function() {
                br(E.optimisticOps, T), T.mutatedParts && Aa(T.mutatedParts);
              })), D;
            }, query: function(T) {
              var C;
              if (!Xl(ee, g) || !Jl("query", T))
                return g.query(T);
              var E = ((C = ee.trans) === null || C === void 0 ? void 0 : C.db._options.cache) === "immutable", D = ee, x = D.requery, O = D.signal, U = qg(u, f, "query", T), I = U[0], R = U[1], N = U[2], $ = U[3];
              if (I && R)
                I.obsSet = T.obsSet;
              else {
                var q = g.query(T).then(function(Z) {
                  var j = Z.result;
                  if (I && (I.res = j), E) {
                    for (var G = 0, B = j.length; G < B; ++G)
                      Object.freeze(j[G]);
                    Object.freeze(j);
                  }
                  return Z;
                }).catch(function(Z) {
                  return $ && I && br($, I), Promise.reject(Z);
                });
                I = {
                  obsSet: T.obsSet,
                  promise: q,
                  subscribers: /* @__PURE__ */ new Set(),
                  type: "query",
                  req: T,
                  dirty: !1
                }, $ ? $.push(I) : ($ = [I], N || (N = Er["idb://".concat(u, "/").concat(f)] = {
                  queries: {
                    query: {},
                    count: {}
                  },
                  objs: /* @__PURE__ */ new Map(),
                  optimisticOps: [],
                  unsignaledParts: {}
                }), N.queries.query[T.query.index.name || ""] = $);
              }
              return Kg(I, $, x, O), I.promise.then(function(Z) {
                var j = td(Z.result, T, N == null ? void 0 : N.optimisticOps, g, I, E);
                return {
                  result: E ? j : Sn(j)
                };
              });
            } });
            return _;
          } });
          return d;
        }
      };
      function Sa(s, u) {
        return new Proxy(s, {
          get: function(d, f, g) {
            return f === "db" ? u : Reflect.get(d, f, g);
          }
        });
      }
      var Rn = (function() {
        function s(u, d) {
          var f = this;
          this._middlewares = {}, this.verno = 0;
          var g = s.dependencies;
          this._options = d = o({
            addons: s.addons,
            autoOpen: !0,
            indexedDB: g.indexedDB,
            IDBKeyRange: g.IDBKeyRange,
            cache: "cloned",
            maxConnections: Il
          }, d), this._deps = {
            indexedDB: d.indexedDB,
            IDBKeyRange: d.IDBKeyRange
          };
          var b = d.addons;
          this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
          var _ = {
            dbOpenError: null,
            isBeingOpened: !1,
            onReadyBeingFired: null,
            openComplete: !1,
            dbReadyResolve: Se,
            dbReadyPromise: null,
            cancelOpen: Se,
            openCanceller: null,
            autoSchema: !0,
            PR1398_maxLoop: 3,
            autoOpen: d.autoOpen
          };
          _.dbReadyPromise = new Q(function(C) {
            _.dbReadyResolve = C;
          }), _.openCanceller = new Q(function(C, E) {
            _.cancelOpen = E;
          }), this._state = _, this.name = u, this.on = Zo(this, "populate", "blocked", "versionchange", "close", {
            ready: [Ls, Se]
          }), this.once = function(C, E) {
            var D = function() {
              for (var x = [], O = 0; O < arguments.length; O++)
                x[O] = arguments[O];
              f.on(C).unsubscribe(D), E.apply(f, x);
            };
            return f.on(C, D);
          }, this.on.ready.subscribe = re(this.on.ready.subscribe, function(C) {
            return function(E, D) {
              s.vip(function() {
                var x = f._state;
                if (x.openComplete)
                  x.dbOpenError || Q.resolve().then(E), D && C(E);
                else if (x.onReadyBeingFired)
                  x.onReadyBeingFired.push(E), D && C(E);
                else {
                  C(E);
                  var O = f;
                  D || C(function U() {
                    O.on.ready.unsubscribe(E), O.on.ready.unsubscribe(U);
                  });
                }
              });
            };
          }), this.Collection = eg(this), this.Table = Qp(this), this.Transaction = ug(this), this.Version = Cg(this), this.WhereClause = ag(this), this.on("versionchange", function(C) {
            C.newVersion > 0 ? console.warn("Another connection wants to upgrade database '".concat(f.name, "'. Closing db now to resume the upgrade.")) : console.warn("Another connection wants to delete database '".concat(f.name, "'. Closing db now to resume the delete request.")), f.close({ disableAutoOpen: !1 });
          }), this.on("blocked", function(C) {
            !C.newVersion || C.newVersion < C.oldVersion ? console.warn("Dexie.delete('".concat(f.name, "') was blocked")) : console.warn("Upgrade '".concat(f.name, "' blocked by other connection holding version ").concat(C.oldVersion / 10));
          }), this._maxKey = Wo(d.IDBKeyRange), this._createTransaction = function(C, E, D, x) {
            return new f.Transaction(C, E, D, f._options.chromeTransactionDurability, x);
          }, this._fireOnBlocked = function(C) {
            f.on("blocked").fire(C), Vo.toArray().filter(function(E) {
              return E.name === f.name && E !== f && !E._state.vcFired;
            }).map(function(E) {
              return E.on("versionchange").fire(C);
            });
          }, this.use($g), this.use(Yg), this.use(Ng), this.use(xg), this.use(Og);
          var T = new Proxy(this, {
            get: function(C, E, D) {
              if (E === "_vip")
                return !0;
              if (E === "table")
                return function(O) {
                  return Sa(f.table(O), T);
                };
              var x = Reflect.get(C, E, D);
              return x instanceof $l ? Sa(x, T) : E === "tables" ? x.map(function(O) {
                return Sa(O, T);
              }) : E === "_createTransaction" ? function() {
                var O = x.apply(this, arguments);
                return Sa(O, T);
              } : x;
            }
          });
          this.vip = T, b.forEach(function(C) {
            return C(f);
          });
        }
        return s.prototype.version = function(u) {
          if (isNaN(u) || u < 0.1)
            throw new ae.Type("Given version is not a positive number");
          if (u = Math.round(u * 10) / 10, this.idbdb || this._state.isBeingOpened)
            throw new ae.Schema("Cannot add version when database is open");
          this.verno = Math.max(this.verno, u);
          var d = this._versions, f = d.filter(function(g) {
            return g._cfg.version === u;
          })[0];
          return f || (f = new this.Version(u), d.push(f), d.sort(pg), f.stores({}), this._state.autoSchema = !1, f);
        }, s.prototype._whenReady = function(u) {
          var d = this;
          return this.idbdb && (this._state.openComplete || ee.letThrough || this._vip) ? u() : new Q(function(f, g) {
            if (d._state.openComplete)
              return g(new ae.DatabaseClosed(d._state.dbOpenError));
            if (!d._state.isBeingOpened) {
              if (!d._state.autoOpen) {
                g(new ae.DatabaseClosed());
                return;
              }
              d.open().catch(Se);
            }
            d._state.dbReadyPromise.then(f, g);
          }).then(u);
        }, s.prototype.use = function(u) {
          var d = u.stack, f = u.create, g = u.level, b = u.name;
          b && this.unuse({ stack: d, name: b });
          var _ = this._middlewares[d] || (this._middlewares[d] = []);
          return _.push({
            stack: d,
            create: f,
            level: g ?? 10,
            name: b
          }), _.sort(function(T, C) {
            return T.level - C.level;
          }), this;
        }, s.prototype.unuse = function(u) {
          var d = u.stack, f = u.name, g = u.create;
          return d && this._middlewares[d] && (this._middlewares[d] = this._middlewares[d].filter(function(b) {
            return g ? b.create !== g : f ? b.name !== f : !1;
          })), this;
        }, s.prototype.open = function() {
          var u = this;
          return Cr(
            In,
            function() {
              return Ig(u);
            }
          );
        }, s.prototype._close = function() {
          this.on.close.fire(new CustomEvent("close"));
          var u = this._state;
          if (Vo.remove(this), this.idbdb) {
            try {
              this.idbdb.close();
            } catch {
            }
            this.idbdb = null;
          }
          u.isBeingOpened || (u.dbReadyPromise = new Q(function(d) {
            u.dbReadyResolve = d;
          }), u.openCanceller = new Q(function(d, f) {
            u.cancelOpen = f;
          }));
        }, s.prototype.close = function(u) {
          var d = u === void 0 ? { disableAutoOpen: !0 } : u, f = d.disableAutoOpen, g = this._state;
          f ? (g.isBeingOpened && g.cancelOpen(new ae.DatabaseClosed()), this._close(), g.autoOpen = !1, g.dbOpenError = new ae.DatabaseClosed()) : (this._close(), g.autoOpen = this._options.autoOpen || g.isBeingOpened, g.openComplete = !1, g.dbOpenError = null);
        }, s.prototype.delete = function(u) {
          var d = this;
          u === void 0 && (u = { disableAutoOpen: !0 });
          var f = arguments.length > 0 && typeof arguments[0] != "object", g = this._state;
          return new Q(function(b, _) {
            var T = function() {
              d.close(u);
              var C = d._deps.indexedDB.deleteDatabase(d.name);
              C.onsuccess = Oe(function() {
                Sg(d._deps, d.name), b();
              }), C.onerror = an(_), C.onblocked = d._fireOnBlocked;
            };
            if (f)
              throw new ae.InvalidArgument("Invalid closeOptions argument to db.delete()");
            g.isBeingOpened ? g.dbReadyPromise.then(T) : T();
          });
        }, s.prototype.backendDB = function() {
          return this.idbdb;
        }, s.prototype.isOpen = function() {
          return this.idbdb !== null;
        }, s.prototype.hasBeenClosed = function() {
          var u = this._state.dbOpenError;
          return u && u.name === "DatabaseClosedError";
        }, s.prototype.hasFailed = function() {
          return this._state.dbOpenError !== null;
        }, s.prototype.dynamicallyOpened = function() {
          return this._state.autoSchema;
        }, Object.defineProperty(s.prototype, "tables", {
          get: function() {
            var u = this;
            return c(this._allTables).map(function(d) {
              return u._allTables[d];
            });
          },
          enumerable: !1,
          configurable: !0
        }), s.prototype.transaction = function() {
          var u = zg.apply(this, arguments);
          return this._transaction.apply(this, u);
        }, s.prototype._transaction = function(u, d, f) {
          var g = this, b = ee.trans;
          (!b || b.db !== this || u.indexOf("!") !== -1) && (b = null);
          var _ = u.indexOf("?") !== -1;
          u = u.replace("!", "").replace("?", "");
          var T, C;
          try {
            if (C = d.map(function(D) {
              var x = D instanceof g.Table ? D.name : D;
              if (typeof x != "string")
                throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
              return x;
            }), u == "r" || u === Qs)
              T = Qs;
            else if (u == "rw" || u == Xs)
              T = Xs;
            else
              throw new ae.InvalidArgument("Invalid transaction mode: " + u);
            if (b) {
              if (b.mode === Qs && T === Xs)
                if (_)
                  b = null;
                else
                  throw new ae.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
              b && C.forEach(function(D) {
                if (b && b.storeNames.indexOf(D) === -1)
                  if (_)
                    b = null;
                  else
                    throw new ae.SubTransaction("Table " + D + " not included in parent transaction.");
              }), _ && b && !b.active && (b = null);
            }
          } catch (D) {
            return b ? b._promise(null, function(x, O) {
              O(D);
            }) : Ke(D);
          }
          var E = Hl.bind(null, this, T, C, b, f);
          return b ? b._promise(T, E, "lock") : ee.trans ? Cr(ee.transless, function() {
            return g._whenReady(E);
          }) : this._whenReady(E);
        }, s.prototype.table = function(u) {
          if (!v(this._allTables, u))
            throw new ae.InvalidTable("Table ".concat(u, " does not exist"));
          return this._allTables[u];
        }, s;
      })(), Vg = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", Bg = (function() {
        function s(u) {
          this._subscribe = u;
        }
        return s.prototype.subscribe = function(u, d, f) {
          return this._subscribe(!u || typeof u == "function" ? { next: u, error: d, complete: f } : u);
        }, s.prototype[Vg] = function() {
          return this;
        }, s;
      })(), Da;
      try {
        Da = {
          indexedDB: a.indexedDB || a.mozIndexedDB || a.webkitIndexedDB || a.msIndexedDB,
          IDBKeyRange: a.IDBKeyRange || a.webkitIDBKeyRange
        };
      } catch {
        Da = { indexedDB: null, IDBKeyRange: null };
      }
      function rd(s) {
        var u = !1, d, f = new Bg(function(g) {
          var b = $s(s);
          function _($) {
            var q = Jr();
            try {
              b && to();
              var Z = Bn(s, $);
              return b && (Z = Z.finally(Hn)), Z;
            } finally {
              q && eo();
            }
          }
          var T = !1, C, E = {}, D = {}, x = {
            get closed() {
              return T;
            },
            unsubscribe: function() {
              T || (T = !0, C && C.abort(), O && Jn.storagemutated.unsubscribe(R));
            }
          };
          g.start && g.start(x);
          var O = !1, U = function() {
            return Vs(N);
          };
          function I() {
            return fu(D, E);
          }
          var R = function($) {
            Pa(E, $), I() && U();
          }, N = function() {
            if (!(T || !Da.indexedDB)) {
              E = {};
              var $ = {};
              C && C.abort(), C = new AbortController();
              var q = {
                subscr: $,
                signal: C.signal,
                requery: U,
                querier: s,
                trans: null
              }, Z = _(q);
              O || (Jn.storagemutated.subscribe(R), O = !0), Promise.resolve(Z).then(function(j) {
                u = !0, d = j, !(T || q.signal.aborted) && (I() ? U() : (D = $, I() ? U() : (E = {}, Vs(function() {
                  return !T && g.next && g.next(j);
                }))));
              }, function(j) {
                T || q.signal.aborted || (u = !1, ["DatabaseClosedError", "AbortError"].includes(j == null ? void 0 : j.name) || T || Vs(function() {
                  T || g.error && g.error(j);
                }));
              });
            }
          };
          return setTimeout(U, 0), x;
        });
        return f.hasValue = function() {
          return u;
        }, f.getValue = function() {
          return d;
        }, f;
      }
      var Sr = Rn;
      k(Sr, o(o({}, ra), {
        delete: function(s) {
          var u = new Sr(s, { addons: [] });
          return u.delete();
        },
        exists: function(s) {
          return new Sr(s, { addons: [] }).open().then(function(u) {
            return u.close(), !0;
          }).catch("NoSuchDatabaseError", function() {
            return !1;
          });
        },
        getDatabaseNames: function(s) {
          try {
            return Ag(Sr.dependencies).then(s);
          } catch {
            return Ke(new ae.MissingAPI());
          }
        },
        defineClass: function() {
          function s(u) {
            h(this, u);
          }
          return s;
        },
        ignoreTransaction: function(s) {
          return ee.trans ? Cr(ee.transless || In, s) : s();
        },
        vip: lu,
        async: function(s) {
          return function() {
            try {
              var u = vu(s.apply(this, arguments));
              return !u || typeof u.then != "function" ? Q.resolve(u) : u;
            } catch (d) {
              return Ke(d);
            }
          };
        },
        spawn: function(s, u, d) {
          try {
            var f = vu(s.apply(d, u || []));
            return !f || typeof f.then != "function" ? Q.resolve(f) : f;
          } catch (g) {
            return Ke(g);
          }
        },
        currentTransaction: {
          get: function() {
            return ee.trans || null;
          }
        },
        waitFor: function(s, u) {
          var d = Q.resolve(typeof s == "function" ? Sr.ignoreTransaction(s) : s).timeout(u || 6e4);
          return ee.trans ? ee.trans.waitFor(d) : d;
        },
        Promise: Q,
        debug: {
          get: function() {
            return dn;
          },
          set: function(s) {
            bl(s);
          }
        },
        derive: S,
        extend: h,
        props: k,
        override: re,
        Events: Zo,
        on: Jn,
        liveQuery: rd,
        extendObservabilitySet: Pa,
        getByKeyPath: he,
        setByKeyPath: _e,
        delByKeyPath: De,
        shallowClone: Ce,
        deepClone: Sn,
        getObjectDiff: yu,
        cmp: we,
        asap: ye,
        minKey: Hs,
        addons: [],
        connections: {
          get: Vo.toArray
        },
        errnames: js,
        dependencies: Da,
        cache: Er,
        semVer: Sl,
        version: Sl.split(".").map(function(s) {
          return parseInt(s);
        }).reduce(function(s, u, d) {
          return s + u / Math.pow(10, d * 2);
        })
      })), Sr.maxKey = Wo(Sr.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (Jn(ya, function(s) {
        if (!er) {
          var u;
          u = new CustomEvent(tu, {
            detail: s
          }), er = !0, dispatchEvent(u), er = !1;
        }
      }), addEventListener(tu, function(s) {
        var u = s.detail;
        er || ku(u);
      }));
      function ku(s) {
        var u = er;
        try {
          er = !0, Jn.storagemutated.fire(s), gu(s, !0);
        } finally {
          er = u;
        }
      }
      var er = !1, tr, _u = function() {
      };
      typeof BroadcastChannel < "u" && (_u = function() {
        tr = new BroadcastChannel(tu), tr.onmessage = function(s) {
          return s.data && ku(s.data);
        };
      }, _u(), typeof tr.unref == "function" && tr.unref(), Jn(ya, function(s) {
        er || tr.postMessage(s);
      })), typeof addEventListener < "u" && (addEventListener("pagehide", function(s) {
        if (!Rn.disableBfCache && s.persisted) {
          dn && console.debug("Dexie: handling persisted pagehide"), tr == null || tr.close();
          for (var u = 0, d = Vo.toArray(); u < d.length; u++) {
            var f = d[u];
            f.close({ disableAutoOpen: !1 });
          }
        }
      }), addEventListener("pageshow", function(s) {
        !Rn.disableBfCache && s.persisted && (dn && console.debug("Dexie: handling persisted pageshow"), _u(), ku({ all: new at(-1 / 0, [[]]) }));
      }));
      function Hg(s) {
        return new Uo({ add: s });
      }
      function Qg(s) {
        return new Uo({ remove: s });
      }
      function Xg(s, u) {
        return new Uo({ replacePrefix: [s, u] });
      }
      Q.rejectionMapper = zp, bl(dn);
      var Jg = /* @__PURE__ */ Object.freeze({
        __proto__: null,
        DEFAULT_MAX_CONNECTIONS: Il,
        Dexie: Rn,
        Entity: Rl,
        PropModification: Uo,
        RangeSet: at,
        add: Hg,
        cmp: we,
        default: Rn,
        liveQuery: rd,
        mergeRanges: Ho,
        rangesOverlap: Wl,
        remove: Qg,
        replacePrefix: Xg
      });
      return o(Rn, Jg, { default: Rn }), Rn;
    }));
  })(Ua)), Ua.exports;
}
var z_ = I_();
const sc = /* @__PURE__ */ S_(z_), Hd = Symbol.for("Dexie"), ts = globalThis[Hd] || (globalThis[Hd] = sc);
if (sc.semVer !== ts.semVer)
  throw new Error(`Two different versions of Dexie loaded in the same app: ${sc.semVer} and ${ts.semVer}`);
const {
  liveQuery: wS,
  mergeRanges: kS,
  rangesOverlap: _S,
  RangeSet: TS,
  cmp: CS,
  Entity: PS,
  PropModification: AS,
  replacePrefix: ES,
  add: SS,
  remove: DS,
  DexieYProvider: IS
} = ts;
ys({
  title: Ue().trim().min(1, "Enter a task title.").max(200),
  category: Yc.optional(),
  description: Ue().max(5e3).default(""),
  /** Free-form reminders about the task: things not to forget. */
  notes: Ue().max(5e3).optional(),
  priority: ko(["low", "medium", "high"]),
  status: ko(["todo", "in_progress", "paused", "completed", "deferred"]),
  estimatedMinutes: jn().int().min(1).max(1440),
  deadline: Ue().datetime().optional(),
  dependencyIds: wo(Ue().min(1)).max(100).optional(),
  scheduledDate: Wc().optional()
});
const co = Ue().regex(/^([01]\d|2[0-3]):[0-5]\d$/), R_ = ys({ id: Ue(), title: Ue().trim().min(1).max(80), start: co, minutes: jn().int().min(1).max(240) });
ys({
  id: un("workday"),
  timeZone: Ue().refine((t) => {
    try {
      return new Intl.DateTimeFormat("en", { timeZone: t }), !/^[+-]/.test(t);
    } catch {
      return !1;
    }
  }, "Enter a valid IANA timezone."),
  start: co,
  end: co,
  workingDays: wo(jn().int().min(1).max(7)).min(1),
  lunchEnabled: hn(),
  lunchStart: co,
  lunchMinutes: jn().int().min(1).max(240),
  breaks: wo(R_).max(12),
  notificationsEnabled: hn(),
  /** Show reminders as a small browser window instead of a system notification. Missing in older saved settings: treated as on. */
  popupReminders: hn().default(!0),
  taskReminders: hn(),
  meetingReminders: hn(),
  breakReminders: hn(),
  workdayReminders: hn(),
  reminderLeadMinutes: jn().int().min(0).max(60),
  checkInMinutes: jn().int().min(0).max(240),
  quietEnabled: hn(),
  quietStart: co,
  quietEnd: co
}).refine((t) => t.start !== t.end, { message: "Start and end must differ. An earlier end means an overnight workday.", path: ["end"] });
function x_() {
  return { id: "workday", timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC", start: "09:00", end: "17:00", workingDays: [1, 2, 3, 4, 5], lunchEnabled: !0, lunchStart: "12:30", lunchMinutes: 30, breaks: [], notificationsEnabled: !0, popupReminders: !0, taskReminders: !0, meetingReminders: !0, breakReminders: !0, workdayReminders: !0, reminderLeadMinutes: 5, checkInMinutes: 30, quietEnabled: !1, quietStart: "18:00", quietEnd: "08:00" };
}
class O_ extends ts {
  constructor(n = "workday-assistant") {
    super(n);
    me(this, "aiPreferences");
    me(this, "aiConfig");
    me(this, "modelCache");
    me(this, "chatMessages");
    me(this, "aiProposals");
    me(this, "tasks");
    me(this, "blocks");
    me(this, "sessions");
    me(this, "events");
    me(this, "settings");
    me(this, "plans");
    me(this, "reminders");
    this.version(1).stores({ tasks: "id, status, scheduledDate, createdAt", blocks: "id, taskId, start", sessions: "id, taskId, startedAt", events: "id, externalId, start" }), this.version(2).stores({ blocks: "id, taskId, start, planDate", settings: "id", plans: "date", reminders: "id, at, taskId, date" }), this.version(3).stores({ aiConfig: "id", modelCache: "id", chatMessages: "id, createdAt, inReplyTo", aiProposals: "id, status, userMessageId" }), this.version(4).stores({ aiPreferences: "id" });
  }
}
const Vc = new O_();
async function M_(t = Vc) {
  return await t.settings.get("workday") ?? x_();
}
class y extends Array {
  constructor(e, n) {
    if (super(e), this.sign = n, Object.setPrototypeOf(this, y.prototype), e > y.__kMaxLength) throw new RangeError("Maximum BigInt size exceeded");
  }
  static BigInt(e) {
    var n = Math.floor, r = Number.isFinite;
    if (typeof e == "number") {
      if (e === 0) return y.__zero();
      if (y.__isOneDigitInt(e)) return 0 > e ? y.__oneDigit(-e, !0) : y.__oneDigit(e, !1);
      if (!r(e) || n(e) !== e) throw new RangeError("The number " + e + " cannot be converted to BigInt because it is not an integer");
      return y.__fromDouble(e);
    }
    if (typeof e == "string") {
      const o = y.__fromString(e);
      if (o === null) throw new SyntaxError("Cannot convert " + e + " to a BigInt");
      return o;
    }
    if (typeof e == "boolean") return e === !0 ? y.__oneDigit(1, !1) : y.__zero();
    if (typeof e == "object") {
      if (e.constructor === y) return e;
      const o = y.__toPrimitive(e);
      return y.BigInt(o);
    }
    throw new TypeError("Cannot convert " + e + " to a BigInt");
  }
  toDebugString() {
    const e = ["BigInt["];
    for (const n of this) e.push((n && (n >>> 0).toString(16)) + ", ");
    return e.push("]"), e.join("");
  }
  toString(e = 10) {
    if (2 > e || 36 < e) throw new RangeError("toString() radix argument must be between 2 and 36");
    return this.length === 0 ? "0" : (e & e - 1) == 0 ? y.__toStringBasePowerOfTwo(this, e) : y.__toStringGeneric(this, e, !1);
  }
  valueOf() {
    throw new Error("Convert JSBI instances to native numbers using `toNumber`.");
  }
  static toNumber(e) {
    const n = e.length;
    if (n === 0) return 0;
    if (n === 1) {
      const S = e.__unsignedDigit(0);
      return e.sign ? -S : S;
    }
    const r = e.__digit(n - 1), o = y.__clz30(r), i = 30 * n - o;
    if (1024 < i) return e.sign ? -1 / 0 : 1 / 0;
    let a = i - 1, c = r, l = n - 1;
    const h = o + 3;
    let m = h === 32 ? 0 : c << h;
    m >>>= 12;
    const p = h - 12;
    let v = 12 <= h ? 0 : c << 20 + h, k = 20 + h;
    for (0 < p && 0 < l && (l--, c = e.__digit(l), m |= c >>> 30 - p, v = c << p + 2, k = p + 2); 0 < k && 0 < l; ) l--, c = e.__digit(l), v |= 30 <= k ? c << k - 30 : c >>> 30 - k, k -= 30;
    const P = y.__decideRounding(e, k, l, c);
    if ((P === 1 || P === 0 && (1 & v) == 1) && (v = v + 1 >>> 0, v === 0 && (m++, m >>> 20 != 0 && (m = 0, a++, 1023 < a)))) return e.sign ? -1 / 0 : 1 / 0;
    const A = e.sign ? -2147483648 : 0;
    return a = a + 1023 << 20, y.__kBitConversionInts[y.__kBitConversionIntHigh] = A | a | m, y.__kBitConversionInts[y.__kBitConversionIntLow] = v, y.__kBitConversionDouble[0];
  }
  static unaryMinus(e) {
    if (e.length === 0) return e;
    const n = e.__copy();
    return n.sign = !e.sign, n;
  }
  static bitwiseNot(e) {
    return e.sign ? y.__absoluteSubOne(e).__trim() : y.__absoluteAddOne(e, !0);
  }
  static exponentiate(e, n) {
    if (n.sign) throw new RangeError("Exponent must be positive");
    if (n.length === 0) return y.__oneDigit(1, !1);
    if (e.length === 0) return e;
    if (e.length === 1 && e.__digit(0) === 1) return e.sign && (1 & n.__digit(0)) == 0 ? y.unaryMinus(e) : e;
    if (1 < n.length) throw new RangeError("BigInt too big");
    let r = n.__unsignedDigit(0);
    if (r === 1) return e;
    if (r >= y.__kMaxLengthBits) throw new RangeError("BigInt too big");
    if (e.length === 1 && e.__digit(0) === 2) {
      const a = 1 + (0 | r / 30), c = e.sign && (1 & r) != 0, l = new y(a, c);
      l.__initializeDigits();
      const h = 1 << r % 30;
      return l.__setDigit(a - 1, h), l;
    }
    let o = null, i = e;
    for ((1 & r) != 0 && (o = e), r >>= 1; r !== 0; r >>= 1) i = y.multiply(i, i), (1 & r) != 0 && (o === null ? o = i : o = y.multiply(o, i));
    return o;
  }
  static multiply(e, n) {
    if (e.length === 0) return e;
    if (n.length === 0) return n;
    let r = e.length + n.length;
    30 <= e.__clzmsd() + n.__clzmsd() && r--;
    const o = new y(r, e.sign !== n.sign);
    o.__initializeDigits();
    for (let i = 0; i < e.length; i++) y.__multiplyAccumulate(n, e.__digit(i), o, i);
    return o.__trim();
  }
  static divide(e, n) {
    if (n.length === 0) throw new RangeError("Division by zero");
    if (0 > y.__absoluteCompare(e, n)) return y.__zero();
    const r = e.sign !== n.sign, o = n.__unsignedDigit(0);
    let i;
    if (n.length === 1 && 32767 >= o) {
      if (o === 1) return r === e.sign ? e : y.unaryMinus(e);
      i = y.__absoluteDivSmall(e, o, null);
    } else i = y.__absoluteDivLarge(e, n, !0, !1);
    return i.sign = r, i.__trim();
  }
  static remainder(e, n) {
    if (n.length === 0) throw new RangeError("Division by zero");
    if (0 > y.__absoluteCompare(e, n)) return e;
    const r = n.__unsignedDigit(0);
    if (n.length === 1 && 32767 >= r) {
      if (r === 1) return y.__zero();
      const i = y.__absoluteModSmall(e, r);
      return i === 0 ? y.__zero() : y.__oneDigit(i, e.sign);
    }
    const o = y.__absoluteDivLarge(e, n, !1, !0);
    return o.sign = e.sign, o.__trim();
  }
  static add(e, n) {
    const r = e.sign;
    return r === n.sign ? y.__absoluteAdd(e, n, r) : 0 <= y.__absoluteCompare(e, n) ? y.__absoluteSub(e, n, r) : y.__absoluteSub(n, e, !r);
  }
  static subtract(e, n) {
    const r = e.sign;
    return r === n.sign ? 0 <= y.__absoluteCompare(e, n) ? y.__absoluteSub(e, n, r) : y.__absoluteSub(n, e, !r) : y.__absoluteAdd(e, n, r);
  }
  static leftShift(e, n) {
    return n.length === 0 || e.length === 0 ? e : n.sign ? y.__rightShiftByAbsolute(e, n) : y.__leftShiftByAbsolute(e, n);
  }
  static signedRightShift(e, n) {
    return n.length === 0 || e.length === 0 ? e : n.sign ? y.__leftShiftByAbsolute(e, n) : y.__rightShiftByAbsolute(e, n);
  }
  static unsignedRightShift() {
    throw new TypeError("BigInts have no unsigned right shift; use >> instead");
  }
  static lessThan(e, n) {
    return 0 > y.__compareToBigInt(e, n);
  }
  static lessThanOrEqual(e, n) {
    return 0 >= y.__compareToBigInt(e, n);
  }
  static greaterThan(e, n) {
    return 0 < y.__compareToBigInt(e, n);
  }
  static greaterThanOrEqual(e, n) {
    return 0 <= y.__compareToBigInt(e, n);
  }
  static equal(e, n) {
    if (e.sign !== n.sign || e.length !== n.length) return !1;
    for (let r = 0; r < e.length; r++) if (e.__digit(r) !== n.__digit(r)) return !1;
    return !0;
  }
  static notEqual(e, n) {
    return !y.equal(e, n);
  }
  static bitwiseAnd(e, n) {
    var r = Math.max;
    if (!e.sign && !n.sign) return y.__absoluteAnd(e, n).__trim();
    if (e.sign && n.sign) {
      const o = r(e.length, n.length) + 1;
      let i = y.__absoluteSubOne(e, o);
      const a = y.__absoluteSubOne(n);
      return i = y.__absoluteOr(i, a, i), y.__absoluteAddOne(i, !0, i).__trim();
    }
    return e.sign && ([e, n] = [n, e]), y.__absoluteAndNot(e, y.__absoluteSubOne(n)).__trim();
  }
  static bitwiseXor(e, n) {
    var r = Math.max;
    if (!e.sign && !n.sign) return y.__absoluteXor(e, n).__trim();
    if (e.sign && n.sign) {
      const a = r(e.length, n.length), c = y.__absoluteSubOne(e, a), l = y.__absoluteSubOne(n);
      return y.__absoluteXor(c, l, c).__trim();
    }
    const o = r(e.length, n.length) + 1;
    e.sign && ([e, n] = [n, e]);
    let i = y.__absoluteSubOne(n, o);
    return i = y.__absoluteXor(i, e, i), y.__absoluteAddOne(i, !0, i).__trim();
  }
  static bitwiseOr(e, n) {
    var r = Math.max;
    const o = r(e.length, n.length);
    if (!e.sign && !n.sign) return y.__absoluteOr(e, n).__trim();
    if (e.sign && n.sign) {
      let a = y.__absoluteSubOne(e, o);
      const c = y.__absoluteSubOne(n);
      return a = y.__absoluteAnd(a, c, a), y.__absoluteAddOne(a, !0, a).__trim();
    }
    e.sign && ([e, n] = [n, e]);
    let i = y.__absoluteSubOne(n, o);
    return i = y.__absoluteAndNot(i, e, i), y.__absoluteAddOne(i, !0, i).__trim();
  }
  static asIntN(e, n) {
    var r = Math.floor;
    if (n.length === 0) return n;
    if (e = r(e), 0 > e) throw new RangeError("Invalid value: not (convertible to) a safe integer");
    if (e === 0) return y.__zero();
    if (e >= y.__kMaxLengthBits) return n;
    const o = 0 | (e + 29) / 30;
    if (n.length < o) return n;
    const i = n.__unsignedDigit(o - 1), a = 1 << (e - 1) % 30;
    if (n.length === o && i < a) return n;
    if ((i & a) !== a) return y.__truncateToNBits(e, n);
    if (!n.sign) return y.__truncateAndSubFromPowerOfTwo(e, n, !0);
    if ((i & a - 1) == 0) {
      for (let c = o - 2; 0 <= c; c--) if (n.__digit(c) !== 0) return y.__truncateAndSubFromPowerOfTwo(e, n, !1);
      return n.length === o && i === a ? n : y.__truncateToNBits(e, n);
    }
    return y.__truncateAndSubFromPowerOfTwo(e, n, !1);
  }
  static asUintN(e, n) {
    var r = Math.floor;
    if (n.length === 0) return n;
    if (e = r(e), 0 > e) throw new RangeError("Invalid value: not (convertible to) a safe integer");
    if (e === 0) return y.__zero();
    if (n.sign) {
      if (e > y.__kMaxLengthBits) throw new RangeError("BigInt too big");
      return y.__truncateAndSubFromPowerOfTwo(e, n, !1);
    }
    if (e >= y.__kMaxLengthBits) return n;
    const o = 0 | (e + 29) / 30;
    if (n.length < o) return n;
    const i = e % 30;
    return n.length == o && (i === 0 || !(n.__digit(o - 1) >>> i)) ? n : y.__truncateToNBits(e, n);
  }
  static ADD(e, n) {
    if (e = y.__toPrimitive(e), n = y.__toPrimitive(n), typeof e == "string") return typeof n != "string" && (n = n.toString()), e + n;
    if (typeof n == "string") return e.toString() + n;
    if (e = y.__toNumeric(e), n = y.__toNumeric(n), y.__isBigInt(e) && y.__isBigInt(n)) return y.add(e, n);
    if (typeof e == "number" && typeof n == "number") return e + n;
    throw new TypeError("Cannot mix BigInt and other types, use explicit conversions");
  }
  static LT(e, n) {
    return y.__compare(e, n, 0);
  }
  static LE(e, n) {
    return y.__compare(e, n, 1);
  }
  static GT(e, n) {
    return y.__compare(e, n, 2);
  }
  static GE(e, n) {
    return y.__compare(e, n, 3);
  }
  static EQ(e, n) {
    for (; ; ) {
      if (y.__isBigInt(e)) return y.__isBigInt(n) ? y.equal(e, n) : y.EQ(n, e);
      if (typeof e == "number") {
        if (y.__isBigInt(n)) return y.__equalToNumber(n, e);
        if (typeof n != "object") return e == n;
        n = y.__toPrimitive(n);
      } else if (typeof e == "string") {
        if (y.__isBigInt(n)) return e = y.__fromString(e), e !== null && y.equal(e, n);
        if (typeof n != "object") return e == n;
        n = y.__toPrimitive(n);
      } else if (typeof e == "boolean") {
        if (y.__isBigInt(n)) return y.__equalToNumber(n, +e);
        if (typeof n != "object") return e == n;
        n = y.__toPrimitive(n);
      } else if (typeof e == "symbol") {
        if (y.__isBigInt(n)) return !1;
        if (typeof n != "object") return e == n;
        n = y.__toPrimitive(n);
      } else if (typeof e == "object") {
        if (typeof n == "object" && n.constructor !== y) return e == n;
        e = y.__toPrimitive(e);
      } else return e == n;
    }
  }
  static NE(e, n) {
    return !y.EQ(e, n);
  }
  static DataViewGetBigInt64(e, n, r = !1) {
    return y.asIntN(64, y.DataViewGetBigUint64(e, n, r));
  }
  static DataViewGetBigUint64(e, n, r = !1) {
    const [o, i] = r ? [4, 0] : [0, 4], a = e.getUint32(n + o, r), c = e.getUint32(n + i, r), l = new y(3, !1);
    return l.__setDigit(0, 1073741823 & c), l.__setDigit(1, (268435455 & a) << 2 | c >>> 30), l.__setDigit(2, a >>> 28), l.__trim();
  }
  static DataViewSetBigInt64(e, n, r, o = !1) {
    y.DataViewSetBigUint64(e, n, r, o);
  }
  static DataViewSetBigUint64(e, n, r, o = !1) {
    r = y.asUintN(64, r);
    let i = 0, a = 0;
    if (0 < r.length && (a = r.__digit(0), 1 < r.length)) {
      const h = r.__digit(1);
      a |= h << 30, i = h >>> 2, 2 < r.length && (i |= r.__digit(2) << 28);
    }
    const [c, l] = o ? [4, 0] : [0, 4];
    e.setUint32(n + c, i, o), e.setUint32(n + l, a, o);
  }
  static __zero() {
    return new y(0, !1);
  }
  static __oneDigit(e, n) {
    const r = new y(1, n);
    return r.__setDigit(0, e), r;
  }
  __copy() {
    const e = new y(this.length, this.sign);
    for (let n = 0; n < this.length; n++) e[n] = this[n];
    return e;
  }
  __trim() {
    let e = this.length, n = this[e - 1];
    for (; n === 0; ) e--, n = this[e - 1], this.pop();
    return e === 0 && (this.sign = !1), this;
  }
  __initializeDigits() {
    for (let e = 0; e < this.length; e++) this[e] = 0;
  }
  static __decideRounding(e, n, r, o) {
    if (0 < n) return -1;
    let i;
    if (0 > n) i = -n - 1;
    else {
      if (r === 0) return -1;
      r--, o = e.__digit(r), i = 29;
    }
    let a = 1 << i;
    if ((o & a) == 0) return -1;
    if (a -= 1, (o & a) != 0) return 1;
    for (; 0 < r; ) if (r--, e.__digit(r) !== 0) return 1;
    return 0;
  }
  static __fromDouble(e) {
    y.__kBitConversionDouble[0] = e;
    const n = 2047 & y.__kBitConversionInts[y.__kBitConversionIntHigh] >>> 20, r = n - 1023, o = (0 | r / 30) + 1, i = new y(o, 0 > e);
    let a = 1048575 & y.__kBitConversionInts[y.__kBitConversionIntHigh] | 1048576, c = y.__kBitConversionInts[y.__kBitConversionIntLow];
    const l = 20, h = r % 30;
    let m, p = 0;
    if (h < 20) {
      const v = l - h;
      p = v + 32, m = a >>> v, a = a << 32 - v | c >>> v, c <<= 32 - v;
    } else if (h === 20) p = 32, m = a, a = c, c = 0;
    else {
      const v = h - l;
      p = 32 - v, m = a << v | c >>> 32 - v, a = c << v, c = 0;
    }
    i.__setDigit(o - 1, m);
    for (let v = o - 2; 0 <= v; v--) 0 < p ? (p -= 30, m = a >>> 2, a = a << 30 | c >>> 2, c <<= 30) : m = 0, i.__setDigit(v, m);
    return i.__trim();
  }
  static __isWhitespace(e) {
    return 13 >= e && 9 <= e || (159 >= e ? e == 32 : 131071 >= e ? e == 160 || e == 5760 : 196607 >= e ? (e &= 131071, 10 >= e || e == 40 || e == 41 || e == 47 || e == 95 || e == 4096) : e == 65279);
  }
  static __fromString(e, n = 0) {
    let r = 0;
    const o = e.length;
    let i = 0;
    if (i === o) return y.__zero();
    let a = e.charCodeAt(i);
    for (; y.__isWhitespace(a); ) {
      if (++i === o) return y.__zero();
      a = e.charCodeAt(i);
    }
    if (a === 43) {
      if (++i === o) return null;
      a = e.charCodeAt(i), r = 1;
    } else if (a === 45) {
      if (++i === o) return null;
      a = e.charCodeAt(i), r = -1;
    }
    if (n === 0) {
      if (n = 10, a === 48) {
        if (++i === o) return y.__zero();
        if (a = e.charCodeAt(i), a === 88 || a === 120) {
          if (n = 16, ++i === o) return null;
          a = e.charCodeAt(i);
        } else if (a === 79 || a === 111) {
          if (n = 8, ++i === o) return null;
          a = e.charCodeAt(i);
        } else if (a === 66 || a === 98) {
          if (n = 2, ++i === o) return null;
          a = e.charCodeAt(i);
        }
      }
    } else if (n === 16 && a === 48) {
      if (++i === o) return y.__zero();
      if (a = e.charCodeAt(i), a === 88 || a === 120) {
        if (++i === o) return null;
        a = e.charCodeAt(i);
      }
    }
    if (r != 0 && n !== 10) return null;
    for (; a === 48; ) {
      if (++i === o) return y.__zero();
      a = e.charCodeAt(i);
    }
    const c = o - i;
    let l = y.__kMaxBitsPerChar[n], h = y.__kBitsPerCharTableMultiplier - 1;
    if (c > 1073741824 / l) return null;
    const m = l * c + h >>> y.__kBitsPerCharTableShift, p = new y(0 | (m + 29) / 30, !1), v = 10 > n ? n : 10, k = 10 < n ? n - 10 : 0;
    if ((n & n - 1) == 0) {
      l >>= y.__kBitsPerCharTableShift;
      const P = [], A = [];
      let S = !1;
      do {
        let z = 0, L = 0;
        for (; ; ) {
          let W;
          if (a - 48 >>> 0 < v) W = a - 48;
          else if ((32 | a) - 97 >>> 0 < k) W = (32 | a) - 87;
          else {
            S = !0;
            break;
          }
          if (L += l, z = z << l | W, ++i === o) {
            S = !0;
            break;
          }
          if (a = e.charCodeAt(i), 30 < L + l) break;
        }
        P.push(z), A.push(L);
      } while (!S);
      y.__fillFromParts(p, P, A);
    } else {
      p.__initializeDigits();
      let P = !1, A = 0;
      do {
        let S = 0, z = 1;
        for (; ; ) {
          let W;
          if (a - 48 >>> 0 < v) W = a - 48;
          else if ((32 | a) - 97 >>> 0 < k) W = (32 | a) - 87;
          else {
            P = !0;
            break;
          }
          const H = z * n;
          if (1073741823 < H) break;
          if (z = H, S = S * n + W, A++, ++i === o) {
            P = !0;
            break;
          }
          a = e.charCodeAt(i);
        }
        h = 30 * y.__kBitsPerCharTableMultiplier - 1;
        const L = 0 | (l * A + h >>> y.__kBitsPerCharTableShift) / 30;
        p.__inplaceMultiplyAdd(z, S, L);
      } while (!P);
    }
    if (i !== o) {
      if (!y.__isWhitespace(a)) return null;
      for (i++; i < o; i++) if (a = e.charCodeAt(i), !y.__isWhitespace(a)) return null;
    }
    return p.sign = r == -1, p.__trim();
  }
  static __fillFromParts(e, n, r) {
    let o = 0, i = 0, a = 0;
    for (let c = n.length - 1; 0 <= c; c--) {
      const l = n[c], h = r[c];
      i |= l << a, a += h, a === 30 ? (e.__setDigit(o++, i), a = 0, i = 0) : 30 < a && (e.__setDigit(o++, 1073741823 & i), a -= 30, i = l >>> h - a);
    }
    if (i !== 0) {
      if (o >= e.length) throw new Error("implementation bug");
      e.__setDigit(o++, i);
    }
    for (; o < e.length; o++) e.__setDigit(o, 0);
  }
  static __toStringBasePowerOfTwo(e, n) {
    const r = e.length;
    let o = n - 1;
    o = (85 & o >>> 1) + (85 & o), o = (51 & o >>> 2) + (51 & o), o = (15 & o >>> 4) + (15 & o);
    const i = o, a = n - 1, c = e.__digit(r - 1), l = y.__clz30(c);
    let h = 0 | (30 * r - l + i - 1) / i;
    if (e.sign && h++, 268435456 < h) throw new Error("string too long");
    const m = Array(h);
    let p = h - 1, v = 0, k = 0;
    for (let A = 0; A < r - 1; A++) {
      const S = e.__digit(A), z = (v | S << k) & a;
      m[p--] = y.__kConversionChars[z];
      const L = i - k;
      for (v = S >>> L, k = 30 - L; k >= i; ) m[p--] = y.__kConversionChars[v & a], v >>>= i, k -= i;
    }
    const P = (v | c << k) & a;
    for (m[p--] = y.__kConversionChars[P], v = c >>> i - k; v !== 0; ) m[p--] = y.__kConversionChars[v & a], v >>>= i;
    if (e.sign && (m[p--] = "-"), p != -1) throw new Error("implementation bug");
    return m.join("");
  }
  static __toStringGeneric(e, n, r) {
    const o = e.length;
    if (o === 0) return "";
    if (o === 1) {
      let A = e.__unsignedDigit(0).toString(n);
      return r === !1 && e.sign && (A = "-" + A), A;
    }
    const i = 30 * o - y.__clz30(e.__digit(o - 1)), a = y.__kMaxBitsPerChar[n], c = a - 1;
    let l = i * y.__kBitsPerCharTableMultiplier;
    l += c - 1, l = 0 | l / c;
    const h = l + 1 >> 1, m = y.exponentiate(y.__oneDigit(n, !1), y.__oneDigit(h, !1));
    let p, v;
    const k = m.__unsignedDigit(0);
    if (m.length === 1 && 32767 >= k) {
      p = new y(e.length, !1), p.__initializeDigits();
      let A = 0;
      for (let S = 2 * e.length - 1; 0 <= S; S--) {
        const z = A << 15 | e.__halfDigit(S);
        p.__setHalfDigit(S, 0 | z / k), A = 0 | z % k;
      }
      v = A.toString(n);
    } else {
      const A = y.__absoluteDivLarge(e, m, !0, !0);
      p = A.quotient;
      const S = A.remainder.__trim();
      v = y.__toStringGeneric(S, n, !0);
    }
    p.__trim();
    let P = y.__toStringGeneric(p, n, !0);
    for (; v.length < h; ) v = "0" + v;
    return r === !1 && e.sign && (P = "-" + P), P + v;
  }
  static __unequalSign(e) {
    return e ? -1 : 1;
  }
  static __absoluteGreater(e) {
    return e ? -1 : 1;
  }
  static __absoluteLess(e) {
    return e ? 1 : -1;
  }
  static __compareToBigInt(e, n) {
    const r = e.sign;
    if (r !== n.sign) return y.__unequalSign(r);
    const o = y.__absoluteCompare(e, n);
    return 0 < o ? y.__absoluteGreater(r) : 0 > o ? y.__absoluteLess(r) : 0;
  }
  static __compareToNumber(e, n) {
    if (y.__isOneDigitInt(n)) {
      const r = e.sign, o = 0 > n;
      if (r !== o) return y.__unequalSign(r);
      if (e.length === 0) {
        if (o) throw new Error("implementation bug");
        return n === 0 ? 0 : -1;
      }
      if (1 < e.length) return y.__absoluteGreater(r);
      const i = Math.abs(n), a = e.__unsignedDigit(0);
      return a > i ? y.__absoluteGreater(r) : a < i ? y.__absoluteLess(r) : 0;
    }
    return y.__compareToDouble(e, n);
  }
  static __compareToDouble(e, n) {
    if (n !== n) return n;
    if (n === 1 / 0) return -1;
    if (n === -1 / 0) return 1;
    const r = e.sign;
    if (r !== 0 > n) return y.__unequalSign(r);
    if (n === 0) throw new Error("implementation bug: should be handled elsewhere");
    if (e.length === 0) return -1;
    y.__kBitConversionDouble[0] = n;
    const o = 2047 & y.__kBitConversionInts[y.__kBitConversionIntHigh] >>> 20;
    if (o == 2047) throw new Error("implementation bug: handled elsewhere");
    const i = o - 1023;
    if (0 > i) return y.__absoluteGreater(r);
    const a = e.length;
    let c = e.__digit(a - 1);
    const l = y.__clz30(c), h = 30 * a - l, m = i + 1;
    if (h < m) return y.__absoluteLess(r);
    if (h > m) return y.__absoluteGreater(r);
    let p = 1048576 | 1048575 & y.__kBitConversionInts[y.__kBitConversionIntHigh], v = y.__kBitConversionInts[y.__kBitConversionIntLow];
    const k = 20, P = 29 - l;
    if (P !== (0 | (h - 1) % 30)) throw new Error("implementation bug");
    let A, S = 0;
    if (20 > P) {
      const z = k - P;
      S = z + 32, A = p >>> z, p = p << 32 - z | v >>> z, v <<= 32 - z;
    } else if (P === 20) S = 32, A = p, p = v, v = 0;
    else {
      const z = P - k;
      S = 32 - z, A = p << z | v >>> 32 - z, p = v << z, v = 0;
    }
    if (c >>>= 0, A >>>= 0, c > A) return y.__absoluteGreater(r);
    if (c < A) return y.__absoluteLess(r);
    for (let z = a - 2; 0 <= z; z--) {
      0 < S ? (S -= 30, A = p >>> 2, p = p << 30 | v >>> 2, v <<= 30) : A = 0;
      const L = e.__unsignedDigit(z);
      if (L > A) return y.__absoluteGreater(r);
      if (L < A) return y.__absoluteLess(r);
    }
    if (p !== 0 || v !== 0) {
      if (S === 0) throw new Error("implementation bug");
      return y.__absoluteLess(r);
    }
    return 0;
  }
  static __equalToNumber(e, n) {
    var r = Math.abs;
    return y.__isOneDigitInt(n) ? n === 0 ? e.length === 0 : e.length === 1 && e.sign === 0 > n && e.__unsignedDigit(0) === r(n) : y.__compareToDouble(e, n) === 0;
  }
  static __comparisonResultToBool(e, n) {
    return n === 0 ? 0 > e : n === 1 ? 0 >= e : n === 2 ? 0 < e : n === 3 ? 0 <= e : void 0;
  }
  static __compare(e, n, r) {
    if (e = y.__toPrimitive(e), n = y.__toPrimitive(n), typeof e == "string" && typeof n == "string") switch (r) {
      case 0:
        return e < n;
      case 1:
        return e <= n;
      case 2:
        return e > n;
      case 3:
        return e >= n;
    }
    if (y.__isBigInt(e) && typeof n == "string") return n = y.__fromString(n), n !== null && y.__comparisonResultToBool(y.__compareToBigInt(e, n), r);
    if (typeof e == "string" && y.__isBigInt(n)) return e = y.__fromString(e), e !== null && y.__comparisonResultToBool(y.__compareToBigInt(e, n), r);
    if (e = y.__toNumeric(e), n = y.__toNumeric(n), y.__isBigInt(e)) {
      if (y.__isBigInt(n)) return y.__comparisonResultToBool(y.__compareToBigInt(e, n), r);
      if (typeof n != "number") throw new Error("implementation bug");
      return y.__comparisonResultToBool(y.__compareToNumber(e, n), r);
    }
    if (typeof e != "number") throw new Error("implementation bug");
    if (y.__isBigInt(n)) return y.__comparisonResultToBool(y.__compareToNumber(n, e), 2 ^ r);
    if (typeof n != "number") throw new Error("implementation bug");
    return r === 0 ? e < n : r === 1 ? e <= n : r === 2 ? e > n : r === 3 ? e >= n : void 0;
  }
  __clzmsd() {
    return y.__clz30(this.__digit(this.length - 1));
  }
  static __absoluteAdd(e, n, r) {
    if (e.length < n.length) return y.__absoluteAdd(n, e, r);
    if (e.length === 0) return e;
    if (n.length === 0) return e.sign === r ? e : y.unaryMinus(e);
    let o = e.length;
    (e.__clzmsd() === 0 || n.length === e.length && n.__clzmsd() === 0) && o++;
    const i = new y(o, r);
    let a = 0, c = 0;
    for (; c < n.length; c++) {
      const l = e.__digit(c) + n.__digit(c) + a;
      a = l >>> 30, i.__setDigit(c, 1073741823 & l);
    }
    for (; c < e.length; c++) {
      const l = e.__digit(c) + a;
      a = l >>> 30, i.__setDigit(c, 1073741823 & l);
    }
    return c < i.length && i.__setDigit(c, a), i.__trim();
  }
  static __absoluteSub(e, n, r) {
    if (e.length === 0) return e;
    if (n.length === 0) return e.sign === r ? e : y.unaryMinus(e);
    const o = new y(e.length, r);
    let i = 0, a = 0;
    for (; a < n.length; a++) {
      const c = e.__digit(a) - n.__digit(a) - i;
      i = 1 & c >>> 30, o.__setDigit(a, 1073741823 & c);
    }
    for (; a < e.length; a++) {
      const c = e.__digit(a) - i;
      i = 1 & c >>> 30, o.__setDigit(a, 1073741823 & c);
    }
    return o.__trim();
  }
  static __absoluteAddOne(e, n, r = null) {
    const o = e.length;
    r === null ? r = new y(o, n) : r.sign = n;
    let i = 1;
    for (let a = 0; a < o; a++) {
      const c = e.__digit(a) + i;
      i = c >>> 30, r.__setDigit(a, 1073741823 & c);
    }
    return i != 0 && r.__setDigitGrow(o, 1), r;
  }
  static __absoluteSubOne(e, n) {
    const r = e.length;
    n = n || r;
    const o = new y(n, !1);
    let i = 1;
    for (let a = 0; a < r; a++) {
      const c = e.__digit(a) - i;
      i = 1 & c >>> 30, o.__setDigit(a, 1073741823 & c);
    }
    if (i != 0) throw new Error("implementation bug");
    for (let a = r; a < n; a++) o.__setDigit(a, 0);
    return o;
  }
  static __absoluteAnd(e, n, r = null) {
    let o = e.length, i = n.length, a = i;
    if (o < i) {
      a = o;
      const h = e, m = o;
      e = n, o = i, n = h, i = m;
    }
    let c = a;
    r === null ? r = new y(c, !1) : c = r.length;
    let l = 0;
    for (; l < a; l++) r.__setDigit(l, e.__digit(l) & n.__digit(l));
    for (; l < c; l++) r.__setDigit(l, 0);
    return r;
  }
  static __absoluteAndNot(e, n, r = null) {
    const o = e.length, i = n.length;
    let a = i;
    o < i && (a = o);
    let c = o;
    r === null ? r = new y(c, !1) : c = r.length;
    let l = 0;
    for (; l < a; l++) r.__setDigit(l, e.__digit(l) & ~n.__digit(l));
    for (; l < o; l++) r.__setDigit(l, e.__digit(l));
    for (; l < c; l++) r.__setDigit(l, 0);
    return r;
  }
  static __absoluteOr(e, n, r = null) {
    let o = e.length, i = n.length, a = i;
    if (o < i) {
      a = o;
      const h = e, m = o;
      e = n, o = i, n = h, i = m;
    }
    let c = o;
    r === null ? r = new y(c, !1) : c = r.length;
    let l = 0;
    for (; l < a; l++) r.__setDigit(l, e.__digit(l) | n.__digit(l));
    for (; l < o; l++) r.__setDigit(l, e.__digit(l));
    for (; l < c; l++) r.__setDigit(l, 0);
    return r;
  }
  static __absoluteXor(e, n, r = null) {
    let o = e.length, i = n.length, a = i;
    if (o < i) {
      a = o;
      const h = e, m = o;
      e = n, o = i, n = h, i = m;
    }
    let c = o;
    r === null ? r = new y(c, !1) : c = r.length;
    let l = 0;
    for (; l < a; l++) r.__setDigit(l, e.__digit(l) ^ n.__digit(l));
    for (; l < o; l++) r.__setDigit(l, e.__digit(l));
    for (; l < c; l++) r.__setDigit(l, 0);
    return r;
  }
  static __absoluteCompare(e, n) {
    const r = e.length - n.length;
    if (r != 0) return r;
    let o = e.length - 1;
    for (; 0 <= o && e.__digit(o) === n.__digit(o); ) o--;
    return 0 > o ? 0 : e.__unsignedDigit(o) > n.__unsignedDigit(o) ? 1 : -1;
  }
  static __multiplyAccumulate(e, n, r, o) {
    if (n === 0) return;
    const i = 32767 & n, a = n >>> 15;
    let c = 0, l = 0;
    for (let h, m = 0; m < e.length; m++, o++) {
      h = r.__digit(o);
      const p = e.__digit(m), v = 32767 & p, k = p >>> 15, P = y.__imul(v, i), A = y.__imul(v, a), S = y.__imul(k, i), z = y.__imul(k, a);
      h += l + P + c, c = h >>> 30, h &= 1073741823, h += ((32767 & A) << 15) + ((32767 & S) << 15), c += h >>> 30, l = z + (A >>> 15) + (S >>> 15), r.__setDigit(o, 1073741823 & h);
    }
    for (; c != 0 || l !== 0; o++) {
      let h = r.__digit(o);
      h += c + l, l = 0, c = h >>> 30, r.__setDigit(o, 1073741823 & h);
    }
  }
  static __internalMultiplyAdd(e, n, r, o, i) {
    let a = r, c = 0;
    for (let l = 0; l < o; l++) {
      const h = e.__digit(l), m = y.__imul(32767 & h, n), p = y.__imul(h >>> 15, n), v = m + ((32767 & p) << 15) + c + a;
      a = v >>> 30, c = p >>> 15, i.__setDigit(l, 1073741823 & v);
    }
    if (i.length > o) for (i.__setDigit(o++, a + c); o < i.length; ) i.__setDigit(o++, 0);
    else if (a + c !== 0) throw new Error("implementation bug");
  }
  __inplaceMultiplyAdd(e, n, r) {
    r > this.length && (r = this.length);
    const o = 32767 & e, i = e >>> 15;
    let a = 0, c = n;
    for (let l = 0; l < r; l++) {
      const h = this.__digit(l), m = 32767 & h, p = h >>> 15, v = y.__imul(m, o), k = y.__imul(m, i), P = y.__imul(p, o), A = y.__imul(p, i);
      let S = c + v + a;
      a = S >>> 30, S &= 1073741823, S += ((32767 & k) << 15) + ((32767 & P) << 15), a += S >>> 30, c = A + (k >>> 15) + (P >>> 15), this.__setDigit(l, 1073741823 & S);
    }
    if (a != 0 || c !== 0) throw new Error("implementation bug");
  }
  static __absoluteDivSmall(e, n, r = null) {
    r === null && (r = new y(e.length, !1));
    let o = 0;
    for (let i, a = 2 * e.length - 1; 0 <= a; a -= 2) {
      i = (o << 15 | e.__halfDigit(a)) >>> 0;
      const c = 0 | i / n;
      o = 0 | i % n, i = (o << 15 | e.__halfDigit(a - 1)) >>> 0;
      const l = 0 | i / n;
      o = 0 | i % n, r.__setDigit(a >>> 1, c << 15 | l);
    }
    return r;
  }
  static __absoluteModSmall(e, n) {
    let r = 0;
    for (let o = 2 * e.length - 1; 0 <= o; o--)
      r = 0 | ((r << 15 | e.__halfDigit(o)) >>> 0) % n;
    return r;
  }
  static __absoluteDivLarge(e, n, r, o) {
    const i = n.__halfDigitLength(), a = n.length, c = e.__halfDigitLength() - i;
    let l = null;
    r && (l = new y(c + 2 >>> 1, !1), l.__initializeDigits());
    const h = new y(i + 2 >>> 1, !1);
    h.__initializeDigits();
    const m = y.__clz15(n.__halfDigit(i - 1));
    0 < m && (n = y.__specialLeftShift(n, m, 0));
    const p = y.__specialLeftShift(e, m, 1), v = n.__halfDigit(i - 1);
    let k = 0;
    for (let P, A = c; 0 <= A; A--) {
      P = 32767;
      const S = p.__halfDigit(A + i);
      if (S !== v) {
        const L = (S << 15 | p.__halfDigit(A + i - 1)) >>> 0;
        P = 0 | L / v;
        let W = 0 | L % v;
        const H = n.__halfDigit(i - 2), re = p.__halfDigit(A + i - 2);
        for (; y.__imul(P, H) >>> 0 > (W << 16 | re) >>> 0 && (P--, W += v, !(32767 < W)); ) ;
      }
      y.__internalMultiplyAdd(n, P, 0, a, h);
      let z = p.__inplaceSub(h, A, i + 1);
      z !== 0 && (z = p.__inplaceAdd(n, A, i), p.__setHalfDigit(A + i, 32767 & p.__halfDigit(A + i) + z), P--), r && (1 & A ? k = P << 15 : l.__setDigit(A >>> 1, k | P));
    }
    if (o) return p.__inplaceRightShift(m), r ? { quotient: l, remainder: p } : p;
    if (r) return l;
    throw new Error("unreachable");
  }
  static __clz15(e) {
    return y.__clz30(e) - 15;
  }
  __inplaceAdd(e, n, r) {
    let o = 0;
    for (let i = 0; i < r; i++) {
      const a = this.__halfDigit(n + i) + e.__halfDigit(i) + o;
      o = a >>> 15, this.__setHalfDigit(n + i, 32767 & a);
    }
    return o;
  }
  __inplaceSub(e, n, r) {
    let o = 0;
    if (1 & n) {
      n >>= 1;
      let i = this.__digit(n), a = 32767 & i, c = 0;
      for (; c < r - 1 >>> 1; c++) {
        const m = e.__digit(c), p = (i >>> 15) - (32767 & m) - o;
        o = 1 & p >>> 15, this.__setDigit(n + c, (32767 & p) << 15 | 32767 & a), i = this.__digit(n + c + 1), a = (32767 & i) - (m >>> 15) - o, o = 1 & a >>> 15;
      }
      const l = e.__digit(c), h = (i >>> 15) - (32767 & l) - o;
      if (o = 1 & h >>> 15, this.__setDigit(n + c, (32767 & h) << 15 | 32767 & a), n + c + 1 >= this.length) throw new RangeError("out of bounds");
      (1 & r) == 0 && (i = this.__digit(n + c + 1), a = (32767 & i) - (l >>> 15) - o, o = 1 & a >>> 15, this.__setDigit(n + e.length, 1073709056 & i | 32767 & a));
    } else {
      n >>= 1;
      let i = 0;
      for (; i < e.length - 1; i++) {
        const m = this.__digit(n + i), p = e.__digit(i), v = (32767 & m) - (32767 & p) - o;
        o = 1 & v >>> 15;
        const k = (m >>> 15) - (p >>> 15) - o;
        o = 1 & k >>> 15, this.__setDigit(n + i, (32767 & k) << 15 | 32767 & v);
      }
      const a = this.__digit(n + i), c = e.__digit(i), l = (32767 & a) - (32767 & c) - o;
      o = 1 & l >>> 15;
      let h = 0;
      (1 & r) == 0 && (h = (a >>> 15) - (c >>> 15) - o, o = 1 & h >>> 15), this.__setDigit(n + i, (32767 & h) << 15 | 32767 & l);
    }
    return o;
  }
  __inplaceRightShift(e) {
    if (e === 0) return;
    let n = this.__digit(0) >>> e;
    const r = this.length - 1;
    for (let o = 0; o < r; o++) {
      const i = this.__digit(o + 1);
      this.__setDigit(o, 1073741823 & i << 30 - e | n), n = i >>> e;
    }
    this.__setDigit(r, n);
  }
  static __specialLeftShift(e, n, r) {
    const o = e.length, i = new y(o + r, !1);
    if (n === 0) {
      for (let c = 0; c < o; c++) i.__setDigit(c, e.__digit(c));
      return 0 < r && i.__setDigit(o, 0), i;
    }
    let a = 0;
    for (let c = 0; c < o; c++) {
      const l = e.__digit(c);
      i.__setDigit(c, 1073741823 & l << n | a), a = l >>> 30 - n;
    }
    return 0 < r && i.__setDigit(o, a), i;
  }
  static __leftShiftByAbsolute(e, n) {
    const r = y.__toShiftAmount(n);
    if (0 > r) throw new RangeError("BigInt too big");
    const o = 0 | r / 30, i = r % 30, a = e.length, c = i !== 0 && e.__digit(a - 1) >>> 30 - i != 0, l = a + o + (c ? 1 : 0), h = new y(l, e.sign);
    if (i === 0) {
      let m = 0;
      for (; m < o; m++) h.__setDigit(m, 0);
      for (; m < l; m++) h.__setDigit(m, e.__digit(m - o));
    } else {
      let m = 0;
      for (let p = 0; p < o; p++) h.__setDigit(p, 0);
      for (let p = 0; p < a; p++) {
        const v = e.__digit(p);
        h.__setDigit(p + o, 1073741823 & v << i | m), m = v >>> 30 - i;
      }
      if (c) h.__setDigit(a + o, m);
      else if (m !== 0) throw new Error("implementation bug");
    }
    return h.__trim();
  }
  static __rightShiftByAbsolute(e, n) {
    const r = e.length, o = e.sign, i = y.__toShiftAmount(n);
    if (0 > i) return y.__rightShiftByMaximum(o);
    const a = 0 | i / 30, c = i % 30;
    let l = r - a;
    if (0 >= l) return y.__rightShiftByMaximum(o);
    let h = !1;
    if (o) {
      if ((e.__digit(a) & (1 << c) - 1) != 0) h = !0;
      else for (let p = 0; p < a; p++) if (e.__digit(p) !== 0) {
        h = !0;
        break;
      }
    }
    h && c === 0 && ~e.__digit(r - 1) == 0 && l++;
    let m = new y(l, o);
    if (c === 0) {
      m.__setDigit(l - 1, 0);
      for (let p = a; p < r; p++) m.__setDigit(p - a, e.__digit(p));
    } else {
      let p = e.__digit(a) >>> c;
      const v = r - a - 1;
      for (let k = 0; k < v; k++) {
        const P = e.__digit(k + a + 1);
        m.__setDigit(k, 1073741823 & P << 30 - c | p), p = P >>> c;
      }
      m.__setDigit(v, p);
    }
    return h && (m = y.__absoluteAddOne(m, !0, m)), m.__trim();
  }
  static __rightShiftByMaximum(e) {
    return e ? y.__oneDigit(1, !0) : y.__zero();
  }
  static __toShiftAmount(e) {
    if (1 < e.length) return -1;
    const n = e.__unsignedDigit(0);
    return n > y.__kMaxLengthBits ? -1 : n;
  }
  static __toPrimitive(e, n = "default") {
    if (typeof e != "object" || e.constructor === y) return e;
    if (typeof Symbol < "u" && typeof Symbol.toPrimitive == "symbol" && e[Symbol.toPrimitive]) {
      const i = e[Symbol.toPrimitive](n);
      if (typeof i != "object") return i;
      throw new TypeError("Cannot convert object to primitive value");
    }
    const r = e.valueOf;
    if (r) {
      const i = r.call(e);
      if (typeof i != "object") return i;
    }
    const o = e.toString;
    if (o) {
      const i = o.call(e);
      if (typeof i != "object") return i;
    }
    throw new TypeError("Cannot convert object to primitive value");
  }
  static __toNumeric(e) {
    return y.__isBigInt(e) ? e : +e;
  }
  static __isBigInt(e) {
    return typeof e == "object" && e !== null && e.constructor === y;
  }
  static __truncateToNBits(e, n) {
    const r = 0 | (e + 29) / 30, o = new y(r, n.sign), i = r - 1;
    for (let c = 0; c < i; c++) o.__setDigit(c, n.__digit(c));
    let a = n.__digit(i);
    if (e % 30 != 0) {
      const c = 32 - e % 30;
      a = a << c >>> c;
    }
    return o.__setDigit(i, a), o.__trim();
  }
  static __truncateAndSubFromPowerOfTwo(e, n, r) {
    var o = Math.min;
    const i = 0 | (e + 29) / 30, a = new y(i, r);
    let c = 0;
    const l = i - 1;
    let h = 0;
    for (const k = o(l, n.length); c < k; c++) {
      const P = 0 - n.__digit(c) - h;
      h = 1 & P >>> 30, a.__setDigit(c, 1073741823 & P);
    }
    for (; c < l; c++) a.__setDigit(c, 0 | 1073741823 & -h);
    let m = l < n.length ? n.__digit(l) : 0;
    const p = e % 30;
    let v;
    if (p == 0) v = 0 - m - h, v &= 1073741823;
    else {
      const k = 32 - p;
      m = m << k >>> k;
      const P = 1 << 32 - k;
      v = P - m - h, v &= P - 1;
    }
    return a.__setDigit(l, v), a.__trim();
  }
  __digit(e) {
    return this[e];
  }
  __unsignedDigit(e) {
    return this[e] >>> 0;
  }
  __setDigit(e, n) {
    this[e] = 0 | n;
  }
  __setDigitGrow(e, n) {
    this[e] = 0 | n;
  }
  __halfDigitLength() {
    const e = this.length;
    return 32767 >= this.__unsignedDigit(e - 1) ? 2 * e - 1 : 2 * e;
  }
  __halfDigit(e) {
    return 32767 & this[e >>> 1] >>> 15 * (1 & e);
  }
  __setHalfDigit(e, n) {
    const r = e >>> 1, o = this.__digit(r), i = 1 & e ? 32767 & o | n << 15 : 1073709056 & o | 32767 & n;
    this.__setDigit(r, i);
  }
  static __digitPow(e, n) {
    let r = 1;
    for (; 0 < n; ) 1 & n && (r *= e), n >>>= 1, e *= e;
    return r;
  }
  static __detectBigEndian() {
    return y.__kBitConversionDouble[0] = -0, y.__kBitConversionInts[0] !== 0;
  }
  static __isOneDigitInt(e) {
    return (1073741823 & e) === e;
  }
}
y.__kMaxLength = 33554432, y.__kMaxLengthBits = y.__kMaxLength << 5, y.__kMaxBitsPerChar = [0, 0, 32, 51, 64, 75, 83, 90, 96, 102, 107, 111, 115, 119, 122, 126, 128, 131, 134, 136, 139, 141, 143, 145, 147, 149, 151, 153, 154, 156, 158, 159, 160, 162, 163, 165, 166], y.__kBitsPerCharTableShift = 5, y.__kBitsPerCharTableMultiplier = 1 << y.__kBitsPerCharTableShift, y.__kConversionChars = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"], y.__kBitConversionBuffer = new ArrayBuffer(8), y.__kBitConversionDouble = new Float64Array(y.__kBitConversionBuffer), y.__kBitConversionInts = new Int32Array(y.__kBitConversionBuffer), y.__kBitConversionIntHigh = y.__detectBigEndian() ? 0 : 1, y.__kBitConversionIntLow = y.__detectBigEndian() ? 1 : 0, y.__clz30 = Math.clz32 ? function(t) {
  return Math.clz32(t) - 2;
} : function(t) {
  return t === 0 ? 30 : 0 | 29 - (0 | Math.log(t >>> 0) / Math.LN2);
}, y.__imul = Math.imul || function(t, e) {
  return 0 | t * e;
};
const Ut = y.BigInt(0), Ai = y.BigInt(1), Bc = y.BigInt(2), $_ = y.BigInt(10), N_ = y.BigInt(24), j_ = y.BigInt(60), L_ = y.BigInt(1e3), Li = y.BigInt(1e6), mi = y.BigInt(1e9), km = y.multiply(y.BigInt(3600), mi), G_ = y.multiply(j_, mi), dr = y.multiply(km, N_);
function On(t) {
  return typeof t == "bigint" ? y.BigInt(t.toString(10)) : t;
}
function _m(t) {
  return y.equal(y.remainder(t, Bc), Ut);
}
function xr(t) {
  return y.lessThan(t, Ut) ? y.unaryMinus(t) : t;
}
function ns(t, e) {
  return y.lessThan(t, e) ? -1 : y.greaterThan(t, e) ? 1 : 0;
}
function ri(t, e) {
  return { quotient: y.divide(t, e), remainder: y.remainder(t, e) };
}
var Qd, Xd;
const le = "slot-epochNanoSeconds", de = "slot-iso-date", xe = "slot-iso-date-time", je = "slot-time", K = "slot-calendar", Tm = "slot-date-brand", Cm = "slot-year-month-brand", Pm = "slot-month-day-brand", Pe = "slot-time-zone", gt = "slot-years", vt = "slot-months", zt = "slot-weeks", yt = "slot-days", bt = "slot-hours", wt = "slot-minutes", kt = "slot-seconds", _t = "slot-milliseconds", Tt = "slot-microseconds", Rt = "slot-nanoseconds", Am = "date", Em = "ym", Sm = "md", Dm = "time", Im = "datetime", zm = "instant", Yr = "original", lo = "timezone-canonical", uc = "timezone-original", oi = "calendar-id", Rm = "locale", cc = "options", xm = /* @__PURE__ */ new WeakMap(), lc = Symbol.for("@@Temporal__GetSlots");
(Qd = globalThis)[lc] || (Qd[lc] = function(t) {
  return xm.get(t);
});
const bs = globalThis[lc], dc = Symbol.for("@@Temporal__CreateSlots");
(Xd = globalThis)[dc] || (Xd[dc] = function(t) {
  xm.set(t, /* @__PURE__ */ Object.create(null));
});
const Yn = globalThis[dc];
function St(t, ...e) {
  if (!t || typeof t != "object") return !1;
  const n = bs(t);
  return !!n && e.every(((r) => r in n));
}
function w(t, e) {
  var r;
  const n = (r = bs(t)) == null ? void 0 : r[e];
  if (n === void 0) throw new TypeError(`Missing internal slot ${e}`);
  return n;
}
function pe(t, e, n) {
  const r = bs(t);
  if (r === void 0) throw new TypeError("Missing slots for the given container");
  if (r[e]) throw new TypeError(`${e} already has set`);
  r[e] = n;
}
const hc = {};
function Vn(t, e) {
  Object.defineProperty(t.prototype, Symbol.toStringTag, { value: e, writable: !1, enumerable: !1, configurable: !0 });
  const n = Object.getOwnPropertyNames(t);
  for (let o = 0; o < n.length; o++) {
    const i = n[o], a = Object.getOwnPropertyDescriptor(t, i);
    a.configurable && a.enumerable && (a.enumerable = !1, Object.defineProperty(t, i, a));
  }
  const r = Object.getOwnPropertyNames(t.prototype);
  for (let o = 0; o < r.length; o++) {
    const i = r[o], a = Object.getOwnPropertyDescriptor(t.prototype, i);
    a.configurable && a.enumerable && (a.enumerable = !1, Object.defineProperty(t.prototype, i, a));
  }
  fc(e, t), fc(`${e}.prototype`, t.prototype);
}
function fc(t, e) {
  const n = `%${t}%`;
  if (hc[n] !== void 0) throw new Error(`intrinsic ${t} already exists`);
  hc[n] = e;
}
function it(t) {
  return hc[t];
}
function fo(t, e) {
  let n = t;
  if (n === 0) return { div: n, mod: n };
  const r = Math.sign(n);
  n = Math.abs(n);
  const o = Math.trunc(1 + Math.log10(n));
  if (e >= o) return { div: 0 * r, mod: r * n };
  if (e === 0) return { div: r * n, mod: 0 * r };
  const i = n.toPrecision(o);
  return { div: r * Number.parseInt(i.slice(0, o - e), 10), mod: r * Number.parseInt(i.slice(o - e), 10) };
}
function Lu(t, e, n) {
  let r = t, o = n;
  if (r === 0) return o;
  const i = Math.sign(r) || Math.sign(o);
  r = Math.abs(r), o = Math.abs(o);
  const a = r.toPrecision(Math.trunc(1 + Math.log10(r)));
  if (o === 0) return i * Number.parseInt(a + "0".repeat(e), 10);
  const c = a + o.toPrecision(Math.trunc(1 + Math.log10(o))).padStart(e, "0");
  return i * Number.parseInt(c, 10);
}
function ws(t, e) {
  const n = e === "negative";
  switch (t) {
    case "ceil":
      return n ? "zero" : "infinity";
    case "floor":
      return n ? "infinity" : "zero";
    case "expand":
      return "infinity";
    case "trunc":
      return "zero";
    case "halfCeil":
      return n ? "half-zero" : "half-infinity";
    case "halfFloor":
      return n ? "half-infinity" : "half-zero";
    case "halfExpand":
      return "half-infinity";
    case "halfTrunc":
      return "half-zero";
    case "halfEven":
      return "half-even";
  }
}
function ks(t, e, n, r, o) {
  return o === "zero" ? t : o === "infinity" ? e : n < 0 ? t : n > 0 ? e : o === "half-zero" ? t : o === "half-infinity" ? e : r ? t : e;
}
class ve {
  constructor(e) {
    this.totalNs = On(e), this.sec = y.toNumber(y.divide(this.totalNs, mi)), this.subsec = y.toNumber(y.remainder(this.totalNs, mi));
  }
  static validateNew(e, n) {
    if (y.greaterThan(xr(e), ve.MAX)) throw new RangeError(`${n} of duration time units cannot exceed ${ve.MAX} s`);
    return new ve(e);
  }
  static fromEpochNsDiff(e, n) {
    const r = y.subtract(On(e), On(n));
    return new ve(r);
  }
  static fromComponents(e, n, r, o, i, a) {
    const c = y.add(y.add(y.add(y.add(y.add(y.BigInt(a), y.multiply(y.BigInt(i), L_)), y.multiply(y.BigInt(o), Li)), y.multiply(y.BigInt(r), mi)), y.multiply(y.BigInt(n), G_)), y.multiply(y.BigInt(e), km));
    return ve.validateNew(c, "total");
  }
  abs() {
    return new ve(xr(this.totalNs));
  }
  add(e) {
    return ve.validateNew(y.add(this.totalNs, e.totalNs), "sum");
  }
  add24HourDays(e) {
    return ve.validateNew(y.add(this.totalNs, y.multiply(y.BigInt(e), dr)), "sum");
  }
  addToEpochNs(e) {
    return y.add(On(e), this.totalNs);
  }
  cmp(e) {
    return ns(this.totalNs, e.totalNs);
  }
  divmod(e) {
    const { quotient: n, remainder: r } = ri(this.totalNs, y.BigInt(e));
    return { quotient: y.toNumber(n), remainder: new ve(r) };
  }
  fdiv(e) {
    const n = On(e), r = y.BigInt(n);
    let { quotient: o, remainder: i } = ri(this.totalNs, r);
    const a = [];
    let c;
    const l = (y.lessThan(this.totalNs, Ut) ? -1 : 1) * Math.sign(y.toNumber(n));
    for (; !y.equal(i, Ut) && a.length < 50; ) i = y.multiply(i, $_), { quotient: c, remainder: i } = ri(i, r), a.push(Math.abs(y.toNumber(c)));
    return l * +(xr(o).toString() + "." + a.join(""));
  }
  isZero() {
    return y.equal(this.totalNs, Ut);
  }
  round(e, n) {
    const r = On(e);
    if (y.equal(r, Ai)) return this;
    const { quotient: o, remainder: i } = ri(this.totalNs, r), a = y.lessThan(this.totalNs, Ut) ? "negative" : "positive", c = y.multiply(xr(o), r), l = y.add(c, r), h = ns(xr(y.multiply(i, Bc)), r), m = ws(n, a), p = y.equal(xr(this.totalNs), c) ? c : ks(c, l, h, _m(o), m), v = a === "positive" ? p : y.unaryMinus(p);
    return ve.validateNew(v, "rounding");
  }
  sign() {
    return this.cmp(new ve(Ut));
  }
  subtract(e) {
    return ve.validateNew(y.subtract(this.totalNs, e.totalNs), "difference");
  }
}
ve.MAX = y.BigInt("9007199254740991999999999"), ve.ZERO = new ve(Ut);
const Jd = /[A-Za-z._][A-Za-z._0-9+-]*/, Gi = new RegExp(`(?:${/(?:[+-](?:[01][0-9]|2[0-3])(?::?[0-5][0-9])?)/.source}|(?:${Jd.source})(?:\\/(?:${Jd.source}))*)`), Om = /(?:[+-]\d{6}|\d{4})/, rs = /(?:0[1-9]|1[0-2])/, mc = /(?:0[1-9]|[12]\d|3[01])/, F_ = new RegExp(`(${Om.source})(?:-(${rs.source})-(${mc.source})|(${rs.source})(${mc.source}))`), Mm = /(\d{2})(?::(\d{2})(?::(\d{2})(?:[.,](\d{1,9}))?)?|(\d{2})(?:(\d{2})(?:[.,](\d{1,9}))?)?)?/, $m = /((?:[+-])(?:[01][0-9]|2[0-3])(?::?(?:[0-5][0-9])(?::?(?:[0-5][0-9])(?:[.,](?:\d{1,9}))?)?)?)/, Nm = new RegExp(`([zZ])|${$m.source}?`), _o = /\[(!)?([a-z_][a-z0-9_-]*)=([A-Za-z0-9]+(?:-[A-Za-z0-9]+)*)\]/g, U_ = new RegExp([`^${F_.source}`, `(?:(?:[tT]|\\s+)${Mm.source}(?:${Nm.source})?)?`, `(?:\\[!?(${Gi.source})\\])?`, `((?:${_o.source})*)$`].join("")), Z_ = new RegExp([`^[tT]?${Mm.source}`, `(?:${Nm.source})?`, `(?:\\[!?${Gi.source}\\])?`, `((?:${_o.source})*)$`].join("")), q_ = new RegExp(`^(${Om.source})-?(${rs.source})(?:\\[!?${Gi.source}\\])?((?:${_o.source})*)$`), K_ = new RegExp(`^(?:--)?(${rs.source})-?(${mc.source})(?:\\[!?${Gi.source}\\])?((?:${_o.source})*)$`), Gu = /(\d+)(?:[.,](\d{1,9}))?/, W_ = new RegExp(`(?:${Gu.source}H)?(?:${Gu.source}M)?(?:${Gu.source}S)?`), Y_ = new RegExp(`^([+-])?P${/(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)W)?(?:(\d+)D)?/.source}(?:T(?!$)${W_.source})?$`, "i"), hr = 864e5, os = 1e6 * hr, V_ = 6e10, jm = 1e8 * hr, To = yn(jm), Ei = y.unaryMinus(To), B_ = y.add(y.subtract(Ei, dr), Ai), H_ = y.subtract(y.add(To, dr), Ai), Q_ = 146097 * hr, eh = -271821, th = 275760, pi = Date.UTC(1847, 0, 1), X_ = ["iso8601", "hebrew", "islamic", "islamic-umalqura", "islamic-tbla", "islamic-civil", "islamic-rgsa", "islamicc", "persian", "ethiopic", "ethioaa", "ethiopic-amete-alem", "coptic", "chinese", "dangi", "roc", "indian", "buddhist", "japanese", "gregory"], J_ = /* @__PURE__ */ new Set(["ACT", "AET", "AGT", "ART", "AST", "BET", "BST", "CAT", "CNT", "CST", "CTT", "EAT", "ECT", "IET", "IST", "JST", "MIT", "NET", "NST", "PLT", "PNT", "PRT", "PST", "SST", "VST"]);
function Le(t) {
  return typeof t == "object" && t !== null || typeof t == "function";
}
function _s(t) {
  if (typeof t == "bigint") throw new TypeError("Cannot convert BigInt to number");
  return Number(t);
}
function Ts(t) {
  if (typeof t == "symbol") throw new TypeError("Cannot convert a Symbol value to a String");
  return String(t);
}
function fe(t) {
  const e = _s(t);
  if (e === 0) return 0;
  if (Number.isNaN(e) || e === 1 / 0 || e === -1 / 0) throw new RangeError("invalid number value");
  const n = Math.trunc(e);
  return n === 0 ? 0 : n;
}
function nh(t, e) {
  const n = fe(t);
  if (n <= 0)
    throw e !== void 0 ? new RangeError(`property '${e}' cannot be a a number less than one`) : new RangeError("Cannot convert a number less than one to a positive integer");
  return n;
}
function cn(t) {
  const e = _s(t);
  if (Number.isNaN(e)) throw new RangeError("not a number");
  if (e === 1 / 0 || e === -1 / 0) throw new RangeError("infinity is out of range");
  if (!(function(n) {
    if (typeof n != "number" || Number.isNaN(n) || n === 1 / 0 || n === -1 / 0) return !1;
    const r = Math.abs(n);
    return Math.floor(r) === r;
  })(e)) throw new RangeError(`unsupported fractional value ${t}`);
  return e === 0 ? 0 : e;
}
function Si(t, e) {
  return String(t).padStart(e, "0");
}
function Be(t) {
  if (typeof t != "string") throw new TypeError(`expected a string, not ${String(t)}`);
  return t;
}
function pc(t, e) {
  if (Le(t)) {
    const n = t == null ? void 0 : t.toString();
    if (typeof n == "string" || typeof n == "number") return n;
    throw new TypeError("Cannot convert object to primitive value");
  }
  return t;
}
const gc = ["era", "eraYear", "year", "month", "monthCode", "day", "hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset", "timeZone"], eT = { era: Ts, eraYear: fe, year: fe, month: nh, monthCode: function(t) {
  const e = Be(pc(t));
  if (e.length < 3 || e.length > 4 || e[0] !== "M" || "0123456789".indexOf(e[1]) === -1 || "0123456789".indexOf(e[2]) === -1 || e[1] + e[2] === "00" && e[3] !== "L" || e[3] !== "L" && e[3] !== void 0) throw new RangeError(`bad month code ${e}; must match M01-M99 or M00L-M99L`);
  return e;
}, day: nh, hour: fe, minute: fe, second: fe, millisecond: fe, microsecond: fe, nanosecond: fe, offset: function(t) {
  const e = Be(pc(t));
  return Mo(e), e;
}, timeZone: At }, tT = { hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }, Co = [["years", "year", "date"], ["months", "month", "date"], ["weeks", "week", "date"], ["days", "day", "date"], ["hours", "hour", "time"], ["minutes", "minute", "time"], ["seconds", "second", "time"], ["milliseconds", "millisecond", "time"], ["microseconds", "microsecond", "time"], ["nanoseconds", "nanosecond", "time"]], rh = Object.fromEntries(Co.map(((t) => [t[0], t[1]]))), nT = Object.fromEntries(Co.map((([t, e]) => [e, t]))), gi = Co.map((([, t]) => t)), Po = { day: os, hour: 36e11, minute: 6e10, second: 1e9, millisecond: 1e6, microsecond: 1e3, nanosecond: 1 }, is = ["days", "hours", "microseconds", "milliseconds", "minutes", "months", "nanoseconds", "seconds", "weeks", "years"], rT = Intl.DateTimeFormat, oh = /* @__PURE__ */ new Map();
function Lm(t) {
  const e = xi(t);
  let n = oh.get(e);
  return n === void 0 && (n = new rT("en-us", { timeZone: e, hour12: !1, era: "short", year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" }), oh.set(e, n)), n;
}
function tt(t) {
  return St(t, le) && !St(t, Pe, K);
}
function $e(t) {
  return St(t, gt, vt, yt, bt, wt, kt, _t, Tt, Rt);
}
function Ne(t) {
  return St(t, Tm);
}
function Fe(t) {
  return St(t, je);
}
function ze(t) {
  return St(t, xe);
}
function nt(t) {
  return St(t, Cm);
}
function Gt(t) {
  return St(t, Pm);
}
function ge(t) {
  return St(t, le, Pe, K);
}
function M(t, e) {
  if (!e(t)) throw new TypeError("invalid receiver: method called with the wrong type of this-object");
}
function Ro(t) {
  if (St(t, K) || St(t, Pe)) throw new TypeError("with() does not support a calendar or timeZone property");
  if (Fe(t)) throw new TypeError("with() does not accept Temporal.PlainTime, use withPlainTime() instead");
  if (t.calendar !== void 0) throw new TypeError("with() does not support a calendar property");
  if (t.timeZone !== void 0) throw new TypeError("with() does not support a timeZone property");
}
function Fi(t, e) {
  return e === "never" || e === "auto" && t === "iso8601" ? "" : `[${e === "critical" ? "!" : ""}u-ca=${t}]`;
}
function Cs(t) {
  let e, n, r = !1;
  for (_o.lastIndex = 0; n = _o.exec(t); ) {
    const { 1: o, 2: i, 3: a } = n;
    if (i === "u-ca") {
      if (e === void 0) e = a, r = o === "!";
      else if (o === "!" || r) throw new RangeError(`Invalid annotations in ${t}: more than one u-ca present with critical flag`);
    } else if (o === "!") throw new RangeError(`Unrecognized annotation: !${i}=${a}`);
  }
  return e;
}
function Pn(t) {
  const e = U_.exec(t);
  if (!e) throw new RangeError(`invalid RFC 9557 string: ${t}`);
  const n = Cs(e[16]);
  let r = e[1];
  if (r === "-000000") throw new RangeError(`invalid RFC 9557 string: ${t}`);
  const o = +r, i = +(e[2] ?? e[4] ?? 1), a = +(e[3] ?? e[5] ?? 1), c = e[6] !== void 0, l = +(e[6] ?? 0), h = +(e[7] ?? e[10] ?? 0);
  let m = +(e[8] ?? e[11] ?? 0);
  m === 60 && (m = 59);
  const p = (e[9] ?? e[12] ?? "") + "000000000", v = +p.slice(0, 3), k = +p.slice(3, 6), P = +p.slice(6, 9);
  let A, S = !1;
  e[13] ? (A = void 0, S = !0) : e[14] && (A = e[14]);
  const z = e[15];
  return tl(o, i, a, l, h, m, v, k, P), { year: o, month: i, day: a, time: c ? { hour: l, minute: h, second: m, millisecond: v, microsecond: k, nanosecond: P } : "start-of-day", tzAnnotation: z, offset: A, z: S, calendar: n };
}
function Gm(t) {
  const e = Z_.exec(t);
  let n, r, o, i, a, c, l;
  if (e) {
    l = Cs(e[10]), n = +(e[1] ?? 0), r = +(e[2] ?? e[5] ?? 0), o = +(e[3] ?? e[6] ?? 0), o === 60 && (o = 59);
    const h = (e[4] ?? e[7] ?? "") + "000000000";
    if (i = +h.slice(0, 3), a = +h.slice(3, 6), c = +h.slice(6, 9), e[8]) throw new RangeError("Z designator not supported for PlainTime");
  } else {
    let h, m;
    if ({ time: h, z: m, calendar: l } = Pn(t), h === "start-of-day") throw new RangeError(`time is missing in string: ${t}`);
    if (m) throw new RangeError("Z designator not supported for PlainTime");
    ({ hour: n, minute: r, second: o, millisecond: i, microsecond: a, nanosecond: c } = h);
  }
  if (Ss(n, r, o, i, a, c), /[tT ][0-9][0-9]/.test(t)) return { hour: n, minute: r, second: o, millisecond: i, microsecond: a, nanosecond: c, calendar: l };
  try {
    const { month: h, day: m } = Qc(t);
    Ur(1972, h, m);
  } catch {
    try {
      const { year: h, month: m } = Hc(t);
      Ur(h, m, 1);
    } catch {
      return { hour: n, minute: r, second: o, millisecond: i, microsecond: a, nanosecond: c, calendar: l };
    }
  }
  throw new RangeError(`invalid RFC 9557 time-only string ${t}; may need a T prefix`);
}
function Hc(t) {
  const e = q_.exec(t);
  let n, r, o, i;
  if (e) {
    o = Cs(e[3]);
    let a = e[1];
    if (a === "-000000") throw new RangeError(`invalid RFC 9557 string: ${t}`);
    if (n = +a, r = +e[2], i = 1, o !== void 0 && o !== "iso8601") throw new RangeError("YYYY-MM format is only valid with iso8601 calendar");
  } else {
    let a;
    if ({ year: n, month: r, calendar: o, day: i, z: a } = Pn(t), a) throw new RangeError("Z designator not supported for PlainYearMonth");
  }
  return { year: n, month: r, calendar: o, referenceISODay: i };
}
function Qc(t) {
  const e = K_.exec(t);
  let n, r, o, i;
  if (e) {
    if (o = Cs(e[3]), n = +e[1], r = +e[2], o !== void 0 && o !== "iso8601") throw new RangeError("MM-DD format is only valid with iso8601 calendar");
  } else {
    let a;
    if ({ month: n, day: r, calendar: o, year: i, z: a } = Pn(t), a) throw new RangeError("Z designator not supported for PlainMonthDay");
  }
  return { month: n, day: r, calendar: o, referenceISOYear: i };
}
const Fm = new RegExp(`^${Gi.source}$`, "i"), Um = new RegExp(`^${/([+-])([01][0-9]|2[0-3])(?::?([0-5][0-9])?)?/.source}$`);
function Zm(t) {
  const e = iT.test(t) ? "Seconds not allowed in offset time zone" : "Invalid time zone";
  throw new RangeError(`${e}: ${t}`);
}
function ur(t) {
  return Fm.test(t) || Zm(t), Um.test(t) ? { offsetMinutes: Mo(t) / 6e10 } : { tzName: t };
}
function vi(t, e, n, r) {
  let o = t, i = e, a = n;
  switch (r) {
    case "reject":
      Ur(o, i, a);
      break;
    case "constrain":
      ({ year: o, month: i, day: a } = ap(o, i, a));
  }
  return { year: o, month: i, day: a };
}
function Ps(t, e, n, r, o, i, a) {
  let c = t, l = e, h = n, m = r, p = o, v = i;
  switch (a) {
    case "reject":
      Ss(c, l, h, m, p, v);
      break;
    case "constrain":
      c = Ct(c, 0, 23), l = Ct(l, 0, 59), h = Ct(h, 0, 59), m = Ct(m, 0, 999), p = Ct(p, 0, 999), v = Ct(v, 0, 999);
  }
  return { hour: c, minute: l, second: h, millisecond: m, microsecond: p, nanosecond: v };
}
function qm(t) {
  if (!Le(t)) throw new TypeError("invalid duration-like");
  const e = { years: void 0, months: void 0, weeks: void 0, days: void 0, hours: void 0, minutes: void 0, seconds: void 0, milliseconds: void 0, microseconds: void 0, nanoseconds: void 0 };
  let n = !1;
  for (let r = 0; r < is.length; r++) {
    const o = is[r], i = t[o];
    i !== void 0 && (n = !0, e[o] = cn(i));
  }
  if (!n) throw new TypeError("invalid duration-like");
  return e;
}
function ct({ years: t, months: e, weeks: n, days: r }, o, i, a) {
  return { years: t, months: a ?? e, weeks: i ?? n, days: o ?? r };
}
function Te(t, e) {
  return { isoDate: t, time: e };
}
function ke(t) {
  return Zn(t, "overflow", ["constrain", "reject"], "constrain");
}
function yi(t) {
  return Zn(t, "disambiguation", ["compatible", "earlier", "later", "reject"], "compatible");
}
function ln(t, e) {
  return Zn(t, "roundingMode", ["ceil", "floor", "expand", "trunc", "halfCeil", "halfFloor", "halfExpand", "halfTrunc", "halfEven"], e);
}
function Za(t, e) {
  return Zn(t, "offset", ["prefer", "use", "ignore", "reject"], e);
}
function Ui(t) {
  return Zn(t, "calendarName", ["auto", "always", "never", "critical"], "auto");
}
function xo(t) {
  let e = t.roundingIncrement;
  if (e === void 0) return 1;
  const n = fe(e);
  if (n < 1 || n > 1e9) throw new RangeError(`roundingIncrement must be at least 1 and at most 1e9, not ${e}`);
  return n;
}
function Oo(t, e, n) {
  const r = n ? e : e - 1;
  if (t > r) throw new RangeError(`roundingIncrement must be at least 1 and less than ${r}, not ${t}`);
  if (e % t != 0) throw new RangeError(`Rounding increment must divide evenly into ${e}`);
}
function Zi(t) {
  const e = t.fractionalSecondDigits;
  if (e === void 0) return "auto";
  if (typeof e != "number") {
    if (Ts(e) !== "auto") throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${e}`);
    return "auto";
  }
  const n = Math.floor(e);
  if (!Number.isFinite(n) || n < 0 || n > 9) throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${e}`);
  return n;
}
function qi(t, e) {
  switch (t) {
    case "minute":
      return { precision: "minute", unit: "minute", increment: 1 };
    case "second":
      return { precision: 0, unit: "second", increment: 1 };
    case "millisecond":
      return { precision: 3, unit: "millisecond", increment: 1 };
    case "microsecond":
      return { precision: 6, unit: "microsecond", increment: 1 };
    case "nanosecond":
      return { precision: 9, unit: "nanosecond", increment: 1 };
  }
  switch (e) {
    case "auto":
      return { precision: e, unit: "nanosecond", increment: 1 };
    case 0:
      return { precision: e, unit: "second", increment: 1 };
    case 1:
    case 2:
    case 3:
      return { precision: e, unit: "millisecond", increment: 10 ** (3 - e) };
    case 4:
    case 5:
    case 6:
      return { precision: e, unit: "microsecond", increment: 10 ** (6 - e) };
    case 7:
    case 8:
    case 9:
      return { precision: e, unit: "nanosecond", increment: 10 ** (9 - e) };
    default:
      throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${e}`);
  }
}
const Wn = Symbol("~required~");
function Ot(t, e, n, r, o = []) {
  let i = [];
  for (let h = 0; h < Co.length; h++) {
    const m = Co[h], p = m[1], v = m[2];
    n !== "datetime" && n !== v || i.push(p);
  }
  i = i.concat(o);
  let a = r;
  a === Wn ? a = void 0 : a !== void 0 && i.push(a);
  let c = [];
  c = c.concat(i);
  for (let h = 0; h < i.length; h++) {
    const m = i[h], p = nT[m];
    p !== void 0 && c.push(p);
  }
  let l = Zn(t, e, c, a);
  if (l === void 0 && r === Wn) throw new RangeError(`${e} is required`);
  return l && l in rh ? rh[l] : l;
}
function Fu(t) {
  const e = t.relativeTo;
  if (e === void 0) return {};
  let n, r, o, i, a, c = "option", l = !1;
  if (Le(e)) {
    if (ge(e)) return { zonedRelativeTo: e };
    if (Ne(e)) return { plainRelativeTo: e };
    if (ze(e)) return { plainRelativeTo: Pt(w(e, xe).isoDate, w(e, K)) };
    o = Bi(e);
    const h = Wt(o, e, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset", "timeZone"], []);
    ({ isoDate: n, time: r } = Wi(o, h, "constrain")), { offset: a, timeZone: i } = h, a === void 0 && (c = "wall");
  } else {
    let h, m, p, v, k;
    if ({ year: p, month: v, day: k, time: r, calendar: o, tzAnnotation: h, offset: a, z: m } = Pn(Be(e)), h) i = At(h), m ? c = "exact" : a || (c = "wall"), l = !0;
    else if (m) throw new RangeError("Z designator not supported for PlainDate relativeTo; either remove the Z or add a bracketed time zone");
    o || (o = "iso8601"), o = Dt(o), n = { year: p, month: v, day: k };
  }
  return i === void 0 ? { plainRelativeTo: Pt(n, o) } : { zonedRelativeTo: ut(as(n, r, c, c === "option" ? Mo(a) : 0, i, "compatible", "reject", l), i, o) };
}
function Mn(t) {
  return w(t, gt) !== 0 ? "year" : w(t, vt) !== 0 ? "month" : w(t, zt) !== 0 ? "week" : w(t, yt) !== 0 ? "day" : w(t, bt) !== 0 ? "hour" : w(t, wt) !== 0 ? "minute" : w(t, kt) !== 0 ? "second" : w(t, _t) !== 0 ? "millisecond" : w(t, Tt) !== 0 ? "microsecond" : "nanosecond";
}
function Fn(t, e) {
  return gi.indexOf(t) > gi.indexOf(e) ? e : t;
}
function mn(t) {
  return t === "year" || t === "month" || t === "week";
}
function $n(t) {
  return mn(t) || t === "day" ? "date" : "time";
}
function gr(t) {
  return it("%calendarImpl%")(t);
}
function Ki(t) {
  return it("%calendarImpl%")(w(t, K));
}
function Et(t, e, n = "date") {
  const r = /* @__PURE__ */ Object.create(null), o = gr(t).isoToDate(e, { year: !0, monthCode: !0, day: !0 });
  return r.monthCode = o.monthCode, n !== "month-day" && n !== "date" || (r.day = o.day), n !== "year-month" && n !== "date" || (r.year = o.year), r;
}
function Wt(t, e, n, r, o) {
  const i = gr(t).extraFields(n), a = n.concat(r, i), c = /* @__PURE__ */ Object.create(null);
  let l = !1;
  a.sort();
  for (let h = 0; h < a.length; h++) {
    const m = a[h], p = e[m];
    if (p !== void 0) l = !0, c[m] = (0, eT[m])(p);
    else if (o !== "partial") {
      if (o.includes(m)) throw new TypeError(`required property '${m}' missing or undefined`);
      c[m] = tT[m];
    }
  }
  if (o === "partial" && !l) throw new TypeError("no supported properties found");
  return c;
}
function vc(t, e = "complete") {
  const n = ["hour", "microsecond", "millisecond", "minute", "nanosecond", "second"];
  let r = !1;
  const o = /* @__PURE__ */ Object.create(null);
  for (let i = 0; i < n.length; i++) {
    const a = n[i], c = t[a];
    c !== void 0 ? (o[a] = fe(c), r = !0) : e === "complete" && (o[a] = 0);
  }
  if (!r) throw new TypeError("invalid time-like");
  return o;
}
function ii(t, e) {
  if (Le(t)) {
    if (Ne(t)) return ke(te(e)), Pt(w(t, de), w(t, K));
    if (ge(t)) {
      const l = nn(w(t, Pe), w(t, le));
      return ke(te(e)), Pt(l.isoDate, w(t, K));
    }
    if (ze(t)) return ke(te(e)), Pt(w(t, xe).isoDate, w(t, K));
    const c = Bi(t);
    return Pt(fr(c, Wt(c, t, ["year", "month", "monthCode", "day"], [], []), ke(te(e))), c);
  }
  let { year: n, month: r, day: o, calendar: i, z: a } = Pn(Be(t));
  if (a) throw new RangeError("Z designator not supported for PlainDate");
  return i || (i = "iso8601"), i = Dt(i), ke(te(e)), Pt({ year: n, month: r, day: o }, i);
}
function Wi(t, e, n) {
  return Te(fr(t, e, n), Ps(e.hour, e.minute, e.second, e.millisecond, e.microsecond, e.nanosecond, n));
}
function ai(t, e) {
  let n, r, o;
  if (Le(t)) {
    if (ze(t)) return ke(te(e)), Xt(w(t, xe), w(t, K));
    if (ge(t)) {
      const c = nn(w(t, Pe), w(t, le));
      return ke(te(e)), Xt(c, w(t, K));
    }
    if (Ne(t)) return ke(te(e)), Xt(Te(w(t, de), { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), w(t, K));
    o = Bi(t);
    const i = Wt(o, t, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond"], []), a = ke(te(e));
    ({ isoDate: n, time: r } = Wi(o, i, a));
  } else {
    let i, a, c, l;
    if ({ year: a, month: c, day: l, time: r, calendar: o, z: i } = Pn(Be(t)), i) throw new RangeError("Z designator not supported for PlainDateTime");
    r === "start-of-day" && (r = { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), tl(a, c, l, r.hour, r.minute, r.second, r.millisecond, r.microsecond, r.nanosecond), o || (o = "iso8601"), o = Dt(o), ke(te(e)), n = { year: a, month: c, day: l };
  }
  return Xt(Te(n, r), o);
}
function tn(t) {
  const e = it("%Temporal.Duration%");
  if ($e(t)) return new e(w(t, gt), w(t, vt), w(t, zt), w(t, yt), w(t, bt), w(t, wt), w(t, kt), w(t, _t), w(t, Tt), w(t, Rt));
  if (!Le(t)) return (function(o) {
    const { years: i, months: a, weeks: c, days: l, hours: h, minutes: m, seconds: p, milliseconds: v, microseconds: k, nanoseconds: P } = (function(A) {
      const S = Y_.exec(A);
      if (!S) throw new RangeError(`invalid duration: ${A}`);
      if (S.every(((yr, Sn) => Sn < 2 || yr === void 0))) throw new RangeError(`invalid duration: ${A}`);
      const z = S[1] === "-" ? -1 : 1, L = S[2] === void 0 ? 0 : fe(S[2]) * z, W = S[3] === void 0 ? 0 : fe(S[3]) * z, H = S[4] === void 0 ? 0 : fe(S[4]) * z, re = S[5] === void 0 ? 0 : fe(S[5]) * z, Ee = S[6] === void 0 ? 0 : fe(S[6]) * z, ye = S[7], ue = S[8], he = S[9], _e = S[10], De = S[11];
      let Ce = 0, We = 0, He = 0;
      if (ye !== void 0) {
        if (ue ?? he ?? _e ?? De) throw new RangeError("only the smallest unit can be fractional");
        He = 3600 * fe((ye + "000000000").slice(0, 9)) * z;
      } else if (Ce = ue === void 0 ? 0 : fe(ue) * z, he !== void 0) {
        if (_e ?? De) throw new RangeError("only the smallest unit can be fractional");
        He = 60 * fe((he + "000000000").slice(0, 9)) * z;
      } else We = _e === void 0 ? 0 : fe(_e) * z, De !== void 0 && (He = fe((De + "000000000").slice(0, 9)) * z);
      const Yt = He % 1e3, An = Math.trunc(He / 1e3) % 1e3, En = Math.trunc(He / 1e6) % 1e3;
      return We += Math.trunc(He / 1e9) % 60, Ce += Math.trunc(He / 6e10), Ds(L, W, H, re, Ee, Ce, We, En, An, Yt), { years: L, months: W, weeks: H, days: re, hours: Ee, minutes: Ce, seconds: We, milliseconds: En, microseconds: An, nanoseconds: Yt };
    })(o);
    return new (it("%Temporal.Duration%"))(i, a, c, l, h, m, p, v, k, P);
  })(Be(t));
  const n = { years: 0, months: 0, weeks: 0, days: 0, hours: 0, minutes: 0, seconds: 0, milliseconds: 0, microseconds: 0, nanoseconds: 0 };
  let r = qm(t);
  for (let o = 0; o < is.length; o++) {
    const i = is[o], a = r[i];
    a !== void 0 && (n[i] = a);
  }
  return new e(n.years, n.months, n.weeks, n.days, n.hours, n.minutes, n.seconds, n.milliseconds, n.microseconds, n.nanoseconds);
}
function si(t) {
  let e;
  if (Le(t)) {
    if (tt(t) || ge(t)) return gn(w(t, le));
    e = pc(t);
  } else e = t;
  const { year: n, month: r, day: o, time: i, offset: a, z: c } = (function(A) {
    const S = Pn(A);
    if (!S.z && !S.offset) throw new RangeError("Temporal.Instant requires a time zone offset");
    return S;
  })(Be(e)), { hour: l = 0, minute: h = 0, second: m = 0, millisecond: p = 0, microsecond: v = 0, nanosecond: k = 0 } = i === "start-of-day" ? {} : i, P = Ri(n, r, o, l, h, m, p, v, k - (c ? 0 : Mo(a)));
  return go(P.isoDate), gn(rt(P));
}
function ih(t, e) {
  if (Le(t)) {
    if (Gt(t)) return ke(te(e)), mo(w(t, de), w(t, K));
    let c;
    return St(t, K) ? c = w(t, K) : (c = t.calendar, c === void 0 && (c = "iso8601"), c = Vi(c)), mo(ss(c, Wt(c, t, ["year", "month", "monthCode", "day"], [], []), ke(te(e))), c);
  }
  let { month: n, day: r, referenceISOYear: o, calendar: i } = Qc(Be(t));
  if (i === void 0 && (i = "iso8601"), i = Dt(i), ke(te(e)), i === "iso8601") return mo({ year: 1972, month: n, day: r }, i);
  let a = { year: o, month: n, day: r };
  return Vr(a), a = ss(i, Et(i, a, "month-day"), "constrain"), mo(a, i);
}
function ar(t, e) {
  let n;
  if (Le(t)) {
    if (Fe(t)) return ke(te(e)), Ln(w(t, je));
    if (ze(t)) return ke(te(e)), Ln(w(t, xe).time);
    if (ge(t)) {
      const h = nn(w(t, Pe), w(t, le));
      return ke(te(e)), Ln(h.time);
    }
    const { hour: r, minute: o, second: i, millisecond: a, microsecond: c, nanosecond: l } = vc(t);
    n = Ps(r, o, i, a, c, l, ke(te(e)));
  } else n = Gm(Be(t)), ke(te(e));
  return Ln(n);
}
function Km(t) {
  return t === void 0 ? { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 } : w(ar(t), je);
}
function ui(t, e) {
  if (Le(t)) {
    if (nt(t)) return ke(te(e)), po(w(t, de), w(t, K));
    const c = Bi(t);
    return po(Di(c, Wt(c, t, ["year", "month", "monthCode"], [], []), ke(te(e))), c);
  }
  let { year: n, month: r, referenceISODay: o, calendar: i } = Hc(Be(t));
  i === void 0 && (i = "iso8601"), i = Dt(i), ke(te(e));
  let a = { year: n, month: r, day: o };
  return nl(a), a = Di(i, Et(i, a, "year-month"), "constrain"), po(a, i);
}
function as(t, e, n, r, o, i, a, c) {
  if (e === "start-of-day") return or(o, t);
  const l = Te(t, e);
  if (n === "wall" || a === "ignore") return lt(o, l, i);
  if (n === "exact" || a === "use") {
    const p = Ri(t.year, t.month, t.day, e.hour, e.minute, e.second, e.millisecond, e.microsecond, e.nanosecond - r);
    go(p.isoDate);
    const v = rt(p);
    return _n(v), v;
  }
  go(t);
  const h = rt(l), m = Ii(o, l);
  for (let p = 0; p < m.length; p++) {
    const v = m[p], k = y.toNumber(y.subtract(h, v)), P = sr(k, 6e10, "halfExpand");
    if (k === r || c && P === r) return v;
  }
  if (a === "reject") {
    const p = yc(r), v = zi(l, "iso8601", "auto");
    throw new RangeError(`Offset ${p} is invalid for ${v} in ${o}`);
  }
  return ep(m, o, l, i);
}
function ci(t, e) {
  let n, r, o, i, a, c, l, h = !1, m = "option";
  if (Le(t)) {
    if (ge(t)) {
      const A = te(e);
      return yi(A), Za(A, "reject"), ke(A), ut(w(t, le), w(t, Pe), w(t, K));
    }
    a = Bi(t);
    const v = Wt(a, t, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset", "timeZone"], ["timeZone"]);
    ({ offset: i, timeZone: o } = v), i === void 0 && (m = "wall");
    const k = te(e);
    c = yi(k), l = Za(k, "reject");
    const P = ke(k);
    ({ isoDate: n, time: r } = Wi(a, v, P));
  } else {
    let v, k, P, A, S;
    ({ year: P, month: A, day: S, time: r, tzAnnotation: v, offset: i, z: k, calendar: a } = (function(L) {
      const W = Pn(L);
      if (!W.tzAnnotation) throw new RangeError("Temporal.ZonedDateTime requires a time zone ID in brackets");
      return W;
    })(Be(t))), o = At(v), k ? m = "exact" : i || (m = "wall"), a || (a = "iso8601"), a = Dt(a), h = !0;
    const z = te(e);
    c = yi(z), l = Za(z, "reject"), ke(z), n = { year: P, month: A, day: S };
  }
  let p = 0;
  return m === "option" && (p = Mo(i)), ut(as(n, r, m, p, o, c, l, h), o, a);
}
function Wm(t, e, n) {
  Vr(e), Yn(t), pe(t, de, e), pe(t, K, n), pe(t, Tm, !0);
}
function Pt(t, e) {
  const n = it("%Temporal.PlainDate%"), r = Object.create(n.prototype);
  return Wm(r, t, e), r;
}
function Ym(t, e, n) {
  Zr(e), Yn(t), pe(t, xe, e), pe(t, K, n);
}
function Xt(t, e) {
  const n = it("%Temporal.PlainDateTime%"), r = Object.create(n.prototype);
  return Ym(r, t, e), r;
}
function Vm(t, e, n) {
  Vr(e), Yn(t), pe(t, de, e), pe(t, K, n), pe(t, Pm, !0);
}
function mo(t, e) {
  const n = it("%Temporal.PlainMonthDay%"), r = Object.create(n.prototype);
  return Vm(r, t, e), r;
}
function Bm(t, e) {
  Yn(t), pe(t, je, e);
}
function Ln(t) {
  const e = it("%Temporal.PlainTime%"), n = Object.create(e.prototype);
  return Bm(n, t), n;
}
function Hm(t, e, n) {
  nl(e), Yn(t), pe(t, de, e), pe(t, K, n), pe(t, Cm, !0);
}
function po(t, e) {
  const n = it("%Temporal.PlainYearMonth%"), r = Object.create(n.prototype);
  return Hm(r, t, e), r;
}
function Qm(t, e) {
  _n(e), Yn(t), pe(t, le, e);
}
function gn(t) {
  const e = it("%Temporal.Instant%"), n = Object.create(e.prototype);
  return Qm(n, t), n;
}
function Xm(t, e, n, r) {
  _n(e), Yn(t), pe(t, le, e), pe(t, Pe, n), pe(t, K, r);
}
function ut(t, e, n = "iso8601") {
  const r = it("%Temporal.ZonedDateTime%"), o = Object.create(r.prototype);
  return Xm(o, t, e, n), o;
}
function ah(t) {
  return gc.filter(((e) => t[e] !== void 0));
}
function Fr(t, e, n) {
  const r = ah(n), o = gr(t).fieldKeysToIgnore(r), i = /* @__PURE__ */ Object.create(null), a = ah(e);
  for (let c = 0; c < gc.length; c++) {
    let l;
    const h = gc[c];
    a.includes(h) && !o.includes(h) && (l = e[h]), r.includes(h) && (l = n[h]), l !== void 0 && (i[h] = l);
  }
  return i;
}
function qt(t, e, n, r) {
  const o = gr(t).dateAdd(e, n, r);
  return Vr(o), o;
}
function Yi(t, e, n, r) {
  return gr(t).dateUntil(e, n, r);
}
function Vi(t) {
  if (Le(t) && St(t, K)) return w(t, K);
  const e = Be(t);
  try {
    return Dt(e);
  } catch {
  }
  let n;
  try {
    ({ calendar: n } = Pn(e));
  } catch {
    try {
      ({ calendar: n } = Gm(e));
    } catch {
      try {
        ({ calendar: n } = Hc(e));
      } catch {
        ({ calendar: n } = Qc(e));
      }
    }
  }
  return n || (n = "iso8601"), Dt(n);
}
function Bi(t) {
  if (St(t, K)) return w(t, K);
  const { calendar: e } = t;
  return e === void 0 ? "iso8601" : Vi(e);
}
function kn(t, e) {
  return Dt(t) === Dt(e);
}
function fr(t, e, n) {
  const r = gr(t);
  r.resolveFields(e, "date");
  const o = r.dateToISO(e, n);
  return Vr(o), o;
}
function Di(t, e, n) {
  const r = gr(t);
  r.resolveFields(e, "year-month"), e.day = 1;
  const o = r.dateToISO(e, n);
  return nl(o), o;
}
function ss(t, e, n) {
  const r = gr(t);
  r.resolveFields(e, "month-day");
  const o = r.monthDayToISOReferenceDate(e, n);
  return Vr(o), o;
}
function At(t) {
  if (Le(t) && ge(t)) return w(t, Pe);
  const e = Be(t);
  if (e === "UTC") return "UTC";
  const { tzName: n, offsetMinutes: r } = (function(i) {
    const { tzAnnotation: a, offset: c, z: l } = (function(h) {
      if (Fm.test(h)) return { tzAnnotation: h, offset: void 0, z: !1 };
      try {
        const { tzAnnotation: m, offset: p, z: v } = Pn(h);
        if (v || m || p) return { tzAnnotation: m, offset: p, z: v };
      } catch {
      }
      Zm(h);
    })(i);
    return a ? ur(a) : l ? ur("UTC") : c ? ur(c) : void 0;
  })(e);
  if (r !== void 0) return Xc(r);
  const o = us(n);
  if (!o) throw new RangeError(`Unrecognized time zone ${n}`);
  return o.identifier;
}
function Jm(t, e) {
  if (t === e) return !0;
  const n = ur(t).offsetMinutes, r = ur(e).offsetMinutes;
  if (n === void 0 && r === void 0) {
    const o = us(e);
    if (!o) return !1;
    const i = us(t);
    return !!i && i.primaryIdentifier === o.primaryIdentifier;
  }
  return n === r;
}
function Gn(t, e) {
  const n = ur(t).offsetMinutes;
  return n !== void 0 ? 6e10 * n : bc(t, e);
}
function yc(t) {
  const e = t < 0 ? "-" : "+", n = Math.abs(t), r = Math.floor(n / 36e11), o = Math.floor(n / 6e10) % 60, i = Math.floor(n / 1e9) % 60, a = n % 1e9;
  return `${e}${As(r, o, i, a, i === 0 && a === 0 ? "minute" : "auto")}`;
}
function nn(t, e) {
  const n = Gn(t, e);
  let { isoDate: { year: r, month: o, day: i }, time: { hour: a, minute: c, second: l, millisecond: h, microsecond: m, nanosecond: p } } = rp(e);
  return Ri(r, o, i, a, c, l, h, m, p + n);
}
function lt(t, e, n) {
  return ep(Ii(t, e), t, e, n);
}
function ep(t, e, n, r) {
  const o = t.length;
  if (o === 1) return t[0];
  if (o) switch (r) {
    case "compatible":
    case "earlier":
      return t[0];
    case "later":
      return t[o - 1];
    case "reject":
      throw new RangeError("multiple instants found");
  }
  if (r === "reject") throw new RangeError("multiple instants found");
  const i = rt(n), a = y.subtract(i, dr);
  _n(a);
  const c = Gn(e, a), l = y.add(i, dr);
  _n(l);
  const h = Gn(e, l) - c;
  switch (r) {
    case "earlier": {
      const m = ve.fromComponents(0, 0, 0, 0, 0, -h), p = Ao(n.time, m);
      return Ii(e, Te($t(n.isoDate.year, n.isoDate.month, n.isoDate.day + p.deltaDays), p))[0];
    }
    case "compatible":
    case "later": {
      const m = ve.fromComponents(0, 0, 0, 0, 0, h), p = Ao(n.time, m), v = Ii(e, Te($t(n.isoDate.year, n.isoDate.month, n.isoDate.day + p.deltaDays), p));
      return v[v.length - 1];
    }
  }
}
function Ii(t, e) {
  if (t === "UTC") return go(e.isoDate), [rt(e)];
  const n = ur(t).offsetMinutes;
  if (n !== void 0) {
    const r = Ri(e.isoDate.year, e.isoDate.month, e.isoDate.day, e.time.hour, e.time.minute - n, e.time.second, e.time.millisecond, e.time.microsecond, e.time.nanosecond);
    go(r.isoDate);
    const o = rt(r);
    return _n(o), [o];
  }
  return go(e.isoDate), (function(r, o) {
    let i = rt(o), a = y.subtract(i, dr);
    y.lessThan(a, Ei) && (a = i);
    let c = y.add(i, dr);
    y.greaterThan(c, To) && (c = i);
    const l = bc(r, a), h = bc(r, c);
    return (l === h ? [l] : [l, h]).map(((p) => {
      const v = y.subtract(i, y.BigInt(p)), k = (function(P, A) {
        const { epochMilliseconds: S, time: { millisecond: z, microsecond: L, nanosecond: W } } = rp(A), { year: H, month: re, day: Ee, hour: ye, minute: ue, second: he } = op(P, S);
        return Ri(H, re, Ee, ye, ue, he, z, L, W);
      })(r, v);
      if (Eo(o, k) === 0) return _n(v), v;
    })).filter(((p) => p !== void 0));
  })(t, e);
}
function or(t, e) {
  const n = Te(e, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), r = Ii(t, n);
  if (r.length) return r[0];
  const o = rt(n), i = y.subtract(o, dr);
  return _n(i), el(t, i);
}
function Hi(t) {
  let e;
  return e = t < 0 || t > 9999 ? (t < 0 ? "-" : "+") + Si(Math.abs(t), 6) : Si(t, 4), e;
}
function Kt(t) {
  return Si(t, 2);
}
function tp(t, e) {
  let n;
  if (e === "auto") {
    if (t === 0) return "";
    n = Si(t, 9).replace(/0+$/, "");
  } else {
    if (e === 0) return "";
    n = Si(t, 9).slice(0, e);
  }
  return `.${n}`;
}
function As(t, e, n, r, o) {
  let i = `${Kt(t)}:${Kt(e)}`;
  return o === "minute" || (i += `:${Kt(n)}`, i += tp(r, o)), i;
}
function sh(t, e, n) {
  let r = e;
  r === void 0 && (r = "UTC");
  const o = w(t, le), i = zi(nn(r, o), "iso8601", n, "never");
  let a = "Z";
  return e !== void 0 && (a = np(Gn(r, o))), `${i}${a}`;
}
function ja(t, e) {
  const n = w(t, gt), r = w(t, vt), o = w(t, zt), i = w(t, yt), a = w(t, bt), c = w(t, wt), l = ls(t);
  let h = "";
  n !== 0 && (h += `${Math.abs(n)}Y`), r !== 0 && (h += `${Math.abs(r)}M`), o !== 0 && (h += `${Math.abs(o)}W`), i !== 0 && (h += `${Math.abs(i)}D`);
  let m = "";
  a !== 0 && (m += `${Math.abs(a)}H`), c !== 0 && (m += `${Math.abs(c)}M`);
  const p = ve.fromComponents(0, 0, w(t, kt), w(t, _t), w(t, Tt), w(t, Rt));
  p.isZero() && !["second", "millisecond", "microsecond", "nanosecond"].includes(Mn(t)) && e === "auto" || (m += `${Math.abs(p.sec)}${tp(Math.abs(p.subsec), e)}S`);
  let v = `${l < 0 ? "-" : ""}P${h}`;
  return m && (v = `${v}T${m}`), v;
}
function uh(t, e = "auto") {
  const { year: n, month: r, day: o } = w(t, de);
  return `${Hi(n)}-${Kt(r)}-${Kt(o)}${Fi(w(t, K), e)}`;
}
function ch({ hour: t, minute: e, second: n, millisecond: r, microsecond: o, nanosecond: i }, a) {
  return As(t, e, n, 1e6 * r + 1e3 * o + i, a);
}
function zi(t, e, n, r = "auto") {
  const { isoDate: { year: o, month: i, day: a }, time: { hour: c, minute: l, second: h, millisecond: m, microsecond: p, nanosecond: v } } = t;
  return `${Hi(o)}-${Kt(i)}-${Kt(a)}T${As(c, l, h, 1e6 * m + 1e3 * p + v, n)}${Fi(e, r)}`;
}
function lh(t, e = "auto") {
  const { year: n, month: r, day: o } = w(t, de);
  let i = `${Kt(r)}-${Kt(o)}`;
  const a = w(t, K);
  e !== "always" && e !== "critical" && a === "iso8601" || (i = `${Hi(n)}-${i}`);
  const c = Fi(a, e);
  return c && (i += c), i;
}
function dh(t, e = "auto") {
  const { year: n, month: r, day: o } = w(t, de);
  let i = `${Hi(n)}-${Kt(r)}`;
  const a = w(t, K);
  e !== "always" && e !== "critical" && a === "iso8601" || (i += `-${Kt(o)}`);
  const c = Fi(a, e);
  return c && (i += c), i;
}
function hh(t, e, n = "auto", r = "auto", o = "auto", i = void 0) {
  let a = w(t, le);
  if (i) {
    const { unit: m, increment: p, roundingMode: v } = i;
    a = Tc(a, p, m, v);
  }
  const c = w(t, Pe), l = Gn(c, a);
  let h = zi(nn(c, a), "iso8601", e, "never");
  return o !== "never" && (h += np(l)), r !== "never" && (h += `[${r === "critical" ? "!" : ""}${c}]`), h += Fi(w(t, K), n), h;
}
function fh(t) {
  return Um.test(t);
}
function Mo(t) {
  const e = aT.exec(t);
  if (!e) throw new RangeError(`invalid time zone offset: ${t}; must match ±HH:MM[:SS.SSSSSSSSS]`);
  return (e[1] === "-" ? -1 : 1) * (1e9 * (60 * (60 * +e[2] + +(e[3] || 0)) + +(e[4] || 0)) + +((e[5] || 0) + "000000000").slice(0, 9));
}
let zr;
const oT = Object.assign(/* @__PURE__ */ Object.create(null), { "/": !0, "-": !0, _: !0 });
function us(t) {
  var i;
  if (zr === void 0) {
    const a = (i = Intl.supportedValuesOf) == null ? void 0 : i.call(Intl, "timeZone");
    if (a) {
      zr = /* @__PURE__ */ new Map();
      for (let c = 0; c < a.length; c++) {
        const l = a[c];
        zr.set(xi(l), l);
      }
    } else zr = null;
  }
  const e = xi(t);
  let n = zr == null ? void 0 : zr.get(e);
  if (n) return { identifier: n, primaryIdentifier: n };
  try {
    n = Lm(t).resolvedOptions().timeZone;
  } catch {
    return;
  }
  if (e === "antarctica/south_pole" && (n = "Antarctica/McMurdo"), J_.has(t)) throw new RangeError(`${t} is a legacy time zone identifier from ICU. Use ${n} instead`);
  const r = [...e].map(((a, c) => c === 0 || oT[e[c - 1]] ? a.toUpperCase() : a)).join("").split("/");
  if (r.length === 1) return e === "gb-eire" ? { identifier: "GB-Eire", primaryIdentifier: n } : { identifier: e.length <= 3 || /[-0-9]/.test(e) ? e.toUpperCase() : r[0], primaryIdentifier: n };
  if (r[0] === "Etc") return { identifier: `Etc/${["Zulu", "Greenwich", "Universal"].includes(r[1]) ? r[1] : r[1].toUpperCase()}`, primaryIdentifier: n };
  if (r[0] === "Us") return { identifier: `US/${r[1]}`, primaryIdentifier: n };
  const o = /* @__PURE__ */ new Map([["Act", "ACT"], ["Lhi", "LHI"], ["Nsw", "NSW"], ["Dar_Es_Salaam", "Dar_es_Salaam"], ["Port_Of_Spain", "Port_of_Spain"], ["Port-Au-Prince", "Port-au-Prince"], ["Isle_Of_Man", "Isle_of_Man"], ["Comodrivadavia", "ComodRivadavia"], ["Knox_In", "Knox_IN"], ["Dumontdurville", "DumontDUrville"], ["Mcmurdo", "McMurdo"], ["Denoronha", "DeNoronha"], ["Easterisland", "EasterIsland"], ["Bajanorte", "BajaNorte"], ["Bajasur", "BajaSur"]]);
  return r[1] = o.get(r[1]) ?? r[1], r.length > 2 && (r[2] = o.get(r[2]) ?? r[2]), { identifier: r.join("/"), primaryIdentifier: n };
}
function jr(t, e) {
  const { year: n, month: r, day: o, hour: i, minute: a, second: c } = op(t, e);
  let l = e % 1e3;
  return l < 0 && (l += 1e3), 1e6 * (Jc({ isoDate: { year: n, month: r, day: o }, time: { hour: i, minute: a, second: c, millisecond: l } }) - e);
}
function bc(t, e) {
  return jr(t, rn(e, "floor"));
}
function Xc(t) {
  const e = t < 0 ? "-" : "+", n = Math.abs(t);
  return `${e}${As(Math.floor(n / 60), n % 60, 0, 0, "minute")}`;
}
function np(t) {
  return Xc(sr(t, V_, "halfExpand") / 6e10);
}
function Jc({ isoDate: { year: t, month: e, day: n }, time: { hour: r, minute: o, second: i, millisecond: a } }) {
  const c = t % 400, l = (t - c) / 400, h = /* @__PURE__ */ new Date();
  return h.setUTCHours(r, o, i, a), h.setUTCFullYear(c, e - 1, n), h.getTime() + Q_ * l;
}
function rt(t) {
  const e = Jc(t), n = 1e3 * t.time.microsecond + t.time.nanosecond;
  return y.add(yn(e), y.BigInt(n));
}
function rp(t) {
  let e = rn(t, "trunc"), n = y.toNumber(y.remainder(t, Li));
  n < 0 && (n += 1e6, e -= 1);
  const r = Math.floor(n / 1e3) % 1e3, o = n % 1e3, i = new Date(e);
  return { epochMilliseconds: e, isoDate: { year: i.getUTCFullYear(), month: i.getUTCMonth() + 1, day: i.getUTCDate() }, time: { hour: i.getUTCHours(), minute: i.getUTCMinutes(), second: i.getUTCSeconds(), millisecond: i.getUTCMilliseconds(), microsecond: r, nanosecond: o } };
}
function el(t, e) {
  if (t === "UTC") return null;
  const n = rn(e, "floor");
  if (n < pi) return el(t, yn(pi));
  const r = Date.now(), o = Math.max(n, r) + 366 * hr * 3;
  let i = n, a = jr(t, i), c = i, l = a;
  for (; a === l && i < o; ) {
    if (c = i + 2 * hr * 7, c > jm) return null;
    l = jr(t, c), a === l && (i = c);
  }
  return a === l ? null : yn(mp(((h) => jr(t, h)), i, c, a, l));
}
function wc(t, e) {
  if (t === "UTC") return null;
  const n = rn(e, "ceil"), r = Date.now(), o = r + 366 * hr * 3;
  if (n > o) {
    const h = wc(t, yn(o));
    if (h === null || y.lessThan(h, yn(r))) return h;
  }
  if (t === "Africa/Casablanca" || t === "Africa/El_Aaiun") {
    const h = Date.UTC(2088, 0, 1);
    if (h < n) return wc(t, yn(h));
  }
  let i = n - 1;
  if (i < pi) return null;
  let a = jr(t, i), c = i, l = a;
  for (; a === l && i > pi; ) {
    if (c = i - 2 * hr * 7, c < pi) return null;
    l = jr(t, c), a === l && (i = c);
  }
  return a === l ? null : yn(mp(((h) => jr(t, h)), c, i, l, a));
}
function op(t, e) {
  return (function(n) {
    const r = n.split(/[^\w]+/);
    if (r.length !== 7) throw new RangeError(`expected 7 parts in "${n}`);
    const o = +r[0], i = +r[1];
    let a = +r[2];
    const c = r[3];
    if (c[0] === "b" || c[0] === "B") a = 1 - a;
    else if (c[0] !== "a" && c[0] !== "A") throw new RangeError(`Unknown era ${c} in "${n}`);
    const l = r[4] === "24" ? 0 : +r[4], h = +r[5], m = +r[6];
    if (!(Number.isFinite(a) && Number.isFinite(o) && Number.isFinite(i) && Number.isFinite(l) && Number.isFinite(h) && Number.isFinite(m))) throw new RangeError(`Invalid number in "${n}`);
    return { year: a, month: o, day: i, hour: l, minute: h, second: m };
  })(Lm(t).format(e));
}
function cs(t) {
  return t !== void 0 && !(t % 4 != 0 || t % 100 == 0 && t % 400 != 0);
}
function Lr(t, e) {
  return { standard: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], leapyear: [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] }[cs(t) ? "leapyear" : "standard"][e - 1];
}
function ls(t) {
  const e = [w(t, gt), w(t, vt), w(t, zt), w(t, yt), w(t, bt), w(t, wt), w(t, kt), w(t, _t), w(t, Tt), w(t, Rt)];
  for (let n = 0; n < e.length; n++) {
    const r = e[n];
    if (r !== 0) return r < 0 ? -1 : 1;
  }
  return 0;
}
function Es(t) {
  const e = ["years", "months", "weeks", "days"];
  for (let n = 0; n < e.length; n++) {
    const r = t[e[n]];
    if (r !== 0) return r < 0 ? -1 : 1;
  }
  return 0;
}
function ip(t) {
  const e = Es(t.date);
  return e !== 0 ? e : t.time.sign();
}
function $r(t, e) {
  let n = t, r = e;
  if (!Number.isFinite(n) || !Number.isFinite(r)) throw new RangeError("infinity is out of range");
  return r -= 1, n += Math.floor(r / 12), r %= 12, r < 0 && (r += 12), r += 1, { year: n, month: r };
}
function $t(t, e, n) {
  let r = t, o = e, i = n;
  if (!Number.isFinite(i)) throw new RangeError("infinity is out of range");
  ({ year: r, month: o } = $r(r, o));
  const a = 146097;
  if (Math.abs(i) > a) {
    const h = Math.trunc(i / a);
    r += 400 * h, i -= h * a;
  }
  let c = 0, l = o > 2 ? r : r - 1;
  for (; c = cs(l) ? 366 : 365, i < -c; ) r -= 1, l -= 1, i += c;
  for (l += 1; c = cs(l) ? 366 : 365, i > c; ) r += 1, l += 1, i -= c;
  for (; i < 1; ) ({ year: r, month: o } = $r(r, o - 1)), i += Lr(r, o);
  for (; i > Lr(r, o); ) i -= Lr(r, o), { year: r, month: o } = $r(r, o + 1);
  return { year: r, month: o, day: i };
}
function Ri(t, e, n, r, o, i, a, c, l) {
  const h = ir(r, o, i, a, c, l);
  return Te($t(t, e, n + h.deltaDays), h);
}
function ir(t, e, n, r, o, i) {
  let a, c = t, l = e, h = n, m = r, p = o, v = i;
  ({ div: a, mod: v } = fo(v, 3)), p += a, v < 0 && (p -= 1, v += 1e3), { div: a, mod: p } = fo(p, 3), m += a, p < 0 && (m -= 1, p += 1e3), h += Math.trunc(m / 1e3), m %= 1e3, m < 0 && (h -= 1, m += 1e3), l += Math.trunc(h / 60), h %= 60, h < 0 && (l -= 1, h += 60), c += Math.trunc(l / 60), l %= 60, l < 0 && (c -= 1, l += 60);
  let k = Math.trunc(c / 24);
  return c %= 24, c < 0 && (k -= 1, c += 24), k += 0, c += 0, l += 0, h += 0, m += 0, p += 0, v += 0, { deltaDays: k, hour: c, minute: l, second: h, millisecond: m, microsecond: p, nanosecond: v };
}
function mh(t, e) {
  const n = ct(t, 0);
  if (Es(n) === 0) return t.days;
  const r = w(e, de), o = qt(w(e, K), r, n, "constrain"), i = qr(r.year, r.month - 1, r.day), a = qr(o.year, o.month - 1, o.day) - i;
  return t.days + a;
}
function jt(t) {
  return new (it("%Temporal.Duration%"))(-w(t, gt), -w(t, vt), -w(t, zt), -w(t, yt), -w(t, bt), -w(t, wt), -w(t, kt), -w(t, _t), -w(t, Tt), -w(t, Rt));
}
function Ct(t, e, n) {
  return Math.min(n, Math.max(e, t));
}
function ap(t, e, n) {
  const r = Ct(e, 1, 12);
  return { year: t, month: r, day: Ct(n, 1, Lr(t, r)) };
}
function Je(t, e, n) {
  if (t < e || t > n) throw new RangeError(`value out of range: ${e} <= ${t} <= ${n}`);
}
function Ur(t, e, n) {
  Je(e, 1, 12), Je(n, 1, Lr(t, e));
}
function Vr(t) {
  Zr(Te(t, { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }));
}
function Ss(t, e, n, r, o, i) {
  Je(t, 0, 23), Je(e, 0, 59), Je(n, 0, 59), Je(r, 0, 999), Je(o, 0, 999), Je(i, 0, 999);
}
function tl(t, e, n, r, o, i, a, c, l) {
  Ur(t, e, n), Ss(r, o, i, a, c, l);
}
function Zr(t) {
  const e = rt(t);
  (y.lessThan(e, B_) || y.greaterThan(e, H_)) && _n(e);
}
function kc(t) {
  rt(t);
}
function _n(t) {
  if (y.lessThan(t, Ei) || y.greaterThan(t, To)) throw new RangeError("date/time value is outside of supported range");
}
function nl({ year: t, month: e }) {
  Je(t, eh, th), t === eh ? Je(e, 4, 12) : t === th && Je(e, 1, 9);
}
function Ds(t, e, n, r, o, i, a, c, l, h) {
  let m = 0;
  const p = [t, e, n, r, o, i, a, c, l, h];
  for (let z = 0; z < p.length; z++) {
    const L = p[z];
    if (L === 1 / 0 || L === -1 / 0) throw new RangeError("infinite values not allowed as duration fields");
    if (L !== 0) {
      const W = L < 0 ? -1 : 1;
      if (m !== 0 && W !== m) throw new RangeError("mixed-sign values not allowed as duration fields");
      m = W;
    }
  }
  if (Math.abs(t) >= 2 ** 32 || Math.abs(e) >= 2 ** 32 || Math.abs(n) >= 2 ** 32) throw new RangeError("years, months, and weeks must be < 2³²");
  const v = fo(c, 3), k = fo(l, 6), P = fo(h, 9), A = fo(1e6 * v.mod + 1e3 * k.mod + P.mod, 9).div, S = 86400 * r + 3600 * o + 60 * i + a + v.div + k.div + P.div + A;
  if (!Number.isSafeInteger(S)) throw new RangeError("total of duration time units cannot exceed 9007199254740991.999999999 s");
}
function ho(t) {
  return { date: { years: w(t, gt), months: w(t, vt), weeks: w(t, zt), days: w(t, yt) }, time: ve.fromComponents(w(t, bt), w(t, wt), w(t, kt), w(t, _t), w(t, Tt), w(t, Rt)) };
}
function vn(t) {
  const e = ve.fromComponents(w(t, bt), w(t, wt), w(t, kt), w(t, _t), w(t, Tt), w(t, Rt)).add24HourDays(w(t, yt));
  return { date: { years: w(t, gt), months: w(t, vt), weeks: w(t, zt), days: 0 }, time: e };
}
function sp(t) {
  const e = vn(t), n = Math.trunc(e.time.sec / 86400);
  return Ds(e.date.years, e.date.months, e.date.weeks, n, 0, 0, 0, 0, 0, 0), { ...e.date, days: n };
}
function Jt(t, e) {
  const n = t.time.sign();
  let r = t.time.abs().subsec, o = 0, i = 0, a = t.time.abs().sec, c = 0, l = 0, h = 0;
  switch (e) {
    case "year":
    case "month":
    case "week":
    case "day":
      o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3, c = Math.trunc(a / 60), a %= 60, l = Math.trunc(c / 60), c %= 60, h = Math.trunc(l / 24), l %= 24;
      break;
    case "hour":
      o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3, c = Math.trunc(a / 60), a %= 60, l = Math.trunc(c / 60), c %= 60;
      break;
    case "minute":
      o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3, c = Math.trunc(a / 60), a %= 60;
      break;
    case "second":
      o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3;
      break;
    case "millisecond":
      o = Math.trunc(r / 1e3), r %= 1e3, i = Lu(a, 3, Math.trunc(o / 1e3)), o %= 1e3, a = 0;
      break;
    case "microsecond":
      o = Lu(a, 6, Math.trunc(r / 1e3)), r %= 1e3, a = 0;
      break;
    case "nanosecond":
      r = Lu(a, 9, r), a = 0;
  }
  return new (it("%Temporal.Duration%"))(t.date.years, t.date.months, t.date.weeks, t.date.days + n * h, n * l, n * c, n * a, n * i, n * o, n * r);
}
function Un(t, e) {
  return Es(t), e.sign(), { date: t, time: e };
}
function qr(t, e, n) {
  return Jc({ isoDate: { year: t, month: e + 1, day: n }, time: { hour: 0, minute: 0, second: 0, millisecond: 0 } }) / hr;
}
function go({ year: t, month: e, day: n }) {
  if (Math.abs(qr(t, e - 1, n)) > 1e8) throw new RangeError("date/time value is outside the supported range");
}
function rl(t, e) {
  const n = e.hour - t.hour, r = e.minute - t.minute, o = e.second - t.second, i = e.millisecond - t.millisecond, a = e.microsecond - t.microsecond, c = e.nanosecond - t.nanosecond;
  return ve.fromComponents(n, r, o, i, a, c);
}
function ol(t, e, n, r, o) {
  let i = ve.fromEpochNsDiff(e, t);
  return i = ds(i, n, r, o), Un({ years: 0, months: 0, weeks: 0, days: 0 }, i);
}
function up(t, e, n, r) {
  kc(t), kc(e);
  let o = rl(t.time, e.time);
  const i = o.sign(), a = Tn(t.isoDate, e.isoDate);
  let c = e.isoDate;
  a === i && (c = $t(c.year, c.month, c.day + i), o = o.add24HourDays(-i));
  const l = Fn("day", r), h = Yi(n, t.isoDate, c, l);
  return r !== l && (o = o.add24HourDays(h.days), h.days = 0), Un(h, o);
}
function cp(t, e, n, r, o) {
  const i = y.subtract(e, t);
  if (y.equal(i, Ut)) return { date: { years: 0, months: 0, weeks: 0, days: 0 }, time: ve.ZERO };
  const a = y.lessThan(i, Ut) ? -1 : 1, c = nn(n, t), l = nn(n, e);
  let h, m = 0, p = a === 1 ? 2 : 1, v = rl(c.time, l.time);
  for (v.sign() === -a && m++; m <= p; m++) {
    h = Te($t(l.isoDate.year, l.isoDate.month, l.isoDate.day - m * a), c.time);
    const P = lt(n, h, "compatible");
    if (v = ve.fromEpochNsDiff(e, P), v.sign() !== -a) break;
  }
  const k = Fn("day", o);
  return Un(Yi(r, c.isoDate, h.isoDate, k), v);
}
function lp(t, e, n, r, o, i, a, c, l) {
  let h, m, p, v, k = e;
  switch (c) {
    case "year": {
      const Ce = sr(k.date.years, a, "trunc");
      h = Ce, m = Ce + a * t, p = { years: h, months: 0, weeks: 0, days: 0 }, v = { ...p, years: m };
      break;
    }
    case "month": {
      const Ce = sr(k.date.months, a, "trunc");
      h = Ce, m = Ce + a * t, p = ct(k.date, 0, 0, h), v = ct(k.date, 0, 0, m);
      break;
    }
    case "week": {
      const Ce = ct(k.date, 0, 0), We = qt(i, r.isoDate, Ce, "constrain"), He = Yi(i, We, $t(We.year, We.month, We.day + k.date.days), "week"), Yt = sr(k.date.weeks + He.weeks, a, "trunc");
      h = Yt, m = Yt + a * t, p = ct(k.date, 0, h), v = ct(k.date, 0, m);
      break;
    }
    case "day": {
      const Ce = sr(k.date.days, a, "trunc");
      h = Ce, m = Ce + a * t, p = ct(k.date, h), v = ct(k.date, m);
      break;
    }
  }
  const P = qt(i, r.isoDate, p, "constrain"), A = qt(i, r.isoDate, v, "constrain");
  let S, z;
  const L = Te(P, r.time), W = Te(A, r.time);
  o ? (S = lt(o, L, "compatible"), z = lt(o, W, "compatible")) : (S = rt(L), z = rt(W));
  const H = ve.fromEpochNsDiff(n, S), re = ve.fromEpochNsDiff(z, S), Ee = ws(l, t < 0 ? "negative" : "positive"), ye = H.add(H).abs().subtract(re.abs()).sign(), ue = Math.abs(h) / a % 2 == 0, he = H.isZero() ? Math.abs(h) : H.cmp(re) ? ks(Math.abs(h), Math.abs(m), ye, ue, Ee) : Math.abs(m), _e = new ve(y.add(y.multiply(re.totalNs, y.BigInt(h)), y.multiply(H.totalNs, y.BigInt(a * t)))).fdiv(re.totalNs), De = he === Math.abs(m);
  return k = { date: De ? v : p, time: ve.ZERO }, { nudgeResult: { duration: k, nudgedEpochNs: De ? z : S, didExpandCalendarUnit: De }, total: _e };
}
function Is(t, e, n, r, o, i, a, c, l) {
  let h = t;
  const m = mn(c) || r && c === "day", p = ip(h) < 0 ? -1 : 1;
  let v;
  return m ? { nudgeResult: v } = lp(p, h, e, n, r, o, a, c, l) : v = r ? (function(k, P, A, S, z, L, W, H) {
    let re = P;
    const Ee = qt(z, A.isoDate, re.date, "constrain"), ye = Te(Ee, A.time), ue = Te($t(Ee.year, Ee.month, Ee.day + k), A.time), he = lt(S, ye, "compatible"), _e = lt(S, ue, "compatible"), De = ve.fromEpochNsDiff(_e, he);
    if (De.sign() !== k) throw new RangeError("time zone returned inconsistent Instants");
    const Ce = y.BigInt(Po[W] * L);
    let We = re.time.round(Ce, H);
    const He = We.subtract(De), Yt = He.sign() !== -k;
    let An, En;
    return Yt ? (An = k, We = He.round(Ce, H), En = We.addToEpochNs(_e)) : (An = 0, En = We.addToEpochNs(he)), { duration: Un(ct(re.date, re.date.days + An), We), nudgedEpochNs: En, didExpandCalendarUnit: Yt };
  })(p, h, n, r, o, a, c, l) : (function(k, P, A, S, z, L) {
    let W = k;
    const H = W.time.add24HourDays(W.date.days), re = H.round(y.BigInt(S * Po[z]), L), Ee = re.subtract(H), { quotient: ye } = H.divmod(os), { quotient: ue } = re.divmod(os), he = Math.sign(ue - ye) === H.sign(), _e = Ee.addToEpochNs(P);
    let De = 0, Ce = re;
    return $n(A) === "date" && (De = ue, Ce = re.add(ve.fromComponents(24 * -ue, 0, 0, 0, 0, 0))), { duration: { date: ct(W.date, De), time: Ce }, nudgedEpochNs: _e, didExpandCalendarUnit: he };
  })(h, e, i, a, c, l), h = v.duration, v.didExpandCalendarUnit && c !== "week" && (h = (function(k, P, A, S, z, L, W, H) {
    let re = P;
    if (H === W) return re;
    const Ee = gi.indexOf(W);
    for (let ye = gi.indexOf(H) - 1; ye >= Ee; ye--) {
      const ue = gi[ye];
      if (ue === "week" && W !== "week") continue;
      let he;
      switch (ue) {
        case "year":
          he = { years: re.date.years + k, months: 0, weeks: 0, days: 0 };
          break;
        case "month": {
          const Ce = re.date.months + k;
          he = ct(re.date, 0, 0, Ce);
          break;
        }
        case "week": {
          const Ce = re.date.weeks + k;
          he = ct(re.date, 0, Ce);
          break;
        }
      }
      const _e = Te(qt(L, S.isoDate, he, "constrain"), S.time);
      let De;
      if (De = z ? lt(z, _e, "compatible") : rt(_e), ns(A, De) === -k) break;
      re = { date: he, time: ve.ZERO };
    }
    return re;
  })(p, h, v.nudgedEpochNs, n, r, o, i, Fn(c, "day"))), h;
}
function ph(t, e, n, r, o, i) {
  return mn(i) || r && i === "day" ? lp(ip(t) < 0 ? -1 : 1, t, e, n, r, o, 1, i, "trunc").total : bi(t.time.add24HourDays(t.date.days), i);
}
function dp(t, e, n, r, o, i, a) {
  if (Eo(t, e) == 0) return { date: { years: 0, months: 0, weeks: 0, days: 0 }, time: ve.ZERO };
  Zr(t), Zr(e);
  const c = up(t, e, n, r);
  return i === "nanosecond" && o === 1 ? c : Is(c, rt(e), t, null, n, r, o, i, a);
}
function hp(t, e, n, r, o, i, a, c) {
  if ($n(o) === "time") return ol(t, e, i, a, c);
  const l = cp(t, e, n, r, o);
  return a === "nanosecond" && i === 1 ? l : Is(l, e, nn(n, t), n, r, o, i, a, c);
}
function $o(t, e, n, r, o, i) {
  const a = Co.reduce(((k, P) => {
    const A = P[0], S = P[1], z = P[2];
    return n !== "datetime" && z !== n || r.includes(S) || k.push(S, A), k;
  }), []);
  let c = Ot(e, "largestUnit", n, "auto");
  if (r.includes(c)) throw new RangeError(`largestUnit must be one of ${a.join(", ")}, not ${c}`);
  const l = xo(e);
  let h = ln(e, "trunc");
  t === "since" && (h = (function(k) {
    switch (k) {
      case "ceil":
        return "floor";
      case "floor":
        return "ceil";
      case "halfCeil":
        return "halfFloor";
      case "halfFloor":
        return "halfCeil";
      default:
        return k;
    }
  })(h));
  const m = Ot(e, "smallestUnit", n, o);
  if (r.includes(m)) throw new RangeError(`smallestUnit must be one of ${a.join(", ")}, not ${m}`);
  const p = Fn(i, m);
  if (c === "auto" && (c = p), Fn(c, m) !== c) throw new RangeError(`largestUnit ${c} cannot be smaller than smallestUnit ${m}`);
  const v = { hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[m];
  return v !== void 0 && Oo(l, v, !1), { largestUnit: c, roundingIncrement: l, roundingMode: h, smallestUnit: m };
}
function gh(t, e, n, r) {
  const o = si(n), i = $o(t, te(r), "time", [], "nanosecond", "second");
  let a = Jt(ol(w(e, le), w(o, le), i.roundingIncrement, i.smallestUnit, i.roundingMode), i.largestUnit);
  return t === "since" && (a = jt(a)), a;
}
function vh(t, e, n, r) {
  const o = ii(n), i = w(e, K), a = w(o, K);
  if (!kn(i, a)) throw new RangeError(`cannot compute difference between dates of ${i} and ${a} calendars`);
  const c = $o(t, te(r), "date", [], "day", "day"), l = it("%Temporal.Duration%"), h = w(e, de), m = w(o, de);
  if (Tn(h, m) === 0) return new l();
  let p = { date: Yi(i, h, m, c.largestUnit), time: ve.ZERO };
  if (c.smallestUnit !== "day" || c.roundingIncrement !== 1) {
    const k = Te(h, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    p = Is(p, rt(Te(m, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 })), k, null, i, c.largestUnit, c.roundingIncrement, c.smallestUnit, c.roundingMode);
  }
  let v = Jt(p, "day");
  return t === "since" && (v = jt(v)), v;
}
function yh(t, e, n, r) {
  const o = ai(n), i = w(e, K), a = w(o, K);
  if (!kn(i, a)) throw new RangeError(`cannot compute difference between dates of ${i} and ${a} calendars`);
  const c = $o(t, te(r), "datetime", [], "nanosecond", "day"), l = it("%Temporal.Duration%"), h = w(e, xe), m = w(o, xe);
  if (Eo(h, m) === 0) return new l();
  let p = Jt(dp(h, m, i, c.largestUnit, c.roundingIncrement, c.smallestUnit, c.roundingMode), c.largestUnit);
  return t === "since" && (p = jt(p)), p;
}
function bh(t, e, n, r) {
  const o = ar(n), i = $o(t, te(r), "time", [], "nanosecond", "hour");
  let a = rl(w(e, je), w(o, je));
  a = ds(a, i.roundingIncrement, i.smallestUnit, i.roundingMode);
  let c = Jt(Un({ years: 0, months: 0, weeks: 0, days: 0 }, a), i.largestUnit);
  return t === "since" && (c = jt(c)), c;
}
function wh(t, e, n, r) {
  const o = ui(n), i = w(e, K), a = w(o, K);
  if (!kn(i, a)) throw new RangeError(`cannot compute difference between months of ${i} and ${a} calendars`);
  const c = $o(t, te(r), "date", ["week", "day"], "month", "year"), l = it("%Temporal.Duration%");
  if (Tn(w(e, de), w(o, de)) == 0) return new l();
  const h = Et(i, w(e, de), "year-month");
  h.day = 1;
  const m = fr(i, h, "constrain"), p = Et(i, w(o, de), "year-month");
  p.day = 1;
  const v = fr(i, p, "constrain");
  let k = { date: ct(Yi(i, m, v, c.largestUnit), 0, 0), time: ve.ZERO };
  if (c.smallestUnit !== "month" || c.roundingIncrement !== 1) {
    const A = Te(m, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    k = Is(k, rt(Te(v, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 })), A, null, i, c.largestUnit, c.roundingIncrement, c.smallestUnit, c.roundingMode);
  }
  let P = Jt(k, "day");
  return t === "since" && (P = jt(P)), P;
}
function kh(t, e, n, r) {
  const o = ci(n), i = w(e, K), a = w(o, K);
  if (!kn(i, a)) throw new RangeError(`cannot compute difference between dates of ${i} and ${a} calendars`);
  const c = $o(t, te(r), "datetime", [], "nanosecond", "hour"), l = w(e, le), h = w(o, le), m = it("%Temporal.Duration%");
  let p;
  if ($n(c.largestUnit) !== "date") p = Jt(ol(l, h, c.roundingIncrement, c.smallestUnit, c.roundingMode), c.largestUnit);
  else {
    const v = w(e, Pe);
    if (!Jm(v, w(o, Pe))) throw new RangeError("When calculating difference between time zones, largestUnit must be 'hours' or smaller because day lengths can vary between time zones due to DST or time zone offset changes.");
    if (y.equal(l, h)) return new m();
    p = Jt(hp(l, h, v, i, c.largestUnit, c.roundingIncrement, c.smallestUnit, c.roundingMode), "hour");
  }
  return t === "since" && (p = jt(p)), p;
}
function Ao({ hour: t, minute: e, second: n, millisecond: r, microsecond: o, nanosecond: i }, a) {
  let c = n, l = i;
  return c += a.sec, l += a.subsec, ir(t, e, c, r, o, l);
}
function _c(t, e) {
  const n = e.addToEpochNs(t);
  return _n(n), n;
}
function li(t, e, n, r, o = "constrain") {
  if (Es(r.date) === 0) return _c(t, r.time);
  const i = nn(e, t);
  return _c(lt(e, Te(qt(n, i.isoDate, r.date, o), i.time), "compatible"), r.time);
}
function _h(t, e, n) {
  let r = tn(n);
  t === "subtract" && (r = jt(r));
  const o = Fn(Mn(e), Mn(r));
  if (mn(o)) throw new RangeError("For years, months, or weeks arithmetic, use date arithmetic relative to a starting point");
  const i = vn(e), a = vn(r);
  return Jt(Un({ years: 0, months: 0, weeks: 0, days: 0 }, i.time.add(a.time)), o);
}
function Th(t, e, n) {
  let r = tn(n);
  t === "subtract" && (r = jt(r));
  const o = Mn(r);
  if ($n(o) === "date") throw new RangeError(`Duration field ${o} not supported by Temporal.Instant. Try Temporal.ZonedDateTime instead.`);
  const i = vn(r);
  return gn(_c(w(e, le), i.time));
}
function Ch(t, e, n, r) {
  const o = w(e, K);
  let i = tn(n);
  t === "subtract" && (i = jt(i));
  const a = sp(i), c = ke(te(r));
  return Pt(qt(o, w(e, de), a, c), o);
}
function Ph(t, e, n, r) {
  let o = tn(n);
  t === "subtract" && (o = jt(o));
  const i = ke(te(r)), a = w(e, K), c = vn(o), l = w(e, xe), h = Ao(l.time, c.time), m = ct(c.date, h.deltaDays);
  return Ds(m.years, m.months, m.weeks, m.days, 0, 0, 0, 0, 0, 0), Xt(Te(qt(a, l.isoDate, m, i), h), a);
}
function Ah(t, e, n) {
  let r = tn(n);
  t === "subtract" && (r = jt(r));
  const o = vn(r), { hour: i, minute: a, second: c, millisecond: l, microsecond: h, nanosecond: m } = Ao(w(e, je), o.time);
  return Ln(Ps(i, a, c, l, h, m, "reject"));
}
function Eh(t, e, n, r) {
  let o = tn(n);
  t === "subtract" && (o = jt(o));
  const i = ke(te(r)), a = ls(o), c = w(e, K), l = Et(c, w(e, de), "year-month");
  l.day = 1;
  let h = fr(c, l, "constrain");
  if (a < 0) {
    const p = qt(c, h, { months: 1 }, "constrain");
    h = $t(p.year, p.month, p.day - 1);
  }
  const m = sp(o);
  return Vr(h), po(Di(c, Et(c, qt(c, h, m, i), "year-month"), i), c);
}
function Sh(t, e, n, r) {
  let o = tn(n);
  t === "subtract" && (o = jt(o));
  const i = ke(te(r)), a = w(e, Pe), c = w(e, K), l = ho(o);
  return ut(li(w(e, le), a, c, l, i), a, c);
}
function sr(t, e, n) {
  const r = Math.trunc(t / e), o = t % e, i = t < 0 ? "negative" : "positive", a = Math.abs(r), c = a + 1, l = xt(Math.abs(2 * o) - e), h = a % 2 == 0, m = ws(n, i), p = o === 0 ? a : ks(a, c, l, h, m);
  return e * (i === "positive" ? p : -p);
}
function Tc(t, e, n, r) {
  const o = Po[n] * e;
  return (function(i, a, c) {
    const l = On(i), h = On(a), m = y.divide(l, h), p = y.remainder(l, h), v = ws(c, "positive");
    let k, P;
    y.lessThan(l, Ut) ? (k = y.subtract(m, Ai), P = m) : (k = m, P = y.add(m, Ai));
    const A = ns(xr(y.multiply(p, Bc)), h) * (y.lessThan(l, Ut) ? -1 : 1) + 0, S = y.equal(p, Ut) ? m : ks(k, P, A, _m(k), v);
    return y.multiply(S, h);
  })(t, y.BigInt(o), r);
}
function Cc(t, e, n, r) {
  kc(t);
  const { year: o, month: i, day: a } = t.isoDate, c = Pc(t.time, e, n, r);
  return Te($t(o, i, a + c.deltaDays), c);
}
function Pc({ hour: t, minute: e, second: n, millisecond: r, microsecond: o, nanosecond: i }, a, c, l) {
  let h;
  switch (c) {
    case "day":
    case "hour":
      h = 1e3 * (1e3 * (1e3 * (60 * (60 * t + e) + n) + r) + o) + i;
      break;
    case "minute":
      h = 1e3 * (1e3 * (1e3 * (60 * e + n) + r) + o) + i;
      break;
    case "second":
      h = 1e3 * (1e3 * (1e3 * n + r) + o) + i;
      break;
    case "millisecond":
      h = 1e3 * (1e3 * r + o) + i;
      break;
    case "microsecond":
      h = 1e3 * o + i;
      break;
    case "nanosecond":
      h = i;
  }
  const m = Po[c], p = sr(h, m * a, l) / m;
  switch (c) {
    case "day":
      return { deltaDays: p, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 };
    case "hour":
      return ir(p, 0, 0, 0, 0, 0);
    case "minute":
      return ir(t, p, 0, 0, 0, 0);
    case "second":
      return ir(t, e, p, 0, 0, 0);
    case "millisecond":
      return ir(t, e, n, p, 0, 0);
    case "microsecond":
      return ir(t, e, n, r, p, 0);
    case "nanosecond":
      return ir(t, e, n, r, o, p);
    default:
      throw new Error(`Invalid unit ${c}`);
  }
}
function ds(t, e, n, r) {
  const o = Po[n];
  return t.round(y.BigInt(o * e), r);
}
function bi(t, e) {
  const n = Po[e];
  return t.fdiv(y.BigInt(n));
}
function Tn(t, e) {
  return t.year !== e.year ? xt(t.year - e.year) : t.month !== e.month ? xt(t.month - e.month) : t.day !== e.day ? xt(t.day - e.day) : 0;
}
function Ac(t, e) {
  return t.hour !== e.hour ? xt(t.hour - e.hour) : t.minute !== e.minute ? xt(t.minute - e.minute) : t.second !== e.second ? xt(t.second - e.second) : t.millisecond !== e.millisecond ? xt(t.millisecond - e.millisecond) : t.microsecond !== e.microsecond ? xt(t.microsecond - e.microsecond) : t.nanosecond !== e.nanosecond ? xt(t.nanosecond - e.nanosecond) : 0;
}
function Eo(t, e) {
  const n = Tn(t.isoDate, e.isoDate);
  return n !== 0 ? n : Ac(t.time, e.time);
}
function fp(t) {
  const e = hs(t);
  return globalThis.BigInt !== void 0 ? globalThis.BigInt(e.toString(10)) : e;
}
function rn(t, e) {
  const n = On(t), { quotient: r, remainder: o } = ri(n, Li);
  let i = y.toNumber(r);
  return e === "floor" && y.toNumber(o) < 0 && (i -= 1), e === "ceil" && y.toNumber(o) > 0 && (i += 1), i;
}
function yn(t) {
  if (!Number.isInteger(t)) throw new RangeError("epoch milliseconds must be an integer");
  return y.multiply(y.BigInt(t), Li);
}
function hs(t) {
  let e = t;
  if (typeof t == "object") {
    const n = t[Symbol.toPrimitive];
    n && typeof n == "function" && (e = n.call(t, "number"));
  }
  if (typeof e == "number") throw new TypeError("cannot convert number to bigint");
  return typeof e == "bigint" ? y.BigInt(e.toString(10)) : y.BigInt(e);
}
const Ec = (() => {
  let t = y.BigInt(Date.now() % 1e6);
  return () => {
    const e = Date.now(), n = y.BigInt(e), r = y.add(yn(e), t);
    return t = y.remainder(n, Li), y.greaterThan(r, To) ? To : y.lessThan(r, Ei) ? Ei : r;
  };
})();
function Jo() {
  return new Intl.DateTimeFormat().resolvedOptions().timeZone;
}
function xt(t) {
  return t < 0 ? -1 : t > 0 ? 1 : t;
}
function te(t) {
  if (t === void 0) return /* @__PURE__ */ Object.create(null);
  if (Le(t) && t !== null) return t;
  throw new TypeError("Options parameter must be an object, not " + (t === null ? "null" : typeof t));
}
function Kr(t, e) {
  const n = /* @__PURE__ */ Object.create(null);
  return n[t] = e, n;
}
function Zn(t, e, n, r) {
  let o = t[e];
  if (o !== void 0) {
    if (o = Ts(o), !n.includes(o)) throw new RangeError(`${e} must be one of ${n.join(", ")}, not ${o}`);
    return o;
  }
  if (r === Wn) throw new RangeError(`${e} option is required`);
  return r;
}
function Dt(t) {
  const e = xi(t);
  if (!X_.includes(xi(e))) throw new RangeError(`invalid calendar identifier ${e}`);
  switch (e) {
    case "ethiopic-amete-alem":
      return "ethioaa";
    case "islamicc":
      return "islamic-civil";
  }
  return e;
}
function xi(t) {
  let e = "";
  for (let n = 0; n < t.length; n++) {
    const r = t.charCodeAt(n);
    e += r >= 65 && r <= 90 ? String.fromCharCode(r + 32) : String.fromCharCode(r);
  }
  return e;
}
function vr(t) {
  throw new TypeError(`Do not use built-in arithmetic operators with Temporal objects. When comparing, use ${t === "PlainMonthDay" ? "Temporal.PlainDate.compare(obj1.toPlainDate(year), obj2.toPlainDate(year))" : `Temporal.${t}.compare(obj1, obj2)`}, not obj1 > obj2. When coercing to strings, use \`\${obj}\` or String(obj), not '' + obj. When coercing to numbers, use properties or methods of the object, not \`+obj\`. When concatenating with strings, use \`\${str}\${obj}\` or str.concat(obj), not str + obj. In React, coerce to a string before rendering a Temporal object.`);
}
const iT = new RegExp(`^${$m.source}$`), aT = new RegExp(`^${/([+-])([01][0-9]|2[0-3])(?::?([0-5][0-9])(?::?([0-5][0-9])(?:[.,](\d{1,9}))?)?)?/.source}$`);
function mp(t, e, n, r = t(e), o = t(n)) {
  let i = e, a = n, c = r, l = o;
  for (; a - i > 1; ) {
    let h = Math.trunc((i + a) / 2);
    const m = t(h);
    m === c ? (i = h, c = m) : m === l && (a = h, l = m);
  }
  return a;
}
function pp(t) {
  return [...t];
}
function gp(t, e) {
  if (t !== "gregory" && t !== "iso8601") return;
  const n = Qi[t];
  let r = e.year;
  const { dayOfWeek: o, dayOfYear: i, daysInYear: a } = n.isoToDate(e, { dayOfWeek: !0, dayOfYear: !0, daysInYear: !0 }), c = n.getFirstDayOfWeek(), l = n.getMinimalDaysInFirstWeek();
  let h = (o + 7 - c) % 7, m = (o - i + 7001 - c) % 7, p = Math.floor((i - 1 + m) / 7);
  if (7 - m >= l && ++p, p == 0) p = (function(v, k, P, A) {
    let S = (A - v - P + 1) % 7;
    S < 0 && (S += 7);
    let z = Math.floor((P + S - 1) / 7);
    return 7 - S >= k && ++z, z;
  })(c, l, i + n.isoToDate(n.dateAdd(e, { years: -1 }, "constrain"), { daysInYear: !0 }).daysInYear, o), r--;
  else if (i >= a - 5) {
    let v = (h + a - i) % 7;
    v < 0 && (v += 7), 6 - v >= l && i + 7 - h > a && (p = 1, r++);
  }
  return { week: p, year: r };
}
function Dh(t, e, n, r, o) {
  if (e !== o.year) {
    if (t * (e - o.year) > 0) return !0;
  } else if (n !== o.month) {
    if (t * (n - o.month) > 0) return !0;
  } else if (r !== o.day && t * (r - o.day) > 0) return !0;
  return !1;
}
const Qi = {};
function Wr(t) {
  if (!t.startsWith("M")) throw new RangeError(`Invalid month code: ${t}.  Month codes must start with M.`);
  const e = +t.slice(1);
  if (Number.isNaN(e)) throw new RangeError(`Invalid month code: ${t}`);
  return e;
}
function bn(t, e = !1) {
  return `M${`${t}`.padStart(2, "0")}${e ? "L" : ""}`;
}
function il(t, e = void 0, n = 12) {
  let { month: r, monthCode: o } = t;
  if (o === void 0) {
    if (r === void 0) throw new TypeError("Either month or monthCode are required");
    e === "reject" && Je(r, 1, n), e === "constrain" && (r = Ct(r, 1, n)), o = bn(r);
  } else {
    const i = Wr(o);
    if (o !== bn(i)) throw new RangeError(`Invalid month code: ${o}`);
    if (r !== void 0 && r !== i) throw new RangeError(`monthCode ${o} and month ${r} must match if both are present`);
    if (r = i, r < 1 || r > n) throw new RangeError(`Invalid monthCode: ${o}`);
  }
  return { ...t, month: r, monthCode: o };
}
Qi.iso8601 = { resolveFields(t, e) {
  if ((e === "date" || e === "year-month") && t.year === void 0) throw new TypeError("year is required");
  if ((e === "date" || e === "month-day") && t.day === void 0) throw new TypeError("day is required");
  Object.assign(t, il(t));
}, dateToISO: (t, e) => vi(t.year, t.month, t.day, e), monthDayToISOReferenceDate(t, e) {
  const { month: n, day: r } = vi(t.year ?? 1972, t.month, t.day, e);
  return { month: n, day: r, year: 1972 };
}, extraFields: () => [], fieldKeysToIgnore(t) {
  const e = /* @__PURE__ */ new Set();
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    e.add(r), r === "month" ? e.add("monthCode") : r === "monthCode" && e.add("month");
  }
  return pp(e);
}, dateAdd(t, { years: e = 0, months: n = 0, weeks: r = 0, days: o = 0 }, i) {
  let { year: a, month: c, day: l } = t;
  return a += e, c += n, { year: a, month: c } = $r(a, c), { year: a, month: c, day: l } = vi(a, c, l, i), l += o + 7 * r, $t(a, c, l);
}, dateUntil(t, e, n) {
  const r = -Tn(t, e);
  if (r === 0) return { years: 0, months: 0, weeks: 0, days: 0 };
  let o, i = 0, a = 0;
  if (n === "year" || n === "month") {
    let m = e.year - t.year;
    for (m !== 0 && (m -= r); !Dh(r, t.year + m, t.month, t.day, e); ) i = m, m += r;
    let p = r;
    for (o = $r(t.year + i, t.month + p); !Dh(r, o.year, o.month, t.day, e); ) a = p, p += r, o = $r(o.year, o.month + r);
    n === "month" && (a += 12 * i, i = 0);
  }
  o = $r(t.year + i, t.month + a);
  const c = ap(o.year, o.month, t.day);
  let l = 0, h = qr(e.year, e.month - 1, e.day) - qr(c.year, c.month - 1, c.day);
  return n === "week" && (l = Math.trunc(h / 7), h %= 7), { years: i, months: a, weeks: l, days: h };
}, isoToDate({ year: t, month: e, day: n }, r) {
  const o = { era: void 0, eraYear: void 0, year: t, month: e, day: n, daysInWeek: 7, monthsInYear: 12 };
  if (r.monthCode && (o.monthCode = bn(e)), r.dayOfWeek) {
    const i = e + (e < 3 ? 10 : -2), a = t - (e < 3 ? 1 : 0), c = Math.floor(a / 100), l = a - 100 * c, h = (n + Math.floor(2.6 * i - 0.2) + (l + Math.floor(l / 4)) + (Math.floor(c / 4) - 2 * c)) % 7;
    o.dayOfWeek = h + (h <= 0 ? 7 : 0);
  }
  if (r.dayOfYear) {
    let i = n;
    for (let a = e - 1; a > 0; a--) i += Lr(t, a);
    o.dayOfYear = i;
  }
  return r.weekOfYear && (o.weekOfYear = gp("iso8601", { year: t, month: e, day: n })), r.daysInMonth && (o.daysInMonth = Lr(t, e)), (r.daysInYear || r.inLeapYear) && (o.inLeapYear = cs(t), o.daysInYear = o.inLeapYear ? 366 : 365), o;
}, getFirstDayOfWeek: () => 1, getMinimalDaysInFirstWeek: () => 4 };
class Xe {
  constructor(e) {
    if (this.map = /* @__PURE__ */ new Map(), this.calls = 0, this.hits = 0, this.misses = 0, e !== void 0) {
      let n = 0;
      for (const r of e.map.entries()) {
        if (++n > Xe.MAX_CACHE_ENTRIES) break;
        this.map.set(...r);
      }
    }
  }
  get(e) {
    const n = this.map.get(e);
    return n && (this.hits++, this.report()), this.calls++, n;
  }
  set(e, n) {
    this.map.set(e, n), this.misses++, this.report();
  }
  report() {
  }
  setObject(e) {
    if (Xe.objectMap.get(e)) throw new RangeError("object already cached");
    Xe.objectMap.set(e, this), this.report();
  }
  static getCacheForObject(e) {
    let n = Xe.objectMap.get(e);
    return n || (n = new Xe(), Xe.objectMap.set(e, n)), n;
  }
}
function vp({ isoYear: t, isoMonth: e, isoDay: n }) {
  return `${Hi(t)}-${Kt(e)}-${Kt(n)}T00:00Z`;
}
function Uu(t, e) {
  return { years: t.year - e.year, months: t.month - e.month, days: t.day - e.day };
}
Xe.objectMap = /* @__PURE__ */ new WeakMap(), Xe.MAX_CACHE_ENTRIES = 1e3;
class Br {
  constructor() {
    this.eras = [], this.hasEra = !1, this.erasBeginMidYear = !1;
  }
  getFormatter() {
    return this.formatter === void 0 && (this.formatter = new Intl.DateTimeFormat(`en-US-u-ca-${this.id}`, { day: "numeric", month: "numeric", year: "numeric", era: "short", timeZone: "UTC" })), this.formatter;
  }
  getCalendarParts(e) {
    let n = this.getFormatter(), r = new Date(e);
    if (e === "-271821-04-19T00:00Z") {
      const o = n.resolvedOptions();
      n = new Intl.DateTimeFormat(o.locale, { ...o, timeZone: "Etc/GMT+1" }), r = /* @__PURE__ */ new Date("-271821-04-20T00:00Z");
    }
    try {
      return n.formatToParts(r);
    } catch {
      throw new RangeError(`Invalid ISO date: ${e}`);
    }
  }
  isoToCalendarDate(e, n) {
    const { year: r, month: o, day: i } = e, a = JSON.stringify({ func: "isoToCalendarDate", isoYear: r, isoMonth: o, isoDay: i, id: this.id }), c = n.get(a);
    if (c) return c;
    const l = vp({ isoYear: r, isoMonth: o, isoDay: i }), h = this.getCalendarParts(l), m = {};
    for (let v = 0; v < h.length; v++) {
      const { type: k, value: P } = h[v];
      if (k !== "year" && k !== "relatedYear" || (this.hasEra ? m.eraYear = +P : m.year = +P), k === "month") {
        const A = /^([0-9]*)(.*?)$/.exec(P);
        if (!A || A.length != 3 || !A[1] && !A[2]) throw new RangeError(`Unexpected month: ${P}`);
        if (m.month = A[1] ? +A[1] : 1, m.month < 1) throw new RangeError(`Invalid month ${P} from ${l}[u-ca-${this.id}] (probably due to https://bugs.chromium.org/p/v8/issues/detail?id=10527)`);
        if (m.month > 13) throw new RangeError(`Invalid month ${P} from ${l}[u-ca-${this.id}] (probably due to https://bugs.chromium.org/p/v8/issues/detail?id=10529)`);
        A[2] && (m.monthExtra = A[2]);
      }
      k === "day" && (m.day = +P), this.hasEra && k === "era" && P != null && P !== "" && (m.era = P.split(" (")[0].normalize("NFD").replace(/[^-0-9 \p{L}]/gu, "").replace(/ /g, "-").toLowerCase());
    }
    if (this.hasEra && m.eraYear === void 0) throw new RangeError(`Intl.DateTimeFormat.formatToParts lacks relatedYear in ${this.id} calendar. Try Node 14+ or modern browsers.`);
    if (this.hasEra) {
      const v = this.eras.find(((k) => m.era === k.genericName));
      v && (m.era = v.code);
    }
    if (this.reviseIntlEra) {
      const { era: v, eraYear: k } = this.reviseIntlEra(m, e);
      m.era = v, m.eraYear = k;
    }
    this.checkIcuBugs && this.checkIcuBugs(e);
    const p = this.adjustCalendarDate(m, n, "constrain", !0);
    if (p.year === void 0) throw new RangeError(`Missing year converting ${JSON.stringify(e)}`);
    if (p.month === void 0) throw new RangeError(`Missing month converting ${JSON.stringify(e)}`);
    if (p.day === void 0) throw new RangeError(`Missing day converting ${JSON.stringify(e)}`);
    return n.set(a, p), ["constrain", "reject"].forEach(((v) => {
      const k = JSON.stringify({ func: "calendarToIsoDate", year: p.year, month: p.month, day: p.day, overflow: v, id: this.id });
      n.set(k, e);
    })), p;
  }
  validateCalendarDate(e) {
    const { month: n, year: r, day: o, eraYear: i, monthCode: a, monthExtra: c } = e;
    if (c !== void 0) throw new RangeError("Unexpected `monthExtra` value");
    if (r === void 0 && i === void 0) throw new TypeError("year or eraYear is required");
    if (n === void 0 && a === void 0) throw new TypeError("month or monthCode is required");
    if (o === void 0) throw new RangeError("Missing day");
    if (a !== void 0) {
      if (typeof a != "string") throw new RangeError("monthCode must be a string, not " + typeof a);
      if (!/^M([01]?\d)(L?)$/.test(a)) throw new RangeError(`Invalid monthCode: ${a}`);
    }
    if (this.hasEra && e.era === void 0 != (e.eraYear === void 0)) throw new TypeError("properties era and eraYear must be provided together");
  }
  adjustCalendarDate(e, n = void 0, r = "constrain", o = !1) {
    if (this.calendarType === "lunisolar") throw new RangeError("Override required for lunisolar calendars");
    let i = e;
    this.validateCalendarDate(i);
    const a = this.monthsInYear(i, n);
    let { month: c, monthCode: l } = i;
    return { month: c, monthCode: l } = il(i, r, a), { ...i, month: c, monthCode: l };
  }
  regulateMonthDayNaive(e, n, r) {
    const o = this.monthsInYear(e, r);
    let { month: i, day: a } = e;
    return n === "reject" ? (Je(i, 1, o), Je(a, 1, this.maximumMonthLength(e))) : (i = Ct(i, 1, o), a = Ct(a, 1, this.maximumMonthLength({ ...e, month: i }))), { ...e, month: i, day: a };
  }
  calendarToIsoDate(e, n = "constrain", r) {
    const o = e;
    let i = this.adjustCalendarDate(e, r, n, !1);
    i = this.regulateMonthDayNaive(i, n, r);
    const { year: a, month: c, day: l } = i, h = JSON.stringify({ func: "calendarToIsoDate", year: a, month: c, day: l, overflow: n, id: this.id });
    let m, p = r.get(h);
    if (p || o.year !== void 0 && o.month !== void 0 && o.day !== void 0 && (o.year !== i.year || o.month !== i.month || o.day !== i.day) && (m = JSON.stringify({ func: "calendarToIsoDate", year: o.year, month: o.month, day: o.day, overflow: n, id: this.id }), p = r.get(m), p)) return p;
    let v = this.estimateIsoDate({ year: a, month: c, day: l });
    const k = (L) => {
      let W = this.addDaysIso(v, L);
      if (i.day > this.minimumMonthLength(i)) {
        let H = this.isoToCalendarDate(W, r);
        for (; H.month !== c || H.year !== a; ) {
          if (n === "reject") throw new RangeError(`day ${l} does not exist in month ${c} of year ${a}`);
          W = this.addDaysIso(W, -1), H = this.isoToCalendarDate(W, r);
        }
      }
      return W;
    };
    let P = 0, A = this.isoToCalendarDate(v, r), S = Uu(i, A);
    if (S.years !== 0 || S.months !== 0 || S.days !== 0) {
      const L = 365 * S.years + 30 * S.months + S.days;
      v = this.addDaysIso(v, L), A = this.isoToCalendarDate(v, r), S = Uu(i, A), S.years === 0 && S.months === 0 ? v = k(S.days) : P = this.compareCalendarDates(i, A);
    }
    let z = 8;
    for (; P; ) {
      v = this.addDaysIso(v, P * z);
      const L = A;
      A = this.isoToCalendarDate(v, r);
      const W = P;
      if (P = this.compareCalendarDates(i, A), P) {
        if (S = Uu(i, A), S.years === 0 && S.months === 0) v = k(S.days), P = 0;
        else if (W && P !== W) if (z > 1) z /= 2;
        else {
          if (n === "reject") throw new RangeError(`Can't find ISO date from calendar date: ${JSON.stringify({ ...o })}`);
          this.compareCalendarDates(A, L) > 0 && (v = this.addDaysIso(v, -1)), P = 0;
        }
      }
    }
    if (r.set(h, v), m && r.set(m, v), i.year === void 0 || i.month === void 0 || i.day === void 0 || i.monthCode === void 0 || this.hasEra && (i.era === void 0 || i.eraYear === void 0)) throw new RangeError("Unexpected missing property");
    return v;
  }
  compareCalendarDates(e, n) {
    return e.year !== n.year ? xt(e.year - n.year) : e.month !== n.month ? xt(e.month - n.month) : e.day !== n.day ? xt(e.day - n.day) : 0;
  }
  regulateDate(e, n = "constrain", r) {
    const o = this.calendarToIsoDate(e, n, r);
    return this.isoToCalendarDate(o, r);
  }
  addDaysIso(e, n) {
    return $t(e.year, e.month, e.day + n);
  }
  addDaysCalendar(e, n, r) {
    const o = this.calendarToIsoDate(e, "constrain", r), i = this.addDaysIso(o, n);
    return this.isoToCalendarDate(i, r);
  }
  addMonthsCalendar(e, n, r, o) {
    let i = e;
    const { day: a } = i;
    for (let c = 0, l = Math.abs(n); c < l; c++) {
      const { month: h } = i, m = i, p = n < 0 ? -Math.max(a, this.daysInPreviousMonth(i, o)) : this.daysInMonth(i, o), v = this.calendarToIsoDate(i, "constrain", o);
      let k = this.addDaysIso(v, p);
      if (i = this.isoToCalendarDate(k, o), n > 0) {
        const P = this.monthsInYear(m, o);
        for (; i.month - 1 != h % P; ) k = this.addDaysIso(k, -1), i = this.isoToCalendarDate(k, o);
      }
      i.day !== a && (i = this.regulateDate({ ...i, day: a }, "constrain", o));
    }
    if (r === "reject" && i.day !== a) throw new RangeError(`Day ${a} does not exist in resulting calendar month`);
    return i;
  }
  addCalendar(e, { years: n = 0, months: r = 0, weeks: o = 0, days: i = 0 }, a, c) {
    const { year: l, day: h, monthCode: m } = e, p = this.adjustCalendarDate({ year: l + n, monthCode: m, day: h }, c), v = this.addMonthsCalendar(p, r, a, c), k = i + 7 * o;
    return this.addDaysCalendar(v, k, c);
  }
  untilCalendar(e, n, r, o) {
    let i = 0, a = 0, c = 0, l = 0;
    switch (r) {
      case "day":
        i = this.calendarDaysUntil(e, n, o);
        break;
      case "week": {
        const h = this.calendarDaysUntil(e, n, o);
        i = h % 7, a = (h - i) / 7;
        break;
      }
      case "month":
      case "year": {
        const h = this.compareCalendarDates(n, e);
        if (!h) return { years: 0, months: 0, weeks: 0, days: 0 };
        const m = n.year - e.year, p = n.day - e.day;
        if (r === "year" && m) {
          let P = 0;
          n.monthCode > e.monthCode && (P = 1), n.monthCode < e.monthCode && (P = -1), P || (P = Math.sign(p)), l = P * h < 0 ? m - h : m;
        }
        let v, k = l ? this.addCalendar(e, { years: l }, "constrain", o) : e;
        do
          c += h, v = k, k = this.addMonthsCalendar(v, h, "constrain", o), k.day !== e.day && (k = this.regulateDate({ ...k, day: e.day }, "constrain", o));
        while (this.compareCalendarDates(n, k) * h >= 0);
        c -= h, i = this.calendarDaysUntil(v, n, o);
        break;
      }
    }
    return { years: l, months: c, weeks: a, days: i };
  }
  daysInMonth(e, n) {
    const { day: r } = e, o = this.maximumMonthLength(e), i = this.minimumMonthLength(e);
    if (i === o) return i;
    const a = r <= o - i ? o : i, c = this.calendarToIsoDate(e, "constrain", n), l = this.addDaysIso(c, a), h = this.isoToCalendarDate(l, n), m = this.addDaysIso(l, -h.day);
    return this.isoToCalendarDate(m, n).day;
  }
  daysInPreviousMonth(e, n) {
    const { day: r, month: o, year: i } = e;
    let a = { year: o > 1 ? i : i - 1, month: o, day: 1 };
    const c = o > 1 ? o - 1 : this.monthsInYear(a, n);
    a = { ...a, month: c };
    const l = this.minimumMonthLength(a), h = this.maximumMonthLength(a);
    if (l === h) return h;
    const m = this.calendarToIsoDate(e, "constrain", n), p = this.addDaysIso(m, -r);
    return this.isoToCalendarDate(p, n).day;
  }
  startOfCalendarYear(e) {
    return { year: e.year, month: 1, monthCode: "M01", day: 1 };
  }
  startOfCalendarMonth(e) {
    return { year: e.year, month: e.month, day: 1 };
  }
  calendarDaysUntil(e, n, r) {
    const o = this.calendarToIsoDate(e, "constrain", r), i = this.calendarToIsoDate(n, "constrain", r);
    return qr(i.year, i.month - 1, i.day) - qr(o.year, o.month - 1, o.day);
  }
  monthDaySearchStartYear(e, n) {
    return 1972;
  }
  monthDayFromFields(e, n, r) {
    let o, i, a, c, l, { era: h, eraYear: m, year: p, month: v, monthCode: k, day: P } = e;
    if (v !== void 0 && p === void 0 && (!this.hasEra || h === void 0 || m === void 0)) throw new TypeError("when month is present, year (or era and eraYear) are required");
    (k === void 0 || p !== void 0 || this.hasEra && m !== void 0) && ({ monthCode: k, day: P } = this.isoToCalendarDate(this.calendarToIsoDate(e, n, r), r));
    const A = { year: this.monthDaySearchStartYear(k, P), month: 12, day: 31 }, S = this.isoToCalendarDate(A, r), z = S.monthCode > k || S.monthCode === k && S.day >= P ? S.year : S.year - 1;
    for (let L = 0; L < 20; L++) {
      const W = this.adjustCalendarDate({ day: P, monthCode: k, year: z - L }, r), H = this.calendarToIsoDate(W, "constrain", r), re = this.isoToCalendarDate(H, r);
      if ({ year: o, month: i, day: a } = H, re.monthCode === k && re.day === P) return { month: i, day: a, year: o };
      if (n === "constrain") {
        const Ee = this.maxLengthOfMonthCodeInAnyYear(re.monthCode);
        if (re.monthCode === k && re.day === Ee && P > Ee) return { month: i, day: a, year: o };
        (c === void 0 || re.monthCode === c.monthCode && re.day > c.day) && (c = re, l = H);
      }
    }
    if (n === "constrain" && l !== void 0) return l;
    throw new RangeError(`No recent ${this.id} year with monthCode ${k} and day ${P}`);
  }
  getFirstDayOfWeek() {
  }
  getMinimalDaysInFirstWeek() {
  }
}
class sT extends Br {
  constructor() {
    super(...arguments), this.id = "hebrew", this.calendarType = "lunisolar", this.months = { Tishri: { leap: 1, regular: 1, monthCode: "M01", days: 30 }, Heshvan: { leap: 2, regular: 2, monthCode: "M02", days: { min: 29, max: 30 } }, Kislev: { leap: 3, regular: 3, monthCode: "M03", days: { min: 29, max: 30 } }, Tevet: { leap: 4, regular: 4, monthCode: "M04", days: 29 }, Shevat: { leap: 5, regular: 5, monthCode: "M05", days: 30 }, Adar: { leap: void 0, regular: 6, monthCode: "M06", days: 29 }, "Adar I": { leap: 6, regular: void 0, monthCode: "M05L", days: 30 }, "Adar II": { leap: 7, regular: void 0, monthCode: "M06", days: 29 }, Nisan: { leap: 8, regular: 7, monthCode: "M07", days: 30 }, Iyar: { leap: 9, regular: 8, monthCode: "M08", days: 29 }, Sivan: { leap: 10, regular: 9, monthCode: "M09", days: 30 }, Tamuz: { leap: 11, regular: 10, monthCode: "M10", days: 29 }, Av: { leap: 12, regular: 11, monthCode: "M11", days: 30 }, Elul: { leap: 13, regular: 12, monthCode: "M12", days: 29 } };
  }
  inLeapYear(e) {
    const { year: n } = e;
    return (7 * n + 1) % 19 < 7;
  }
  monthsInYear(e) {
    return this.inLeapYear(e) ? 13 : 12;
  }
  minimumMonthLength(e) {
    return this.minMaxMonthLength(e, "min");
  }
  maximumMonthLength(e) {
    return this.minMaxMonthLength(e, "max");
  }
  minMaxMonthLength(e, n) {
    const { month: r, year: o } = e, i = this.getMonthCode(o, r), a = Object.entries(this.months).find(((l) => l[1].monthCode === i));
    if (a === void 0) throw new RangeError(`unmatched Hebrew month: ${r}`);
    const c = a[1].days;
    return typeof c == "number" ? c : c[n];
  }
  maxLengthOfMonthCodeInAnyYear(e) {
    return ["M04", "M06", "M08", "M10", "M12"].includes(e) ? 29 : 30;
  }
  estimateIsoDate(e) {
    const { year: n } = e;
    return { year: n - 3760, month: 1, day: 1 };
  }
  getMonthCode(e, n) {
    return this.inLeapYear({ year: e }) ? n === 6 ? bn(5, !0) : bn(n < 6 ? n : n - 1) : bn(n);
  }
  adjustCalendarDate(e, n, r = "constrain", o = !1) {
    let { year: i, month: a, monthCode: c, day: l, monthExtra: h } = e;
    if (i === void 0) throw new TypeError("Missing property: year");
    if (o) {
      if (h) {
        const m = this.months[h];
        if (!m) throw new RangeError(`Unrecognized month from formatToParts: ${h}`);
        a = this.inLeapYear({ year: i }) ? m.leap : m.regular;
      }
      return c = this.getMonthCode(i, a), { year: i, month: a, day: l, monthCode: c };
    }
    if (this.validateCalendarDate(e), a === void 0) if (c.endsWith("L")) {
      if (c !== "M05L") throw new RangeError(`Hebrew leap month must have monthCode M05L, not ${c}`);
      if (a = 6, !this.inLeapYear({ year: i })) {
        if (r === "reject") throw new RangeError(`Hebrew monthCode M05L is invalid in year ${i} which is not a leap year`);
        a = 6, c = "M06";
      }
    } else {
      a = Wr(c), this.inLeapYear({ year: i }) && a >= 6 && a++;
      const m = this.monthsInYear({ year: i });
      if (a < 1 || a > m) throw new RangeError(`Invalid monthCode: ${c}`);
    }
    else if (r === "reject" ? (Je(a, 1, this.monthsInYear({ year: i })), Je(l, 1, this.maximumMonthLength({ year: i, month: a }))) : (a = Ct(a, 1, this.monthsInYear({ year: i })), l = Ct(l, 1, this.maximumMonthLength({ year: i, month: a }))), c === void 0) c = this.getMonthCode(i, a);
    else if (this.getMonthCode(i, a) !== c) throw new RangeError(`monthCode ${c} doesn't correspond to month ${a} in Hebrew year ${i}`);
    return { ...e, day: l, month: a, monthCode: c, year: i };
  }
}
class No extends Br {
  constructor() {
    super(...arguments), this.calendarType = "lunar", this.DAYS_PER_ISLAMIC_YEAR = 354 + 11 / 30, this.DAYS_PER_ISO_YEAR = 365.2425;
  }
  inLeapYear(e, n) {
    const r = { year: e.year, month: 1, monthCode: "M01", day: 1 }, o = { year: e.year + 1, month: 1, monthCode: "M01", day: 1 };
    return this.calendarDaysUntil(r, o, n) === 355;
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength() {
    return 29;
  }
  maximumMonthLength() {
    return 30;
  }
  maxLengthOfMonthCodeInAnyYear() {
    return 30;
  }
  estimateIsoDate(e) {
    const { year: n } = this.adjustCalendarDate(e);
    return { year: Math.floor(n * this.DAYS_PER_ISLAMIC_YEAR / this.DAYS_PER_ISO_YEAR) + 622, month: 1, day: 1 };
  }
}
class uT extends No {
  constructor() {
    super(...arguments), this.id = "islamic";
  }
}
class cT extends No {
  constructor() {
    super(...arguments), this.id = "islamic-umalqura";
  }
}
class lT extends No {
  constructor() {
    super(...arguments), this.id = "islamic-tbla";
  }
}
class dT extends No {
  constructor() {
    super(...arguments), this.id = "islamic-civil";
  }
}
class hT extends No {
  constructor() {
    super(...arguments), this.id = "islamic-rgsa";
  }
}
class fT extends No {
  constructor() {
    super(...arguments), this.id = "islamicc";
  }
}
class mT extends Br {
  constructor() {
    super(...arguments), this.id = "persian", this.calendarType = "solar";
  }
  inLeapYear(e, n) {
    return this.daysInMonth({ year: e.year, month: 12, day: 1 }, n) === 30;
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e) {
    const { month: n } = e;
    return n === 12 ? 29 : n <= 6 ? 31 : 30;
  }
  maximumMonthLength(e) {
    const { month: n } = e;
    return n === 12 ? 30 : n <= 6 ? 31 : 30;
  }
  maxLengthOfMonthCodeInAnyYear(e) {
    return Wr(e) <= 6 ? 31 : 30;
  }
  estimateIsoDate(e) {
    const { year: n } = this.adjustCalendarDate(e);
    return { year: n + 621, month: 1, day: 1 };
  }
}
class pT extends Br {
  constructor() {
    super(...arguments), this.id = "indian", this.calendarType = "solar", this.months = { 1: { length: 30, month: 3, day: 22, leap: { length: 31, month: 3, day: 21 } }, 2: { length: 31, month: 4, day: 21 }, 3: { length: 31, month: 5, day: 22 }, 4: { length: 31, month: 6, day: 22 }, 5: { length: 31, month: 7, day: 23 }, 6: { length: 31, month: 8, day: 23 }, 7: { length: 30, month: 9, day: 23 }, 8: { length: 30, month: 10, day: 23 }, 9: { length: 30, month: 11, day: 22 }, 10: { length: 30, month: 12, day: 22 }, 11: { length: 30, month: 1, nextYear: !0, day: 21 }, 12: { length: 30, month: 2, nextYear: !0, day: 20 } }, this.vulnerableToBceBug = (/* @__PURE__ */ new Date("0000-01-01T00:00Z")).toLocaleDateString("en-US-u-ca-indian", { timeZone: "UTC" }) !== "10/11/-79 Saka";
  }
  inLeapYear(e) {
    return al(e.year + 78);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e) {
    return this.getMonthInfo(e).length;
  }
  maximumMonthLength(e) {
    return this.getMonthInfo(e).length;
  }
  maxLengthOfMonthCodeInAnyYear(e) {
    const n = Wr(e);
    let r = this.months[n];
    return r = r.leap ?? r, r.length;
  }
  getMonthInfo(e) {
    const { month: n } = e;
    let r = this.months[n];
    if (r === void 0) throw new RangeError(`Invalid month: ${n}`);
    return this.inLeapYear(e) && r.leap && (r = r.leap), r;
  }
  estimateIsoDate(e) {
    const n = this.adjustCalendarDate(e), r = this.getMonthInfo(n);
    return $t(n.year + 78 + (r.nextYear ? 1 : 0), r.month, r.day + n.day - 1);
  }
  checkIcuBugs(e) {
    if (this.vulnerableToBceBug && e.year < 1) throw new RangeError(`calendar '${this.id}' is broken for ISO dates before 0001-01-01 (see https://bugs.chromium.org/p/v8/issues/detail?id=10529)`);
  }
}
function al(t) {
  return t % 4 == 0 && (t % 100 != 0 || t % 400 == 0);
}
class yp extends Br {
  constructor(e, n) {
    super(), this.calendarType = "solar", this.id = e, this.isoEpoch = n;
  }
  inLeapYear(e) {
    const { year: n } = this.estimateIsoDate({ month: 1, day: 1, year: e.year });
    return al(n);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e) {
    const { month: n } = e;
    return n === 2 ? this.inLeapYear(e) ? 29 : 28 : [4, 6, 9, 11].indexOf(n) >= 0 ? 30 : 31;
  }
  maximumMonthLength(e) {
    return this.minimumMonthLength(e);
  }
  maxLengthOfMonthCodeInAnyYear(e) {
    return [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][Wr(e) - 1];
  }
  estimateIsoDate(e) {
    const n = this.adjustCalendarDate(e);
    return vi(n.year + this.isoEpoch.year, n.month + this.isoEpoch.month, n.day + this.isoEpoch.day, "constrain");
  }
}
class bp extends Br {
  constructor(e, n) {
    super(), this.hasEra = !0, this.calendarType = "solar", this.id = e;
    const { eras: r, anchorEra: o } = (function(i) {
      let a, c = i;
      if (c.length === 0) throw new RangeError("Invalid era data: eras are required");
      if (c.length === 1 && c[0].reverseOf) throw new RangeError("Invalid era data: anchor era cannot count years backwards");
      if (c.length === 1 && !c[0].code) throw new RangeError("Invalid era data: at least one named era is required");
      if (c.filter(((h) => h.reverseOf != null)).length > 1) throw new RangeError("Invalid era data: only one era can count years backwards");
      c.forEach(((h) => {
        if (h.isAnchor || !h.anchorEpoch && !h.reverseOf) {
          if (a) throw new RangeError("Invalid era data: cannot have multiple anchor eras");
          a = h, h.anchorEpoch = { year: h.hasYearZero ? 0 : 1 };
        } else if (!h.code) throw new RangeError("If era name is blank, it must be the anchor era");
      })), c = c.filter(((h) => h.code)), c.forEach(((h) => {
        const { reverseOf: m } = h;
        if (m) {
          const p = c.find(((v) => v.code === m));
          if (p === void 0) throw new RangeError(`Invalid era data: unmatched reverseOf era: ${m}`);
          h.reverseOf = p, h.anchorEpoch = p.anchorEpoch, h.isoEpoch = p.isoEpoch;
        }
        h.anchorEpoch.month === void 0 && (h.anchorEpoch.month = 1), h.anchorEpoch.day === void 0 && (h.anchorEpoch.day = 1);
      })), c.sort(((h, m) => {
        if (h.reverseOf) return 1;
        if (m.reverseOf) return -1;
        if (!h.isoEpoch || !m.isoEpoch) throw new RangeError("Invalid era data: missing ISO epoch");
        return m.isoEpoch.year - h.isoEpoch.year;
      }));
      const l = c[c.length - 1].reverseOf;
      if (l && l !== c[c.length - 2]) throw new RangeError("Invalid era data: invalid reverse-sign era");
      return c.forEach(((h, m) => {
        h.genericName = "era" + (c.length - 1 - m);
      })), { eras: c, anchorEra: a || c[0] };
    })(n);
    this.anchorEra = o, this.eras = r;
  }
  inLeapYear(e) {
    const { year: n } = this.estimateIsoDate({ month: 1, day: 1, year: e.year });
    return al(n);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e) {
    const { month: n } = e;
    return n === 2 ? this.inLeapYear(e) ? 29 : 28 : [4, 6, 9, 11].indexOf(n) >= 0 ? 30 : 31;
  }
  maximumMonthLength(e) {
    return this.minimumMonthLength(e);
  }
  maxLengthOfMonthCodeInAnyYear(e) {
    return [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][Wr(e) - 1];
  }
  completeEraYear(e) {
    const n = (c, l, h) => {
      const m = e[c];
      if (m != null && m != l && !(h || []).includes(m)) {
        const p = h == null ? void 0 : h[0];
        throw new RangeError(`Input ${c} ${m} doesn't match calculated value ${p ? `${l} (also called ${p})` : l}`);
      }
    }, r = (c) => {
      let l;
      const h = { ...e, year: c }, m = this.eras.find(((p, v) => {
        if (v === this.eras.length - 1) {
          if (p.reverseOf) {
            if (c > 0) throw new RangeError(`Signed year ${c} is invalid for era ${p.code}`);
            return l = p.anchorEpoch.year - c, !0;
          }
          return l = c - p.anchorEpoch.year + (p.hasYearZero ? 0 : 1), !0;
        }
        return this.compareCalendarDates(h, p.anchorEpoch) >= 0 && (l = c - p.anchorEpoch.year + (p.hasYearZero ? 0 : 1), !0);
      }));
      if (!m) throw new RangeError(`Year ${c} was not matched by any era`);
      return { eraYear: l, era: m.code, eraNames: m.names };
    };
    let { year: o, eraYear: i, era: a } = e;
    if (o != null) {
      const c = r(o);
      ({ eraYear: i, era: a } = c), n("era", a, c == null ? void 0 : c.eraNames), n("eraYear", i);
    } else {
      if (i == null) throw new RangeError("Either year or eraYear and era are required");
      {
        if (a === void 0) throw new RangeError("era and eraYear must be provided together");
        const c = this.eras.find((({ code: l, names: h = [] }) => l === a || h.includes(a)));
        if (!c) throw new RangeError(`Era ${a} (ISO year ${i}) was not matched by any era`);
        o = c.reverseOf ? c.anchorEpoch.year - i : i + c.anchorEpoch.year - (c.hasYearZero ? 0 : 1), n("year", o), { eraYear: i, era: a } = r(o);
      }
    }
    return { ...e, year: o, eraYear: i, era: a };
  }
  adjustCalendarDate(e, n, r = "constrain") {
    let o = e;
    const { month: i, monthCode: a } = o;
    return i === void 0 && (o = { ...o, month: Wr(a) }), this.validateCalendarDate(o), o = this.completeEraYear(o), super.adjustCalendarDate(o, n, r);
  }
  estimateIsoDate(e) {
    const n = this.adjustCalendarDate(e), { year: r, month: o, day: i } = n, { anchorEra: a } = this;
    return vi(r + a.isoEpoch.year - (a.hasYearZero ? 0 : 1), o, i, "constrain");
  }
}
class sl extends bp {
  constructor(e, n) {
    super(e, n);
  }
  isoToCalendarDate(e) {
    const { year: n, month: r, day: o } = e, i = bn(r), a = n - this.anchorEra.isoEpoch.year + 1;
    return this.completeEraYear({ year: a, month: r, monthCode: i, day: o });
  }
}
const pn = { inLeapYear(t) {
  const { year: e } = t;
  return (e + 1) % 4 == 0;
}, monthsInYear: () => 13, minimumMonthLength(t) {
  const { month: e } = t;
  return e === 13 ? this.inLeapYear(t) ? 6 : 5 : 30;
}, maximumMonthLength(t) {
  return this.minimumMonthLength(t);
}, maxLengthOfMonthCodeInAnyYear: (t) => t === "M13" ? 6 : 30 };
class gT extends yp {
  constructor(e, n) {
    super(e, n), this.inLeapYear = pn.inLeapYear, this.monthsInYear = pn.monthsInYear, this.minimumMonthLength = pn.minimumMonthLength, this.maximumMonthLength = pn.maximumMonthLength, this.maxLengthOfMonthCodeInAnyYear = pn.maxLengthOfMonthCodeInAnyYear;
  }
}
class wp extends bp {
  constructor(e, n) {
    super(e, n), this.inLeapYear = pn.inLeapYear, this.monthsInYear = pn.monthsInYear, this.minimumMonthLength = pn.minimumMonthLength, this.maximumMonthLength = pn.maximumMonthLength, this.maxLengthOfMonthCodeInAnyYear = pn.maxLengthOfMonthCodeInAnyYear;
  }
}
class vT extends gT {
  constructor() {
    super("ethioaa", { year: -5492, month: 7, day: 17 });
  }
}
class yT extends wp {
  constructor() {
    super("coptic", [{ code: "coptic", isoEpoch: { year: 284, month: 8, day: 29 } }, { code: "coptic-inverse", reverseOf: "coptic" }]);
  }
}
class bT extends wp {
  constructor() {
    super("ethiopic", [{ code: "ethioaa", names: ["ethiopic-amete-alem", "mundi"], isoEpoch: { year: -5492, month: 7, day: 17 } }, { code: "ethiopic", names: ["incar"], isoEpoch: { year: 8, month: 8, day: 27 }, anchorEpoch: { year: 5501 } }]);
  }
}
class wT extends sl {
  constructor() {
    super("roc", [{ code: "roc", names: ["minguo"], isoEpoch: { year: 1912, month: 1, day: 1 } }, { code: "roc-inverse", names: ["before-roc"], reverseOf: "roc" }]);
  }
}
class kT extends yp {
  constructor() {
    super("buddhist", { year: -543, month: 1, day: 1 });
  }
}
class _T extends sl {
  constructor() {
    super("gregory", [{ code: "gregory", names: ["ad", "ce"], isoEpoch: { year: 1, month: 1, day: 1 } }, { code: "gregory-inverse", names: ["be", "bce"], reverseOf: "gregory" }]);
  }
  reviseIntlEra(e) {
    let { era: n, eraYear: r } = e;
    return n === "b" && (n = "gregory-inverse"), n === "a" && (n = "gregory"), { era: n, eraYear: r };
  }
  getFirstDayOfWeek() {
    return 1;
  }
  getMinimalDaysInFirstWeek() {
    return 1;
  }
}
class TT extends sl {
  constructor() {
    super("japanese", [{ code: "reiwa", isoEpoch: { year: 2019, month: 5, day: 1 }, anchorEpoch: { year: 2019, month: 5, day: 1 } }, { code: "heisei", isoEpoch: { year: 1989, month: 1, day: 8 }, anchorEpoch: { year: 1989, month: 1, day: 8 } }, { code: "showa", isoEpoch: { year: 1926, month: 12, day: 25 }, anchorEpoch: { year: 1926, month: 12, day: 25 } }, { code: "taisho", isoEpoch: { year: 1912, month: 7, day: 30 }, anchorEpoch: { year: 1912, month: 7, day: 30 } }, { code: "meiji", isoEpoch: { year: 1868, month: 9, day: 8 }, anchorEpoch: { year: 1868, month: 9, day: 8 } }, { code: "japanese", names: ["japanese", "gregory", "ad", "ce"], isoEpoch: { year: 1, month: 1, day: 1 } }, { code: "japanese-inverse", names: ["japanese-inverse", "gregory-inverse", "bc", "bce"], reverseOf: "japanese" }]), this.erasBeginMidYear = !0;
  }
  reviseIntlEra(e, n) {
    const { era: r, eraYear: o } = e, { year: i } = n;
    return this.eras.find(((a) => a.code === r)) ? { era: r, eraYear: o } : i < 1 ? { era: "japanese-inverse", eraYear: 1 - i } : { era: "japanese", eraYear: i };
  }
}
class kp extends Br {
  constructor() {
    super(...arguments), this.calendarType = "lunisolar";
  }
  inLeapYear(e, n) {
    const r = this.getMonthList(e.year, n);
    return Object.entries(r).length === 13;
  }
  monthsInYear(e, n) {
    return this.inLeapYear(e, n) ? 13 : 12;
  }
  minimumMonthLength() {
    return 29;
  }
  maximumMonthLength() {
    return 30;
  }
  maxLengthOfMonthCodeInAnyYear(e) {
    return ["M01L", "M09L", "M10L", "M11L", "M12L"].includes(e) ? 29 : 30;
  }
  monthDaySearchStartYear(e, n) {
    const r = { M01L: [1651, 1651], M02L: [1947, 1765], M03L: [1966, 1955], M04L: [1963, 1944], M05L: [1971, 1952], M06L: [1960, 1941], M07L: [1968, 1938], M08L: [1957, 1718], M09L: [1832, 1832], M10L: [1870, 1870], M11L: [1814, 1814], M12L: [1890, 1890] }[e] ?? [1972, 1972];
    return n < 30 ? r[0] : r[1];
  }
  getMonthList(e, n) {
    if (e === void 0) throw new TypeError("Missing year");
    const r = JSON.stringify({ func: "getMonthList", calendarYear: e, id: this.id }), o = n.get(r);
    if (o) return o;
    const i = this.getFormatter(), a = (S, z) => {
      const L = vp({ isoYear: S, isoMonth: 2, isoDay: 1 }), W = new Date(L);
      W.setUTCDate(z + 1);
      const H = i.formatToParts(W), re = H.find(((he) => he.type === "month")).value, Ee = +H.find(((he) => he.type === "day")).value, ye = H.find(((he) => he.type === "relatedYear"));
      let ue;
      if (ye === void 0) throw new RangeError(`Intl.DateTimeFormat.formatToParts lacks relatedYear in ${this.id} calendar. Try Node 14+ or modern browsers.`);
      return ue = +ye.value, { calendarMonthString: re, calendarDay: Ee, calendarYearToVerify: ue };
    };
    let c = 17, { calendarMonthString: l, calendarDay: h, calendarYearToVerify: m } = a(e, c);
    l !== "1" && (c += 29, { calendarMonthString: l, calendarDay: h } = a(e, c)), c -= h - 5;
    const p = {};
    let v, k, P = 1, A = !1;
    do
      ({ calendarMonthString: l, calendarDay: h, calendarYearToVerify: m } = a(e, c)), v && (p[k].daysInMonth = v + 30 - h), m !== e ? A = !0 : (p[l] = { monthIndex: P++ }, c += 30), v = h, k = l;
    while (!A);
    return p[k].daysInMonth = v + 30 - h, n.set(r, p), p;
  }
  estimateIsoDate(e) {
    const { year: n, month: r } = e;
    return { year: n, month: r >= 12 ? 12 : r + 1, day: 1 };
  }
  adjustCalendarDate(e, n, r = "constrain", o = !1) {
    let { year: i, month: a, monthExtra: c, day: l, monthCode: h } = e;
    if (i === void 0) throw new TypeError("Missing property: year");
    if (o) {
      if (c && c !== "bis") throw new RangeError(`Unexpected leap month suffix: ${c}`);
      const m = bn(a, c !== void 0), p = `${a}${c || ""}`, v = this.getMonthList(i, n)[p];
      if (v === void 0) throw new RangeError(`Unmatched month ${p} in Chinese year ${i}`);
      return a = v.monthIndex, { year: i, month: a, day: l, monthCode: m };
    }
    if (this.validateCalendarDate(e), a === void 0) {
      const m = this.getMonthList(i, n);
      let p = h.replace(/^M|L$/g, ((k) => k === "L" ? "bis" : ""));
      p[0] === "0" && (p = p.slice(1));
      let v = m[p];
      if (a = v && v.monthIndex, a === void 0 && h.endsWith("L") && h != "M13L" && r === "constrain") {
        const k = +h.replace(/^M0?|L$/g, "");
        v = m[k], v && (a = v.monthIndex, h = bn(k));
      }
      if (a === void 0) throw new RangeError(`Unmatched month ${h} in Chinese year ${i}`);
    } else if (h === void 0) {
      const m = this.getMonthList(i, n), p = Object.entries(m), v = p.length;
      r === "reject" ? (Je(a, 1, v), Je(l, 1, this.maximumMonthLength())) : (a = Ct(a, 1, v), l = Ct(l, 1, this.maximumMonthLength()));
      const k = p.find(((P) => P[1].monthIndex === a));
      if (k === void 0) throw new RangeError(`Invalid month ${a} in Chinese year ${i}`);
      h = bn(+k[0].replace("bis", ""), k[0].indexOf("bis") !== -1);
    } else {
      const m = this.getMonthList(i, n);
      let p = h.replace(/^M|L$/g, ((k) => k === "L" ? "bis" : ""));
      p[0] === "0" && (p = p.slice(1));
      const v = m[p];
      if (!v) throw new RangeError(`Unmatched monthCode ${h} in Chinese year ${i}`);
      if (a !== v.monthIndex) throw new RangeError(`monthCode ${h} doesn't correspond to month ${a} in Chinese year ${i}`);
    }
    return { ...e, year: i, month: a, monthCode: h, day: l };
  }
}
class CT extends kp {
  constructor() {
    super(...arguments), this.id = "chinese";
  }
}
class PT extends kp {
  constructor() {
    super(...arguments), this.id = "dangi";
  }
}
class AT {
  constructor(e) {
    this.helper = e;
  }
  extraFields(e) {
    return this.helper.hasEra && e.includes("year") ? ["era", "eraYear"] : [];
  }
  resolveFields(e) {
    if (this.helper.calendarType !== "lunisolar") {
      const n = new Xe();
      il(e, void 0, this.helper.monthsInYear({ year: e.year ?? 1972 }, n));
    }
  }
  dateToISO(e, n) {
    const r = new Xe(), o = this.helper.calendarToIsoDate(e, n, r);
    return r.setObject(o), o;
  }
  monthDayToISOReferenceDate(e, n) {
    const r = new Xe(), o = this.helper.monthDayFromFields(e, n, r);
    return r.setObject(o), o;
  }
  fieldKeysToIgnore(e) {
    const n = /* @__PURE__ */ new Set();
    for (let r = 0; r < e.length; r++) {
      const o = e[r];
      switch (n.add(o), o) {
        case "era":
          n.add("eraYear"), n.add("year");
          break;
        case "eraYear":
          n.add("era"), n.add("year");
          break;
        case "year":
          n.add("era"), n.add("eraYear");
          break;
        case "month":
          n.add("monthCode"), this.helper.erasBeginMidYear && (n.add("era"), n.add("eraYear"));
          break;
        case "monthCode":
          n.add("month"), this.helper.erasBeginMidYear && (n.add("era"), n.add("eraYear"));
          break;
        case "day":
          this.helper.erasBeginMidYear && (n.add("era"), n.add("eraYear"));
      }
    }
    return pp(n);
  }
  dateAdd(e, { years: n, months: r, weeks: o, days: i }, a) {
    const c = Xe.getCacheForObject(e), l = this.helper.isoToCalendarDate(e, c), h = this.helper.addCalendar(l, { years: n, months: r, weeks: o, days: i }, a, c), m = this.helper.calendarToIsoDate(h, "constrain", c);
    return Xe.getCacheForObject(m) || new Xe(c).setObject(m), m;
  }
  dateUntil(e, n, r) {
    const o = Xe.getCacheForObject(e), i = Xe.getCacheForObject(n), a = this.helper.isoToCalendarDate(e, o), c = this.helper.isoToCalendarDate(n, i);
    return this.helper.untilCalendar(a, c, r, o);
  }
  isoToDate(e, n) {
    const r = Xe.getCacheForObject(e), o = this.helper.isoToCalendarDate(e, r);
    if (n.dayOfWeek && (o.dayOfWeek = Qi.iso8601.isoToDate(e, { dayOfWeek: !0 }).dayOfWeek), n.dayOfYear) {
      const i = this.helper.startOfCalendarYear(o), a = this.helper.calendarDaysUntil(i, o, r);
      o.dayOfYear = a + 1;
    }
    if (n.weekOfYear && (o.weekOfYear = gp(this.helper.id, e)), o.daysInWeek = 7, n.daysInMonth && (o.daysInMonth = this.helper.daysInMonth(o, r)), n.daysInYear) {
      const i = this.helper.startOfCalendarYear(o), a = this.helper.addCalendar(i, { years: 1 }, "constrain", r);
      o.daysInYear = this.helper.calendarDaysUntil(i, a, r);
    }
    return n.monthsInYear && (o.monthsInYear = this.helper.monthsInYear(o, r)), n.inLeapYear && (o.inLeapYear = this.helper.inLeapYear(o, r)), o;
  }
  getFirstDayOfWeek() {
    return this.helper.getFirstDayOfWeek();
  }
  getMinimalDaysInFirstWeek() {
    return this.helper.getMinimalDaysInFirstWeek();
  }
}
for (const t of [sT, mT, bT, vT, yT, CT, PT, wT, pT, kT, _T, TT, uT, cT, lT, dT, hT, fT]) {
  const e = new t();
  Qi[e.id] = new AT(e);
}
fc("calendarImpl", (function(t) {
  return Qi[t];
}));
const Oi = Intl.DateTimeFormat;
function io(t, e) {
  let n = w(t, e);
  return typeof n == "function" && (n = new Oi(w(t, Rm), n(w(t, cc))), (function(r, o, i) {
    const a = bs(r);
    if (a === void 0) throw new TypeError("Missing slots for the given container");
    if (a[o] === void 0) throw new TypeError(`tried to reset ${o} which was not set`);
    a[o] = i;
  })(t, e, n)), n;
}
function ei(t) {
  return St(t, Yr);
}
class Mi {
  constructor(e = void 0, n = void 0) {
    (function(r, o, i) {
      const a = i !== void 0;
      let c;
      if (a) {
        const p = ["localeMatcher", "calendar", "numberingSystem", "hour12", "hourCycle", "timeZone", "weekday", "era", "year", "month", "day", "dayPeriod", "hour", "minute", "second", "fractionalSecondDigits", "timeZoneName", "formatMatcher", "dateStyle", "timeStyle"];
        c = (function(k) {
          if (k == null) throw new TypeError(`Expected object not ${k}`);
          return Object(k);
        })(i);
        const v = /* @__PURE__ */ Object.create(null);
        for (let k = 0; k < p.length; k++) {
          const P = p[k];
          Object.prototype.hasOwnProperty.call(c, P) && (v[P] = c[P]);
        }
        c = v;
      } else c = /* @__PURE__ */ Object.create(null);
      const l = new Oi(o, c), h = l.resolvedOptions();
      if (Yn(r), a) {
        const p = Object.assign(/* @__PURE__ */ Object.create(null), h);
        for (const v in p) Object.prototype.hasOwnProperty.call(c, v) || delete p[v];
        p.hour12 = c.hour12, p.hourCycle = c.hourCycle, pe(r, cc, p);
      } else pe(r, cc, c);
      pe(r, Rm, h.locale), pe(r, Yr, l), pe(r, lo, h.timeZone), pe(r, oi, h.calendar), pe(r, Am, MT), pe(r, Em, xT), pe(r, Sm, OT), pe(r, Dm, RT), pe(r, Im, $T), pe(r, zm, NT);
      const m = a ? c.timeZone : void 0;
      if (m === void 0) pe(r, uc, h.timeZone);
      else {
        const p = Ts(m);
        if (p.startsWith("−")) throw new RangeError("Unicode minus (U+2212) is not supported in time zone offsets");
        pe(r, uc, At(p));
      }
    })(this, e, n);
  }
  get format() {
    M(this, ei);
    const e = ST.bind(this);
    return Object.defineProperties(e, { length: { value: 1, enumerable: !1, writable: !1, configurable: !0 }, name: { value: "", enumerable: !1, writable: !1, configurable: !0 } }), e;
  }
  formatRange(e, n) {
    return M(this, ei), IT.call(this, e, n);
  }
  formatToParts(e, ...n) {
    return M(this, ei), DT.call(this, e, ...n);
  }
  formatRangeToParts(e, n) {
    return M(this, ei), zT.call(this, e, n);
  }
  resolvedOptions() {
    return M(this, ei), ET.call(this);
  }
}
"formatToParts" in Oi.prototype || delete Mi.prototype.formatToParts, "formatRangeToParts" in Oi.prototype || delete Mi.prototype.formatRangeToParts;
const en = function(t = void 0, e = void 0) {
  return new Mi(t, e);
};
function ET() {
  const t = w(this, Yr).resolvedOptions();
  return t.timeZone = w(this, uc), t;
}
function ST(t, ...e) {
  let n, r, o = So(t, this);
  return o.formatter ? (n = o.formatter, r = [rn(o.epochNs, "floor")]) : (n = w(this, Yr), r = [t, ...e]), n.format(...r);
}
function DT(t, ...e) {
  let n, r, o = So(t, this);
  return o.formatter ? (n = o.formatter, r = [rn(o.epochNs, "floor")]) : (n = w(this, Yr), r = [t, ...e]), n.formatToParts(...r);
}
function IT(t, e) {
  if (t === void 0 || e === void 0) throw new TypeError("Intl.DateTimeFormat.formatRange requires two values");
  const n = fs(t), r = fs(e);
  let o, i = [n, r];
  if (qn(n) !== qn(r)) throw new TypeError("Intl.DateTimeFormat.formatRange accepts two values of the same type");
  if (qn(n)) {
    if (!_p(n, r)) throw new TypeError("Intl.DateTimeFormat.formatRange accepts two values of the same type");
    const { epochNs: a, formatter: c } = So(n, this), { epochNs: l, formatter: h } = So(r, this);
    c && (o = c, i = [rn(a, "floor"), rn(l, "floor")]);
  }
  return o || (o = w(this, Yr)), o.formatRange(...i);
}
function zT(t, e) {
  if (t === void 0 || e === void 0) throw new TypeError("Intl.DateTimeFormat.formatRange requires two values");
  const n = fs(t), r = fs(e);
  let o, i = [n, r];
  if (qn(n) !== qn(r)) throw new TypeError("Intl.DateTimeFormat.formatRangeToParts accepts two values of the same type");
  if (qn(n)) {
    if (!_p(n, r)) throw new TypeError("Intl.DateTimeFormat.formatRangeToParts accepts two values of the same type");
    const { epochNs: a, formatter: c } = So(n, this), { epochNs: l, formatter: h } = So(r, this);
    c && (o = c, i = [rn(a, "floor"), rn(l, "floor")]);
  }
  return o || (o = w(this, Yr)), o.formatRangeToParts(...i);
}
function Xi(t = {}, e = {}) {
  const n = Object.assign({}, t), r = ["year", "month", "day", "hour", "minute", "second", "weekday", "dayPeriod", "timeZoneName", "dateStyle", "timeStyle"];
  for (let o = 0; o < r.length; o++) {
    const i = r[o];
    n[i] = i in e ? e[i] : n[i], n[i] !== !1 && n[i] !== void 0 || delete n[i];
  }
  return n;
}
function RT(t) {
  const e = Xi(t, { year: !1, month: !1, day: !1, weekday: !1, timeZoneName: !1, dateStyle: !1 });
  if (e.timeStyle !== "long" && e.timeStyle !== "full" || (delete e.timeStyle, Object.assign(e, { hour: "numeric", minute: "2-digit", second: "2-digit" })), !Rs(e)) {
    if (Ji(t)) throw new TypeError(`cannot format Temporal.PlainTime with options [${Object.keys(t)}]`);
    Object.assign(e, { hour: "numeric", minute: "numeric", second: "numeric" });
  }
  return e;
}
function xT(t) {
  const e = { short: { year: "2-digit", month: "numeric" }, medium: { year: "numeric", month: "short" }, long: { year: "numeric", month: "long" }, full: { year: "numeric", month: "long" } }, n = Xi(t, { day: !1, hour: !1, minute: !1, second: !1, weekday: !1, dayPeriod: !1, timeZoneName: !1, timeStyle: !1 });
  if ("dateStyle" in n && n.dateStyle) {
    const r = n.dateStyle;
    delete n.dateStyle, Object.assign(n, e[r]);
  }
  if (!("year" in n || "month" in n || "era" in n)) {
    if (Ji(t)) throw new TypeError(`cannot format PlainYearMonth with options [${Object.keys(t)}]`);
    Object.assign(n, { year: "numeric", month: "numeric" });
  }
  return n;
}
function OT(t) {
  const e = { short: { month: "numeric", day: "numeric" }, medium: { month: "short", day: "numeric" }, long: { month: "long", day: "numeric" }, full: { month: "long", day: "numeric" } }, n = Xi(t, { year: !1, hour: !1, minute: !1, second: !1, weekday: !1, dayPeriod: !1, timeZoneName: !1, timeStyle: !1 });
  if ("dateStyle" in n && n.dateStyle) {
    const r = n.dateStyle;
    delete n.dateStyle, Object.assign(n, e[r]);
  }
  if (!("month" in n) && !("day" in n)) {
    if (Ji(t)) throw new TypeError(`cannot format PlainMonthDay with options [${Object.keys(t)}]`);
    Object.assign(n, { month: "numeric", day: "numeric" });
  }
  return n;
}
function MT(t) {
  const e = Xi(t, { hour: !1, minute: !1, second: !1, dayPeriod: !1, timeZoneName: !1, timeStyle: !1 });
  if (!zs(e)) {
    if (Ji(t)) throw new TypeError(`cannot format PlainDate with options [${Object.keys(t)}]`);
    Object.assign(e, { year: "numeric", month: "numeric", day: "numeric" });
  }
  return e;
}
function $T(t) {
  const e = Xi(t, { timeZoneName: !1 });
  if ((e.timeStyle === "long" || e.timeStyle === "full") && (delete e.timeStyle, Object.assign(e, { hour: "numeric", minute: "2-digit", second: "2-digit" }), e.dateStyle) && (Object.assign(e, { short: { year: "numeric", month: "numeric", day: "numeric" }, medium: { year: "numeric", month: "short", day: "numeric" }, long: { year: "numeric", month: "long", day: "numeric" }, full: { year: "numeric", month: "long", day: "numeric", weekday: "long" } }[e.dateStyle]), delete e.dateStyle), !Rs(e) && !zs(e)) {
    if (Ji(t)) throw new TypeError(`cannot format PlainDateTime with options [${Object.keys(t)}]`);
    Object.assign(e, { year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" });
  }
  return e;
}
function NT(t) {
  let e = t;
  return Rs(e) || zs(e) || (e = Object.assign({}, e, { year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" })), e;
}
function zs(t) {
  return "year" in t || "month" in t || "day" in t || "weekday" in t || "dateStyle" in t || "era" in t;
}
function Rs(t) {
  return "hour" in t || "minute" in t || "second" in t || "timeStyle" in t || "dayPeriod" in t || "fractionalSecondDigits" in t;
}
function Ji(t) {
  return zs(t) || Rs(t) || "dateStyle" in t || "timeStyle" in t || "timeZoneName" in t;
}
function qn(t) {
  return Ne(t) || Fe(t) || ze(t) || ge(t) || nt(t) || Gt(t) || tt(t);
}
function fs(t) {
  return qn(t) ? t : _s(t);
}
function _p(t, e) {
  return !(!qn(t) || !qn(e) || Fe(t) && !Fe(e) || Ne(t) && !Ne(e) || ze(t) && !ze(e) || ge(t) && !ge(e) || nt(t) && !nt(e) || Gt(t) && !Gt(e) || tt(t) && !tt(e));
}
function So(t, e) {
  if (Fe(t)) {
    const n = { isoDate: { year: 1970, month: 1, day: 1 }, time: w(t, je) };
    return { epochNs: lt(w(e, lo), n, "compatible"), formatter: io(e, Dm) };
  }
  if (nt(t)) {
    const n = w(t, K), r = w(e, oi);
    if (n !== r) throw new RangeError(`cannot format PlainYearMonth with calendar ${n} in locale with calendar ${r}`);
    const o = Te(w(t, de), { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    return { epochNs: lt(w(e, lo), o, "compatible"), formatter: io(e, Em) };
  }
  if (Gt(t)) {
    const n = w(t, K), r = w(e, oi);
    if (n !== r) throw new RangeError(`cannot format PlainMonthDay with calendar ${n} in locale with calendar ${r}`);
    const o = Te(w(t, de), { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    return { epochNs: lt(w(e, lo), o, "compatible"), formatter: io(e, Sm) };
  }
  if (Ne(t)) {
    const n = w(t, K), r = w(e, oi);
    if (n !== "iso8601" && n !== r) throw new RangeError(`cannot format PlainDate with calendar ${n} in locale with calendar ${r}`);
    const o = Te(w(t, de), { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    return { epochNs: lt(w(e, lo), o, "compatible"), formatter: io(e, Am) };
  }
  if (ze(t)) {
    const n = w(t, K), r = w(e, oi);
    if (n !== "iso8601" && n !== r) throw new RangeError(`cannot format PlainDateTime with calendar ${n} in locale with calendar ${r}`);
    const o = w(t, xe);
    return { epochNs: lt(w(e, lo), o, "compatible"), formatter: io(e, Im) };
  }
  if (ge(t)) throw new TypeError("Temporal.ZonedDateTime not supported in DateTimeFormat methods. Use toLocaleString() instead.");
  return tt(t) ? { epochNs: w(t, le), formatter: io(e, zm) } : {};
}
function Tp(t) {
  const e = /* @__PURE__ */ Object.create(null);
  return e.years = w(t, gt), e.months = w(t, vt), e.weeks = w(t, zt), e.days = w(t, yt), e.hours = w(t, bt), e.minutes = w(t, wt), e.seconds = w(t, kt), e.milliseconds = w(t, _t), e.microseconds = w(t, Tt), e.nanoseconds = w(t, Rt), e;
}
Mi.prototype.constructor = en, Object.defineProperty(en, "prototype", { value: Mi.prototype, writable: !1, enumerable: !1, configurable: !1 }), en.supportedLocalesOf = Oi.supportedLocalesOf, Vn(en, "Intl.DateTimeFormat");
var Nh;
const { format: jT, formatToParts: LT } = ((Nh = Intl.DurationFormat) == null ? void 0 : Nh.prototype) ?? /* @__PURE__ */ Object.create(null);
function Cp(t) {
  Intl.DurationFormat.prototype.resolvedOptions.call(this);
  const e = Tp(tn(t));
  return jT.call(this, e);
}
var jh;
(jh = Intl.DurationFormat) != null && jh.prototype && (Intl.DurationFormat.prototype.format = Cp, Intl.DurationFormat.prototype.formatToParts = function(t) {
  Intl.DurationFormat.prototype.resolvedOptions.call(this);
  const e = Tp(tn(t));
  return LT.call(this, e);
});
class ul {
  constructor(e) {
    if (arguments.length < 1) throw new TypeError("missing argument: epochNanoseconds is required");
    Qm(this, hs(e));
  }
  get epochMilliseconds() {
    return M(this, tt), rn(w(this, le), "floor");
  }
  get epochNanoseconds() {
    return M(this, tt), fp(y.BigInt(w(this, le)));
  }
  add(e) {
    return M(this, tt), Th("add", this, e);
  }
  subtract(e) {
    return M(this, tt), Th("subtract", this, e);
  }
  until(e, n = void 0) {
    return M(this, tt), gh("until", this, e, n);
  }
  since(e, n = void 0) {
    return M(this, tt), gh("since", this, e, n);
  }
  round(e) {
    if (M(this, tt), e === void 0) throw new TypeError("options parameter is required");
    const n = typeof e == "string" ? Kr("smallestUnit", e) : te(e), r = xo(n), o = ln(n, "halfExpand"), i = Ot(n, "smallestUnit", "time", Wn);
    return Oo(r, { hour: 24, minute: 1440, second: 86400, millisecond: 864e5, microsecond: 864e8, nanosecond: 864e11 }[i], !0), gn(Tc(w(this, le), r, i, o));
  }
  equals(e) {
    M(this, tt);
    const n = si(e), r = w(this, le), o = w(n, le);
    return y.equal(y.BigInt(r), y.BigInt(o));
  }
  toString(e = void 0) {
    M(this, tt);
    const n = te(e), r = Zi(n), o = ln(n, "trunc"), i = Ot(n, "smallestUnit", "time", void 0);
    if (i === "hour") throw new RangeError('smallestUnit must be a time unit other than "hour"');
    let a = n.timeZone;
    a !== void 0 && (a = At(a));
    const { precision: c, unit: l, increment: h } = qi(i, r);
    return sh(gn(Tc(w(this, le), h, l, o)), a, c);
  }
  toJSON() {
    return M(this, tt), sh(this, void 0, "auto");
  }
  toLocaleString(e = void 0, n = void 0) {
    return M(this, tt), new en(e, n).format(this);
  }
  valueOf() {
    vr("Instant");
  }
  toZonedDateTimeISO(e) {
    M(this, tt);
    const n = At(e);
    return ut(w(this, le), n, "iso8601");
  }
  static fromEpochMilliseconds(e) {
    return gn(yn(_s(e)));
  }
  static fromEpochNanoseconds(e) {
    return gn(hs(e));
  }
  static from(e) {
    return si(e);
  }
  static compare(e, n) {
    const r = si(e), o = si(n), i = w(r, le), a = w(o, le);
    return y.lessThan(i, a) ? -1 : y.greaterThan(i, a) ? 1 : 0;
  }
}
Vn(ul, "Temporal.Instant");
class cl {
  constructor(e, n, r, o = "iso8601") {
    const i = fe(e), a = fe(n), c = fe(r), l = Dt(o === void 0 ? "iso8601" : Be(o));
    Ur(i, a, c), Wm(this, { year: i, month: a, day: c }, l);
  }
  get calendarId() {
    return M(this, Ne), w(this, K);
  }
  get era() {
    return ht(this, "era");
  }
  get eraYear() {
    return ht(this, "eraYear");
  }
  get year() {
    return ht(this, "year");
  }
  get month() {
    return ht(this, "month");
  }
  get monthCode() {
    return ht(this, "monthCode");
  }
  get day() {
    return ht(this, "day");
  }
  get dayOfWeek() {
    return ht(this, "dayOfWeek");
  }
  get dayOfYear() {
    return ht(this, "dayOfYear");
  }
  get weekOfYear() {
    var e;
    return (e = ht(this, "weekOfYear")) == null ? void 0 : e.week;
  }
  get yearOfWeek() {
    var e;
    return (e = ht(this, "weekOfYear")) == null ? void 0 : e.year;
  }
  get daysInWeek() {
    return ht(this, "daysInWeek");
  }
  get daysInMonth() {
    return ht(this, "daysInMonth");
  }
  get daysInYear() {
    return ht(this, "daysInYear");
  }
  get monthsInYear() {
    return ht(this, "monthsInYear");
  }
  get inLeapYear() {
    return ht(this, "inLeapYear");
  }
  with(e, n = void 0) {
    if (M(this, Ne), !Le(e)) throw new TypeError("invalid argument");
    Ro(e);
    const r = w(this, K);
    let o = Et(r, w(this, de));
    return o = Fr(r, o, Wt(r, e, ["year", "month", "monthCode", "day"], [], "partial")), Pt(fr(r, o, ke(te(n))), r);
  }
  withCalendar(e) {
    M(this, Ne);
    const n = Vi(e);
    return Pt(w(this, de), n);
  }
  add(e, n = void 0) {
    return M(this, Ne), Ch("add", this, e, n);
  }
  subtract(e, n = void 0) {
    return M(this, Ne), Ch("subtract", this, e, n);
  }
  until(e, n = void 0) {
    return M(this, Ne), vh("until", this, e, n);
  }
  since(e, n = void 0) {
    return M(this, Ne), vh("since", this, e, n);
  }
  equals(e) {
    M(this, Ne);
    const n = ii(e);
    return Tn(w(this, de), w(n, de)) === 0 && kn(w(this, K), w(n, K));
  }
  toString(e = void 0) {
    return M(this, Ne), uh(this, Ui(te(e)));
  }
  toJSON() {
    return M(this, Ne), uh(this);
  }
  toLocaleString(e = void 0, n = void 0) {
    return M(this, Ne), new en(e, n).format(this);
  }
  valueOf() {
    vr("PlainDate");
  }
  toPlainDateTime(e = void 0) {
    M(this, Ne);
    const n = Km(e);
    return Xt(Te(w(this, de), n), w(this, K));
  }
  toZonedDateTime(e) {
    let n, r;
    if (M(this, Ne), Le(e)) {
      const a = e.timeZone;
      a === void 0 ? n = At(e) : (n = At(a), r = e.plainTime);
    } else n = At(e);
    const o = w(this, de);
    let i;
    return r === void 0 ? i = or(n, o) : (r = ar(r), i = lt(n, Te(o, w(r, je)), "compatible")), ut(i, n, w(this, K));
  }
  toPlainYearMonth() {
    M(this, Ne);
    const e = w(this, K);
    return po(Di(e, Et(e, w(this, de)), "constrain"), e);
  }
  toPlainMonthDay() {
    M(this, Ne);
    const e = w(this, K);
    return mo(ss(e, Et(e, w(this, de)), "constrain"), e);
  }
  static from(e, n = void 0) {
    return ii(e, n);
  }
  static compare(e, n) {
    const r = ii(e), o = ii(n);
    return Tn(w(r, de), w(o, de));
  }
}
function ht(t, e) {
  M(t, Ne);
  const n = w(t, de);
  return Ki(t).isoToDate(n, { [e]: !0 })[e];
}
Vn(cl, "Temporal.PlainDate");
class ll {
  constructor(e, n, r, o = 0, i = 0, a = 0, c = 0, l = 0, h = 0, m = "iso8601") {
    const p = fe(e), v = fe(n), k = fe(r), P = o === void 0 ? 0 : fe(o), A = i === void 0 ? 0 : fe(i), S = a === void 0 ? 0 : fe(a), z = c === void 0 ? 0 : fe(c), L = l === void 0 ? 0 : fe(l), W = h === void 0 ? 0 : fe(h), H = Dt(m === void 0 ? "iso8601" : Be(m));
    tl(p, v, k, P, A, S, z, L, W), Ym(this, { isoDate: { year: p, month: v, day: k }, time: { hour: P, minute: A, second: S, millisecond: z, microsecond: L, nanosecond: W } }, H);
  }
  get calendarId() {
    return M(this, ze), w(this, K);
  }
  get year() {
    return ft(this, "year");
  }
  get month() {
    return ft(this, "month");
  }
  get monthCode() {
    return ft(this, "monthCode");
  }
  get day() {
    return ft(this, "day");
  }
  get hour() {
    return ao(this, "hour");
  }
  get minute() {
    return ao(this, "minute");
  }
  get second() {
    return ao(this, "second");
  }
  get millisecond() {
    return ao(this, "millisecond");
  }
  get microsecond() {
    return ao(this, "microsecond");
  }
  get nanosecond() {
    return ao(this, "nanosecond");
  }
  get era() {
    return ft(this, "era");
  }
  get eraYear() {
    return ft(this, "eraYear");
  }
  get dayOfWeek() {
    return ft(this, "dayOfWeek");
  }
  get dayOfYear() {
    return ft(this, "dayOfYear");
  }
  get weekOfYear() {
    var e;
    return (e = ft(this, "weekOfYear")) == null ? void 0 : e.week;
  }
  get yearOfWeek() {
    var e;
    return (e = ft(this, "weekOfYear")) == null ? void 0 : e.year;
  }
  get daysInWeek() {
    return ft(this, "daysInWeek");
  }
  get daysInYear() {
    return ft(this, "daysInYear");
  }
  get daysInMonth() {
    return ft(this, "daysInMonth");
  }
  get monthsInYear() {
    return ft(this, "monthsInYear");
  }
  get inLeapYear() {
    return ft(this, "inLeapYear");
  }
  with(e, n = void 0) {
    if (M(this, ze), !Le(e)) throw new TypeError("invalid argument");
    Ro(e);
    const r = w(this, K), o = w(this, xe);
    let i = { ...Et(r, o.isoDate), ...o.time };
    return i = Fr(r, i, Wt(r, e, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond"], "partial")), Xt(Wi(r, i, ke(te(n))), r);
  }
  withPlainTime(e = void 0) {
    M(this, ze);
    const n = Km(e);
    return Xt(Te(w(this, xe).isoDate, n), w(this, K));
  }
  withCalendar(e) {
    M(this, ze);
    const n = Vi(e);
    return Xt(w(this, xe), n);
  }
  add(e, n = void 0) {
    return M(this, ze), Ph("add", this, e, n);
  }
  subtract(e, n = void 0) {
    return M(this, ze), Ph("subtract", this, e, n);
  }
  until(e, n = void 0) {
    return M(this, ze), yh("until", this, e, n);
  }
  since(e, n = void 0) {
    return M(this, ze), yh("since", this, e, n);
  }
  round(e) {
    if (M(this, ze), e === void 0) throw new TypeError("options parameter is required");
    const n = typeof e == "string" ? Kr("smallestUnit", e) : te(e), r = xo(n), o = ln(n, "halfExpand"), i = Ot(n, "smallestUnit", "time", Wn, ["day"]), a = { day: 1, hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[i];
    Oo(r, a, a === 1);
    const c = w(this, xe);
    return Xt(r === 1 && i === "nanosecond" ? c : Cc(c, r, i, o), w(this, K));
  }
  equals(e) {
    M(this, ze);
    const n = ai(e);
    return Eo(w(this, xe), w(n, xe)) === 0 && kn(w(this, K), w(n, K));
  }
  toString(e = void 0) {
    M(this, ze);
    const n = te(e), r = Ui(n), o = Zi(n), i = ln(n, "trunc"), a = Ot(n, "smallestUnit", "time", void 0);
    if (a === "hour") throw new RangeError('smallestUnit must be a time unit other than "hour"');
    const { precision: c, unit: l, increment: h } = qi(a, o), m = Cc(w(this, xe), h, l, i);
    return Zr(m), zi(m, w(this, K), c, r);
  }
  toJSON() {
    return M(this, ze), zi(w(this, xe), w(this, K), "auto");
  }
  toLocaleString(e = void 0, n = void 0) {
    return M(this, ze), new en(e, n).format(this);
  }
  valueOf() {
    vr("PlainDateTime");
  }
  toZonedDateTime(e, n = void 0) {
    M(this, ze);
    const r = At(e), o = yi(te(n));
    return ut(lt(r, w(this, xe), o), r, w(this, K));
  }
  toPlainDate() {
    return M(this, ze), Pt(w(this, xe).isoDate, w(this, K));
  }
  toPlainTime() {
    return M(this, ze), Ln(w(this, xe).time);
  }
  static from(e, n = void 0) {
    return ai(e, n);
  }
  static compare(e, n) {
    const r = ai(e), o = ai(n);
    return Eo(w(r, xe), w(o, xe));
  }
}
function ft(t, e) {
  M(t, ze);
  const n = w(t, xe).isoDate;
  return Ki(t).isoToDate(n, { [e]: !0 })[e];
}
function ao(t, e) {
  return M(t, ze), w(t, xe).time[e];
}
Vn(ll, "Temporal.PlainDateTime");
class Do {
  constructor(e = 0, n = 0, r = 0, o = 0, i = 0, a = 0, c = 0, l = 0, h = 0, m = 0) {
    const p = e === void 0 ? 0 : cn(e), v = n === void 0 ? 0 : cn(n), k = r === void 0 ? 0 : cn(r), P = o === void 0 ? 0 : cn(o), A = i === void 0 ? 0 : cn(i), S = a === void 0 ? 0 : cn(a), z = c === void 0 ? 0 : cn(c), L = l === void 0 ? 0 : cn(l), W = h === void 0 ? 0 : cn(h), H = m === void 0 ? 0 : cn(m);
    Ds(p, v, k, P, A, S, z, L, W, H), Yn(this), pe(this, gt, p), pe(this, vt, v), pe(this, zt, k), pe(this, yt, P), pe(this, bt, A), pe(this, wt, S), pe(this, kt, z), pe(this, _t, L), pe(this, Tt, W), pe(this, Rt, H);
  }
  get years() {
    return M(this, $e), w(this, gt);
  }
  get months() {
    return M(this, $e), w(this, vt);
  }
  get weeks() {
    return M(this, $e), w(this, zt);
  }
  get days() {
    return M(this, $e), w(this, yt);
  }
  get hours() {
    return M(this, $e), w(this, bt);
  }
  get minutes() {
    return M(this, $e), w(this, wt);
  }
  get seconds() {
    return M(this, $e), w(this, kt);
  }
  get milliseconds() {
    return M(this, $e), w(this, _t);
  }
  get microseconds() {
    return M(this, $e), w(this, Tt);
  }
  get nanoseconds() {
    return M(this, $e), w(this, Rt);
  }
  get sign() {
    return M(this, $e), ls(this);
  }
  get blank() {
    return M(this, $e), ls(this) === 0;
  }
  with(e) {
    M(this, $e);
    const n = qm(e), { years: r = w(this, gt), months: o = w(this, vt), weeks: i = w(this, zt), days: a = w(this, yt), hours: c = w(this, bt), minutes: l = w(this, wt), seconds: h = w(this, kt), milliseconds: m = w(this, _t), microseconds: p = w(this, Tt), nanoseconds: v = w(this, Rt) } = n;
    return new Do(r, o, i, a, c, l, h, m, p, v);
  }
  negated() {
    return M(this, $e), jt(this);
  }
  abs() {
    return M(this, $e), new Do(Math.abs(w(this, gt)), Math.abs(w(this, vt)), Math.abs(w(this, zt)), Math.abs(w(this, yt)), Math.abs(w(this, bt)), Math.abs(w(this, wt)), Math.abs(w(this, kt)), Math.abs(w(this, _t)), Math.abs(w(this, Tt)), Math.abs(w(this, Rt)));
  }
  add(e) {
    return M(this, $e), _h("add", this, e);
  }
  subtract(e) {
    return M(this, $e), _h("subtract", this, e);
  }
  round(e) {
    if (M(this, $e), e === void 0) throw new TypeError("options parameter is required");
    const n = Mn(this), r = typeof e == "string" ? Kr("smallestUnit", e) : te(e);
    let o = Ot(r, "largestUnit", "datetime", void 0, ["auto"]), { plainRelativeTo: i, zonedRelativeTo: a } = Fu(r);
    const c = xo(r), l = ln(r, "halfExpand");
    let h = Ot(r, "smallestUnit", "datetime", void 0), m = !0;
    h || (m = !1, h = "nanosecond");
    const p = Fn(n, h);
    let v = !0;
    if (o || (v = !1, o = p), o === "auto" && (o = p), !m && !v) throw new RangeError("at least one of smallestUnit or largestUnit is required");
    if (Fn(o, h) !== o) throw new RangeError(`largestUnit ${o} cannot be smaller than smallestUnit ${h}`);
    const k = { hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[h];
    if (k !== void 0 && Oo(c, k, !1), c > 1 && $n(h) === "date" && o !== h) throw new RangeError("For calendar units with roundingIncrement > 1, use largestUnit = smallestUnit");
    if (a) {
      let A = ho(this);
      const S = w(a, Pe), z = w(a, K), L = w(a, le);
      return A = hp(L, li(L, S, z, A), S, z, o, c, h, l), $n(o) === "date" && (o = "hour"), Jt(A, o);
    }
    if (i) {
      let A = vn(this);
      const S = Ao({ hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }, A.time), z = w(i, de), L = w(i, K), W = qt(L, z, ct(A.date, S.deltaDays), "constrain");
      return A = dp(Te(z, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), Te(W, S), L, o, c, h, l), Jt(A, o);
    }
    if (mn(n)) throw new RangeError(`a starting point is required for ${n}s balancing`);
    if (mn(o)) throw new RangeError(`a starting point is required for ${o}s balancing`);
    let P = vn(this);
    if (h === "day") {
      const { quotient: A, remainder: S } = P.time.divmod(os);
      let z = P.date.days + A + bi(S, "day");
      z = sr(z, c, l), P = Un({ years: 0, months: 0, weeks: 0, days: z }, ve.ZERO);
    } else P = Un({ years: 0, months: 0, weeks: 0, days: 0 }, ds(P.time, c, h, l));
    return Jt(P, o);
  }
  total(e) {
    if (M(this, $e), e === void 0) throw new TypeError("options argument is required");
    const n = typeof e == "string" ? Kr("unit", e) : te(e);
    let { plainRelativeTo: r, zonedRelativeTo: o } = Fu(n);
    const i = Ot(n, "unit", "datetime", Wn);
    if (o) {
      const c = ho(this), l = w(o, Pe), h = w(o, K), m = w(o, le);
      return (function(p, v, k, P, A) {
        return $n(A) === "time" ? bi(ve.fromEpochNsDiff(v, p), A) : ph(cp(p, v, k, P, A), v, nn(k, p), k, P, A);
      })(m, li(m, l, h, c), l, h, i);
    }
    if (r) {
      const c = vn(this);
      let l = Ao({ hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }, c.time);
      const h = w(r, de), m = w(r, K), p = qt(m, h, ct(c.date, l.deltaDays), "constrain");
      return (function(v, k, P, A) {
        if (Eo(v, k) == 0) return 0;
        Zr(v), Zr(k);
        const S = up(v, k, P, A);
        return A === "nanosecond" ? y.toNumber(S.time.totalNs) : ph(S, rt(k), v, null, P, A);
      })(Te(h, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), Te(p, l), m, i);
    }
    const a = Mn(this);
    if (mn(a)) throw new RangeError(`a starting point is required for ${a}s total`);
    if (mn(i)) throw new RangeError(`a starting point is required for ${i}s total`);
    return bi(vn(this).time, i);
  }
  toString(e = void 0) {
    M(this, $e);
    const n = te(e), r = Zi(n), o = ln(n, "trunc"), i = Ot(n, "smallestUnit", "time", void 0);
    if (i === "hour" || i === "minute") throw new RangeError('smallestUnit must be a time unit other than "hours" or "minutes"');
    const { precision: a, unit: c, increment: l } = qi(i, r);
    if (c === "nanosecond" && l === 1) return ja(this, a);
    const h = Mn(this);
    let m = ho(this);
    const p = ds(m.time, l, c, o);
    return m = Un(m.date, p), ja(Jt(m, Fn(h, "second")), a);
  }
  toJSON() {
    return M(this, $e), ja(this, "auto");
  }
  toLocaleString(e = void 0, n = void 0) {
    if (M(this, $e), typeof Intl.DurationFormat == "function") {
      const r = new Intl.DurationFormat(e, n);
      return Cp.call(r, this);
    }
    return console.warn("Temporal.Duration.prototype.toLocaleString() requires Intl.DurationFormat."), ja(this, "auto");
  }
  valueOf() {
    vr("Duration");
  }
  static from(e) {
    return tn(e);
  }
  static compare(e, n, r = void 0) {
    const o = tn(e), i = tn(n), a = te(r), { plainRelativeTo: c, zonedRelativeTo: l } = Fu(a);
    if (w(o, gt) === w(i, gt) && w(o, vt) === w(i, vt) && w(o, zt) === w(i, zt) && w(o, yt) === w(i, yt) && w(o, bt) === w(i, bt) && w(o, wt) === w(i, wt) && w(o, kt) === w(i, kt) && w(o, _t) === w(i, _t) && w(o, Tt) === w(i, Tt) && w(o, Rt) === w(i, Rt)) return 0;
    const h = Mn(o), m = Mn(i), p = ho(o), v = ho(i);
    if (l && ($n(h) === "date" || $n(m) === "date")) {
      const z = w(l, Pe), L = w(l, K), W = w(l, le), H = li(W, z, L, p), re = li(W, z, L, v);
      return xt(y.toNumber(y.subtract(H, re)));
    }
    let k = p.date.days, P = v.date.days;
    if (mn(h) || mn(m)) {
      if (!c) throw new RangeError("A starting point is required for years, months, or weeks comparison");
      k = mh(p.date, c), P = mh(v.date, c);
    }
    const A = p.time.add24HourDays(k), S = v.time.add24HourDays(P);
    return A.cmp(S);
  }
}
Vn(Do, "Temporal.Duration");
class dl {
  constructor(e, n, r = "iso8601", o = 1972) {
    const i = fe(e), a = fe(n), c = Dt(r === void 0 ? "iso8601" : Be(r)), l = fe(o);
    Ur(l, i, a), Vm(this, { year: l, month: i, day: a }, c);
  }
  get monthCode() {
    return Ih(this, "monthCode");
  }
  get day() {
    return Ih(this, "day");
  }
  get calendarId() {
    return M(this, Gt), w(this, K);
  }
  with(e, n = void 0) {
    if (M(this, Gt), !Le(e)) throw new TypeError("invalid argument");
    Ro(e);
    const r = w(this, K);
    let o = Et(r, w(this, de), "month-day");
    return o = Fr(r, o, Wt(r, e, ["year", "month", "monthCode", "day"], [], "partial")), mo(ss(r, o, ke(te(n))), r);
  }
  equals(e) {
    M(this, Gt);
    const n = ih(e);
    return Tn(w(this, de), w(n, de)) === 0 && kn(w(this, K), w(n, K));
  }
  toString(e = void 0) {
    return M(this, Gt), lh(this, Ui(te(e)));
  }
  toJSON() {
    return M(this, Gt), lh(this);
  }
  toLocaleString(e = void 0, n = void 0) {
    return M(this, Gt), new en(e, n).format(this);
  }
  valueOf() {
    vr("PlainMonthDay");
  }
  toPlainDate(e) {
    if (M(this, Gt), !Le(e)) throw new TypeError("argument should be an object");
    const n = w(this, K);
    return Pt(fr(n, Fr(n, Et(n, w(this, de), "month-day"), Wt(n, e, ["year"], [], [])), "constrain"), n);
  }
  static from(e, n = void 0) {
    return ih(e, n);
  }
}
function Ih(t, e) {
  M(t, Gt);
  const n = w(t, de);
  return Ki(t).isoToDate(n, { [e]: !0 })[e];
}
function Zu(t) {
  return nn(t, Ec());
}
Vn(dl, "Temporal.PlainMonthDay");
const Pp = { instant: () => gn(Ec()), plainDateTimeISO: (t = Jo()) => Xt(Zu(At(t)), "iso8601"), plainDateISO: (t = Jo()) => Pt(Zu(At(t)).isoDate, "iso8601"), plainTimeISO: (t = Jo()) => Ln(Zu(At(t)).time), timeZoneId: () => Jo(), zonedDateTimeISO: (t = Jo()) => {
  const e = At(t);
  return ut(Ec(), e, "iso8601");
}, [Symbol.toStringTag]: "Temporal.Now" };
Object.defineProperty(Pp, Symbol.toStringTag, { value: "Temporal.Now", writable: !1, enumerable: !1, configurable: !0 });
class ea {
  constructor(e = 0, n = 0, r = 0, o = 0, i = 0, a = 0) {
    const c = e === void 0 ? 0 : fe(e), l = n === void 0 ? 0 : fe(n), h = r === void 0 ? 0 : fe(r), m = o === void 0 ? 0 : fe(o), p = i === void 0 ? 0 : fe(i), v = a === void 0 ? 0 : fe(a);
    Ss(c, l, h, m, p, v), Bm(this, { hour: c, minute: l, second: h, millisecond: m, microsecond: p, nanosecond: v });
  }
  get hour() {
    return M(this, Fe), w(this, je).hour;
  }
  get minute() {
    return M(this, Fe), w(this, je).minute;
  }
  get second() {
    return M(this, Fe), w(this, je).second;
  }
  get millisecond() {
    return M(this, Fe), w(this, je).millisecond;
  }
  get microsecond() {
    return M(this, Fe), w(this, je).microsecond;
  }
  get nanosecond() {
    return M(this, Fe), w(this, je).nanosecond;
  }
  with(e, n = void 0) {
    if (M(this, Fe), !Le(e)) throw new TypeError("invalid argument");
    Ro(e);
    const r = vc(e, "partial"), o = vc(this);
    let { hour: i, minute: a, second: c, millisecond: l, microsecond: h, nanosecond: m } = Object.assign(o, r);
    const p = ke(te(n));
    return { hour: i, minute: a, second: c, millisecond: l, microsecond: h, nanosecond: m } = Ps(i, a, c, l, h, m, p), new ea(i, a, c, l, h, m);
  }
  add(e) {
    return M(this, Fe), Ah("add", this, e);
  }
  subtract(e) {
    return M(this, Fe), Ah("subtract", this, e);
  }
  until(e, n = void 0) {
    return M(this, Fe), bh("until", this, e, n);
  }
  since(e, n = void 0) {
    return M(this, Fe), bh("since", this, e, n);
  }
  round(e) {
    if (M(this, Fe), e === void 0) throw new TypeError("options parameter is required");
    const n = typeof e == "string" ? Kr("smallestUnit", e) : te(e), r = xo(n), o = ln(n, "halfExpand"), i = Ot(n, "smallestUnit", "time", Wn);
    return Oo(r, { hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[i], !1), Ln(Pc(w(this, je), r, i, o));
  }
  equals(e) {
    M(this, Fe);
    const n = ar(e);
    return Ac(w(this, je), w(n, je)) === 0;
  }
  toString(e = void 0) {
    M(this, Fe);
    const n = te(e), r = Zi(n), o = ln(n, "trunc"), i = Ot(n, "smallestUnit", "time", void 0);
    if (i === "hour") throw new RangeError('smallestUnit must be a time unit other than "hour"');
    const { precision: a, unit: c, increment: l } = qi(i, r);
    return ch(Pc(w(this, je), l, c, o), a);
  }
  toJSON() {
    return M(this, Fe), ch(w(this, je), "auto");
  }
  toLocaleString(e = void 0, n = void 0) {
    return M(this, Fe), new en(e, n).format(this);
  }
  valueOf() {
    vr("PlainTime");
  }
  static from(e, n = void 0) {
    return ar(e, n);
  }
  static compare(e, n) {
    const r = ar(e), o = ar(n);
    return Ac(w(r, je), w(o, je));
  }
}
Vn(ea, "Temporal.PlainTime");
class hl {
  constructor(e, n, r = "iso8601", o = 1) {
    const i = fe(e), a = fe(n), c = Dt(r === void 0 ? "iso8601" : Be(r)), l = fe(o);
    Ur(i, a, l), Hm(this, { year: i, month: a, day: l }, c);
  }
  get year() {
    return xn(this, "year");
  }
  get month() {
    return xn(this, "month");
  }
  get monthCode() {
    return xn(this, "monthCode");
  }
  get calendarId() {
    return M(this, nt), w(this, K);
  }
  get era() {
    return xn(this, "era");
  }
  get eraYear() {
    return xn(this, "eraYear");
  }
  get daysInMonth() {
    return xn(this, "daysInMonth");
  }
  get daysInYear() {
    return xn(this, "daysInYear");
  }
  get monthsInYear() {
    return xn(this, "monthsInYear");
  }
  get inLeapYear() {
    return xn(this, "inLeapYear");
  }
  with(e, n = void 0) {
    if (M(this, nt), !Le(e)) throw new TypeError("invalid argument");
    Ro(e);
    const r = w(this, K);
    let o = Et(r, w(this, de), "year-month");
    return o = Fr(r, o, Wt(r, e, ["year", "month", "monthCode"], [], "partial")), po(Di(r, o, ke(te(n))), r);
  }
  add(e, n = void 0) {
    return M(this, nt), Eh("add", this, e, n);
  }
  subtract(e, n = void 0) {
    return M(this, nt), Eh("subtract", this, e, n);
  }
  until(e, n = void 0) {
    return M(this, nt), wh("until", this, e, n);
  }
  since(e, n = void 0) {
    return M(this, nt), wh("since", this, e, n);
  }
  equals(e) {
    M(this, nt);
    const n = ui(e);
    return Tn(w(this, de), w(n, de)) === 0 && kn(w(this, K), w(n, K));
  }
  toString(e = void 0) {
    return M(this, nt), dh(this, Ui(te(e)));
  }
  toJSON() {
    return M(this, nt), dh(this);
  }
  toLocaleString(e = void 0, n = void 0) {
    return M(this, nt), new en(e, n).format(this);
  }
  valueOf() {
    vr("PlainYearMonth");
  }
  toPlainDate(e) {
    if (M(this, nt), !Le(e)) throw new TypeError("argument should be an object");
    const n = w(this, K);
    return Pt(fr(n, Fr(n, Et(n, w(this, de), "year-month"), Wt(n, e, ["day"], [], [])), "constrain"), n);
  }
  static from(e, n = void 0) {
    return ui(e, n);
  }
  static compare(e, n) {
    const r = ui(e), o = ui(n);
    return Tn(w(r, de), w(o, de));
  }
}
function xn(t, e) {
  M(t, nt);
  const n = w(t, de);
  return Ki(t).isoToDate(n, { [e]: !0 })[e];
}
Vn(hl, "Temporal.PlainYearMonth");
const GT = en.prototype.resolvedOptions;
class fl {
  constructor(e, n, r = "iso8601") {
    if (arguments.length < 1) throw new TypeError("missing argument: epochNanoseconds is required");
    const o = hs(e);
    let i = Be(n);
    const { tzName: a, offsetMinutes: c } = ur(i);
    if (c === void 0) {
      const l = us(a);
      if (!l) throw new RangeError(`unknown time zone ${a}`);
      i = l.identifier;
    } else i = Xc(c);
    Xm(this, o, i, Dt(r === void 0 ? "iso8601" : Be(r)));
  }
  get calendarId() {
    return M(this, ge), w(this, K);
  }
  get timeZoneId() {
    return M(this, ge), w(this, Pe);
  }
  get year() {
    return mt(this, "year");
  }
  get month() {
    return mt(this, "month");
  }
  get monthCode() {
    return mt(this, "monthCode");
  }
  get day() {
    return mt(this, "day");
  }
  get hour() {
    return so(this, "hour");
  }
  get minute() {
    return so(this, "minute");
  }
  get second() {
    return so(this, "second");
  }
  get millisecond() {
    return so(this, "millisecond");
  }
  get microsecond() {
    return so(this, "microsecond");
  }
  get nanosecond() {
    return so(this, "nanosecond");
  }
  get era() {
    return mt(this, "era");
  }
  get eraYear() {
    return mt(this, "eraYear");
  }
  get epochMilliseconds() {
    return M(this, ge), rn(w(this, le), "floor");
  }
  get epochNanoseconds() {
    return M(this, ge), fp(w(this, le));
  }
  get dayOfWeek() {
    return mt(this, "dayOfWeek");
  }
  get dayOfYear() {
    return mt(this, "dayOfYear");
  }
  get weekOfYear() {
    var e;
    return (e = mt(this, "weekOfYear")) == null ? void 0 : e.week;
  }
  get yearOfWeek() {
    var e;
    return (e = mt(this, "weekOfYear")) == null ? void 0 : e.year;
  }
  get hoursInDay() {
    M(this, ge);
    const e = w(this, Pe), n = fn(this).isoDate, r = $t(n.year, n.month, n.day + 1), o = or(e, n), i = or(e, r);
    return bi(ve.fromEpochNsDiff(i, o), "hour");
  }
  get daysInWeek() {
    return mt(this, "daysInWeek");
  }
  get daysInMonth() {
    return mt(this, "daysInMonth");
  }
  get daysInYear() {
    return mt(this, "daysInYear");
  }
  get monthsInYear() {
    return mt(this, "monthsInYear");
  }
  get inLeapYear() {
    return mt(this, "inLeapYear");
  }
  get offset() {
    return M(this, ge), yc(Gn(w(this, Pe), w(this, le)));
  }
  get offsetNanoseconds() {
    return M(this, ge), Gn(w(this, Pe), w(this, le));
  }
  with(e, n = void 0) {
    if (M(this, ge), !Le(e)) throw new TypeError("invalid zoned-date-time-like");
    Ro(e);
    const r = w(this, K), o = w(this, Pe), i = Gn(o, w(this, le)), a = fn(this);
    let c = { ...Et(r, a.isoDate), ...a.time, offset: yc(i) };
    c = Fr(r, c, Wt(r, e, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset"], "partial"));
    const l = te(n), h = yi(l), m = Za(l, "prefer"), p = Wi(r, c, ke(l)), v = Mo(c.offset);
    return ut(as(p.isoDate, p.time, "option", v, o, h, m, !1), o, r);
  }
  withPlainTime(e = void 0) {
    M(this, ge);
    const n = w(this, Pe), r = w(this, K), o = fn(this).isoDate;
    let i;
    return i = e === void 0 ? or(n, o) : lt(n, Te(o, w(ar(e), je)), "compatible"), ut(i, n, r);
  }
  withTimeZone(e) {
    M(this, ge);
    const n = At(e);
    return ut(w(this, le), n, w(this, K));
  }
  withCalendar(e) {
    M(this, ge);
    const n = Vi(e);
    return ut(w(this, le), w(this, Pe), n);
  }
  add(e, n = void 0) {
    return M(this, ge), Sh("add", this, e, n);
  }
  subtract(e, n = void 0) {
    return M(this, ge), Sh("subtract", this, e, n);
  }
  until(e, n = void 0) {
    return M(this, ge), kh("until", this, e, n);
  }
  since(e, n = void 0) {
    return M(this, ge), kh("since", this, e, n);
  }
  round(e) {
    if (M(this, ge), e === void 0) throw new TypeError("options parameter is required");
    const n = typeof e == "string" ? Kr("smallestUnit", e) : te(e), r = xo(n), o = ln(n, "halfExpand"), i = Ot(n, "smallestUnit", "time", Wn, ["day"]), a = { day: 1, hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[i];
    if (Oo(r, a, a === 1), i === "nanosecond" && r === 1) return ut(w(this, le), w(this, Pe), w(this, K));
    const c = w(this, Pe), l = w(this, le), h = fn(this);
    let m;
    if (i === "day") {
      const p = h.isoDate, v = $t(p.year, p.month, p.day + 1), k = or(c, p), P = or(c, v), A = y.subtract(P, k);
      m = ve.fromEpochNsDiff(l, k).round(A, o).addToEpochNs(k);
    } else {
      const p = Cc(h, r, i, o), v = Gn(c, l);
      m = as(p.isoDate, p.time, "option", v, c, "compatible", "prefer", !1);
    }
    return ut(m, c, w(this, K));
  }
  equals(e) {
    M(this, ge);
    const n = ci(e), r = w(this, le), o = w(n, le);
    return !!y.equal(y.BigInt(r), y.BigInt(o)) && !!Jm(w(this, Pe), w(n, Pe)) && kn(w(this, K), w(n, K));
  }
  toString(e = void 0) {
    M(this, ge);
    const n = te(e), r = Ui(n), o = Zi(n), i = (function(v) {
      return Zn(v, "offset", ["auto", "never"], "auto");
    })(n), a = ln(n, "trunc"), c = Ot(n, "smallestUnit", "time", void 0);
    if (c === "hour") throw new RangeError('smallestUnit must be a time unit other than "hour"');
    const l = (function(v) {
      return Zn(v, "timeZoneName", ["auto", "never", "critical"], "auto");
    })(n), { precision: h, unit: m, increment: p } = qi(c, o);
    return hh(this, h, r, l, i, { unit: m, increment: p, roundingMode: a });
  }
  toLocaleString(e = void 0, n = void 0) {
    M(this, ge);
    const r = te(n), o = /* @__PURE__ */ Object.create(null);
    if ((function(l, h, m, p) {
      if (h == null) return;
      const v = Reflect.ownKeys(h);
      for (let k = 0; k < v.length; k++) {
        const P = v[k];
        if (!m.some(((A) => Object.is(A, P))) && Object.prototype.propertyIsEnumerable.call(h, P)) {
          const A = h[P];
          l[P] = A;
        }
      }
    })(o, r, ["timeZone"]), r.timeZone !== void 0) throw new TypeError("ZonedDateTime toLocaleString does not accept a timeZone option");
    if (o.year === void 0 && o.month === void 0 && o.day === void 0 && o.era === void 0 && o.weekday === void 0 && o.dateStyle === void 0 && o.hour === void 0 && o.minute === void 0 && o.second === void 0 && o.fractionalSecondDigits === void 0 && o.timeStyle === void 0 && o.dayPeriod === void 0 && o.timeZoneName === void 0 && (o.timeZoneName = "short"), o.timeZone = w(this, Pe), fh(o.timeZone)) throw new RangeError("toLocaleString does not currently support offset time zones");
    const i = new en(e, o), a = GT.call(i).calendar, c = w(this, K);
    if (c !== "iso8601" && a !== "iso8601" && !kn(a, c)) throw new RangeError(`cannot format ZonedDateTime with calendar ${c} in locale with calendar ${a}`);
    return i.format(gn(w(this, le)));
  }
  toJSON() {
    return M(this, ge), hh(this, "auto");
  }
  valueOf() {
    vr("ZonedDateTime");
  }
  startOfDay() {
    M(this, ge);
    const e = w(this, Pe);
    return ut(or(e, fn(this).isoDate), e, w(this, K));
  }
  getTimeZoneTransition(e) {
    M(this, ge);
    const n = w(this, Pe);
    if (e === void 0) throw new TypeError("options parameter is required");
    const r = Zn(typeof e == "string" ? Kr("direction", e) : te(e), "direction", ["next", "previous"], Wn);
    if (r === void 0) throw new TypeError("direction option is required");
    if (fh(n) || n === "UTC") return null;
    const o = w(this, le), i = r === "next" ? el(n, o) : wc(n, o);
    return i === null ? null : ut(i, n, w(this, K));
  }
  toInstant() {
    return M(this, ge), gn(w(this, le));
  }
  toPlainDate() {
    return M(this, ge), Pt(fn(this).isoDate, w(this, K));
  }
  toPlainTime() {
    return M(this, ge), Ln(fn(this).time);
  }
  toPlainDateTime() {
    return M(this, ge), Xt(fn(this), w(this, K));
  }
  static from(e, n = void 0) {
    return ci(e, n);
  }
  static compare(e, n) {
    const r = ci(e), o = ci(n), i = w(r, le), a = w(o, le);
    return y.lessThan(y.BigInt(i), y.BigInt(a)) ? -1 : y.greaterThan(y.BigInt(i), y.BigInt(a)) ? 1 : 0;
  }
}
function fn(t) {
  return nn(w(t, Pe), w(t, le));
}
function mt(t, e) {
  M(t, ge);
  const n = fn(t).isoDate;
  return Ki(t).isoToDate(n, { [e]: !0 })[e];
}
function so(t, e) {
  return M(t, ge), fn(t).time[e];
}
Vn(fl, "Temporal.ZonedDateTime");
var ta = Object.freeze({ __proto__: null, Duration: Do, Instant: ul, Now: Pp, PlainDate: cl, PlainDateTime: ll, PlainMonthDay: dl, PlainTime: ea, PlainYearMonth: hl, ZonedDateTime: fl });
const FT = [ul, cl, ll, Do, dl, ea, hl, fl];
for (const t of FT) {
  const e = Object.getOwnPropertyDescriptor(t, "prototype");
  (e.configurable || e.enumerable || e.writable) && (e.configurable = !1, e.enumerable = !1, e.writable = !1, Object.defineProperty(t, "prototype", e));
}
const Rr = 6e4, Ht = (t) => new Date(t).toISOString();
function UT(t, e) {
  return ta.Instant.fromEpochMilliseconds(t).toZonedDateTimeISO(e).toPlainDate().toString();
}
function Sc(t, e) {
  return ta.PlainDate.from(t).add({ days: e }).toString();
}
function zh(t, e, n, r = !1) {
  return ta.PlainDateTime.from(`${t}T${e}`).toZonedDateTime(n, { disambiguation: r ? "reject" : "compatible" }).epochMilliseconds;
}
function ZT(t, e) {
  return { start: zh(t, e.start, e.timeZone), end: zh(e.end < e.start ? Sc(t, 1) : t, e.end, e.timeZone), working: e.workingDays.includes(ta.PlainDate.from(t).dayOfWeek) };
}
function qT(t, e) {
  return ta.Instant.fromEpochMilliseconds(new Date(t).getTime()).toZonedDateTimeISO(e).toPlainTime().toString({ smallestUnit: "minute" });
}
function KT(t) {
  const e = t.settings;
  return JSON.stringify({ settings: { timeZone: e.timeZone, start: e.start, end: e.end, workingDays: e.workingDays, lunchEnabled: e.lunchEnabled, lunchStart: e.lunchStart, lunchMinutes: e.lunchMinutes, breaks: e.breaks }, tasks: [...t.tasks].sort((n, r) => n.id.localeCompare(r.id)).map((n) => ({ id: n.id, title: n.title, priority: n.priority, status: ["todo", "paused", "in_progress"].includes(n.status) ? "active" : n.status, estimatedMinutes: n.estimatedMinutes, actualSeconds: n.actualSeconds, deadline: n.deadline, scheduledDate: n.scheduledDate, dependencyIds: n.dependencyIds, completedAt: n.completedAt })), events: [...t.events].sort((n, r) => n.id.localeCompare(r.id)) });
}
ys({ title: Ue().trim().min(1).max(200), start: ic(), end: ic(), timeZone: Ue() }).refine((t) => Date.parse(t.end) > Date.parse(t.start), "Meeting end must be after its start.");
function WT(t, e) {
  if (!e.quietEnabled) return !1;
  const n = qT(t, e.timeZone);
  return e.quietStart === e.quietEnd || (e.quietStart < e.quietEnd ? n >= e.quietStart && n < e.quietEnd : n >= e.quietStart || n < e.quietEnd);
}
function YT(t, e) {
  const { settings: n, plans: r, blocks: o, tasks: i, events: a, sessions: c } = t, l = [], h = n.reminderLeadMinutes * Rr, m = (v) => {
    Date.parse(v.expiresAt) > e && l.push(v);
  }, p = r.filter((v) => v.signature === KT(t));
  for (const v of o.filter((k) => p.some((P) => P.date === k.planDate))) {
    const k = i.find((S) => S.id === v.taskId), P = Date.parse(v.start), A = Date.parse(v.end);
    v.kind === "task" && k && !["completed", "deferred"].includes(k.status) && (n.taskReminders && m({ id: `start:${v.id}`, kind: "task", at: Ht(P - h), expiresAt: Ht(Math.min(A, P + 5 * Rr)), taskId: k.id, blockId: v.id, date: v.planDate, title: "Time to focus", message: k.title }), m({ id: `end:${v.id}:${A}`, kind: "checkin", at: v.end, expiresAt: Ht(A + 30 * Rr), taskId: k.id, blockId: v.id, date: v.planDate, title: "How is this task going?", message: k.title })), v.kind === "break" && n.breakReminders && m({ id: `start:${v.id}`, kind: "break", at: v.start, expiresAt: Ht(Math.min(A, P + 5 * Rr)), blockId: v.id, date: v.planDate, title: "Take a break", message: v.title ?? "Break time" });
  }
  if (n.meetingReminders) for (const v of a.filter((k) => k.busy)) m({ id: `meeting:${v.id}:${v.start}`, kind: "meeting", at: Ht(Date.parse(v.start) - h), expiresAt: Ht(Math.min(Date.parse(v.end), Date.parse(v.start) + 5 * Rr)), blockId: `meeting:${v.id}`, title: "Upcoming meeting", message: v.title });
  if (n.workdayReminders) {
    const v = UT(e, n.timeZone), k = /* @__PURE__ */ new Set([Sc(v, -1), v, Sc(v, 1)]);
    for (const P of k) {
      const A = ZT(P, n);
      A.working && m({ id: `workend:${P}:${Ht(A.end)}`, kind: "end", at: Ht(A.end), expiresAt: Ht(A.end + 15 * Rr), date: P, title: "Your workday is ending", message: "Review your progress and leave unfinished tasks for another day." });
    }
  }
  if (n.checkInMinutes > 0) for (const v of c.filter((k) => !k.endedAt)) {
    const k = i.find((S) => S.id === v.taskId);
    if (!k || k.status !== "in_progress") continue;
    const P = n.checkInMinutes * Rr, A = Math.max(1, Math.floor((e - Date.parse(v.startedAt)) / P));
    for (const S of [A, A + 1]) {
      const z = Date.parse(v.startedAt) + S * P;
      m({ id: `focus:${v.id}:${S}`, sessionId: v.id, kind: "checkin", at: Ht(z), expiresAt: Ht(z + P), taskId: k.id, title: "How is this task going?", message: k.title });
    }
  }
  return l.sort((v, k) => v.at.localeCompare(k.at));
}
async function VT(t, e = Vc, n = Date.now()) {
  const r = await e.transaction("r", e.tables, async () => ({ settings: await M_(e), tasks: await e.tasks.toArray(), blocks: await e.blocks.toArray(), plans: await e.plans.toArray(), sessions: await e.sessions.toArray(), events: await e.events.toArray() })), o = YT(r, n);
  await e.transaction("rw", e.reminders, async () => {
    const l = new Set(o.map((h) => h.id));
    for (const h of await e.reminders.toArray())
      (!l.has(h.id) && !h.deliveredAt && !h.handledAt || Date.parse(h.expiresAt) < n - 7 * 864e5) && await e.reminders.delete(h.id);
    for (const h of o) {
      const m = await e.reminders.get(h.id);
      await e.reminders.put({ ...h, deliveredAt: m == null ? void 0 : m.deliveredAt, handledAt: m == null ? void 0 : m.handledAt, deliveryError: m == null ? void 0 : m.deliveryError });
    }
  });
  const i = (await e.reminders.toArray()).filter((l) => !l.deliveredAt && !l.handledAt && o.some((h) => h.id === l.id)), a = i.filter((l) => Date.parse(l.at) > n).slice(0, 400), c = new Set(a.map((l) => `wd:${l.id}`));
  for (const l of await t.listAlarms()) l.startsWith("wd:") && !c.has(l) && await t.clearAlarm(l);
  for (const l of a) await t.setAlarm(`wd:${l.id}`, Date.parse(l.at));
  for (const l of i.filter((h) => Date.parse(h.at) <= n && Date.parse(h.expiresAt) > n))
    if (await e.transaction("rw", e.reminders, async () => {
      const m = await e.reminders.get(l.id);
      return !m || m.deliveredAt ? !1 : (await e.reminders.update(l.id, { deliveredAt: Ht(n) }), !0);
    }) && r.settings.notificationsEnabled && !WT(n, r.settings)) {
      const m = `${l.message}${l.kind === "checkin" ? " — open Workday for Completed, Need more time, Pause or Skip." : ""}`;
      try {
        r.settings.popupReminders !== !1 && t.popup ? await t.popup(l.title, m) : await t.notify(`wd:${l.id}`, l.title, m, l.kind === "checkin");
      } catch {
        await e.reminders.update(l.id, { deliveryError: "Reminder delivery failed. Check browser and OS notification permissions." });
      }
    }
}
const BT = "Recharger", HT = "Fermer", QT = "Catégorie", XT = "Description", JT = "Notes", eC = "Priorité", tC = "Haute", nC = "Moyenne", rC = "Basse", oC = "Statut", iC = "Annuler", aC = "Tâches", sC = "Aujourd’hui", uC = "Terminées", cC = "Rouvrir", lC = "Terminer", dC = "min", hC = "Échéance", fC = "Modifier", mC = "Reporter", pC = "Supprimer", gC = "Paramètres", vC = "Apparence", yC = "Langue", bC = "Conversation", wC = "Vous", kC = "Envoyer", _C = "Aucun", TC = "Tâche", CC = "Connecté", PC = "Pause", AC = "Reprendre", EC = "Se concentrer", SC = "Planning", DC = "Engagement", IC = "Réunions", zC = "Fuseau horaire", RC = "Lun", xC = "Mar", OC = "Mer", MC = "Jeu", $C = "Ven", NC = "Sam", jC = "Dim", LC = "Retirer", GC = "Rappels", FC = "En pause", UC = "Reportée", ZC = "à faire", qC = "en pause", KC = "terminée", WC = "reportée", YC = "haute", VC = "moyenne", BC = "basse", HC = "développement", QC = "révision", XC = "rédaction", JC = "planification", e1 = "communication", t1 = "autre", n1 = "tâche", r1 = "réunion", o1 = "sombre", i1 = "clair", a1 = "Titre", s1 = "Échéance", u1 = "Prérequis", c1 = "Début", l1 = "Fin", d1 = "Déjeuner", h1 = {
  "Unable to open Workday": "Impossible d’ouvrir Workday",
  "Your data has not been deleted. Reload the panel to try again.": "Vos données n’ont pas été supprimées. Rechargez le panneau pour réessayer.",
  Reload: BT,
  Dismiss: HT,
  "Open Workday": "Ouvrir Workday",
  "Edit task": "Modifier la tâche",
  "New task": "Nouvelle tâche",
  "Close task editor": "Fermer l’éditeur de tâche",
  "Task title": "Titre de la tâche",
  "What needs your attention?": "Qu’est-ce qui demande votre attention ?",
  Category: QT,
  Description: XT,
  Notes: JT,
  "Anything you don’t want to forget": "Tout ce que vous ne voulez pas oublier",
  Priority: eC,
  High: tC,
  Medium: nC,
  Low: rC,
  "Estimate · minutes": "Estimation · minutes",
  "Scheduled date": "Date prévue",
  Status: oC,
  "Deadline ({zone})": "Échéance ({zone})",
  "Dependencies (optional)": "Dépendances (facultatif)",
  "Missing prerequisite ({id}) — uncheck to remove": "Prérequis manquant ({id}) — décochez pour le retirer",
  Cancel: iC,
  "Saving…": "Enregistrement…",
  "Save task": "Enregistrer la tâche",
  "Local data exported.": "Données locales exportées.",
  "Main navigation": "Navigation principale",
  "Local storage unavailable: {error}. Reload the panel to retry.": "Stockage local indisponible : {error}. Rechargez le panneau pour réessayer.",
  "Dismiss message": "Fermer le message",
  "Day off": "Jour de repos",
  "Before work": "Avant le travail",
  "Workday ended": "Journée terminée",
  "Workday in progress": "Journée en cours",
  "Daily task progress": "Progression des tâches du jour",
  "{done} of {total} done": "{done} sur {total} terminées",
  "{minutes} min left": "{minutes} min restantes",
  "{done} of {total} tasks completed": "{done} tâches terminées sur {total}",
  Tasks: aC,
  "Add task": "Ajouter une tâche",
  "Filter tasks": "Filtrer les tâches",
  Today: sC,
  "All tasks": "Toutes les tâches",
  Completed: uC,
  "Loading local tasks…": "Chargement des tâches locales…",
  "Your wins will appear here": "Vos réussites apparaîtront ici",
  "Make room for your best work": "Faites de la place pour votre meilleur travail",
  "Add your first task for today. Keep it small, give it an estimate, and take it from there.": "Ajoutez votre première tâche du jour. Gardez-la petite, donnez-lui une estimation et avancez à partir de là.",
  "Create a task to get started.": "Créez une tâche pour commencer.",
  "Create a task": "Créer une tâche",
  Reopen: cC,
  Complete: lC,
  "Task reopened.": "Tâche rouverte.",
  "Task completed.": "Tâche terminée.",
  min: dC,
  Due: hC,
  Edit: fC,
  "Task deferred.": "Tâche reportée.",
  Defer: mC,
  Delete: pC,
  "Delete this task and its work records?": "Supprimer cette tâche et ses enregistrements de travail ?",
  "Task deleted.": "Tâche supprimée.",
  "Delete task": "Supprimer la tâche",
  "Ask AI to adjust my day": "Demander à l’IA d’ajuster ma journée",
  Settings: gC,
  Appearance: vC,
  "Color theme": "Thème de couleur",
  Language: yC,
  "Display language": "Langue d’affichage",
  "Same as browser": "Identique au navigateur",
  "The assistant also replies in this language.": "L’assistant répond aussi dans cette langue.",
  "Your data": "Vos données",
  "Everything is saved in this browser on this device and works offline. Uninstalling the extension or clearing browser data removes it.": "Tout est enregistré dans ce navigateur, sur cet appareil, et fonctionne hors ligne. Désinstaller l’extension ou effacer les données du navigateur les supprime.",
  "Export local data": "Exporter les données locales",
  "Exports contain tasks and work records, never keys or sign-ins.": "Les exports contiennent les tâches et les enregistrements de travail, jamais les clés ni les connexions.",
  "Delete all local data": "Supprimer toutes les données locales",
  "Permanently delete all tasks, work records, chats and AI settings, and sign out of ChatGPT? Export a backup first if you need one.": "Supprimer définitivement toutes les tâches, les enregistrements de travail, les conversations et les paramètres d’IA, et vous déconnecter de ChatGPT ? Exportez d’abord une sauvegarde si nécessaire.",
  "All task and work records deleted.": "Toutes les tâches et tous les enregistrements de travail ont été supprimés.",
  "Delete permanently": "Supprimer définitivement",
  "AI Chat": "Chat IA",
  "Back to Today": "Retour à Aujourd’hui",
  "Clear chat": "Effacer la conversation",
  "Connect your ChatGPT account, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Connectez votre compte ChatGPT, choisissez un modèle et activez le partage de données dans les Paramètres. La planification manuelle fonctionne sans IA.",
  "Connect your own {provider} API key, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Ajoutez votre propre clé API {provider}, choisissez un modèle et activez le partage de données dans les Paramètres. La planification manuelle fonctionne sans IA.",
  "Configure AI": "Configurer l’IA",
  "Using ChatGPT plan ·": "Forfait ChatGPT utilisé ·",
  "Manage usage": "Gérer l’utilisation",
  "You’re offline. Saved conversations and manual planning remain available; sending needs a connection.": "Vous êtes hors ligne. Les conversations enregistrées et la planification manuelle restent disponibles ; l’envoi nécessite une connexion.",
  "{provider} · Model: {model}": "{provider} · Modèle : {model}",
  "Chat options": "Options du chat",
  "Task changes require your approval.": "Les modifications de tâches nécessitent votre approbation.",
  "Planning date": "Date de planification",
  "Task context": "Contexte des tâches",
  "This day, next day & unscheduled": "Ce jour, le lendemain et les tâches non planifiées",
  "All dates (up to 80 tasks + prerequisites)": "Toutes les dates (jusqu’à 80 tâches + prérequis)",
  "Include task descriptions and notes (up to 500 characters each)": "Inclure les descriptions et les notes des tâches (500 caractères maximum chacune)",
  "Include meeting titles, so the assistant can find a meeting by name": "Inclure les titres des réunions, pour que l’assistant puisse retrouver une réunion par son nom",
  "Each request sends up to 80 tasks, your meeting times, work hours and your six most recent messages with this provider. Webpages are never sent.": "Chaque demande envoie jusqu’à 80 tâches, les horaires de vos réunions, vos heures de travail et vos six derniers messages avec ce fournisseur. Les pages web ne sont jamais envoyées.",
  Conversation: bC,
  "Tell me what’s on your plate. I’ll suggest task changes for you to approve.": "Dites-moi ce que vous avez à faire. Je proposerai des modifications de tâches que vous pourrez approuver.",
  "Plan my day.": "Planifie ma journée.",
  "What should I work on next?": "Sur quoi devrais-je travailler ensuite ?",
  "What tasks have I not completed?": "Quelles tâches n’ai-je pas terminées ?",
  You: wC,
  "Thinking…": "Réflexion…",
  "Interrupted or pending request. Retry with the latest context.": "Demande interrompue ou en attente. Réessayez avec le contexte le plus récent.",
  "Request cancelled.": "Demande annulée.",
  "Retry request": "Réessayer la demande",
  " · retried once": " · une nouvelle tentative",
  "Message to AI": "Message à l’IA",
  "What would you like to plan?": "Que souhaitez-vous planifier ?",
  "Shift+Enter for a new line": "Maj+Entrée pour une nouvelle ligne",
  "Cancel request": "Annuler la demande",
  Send: kC,
  "Clear conversation": "Effacer la conversation",
  "Delete this provider’s local conversation and proposals? Other conversations, approved tasks and schedules will remain.": "Supprimer la conversation et les propositions locales de ce fournisseur ? Les autres conversations, les tâches approuvées et les plannings seront conservés.",
  "Unable to clear chat.": "Impossible d’effacer la conversation.",
  "Delete chat": "Supprimer la conversation",
  None: _C,
  "Missing prerequisite": "Prérequis manquant",
  "AI change proposal": "Proposition de modification de l’IA",
  "Changes approved": "Modifications approuvées",
  "Proposal rejected": "Proposition rejetée",
  "Review proposed changes": "Vérifier les modifications proposées",
  "Nothing has been applied. Preview expires after 60 seconds; refresh it if needed. The local scheduler rechecks times at approval.": "Rien n’a été appliqué. L’aperçu expire après 60 secondes ; actualisez-le si nécessaire. Le planificateur local revérifie les horaires lors de l’approbation.",
  "AI proposed schedule": "Planning proposé par l’IA",
  "Showing 200 of {count} blocks. Use Today after approval for the full timeline.": "Affichage de 200 blocs sur {count}. Consultez Aujourd’hui après approbation pour le planning complet.",
  "Overflow · {count} task(s)": "Dépassement · {count} tâche(s)",
  Task: TC,
  "Approve changes": "Approuver les modifications",
  "Reject changes": "Rejeter les modifications",
  "Refresh preview": "Actualiser l’aperçu",
  "Tasks and affected schedules were saved together.": "Les tâches et les plannings concernés ont été enregistrés ensemble.",
  "No task or schedule changes were applied.": "Aucune modification de tâche ou de planning n’a été appliquée.",
  "View Today": "Voir Aujourd’hui",
  "AI provider settings": "Paramètres du fournisseur d’IA",
  "AI assistant": "Assistant IA",
  "Assistant name": "Nom de l’assistant",
  "Shown in chat, and the assistant answers to it. Saved as you type.": "Affiché dans le chat, et l’assistant y répond. Enregistré pendant la saisie.",
  "AI provider": "Fournisseur d’IA",
  "{provider} selected. Each provider keeps its own settings and conversation.": "{provider} sélectionné. Chaque fournisseur conserve ses propres paramètres et sa propre conversation.",
  "Unable to switch AI provider. Please retry.": "Impossible de changer de fournisseur d’IA. Veuillez réessayer.",
  "Retrieved {count} models from {provider}. Select a model and save.": "{count} modèles récupérés auprès de {provider}. Sélectionnez un modèle et enregistrez.",
  "{provider} settings saved. Send a request in AI Chat to test the selected model.": "Paramètres {provider} enregistrés. Envoyez une demande dans le Chat IA pour tester le modèle sélectionné.",
  "Unable to save AI settings. Check the model ID and key (16–512 characters, no spaces).": "Impossible d’enregistrer les paramètres d’IA. Vérifiez l’identifiant du modèle et la clé (16 à 512 caractères, sans espaces).",
  "{provider} settings": "Paramètres {provider}",
  "Uses your own API key, saved only in this extension on this device.": "Utilise votre propre clé API, enregistrée uniquement dans cette extension sur cet appareil.",
  " To sign in with a ChatGPT subscription instead, choose ChatGPT plan above.": " Pour vous connecter avec un abonnement ChatGPT, choisissez plutôt Forfait ChatGPT ci-dessus.",
  " Get a key from the Anthropic Console. A Claude subscription cannot be used here.": " Obtenez une clé dans la Console Anthropic. Un abonnement Claude ne peut pas être utilisé ici.",
  "{provider} API key": "Clé API {provider}",
  "Saved key · enter a replacement": "Clé enregistrée · saisissez-en une nouvelle pour la remplacer",
  "Enter your own {provider} key": "Saisissez votre propre clé {provider}",
  "A key is saved on this device.": "Une clé est enregistrée sur cet appareil.",
  "No API key saved.": "Aucune clé API enregistrée.",
  "Working…": "En cours…",
  "Refresh models": "Actualiser les modèles",
  "{provider} key removed and sharing disabled. Other providers are unchanged.": "Clé {provider} supprimée et partage désactivé. Les autres fournisseurs sont inchangés.",
  "Unable to remove the saved key. Please retry.": "Impossible de supprimer la clé enregistrée. Veuillez réessayer.",
  "Forget key": "Oublier la clé",
  "Show free models only": "Afficher uniquement les modèles gratuits",
  "Find a model": "Rechercher un modèle",
  "Search name or ID": "Rechercher par nom ou identifiant",
  "Discovered model": "Modèle détecté",
  "Choose a model…": "Choisissez un modèle…",
  " · Free": " · Gratuit",
  " · Paid": " · Payant",
  "Model ID": "Identifiant du modèle",
  "Select above or enter a model ID": "Sélectionnez ci-dessus ou saisissez un identifiant de modèle",
  "Free model; account limits still apply.": "Modèle gratuit ; les limites du compte s’appliquent toujours.",
  "Paid model · prompt {prompt} / completion {completion} USD per token.": "Modèle payant · entrée {prompt} / sortie {completion} USD par jeton.",
  "Requests may be billed by {provider}. Check pricing in your provider account.": "Les demandes peuvent être facturées par {provider}. Vérifiez les tarifs dans votre compte fournisseur.",
  "Save AI settings": "Enregistrer les paramètres d’IA",
  "What gets shared?": "Qu’est-ce qui est partagé ?",
  "Each request sends task summaries, work hours, meeting times and your recent conversation with this provider. Meeting titles are sent unless you turn that off in Chat options; task descriptions and notes are sent only if you turn that on. Webpages and saved keys are never sent. An invalid answer may trigger one automatic retry, which can cost extra. There is no automatic switch to another provider or a paid model.": "Chaque demande envoie un résumé des tâches, vos heures de travail, les horaires de vos réunions et votre conversation récente avec ce fournisseur. Les titres des réunions sont envoyés, sauf si vous désactivez cette option dans les Options du chat ; les descriptions et les notes des tâches ne sont envoyées que si vous l’activez. Les pages web et les clés enregistrées ne sont jamais envoyées. Une réponse non valide peut déclencher une nouvelle tentative automatique, qui peut entraîner un coût supplémentaire. Il n’y a pas de bascule automatique vers un autre fournisseur ou un modèle payant.",
  "ChatGPT connected. Choose a model and allow sharing to finish.": "ChatGPT connecté. Choisissez un modèle et autorisez le partage pour terminer.",
  "ChatGPT plan settings": "Paramètres du forfait ChatGPT",
  "ChatGPT plan": "Forfait ChatGPT",
  "Use your ChatGPT subscription instead of an API key. Availability depends on your plan, workspace and region.": "Utilisez votre abonnement ChatGPT au lieu d’une clé API. La disponibilité dépend de votre forfait, de votre espace de travail et de votre région.",
  "Finish signing in in the browser tab that opened, then come back here.": "Terminez la connexion dans l’onglet du navigateur qui s’est ouvert, puis revenez ici.",
  "Cancel sign-in": "Annuler la connexion",
  "Continue with ChatGPT": "Continuer avec ChatGPT",
  Connected: CC,
  "Plan access off": "Accès au forfait désactivé",
  "Signed out": "Déconnecté",
  " · In use": " · Utilisé",
  "Use account": "Utiliser ce compte",
  "Enable plan access": "Activer l’accès au forfait",
  "Sign in again": "Se reconnecter",
  "Sign out": "Se déconnecter",
  "You’re using your ChatGPT plan": "Vous utilisez votre forfait ChatGPT",
  "Got it": "Compris",
  "ChatGPT is ready. Open AI Chat to start.": "ChatGPT est prêt. Ouvrez le Chat IA pour commencer.",
  "ChatGPT model": "Modèle ChatGPT",
  "Refresh ChatGPT models": "Actualiser les modèles ChatGPT",
  "Allow sending my requests, selected workday context and this account’s recent chat to OpenAI using my ChatGPT plan.": "Autoriser l’envoi de mes demandes, du contexte de journée sélectionné et de la conversation récente de ce compte à OpenAI avec mon forfait ChatGPT.",
  "Save ChatGPT settings": "Enregistrer les paramètres ChatGPT",
  "Task changes always wait for your approval.": "Les modifications de tâches attendent toujours votre approbation.",
  "Sign-in runs inside the extension; there is nothing else to install. Your ChatGPT session is saved in this extension’s private storage in this browser profile until you sign out. Signing out removes the account, its saved details and its conversation from this extension.": "La connexion se fait dans l’extension ; il n’y a rien d’autre à installer. Votre session ChatGPT est enregistrée dans le stockage privé de cette extension, dans ce profil de navigateur, jusqu’à votre déconnexion. La déconnexion supprime de cette extension le compte, ses informations enregistrées et sa conversation.",
  "Focus timer": "Minuteur de concentration",
  "Focusing now": "Concentration en cours",
  "Focus paused": "Concentration en pause",
  "{time} remaining": "{time} restantes",
  "{time} over estimate": "{time} au-delà de l’estimation",
  "Focus paused.": "Concentration mise en pause.",
  "Focus resumed.": "Concentration reprise.",
  Pause: PC,
  Resume: AC,
  "Task completed. Preview the plan to reuse the free time.": "Tâche terminée. Prévisualisez le plan pour réutiliser le temps libéré.",
  "Focus started.": "Concentration démarrée.",
  Focus: EC,
  "Meeting editor": "Éditeur de réunion",
  "Edit meeting": "Modifier la réunion",
  "New meeting": "Nouvelle réunion",
  "Close meeting editor": "Fermer l’éditeur de réunion",
  "Times in {zone}": "Heures en {zone}",
  "Meeting title": "Titre de la réunion",
  "Meeting starts": "Début de la réunion",
  "Meeting ends": "Fin de la réunion",
  "Save meeting": "Enregistrer la réunion",
  "Loading your schedule…": "Chargement de votre planning…",
  "Plan approved and saved.": "Plan approuvé et enregistré.",
  "Day planner": "Planificateur de journée",
  "Meeting now": "Réunion en cours",
  "Next meeting": "Prochaine réunion",
  "How is this task going?": "Comment avance cette tâche ?",
  "Need more time (+30m)": "Besoin de plus de temps (+30 min)",
  "Skip for now": "Ignorer pour l’instant",
  Schedule: SC,
  "Planning…": "Planification…",
  "Preview plan": "Prévisualiser le plan",
  "Plan date": "Date du plan",
  " (next day)": " (le lendemain)",
  "Tasks or constraints changed. Preview and approve an updated plan before following this timeline.": "Les tâches ou les contraintes ont changé. Prévisualisez et approuvez un plan à jour avant de suivre ce planning.",
  "Review your proposed plan": "Vérifiez le plan proposé",
  "Includes 30 more minutes for the selected task. ": "Inclut 30 minutes de plus pour la tâche sélectionnée. ",
  "Nothing is saved until you approve. This preview expires in 60 seconds.": "Rien n’est enregistré tant que vous n’avez pas approuvé. Cet aperçu expire dans 60 secondes.",
  "Approve plan": "Approuver le plan",
  "Reject plan": "Rejeter le plan",
  "Proposed schedule": "Planning proposé",
  "Approved schedule": "Planning approuvé",
  Commitment: DC,
  "No schedule yet. Preview a plan to fit tasks around meetings and breaks.": "Pas encore de planning. Prévisualisez un plan pour placer les tâches autour des réunions et des pauses.",
  "Doesn’t fit in this workday": "Ne tient pas dans cette journée de travail",
  "Shorten a task, change your hours, or move a task to {date}.": "Raccourcissez une tâche, modifiez vos horaires ou déplacez une tâche au {date}.",
  Meetings: IC,
  "Add meeting": "Ajouter une réunion",
  "Meeting saved. Review the updated plan.": "Réunion enregistrée. Vérifiez le plan mis à jour.",
  "No meetings for this day.": "Aucune réunion ce jour-là.",
  "Delete meeting": "Supprimer la réunion",
  "Delete this meeting?": "Supprimer cette réunion ?",
  "Meeting deleted. Review the updated plan.": "Réunion supprimée. Vérifiez le plan mis à jour.",
  "System notifications could not be delivered. Check Windows notification settings for Microsoft Edge; your schedule and check-ins remain available here.": "Les notifications système n’ont pas pu être affichées. Vérifiez les paramètres de notification Windows pour Microsoft Edge ; votre planning et vos points d’étape restent disponibles ici.",
  " · now": " · maintenant",
  "Reminders only pop up in the installed extension.": "Les rappels ne s’affichent que dans l’extension installée.",
  "Workday reminders are on": "Les rappels Workday sont activés",
  "Reminders and check-ins will appear like this.": "Les rappels et les points d’étape apparaîtront ainsi.",
  "A reminder window should have opened.": "Une fenêtre de rappel devrait s’être ouverte.",
  "Sent to Windows. If nothing appeared, Windows is blocking notifications from Microsoft Edge (Settings → System → Notifications, or Do not disturb). Switch on “Pop up in a browser window” above to avoid that.": "Envoyé à Windows. Si rien n’est apparu, Windows bloque les notifications de Microsoft Edge (Paramètres → Système → Notifications, ou Ne pas déranger). Activez « Afficher dans une fenêtre du navigateur » ci-dessus pour l’éviter.",
  "The reminder could not be shown. Try the other reminder style.": "Le rappel n’a pas pu être affiché. Essayez l’autre style de rappel.",
  "Workday settings saved. Preview your schedule to apply changed constraints.": "Paramètres de la journée enregistrés. Prévisualisez votre planning pour appliquer les contraintes modifiées.",
  "Workday settings": "Paramètres de la journée de travail",
  "Workday start": "Début de la journée",
  "Workday end": "Fin de la journée",
  "An end time before the start means an overnight shift.": "Une heure de fin antérieure à l’heure de début correspond à un travail de nuit.",
  Timezone: zC,
  "Working days": "Jours travaillés",
  Mon: RC,
  Tue: xC,
  Wed: OC,
  Thu: MC,
  Fri: $C,
  Sat: NC,
  Sun: jC,
  "Reserve lunch": "Réserver le déjeuner",
  "Lunch starts": "Début du déjeuner",
  "Lunch · minutes": "Déjeuner · minutes",
  "Additional breaks": "Pauses supplémentaires",
  "Break name": "Nom de la pause",
  "Break starts": "Début de la pause",
  "Break · minutes": "Pause · minutes",
  Remove: LC,
  "Remove break": "Retirer la pause",
  "Add break": "Ajouter une pause",
  Reminders: GC,
  "Pop up reminders and check-ins": "Afficher les rappels et les points d’étape",
  "Pop up in a browser window (works even when Windows notifications are off)": "Afficher dans une fenêtre du navigateur (fonctionne même si les notifications Windows sont désactivées)",
  "Reminders appear while Edge is running, even with this panel closed. Untick the second box to use Windows system notifications instead. Save after changing these.": "Les rappels apparaissent tant qu’Edge est ouvert, même si ce panneau est fermé. Décochez la deuxième case pour utiliser plutôt les notifications système de Windows. Enregistrez après avoir modifié ces options.",
  "Send a test reminder": "Envoyer un rappel de test",
  "Task-start reminders": "Rappels de début de tâche",
  "Upcoming meetings": "Réunions à venir",
  "Break reminders": "Rappels de pause",
  "Workday-end reminder": "Rappel de fin de journée",
  "Lead time · minutes": "Délai d’avance · minutes",
  "Check-in · minutes": "Point d’étape · minutes",
  "Set check-in to 0 to turn off periodic check-ins.": "Réglez le point d’étape sur 0 pour désactiver les points d’étape périodiques.",
  "Quiet hours for notifications": "Heures calmes pour les notifications",
  "Quiet hours start": "Début des heures calmes",
  "Quiet hours end": "Fin des heures calmes",
  "Save workday settings": "Enregistrer les paramètres de la journée",
  "The AI request could not be completed. No task changes were applied. Retry or use the manual planner.": "La demande à l’IA n’a pas pu aboutir. Aucune modification de tâche n’a été appliquée. Réessayez ou utilisez le planificateur manuel.",
  "Reconnect your ChatGPT plan in Settings.": "Reconnectez votre forfait ChatGPT dans les Paramètres.",
  "Enter a request between 1 and 6000 characters.": "Saisissez une demande de 1 à 6000 caractères.",
  "This request is already answered or no longer exists.": "Cette demande a déjà reçu une réponse ou n’existe plus.",
  "This request already has a proposal. Review it instead of retrying.": "Cette demande a déjà une proposition. Examinez-la au lieu de réessayer.",
  "Switch back to the original provider to retry this request.": "Revenez au fournisseur d’origine pour réessayer cette demande.",
  "AI request cancelled. No task changes were applied.": "Demande à l’IA annulée. Aucune modification de tâche n’a été appliquée.",
  "This request was cancelled because chat data or AI configuration changed.": "Cette demande a été annulée, car les données du chat ou la configuration de l’IA ont changé.",
  "Your workday changed while the model was responding. Retry with the latest context.": "Votre journée a changé pendant que le modèle répondait. Réessayez avec le contexte le plus récent.",
  "ChatGPT usage limit reached. Manage usage in ChatGPT, then retry here.": "Limite d’utilisation de ChatGPT atteinte. Gérez votre utilisation dans ChatGPT, puis réessayez ici.",
  "ChatGPT plan access is unavailable for this account, workspace or region.": "L’accès au forfait ChatGPT n’est pas disponible pour ce compte, cet espace de travail ou cette région.",
  "ChatGPT authorization expired. Sign in again.": "L’autorisation ChatGPT a expiré. Reconnectez-vous.",
  "ChatGPT could not complete this request. Please retry later.": "ChatGPT n’a pas pu traiter cette demande. Veuillez réessayer plus tard.",
  "ChatGPT request cancelled.": "Demande ChatGPT annulée.",
  "ChatGPT could not be reached. Your saved sign-in is kept.": "ChatGPT est injoignable. Votre connexion enregistrée est conservée.",
  "ChatGPT sign-in timed out. Please try again.": "La connexion à ChatGPT a expiré. Veuillez réessayer.",
  "A ChatGPT sign-in is already open. Finish or cancel it first.": "Une connexion à ChatGPT est déjà en cours. Terminez-la ou annulez-la d’abord.",
  "The selected ChatGPT account no longer exists.": "Le compte ChatGPT sélectionné n’existe plus.",
  "Sign out of the current ChatGPT account before signing in to another.": "Déconnectez-vous du compte ChatGPT actuel avant de vous connecter à un autre.",
  "Unable to open the ChatGPT sign-in tab.": "Impossible d’ouvrir l’onglet de connexion à ChatGPT.",
  "ChatGPT sign-in was not authorized.": "La connexion à ChatGPT n’a pas été autorisée.",
  "ChatGPT sign-in was cancelled.": "La connexion à ChatGPT a été annulée.",
  "ChatGPT sign-in did not complete. Please retry.": "La connexion à ChatGPT n’a pas abouti. Veuillez réessayer.",
  "Sign in with ChatGPT first.": "Connectez-vous d’abord avec ChatGPT.",
  "Your ChatGPT session expired. Sign in again.": "Votre session ChatGPT a expiré. Reconnectez-vous.",
  "ChatGPT plan use is not enabled. Choose Enable plan access in Settings.": "L’utilisation du forfait ChatGPT n’est pas activée. Choisissez Activer l’accès au forfait dans les Paramètres.",
  "Choose a ChatGPT model in Settings.": "Choisissez un modèle ChatGPT dans les Paramètres.",
  "ChatGPT took too long to answer. No task changes were applied.": "ChatGPT a mis trop de temps à répondre. Aucune modification de tâche n’a été appliquée.",
  "ChatGPT request interrupted. No task changes were applied.": "Demande ChatGPT interrompue. Aucune modification de tâche n’a été appliquée.",
  "ChatGPT response was interrupted or empty. No task changes were applied.": "La réponse de ChatGPT a été interrompue ou était vide. Aucune modification de tâche n’a été appliquée.",
  "Connect a ChatGPT account first.": "Connectez d’abord un compte ChatGPT.",
  "The AI request timed out. Retry or choose a faster model.": "La demande à l’IA a expiré. Réessayez ou choisissez un modèle plus rapide.",
  "Enter a valid provider API key (16–512 characters, no spaces or control characters).": "Saisissez une clé API valide (16 à 512 caractères, sans espaces ni caractères de contrôle).",
  "Enter a model ID in the model field, not an API key.": "Saisissez un identifiant de modèle dans le champ du modèle, pas une clé API.",
  "Connect ChatGPT and enable plan access first.": "Connectez d’abord ChatGPT et activez l’accès au forfait.",
  "Model discovery cancelled.": "Recherche de modèles annulée.",
  "Model discovery cancelled because the saved key changed.": "Recherche de modèles annulée, car la clé enregistrée a changé.",
  "The provider returned no usable model IDs. Retry discovery or enter a model ID manually.": "Le fournisseur n’a renvoyé aucun identifiant de modèle utilisable. Relancez la recherche ou saisissez un identifiant de modèle manuellement.",
  "Sign in to this ChatGPT account first.": "Connectez-vous d’abord à ce compte ChatGPT.",
  "The AI request timed out. Your manual planner is still available.": "La demande à l’IA a expiré. Votre planificateur manuel reste disponible.",
  "The provider response was too large. Try a smaller request or another model.": "La réponse du fournisseur était trop volumineuse. Essayez une demande plus courte ou un autre modèle.",
  "No text chat models were found. Retry discovery or enter a model ID manually.": "Aucun modèle de chat textuel n’a été trouvé. Relancez la recherche ou saisissez un identifiant de modèle manuellement.",
  "The model returned a refused, incomplete or invalid response. No task data changed. Try another model or a smaller request.": "Le modèle a renvoyé une réponse refusée, incomplète ou non valide. Aucune donnée de tâche n’a changé. Essayez un autre modèle ou une demande plus courte.",
  "The model could not produce valid task actions. No task data changed.": "Le modèle n’a pas pu produire d’actions de tâche valides. Aucune donnée de tâche n’a changé.",
  "Meeting times are invalid or ambiguous in your workday timezone.": "Les horaires de la réunion sont invalides ou ambigus dans le fuseau horaire de votre journée de travail.",
  "Meeting end must be after its start and within seven days.": "La fin de la réunion doit être postérieure à son début, dans un délai de sept jours.",
  "The model referenced a meeting that does not exist.": "Le modèle a fait référence à une réunion qui n’existe pas.",
  "The referenced task no longer exists.": "La tâche référencée n’existe plus.",
  "This task is already completed.": "Cette tâche est déjà terminée.",
  "Reopen the task before adding focus time.": "Rouvrez la tâche avant d’ajouter du temps de concentration.",
  "Limit one proposal to seven affected workdays.": "Limitez une proposition à sept journées de travail concernées.",
  "This proposal has already been resolved or removed.": "Cette proposition a déjà été traitée ou supprimée.",
  "This proposal expired. Refresh its preview before approval.": "Cette proposition a expiré. Actualisez son aperçu avant de l’approuver.",
  "Your tasks, meetings, focus or work settings changed. Refresh the preview before approval.": "Vos tâches, réunions, sessions de concentration ou paramètres de travail ont changé. Actualisez l’aperçu avant de l’approuver.",
  "This proposal is no longer pending.": "Cette proposition n’est plus en attente.",
  "Here are the changes for you to review.": "Voici les modifications à examiner.",
  "The model did not return valid task actions. No task data changed. Try again or choose another model.": "Le modèle n’a pas renvoyé d’actions de tâche valides. Aucune donnée de tâche n’a changé. Réessayez ou choisissez un autre modèle.",
  "Reopen this task before starting focus.": "Rouvrez cette tâche avant de démarrer la concentration.",
  "Time to focus": "C’est l’heure de se concentrer",
  "Break time": "C’est l’heure de la pause",
  "Upcoming meeting": "Réunion à venir",
  "Your workday is ending": "Votre journée de travail se termine",
  "Review your progress and leave unfinished tasks for another day.": "Faites le point sur votre progression et gardez les tâches inachevées pour un autre jour.",
  "Work from another saved plan reserves time in this window.": "Le travail d’un autre plan enregistré réserve du temps sur ce créneau.",
  "This is not a configured working day.": "Ce n’est pas un jour travaillé configuré.",
  "Unfinished, missing or circular dependency": "Dépendance inachevée, manquante ou circulaire",
  "Estimate used up; complete this task or add more time": "Estimation épuisée ; terminez cette tâche ou ajoutez du temps",
  "Insufficient time before deadline": "Temps insuffisant avant l’échéance",
  "Insufficient working time": "Temps de travail insuffisant",
  "This task is no longer available to extend.": "Cette tâche ne peut plus être prolongée.",
  "The task estimate cannot exceed 1440 minutes.": "L’estimation de la tâche ne peut pas dépasser 1440 minutes.",
  "This preview expired. Preview the plan again.": "Cet aperçu a expiré. Prévisualisez de nouveau le plan.",
  "Your tasks, focus, meetings or settings changed. Preview the plan again.": "Vos tâches, sessions de concentration, réunions ou paramètres ont changé. Prévisualisez de nouveau le plan.",
  "Meeting end must be after its start.": "La fin de la réunion doit être postérieure à son début.",
  "Meeting no longer exists.": "La réunion n’existe plus.",
  "This local time is invalid or ambiguous (daylight saving). Choose another time.": "Cette heure locale est invalide ou ambiguë (changement d’heure). Choisissez une autre heure.",
  "Enter a task title.": "Saisissez un titre de tâche.",
  "Enter a valid IANA timezone.": "Saisissez un fuseau horaire IANA valide.",
  "Start and end must differ. An earlier end means an overnight workday.": "Le début et la fin doivent être différents. Une fin antérieure au début correspond à un travail de nuit.",
  "Task no longer exists.": "La tâche n’existe plus.",
  "Task dependencies cannot contain a cycle.": "Les dépendances entre tâches ne peuvent pas former un cycle.",
  "To do": "À faire",
  "In progress": "En cours",
  Paused: FC,
  Deferred: UC,
  todo: ZC,
  "in progress": "en cours",
  paused: qC,
  completed: KC,
  deferred: WC,
  high: YC,
  medium: VC,
  low: BC,
  development: HC,
  review: QC,
  writing: XC,
  planning: JC,
  communication: e1,
  other: t1,
  task: n1,
  meeting: r1,
  break: "pause",
  dark: o1,
  light: i1,
  Title: a1,
  "Estimate (min)": "Estimation (min)",
  Date: "Date",
  Deadline: s1,
  Prerequisites: u1,
  Starts: c1,
  Ends: l1,
  "Create task": "Créer la tâche",
  "Update task": "Modifier la tâche",
  "Create meeting": "Créer la réunion",
  "Update meeting": "Modifier la réunion",
  Lunch: d1,
  "Take a break": "Faites une pause",
  " — open Workday for Completed, Need more time, Pause or Skip.": " — ouvrez Workday pour choisir Terminée, Besoin de plus de temps, Pause ou Ignorer.",
  "No task changes were applied.": "Aucune modification de tâche n’a été appliquée.",
  "{provider} rejected this key or access policy. Check the key and account permissions in Settings.": "{provider} a refusé cette clé ou cette politique d’accès. Vérifiez la clé et les autorisations du compte dans les Paramètres.",
  "{provider} reports insufficient credits. Review your provider account or select another available model.": "{provider} signale un crédit insuffisant. Vérifiez votre compte fournisseur ou sélectionnez un autre modèle disponible.",
  "{provider} is rate limiting requests or reports exhausted quota. Review your quota and wait before retrying.": "{provider} limite le débit des demandes ou signale un quota épuisé. Vérifiez votre quota et patientez avant de réessayer.",
  "{provider} could not serve the selected model or rejected the request. Refresh models, choose another model, or retry later.": "{provider} n’a pas pu servir le modèle sélectionné ou a rejeté la demande. Actualisez les modèles, choisissez-en un autre ou réessayez plus tard.",
  "{provider} could not be reached. Check your connection; manual tasks and scheduling still work offline.": "{provider} est injoignable. Vérifiez votre connexion ; les tâches manuelles et la planification fonctionnent toujours hors ligne.",
  "Configure your {provider} connection, model and data-sharing consent in Settings first.": "Configurez d’abord votre connexion {provider}, le modèle et le consentement au partage de données dans les Paramètres.",
  "Enter your {provider} API key before discovering models. You can use the key field without saving first.": "Saisissez votre clé API {provider} avant de rechercher des modèles. Vous pouvez utiliser le champ de clé sans l’enregistrer.",
  "Enter your {provider} API key before discovering models.": "Saisissez votre clé API {provider} avant de rechercher des modèles.",
  "{provider} returned a refused, incomplete or invalid response. No task data changed. Try a smaller request or another model.": "{provider} a renvoyé une réponse refusée, incomplète ou non valide. Aucune donnée de tâche n’a changé. Essayez une demande plus courte ou un autre modèle.",
  "{provider} returned an invalid model catalog. Retry discovery or enter a model ID manually.": "{provider} a renvoyé un catalogue de modèles non valide. Relancez la recherche ou saisissez un identifiant de modèle manuellement.",
  "{provider} could not complete this request. Please retry later.": "{provider} n’a pas pu traiter cette demande. Veuillez réessayer plus tard.",
  "You’ve reached your ChatGPT plan’s usage limit. Wait for it to reset, or choose another AI provider in Settings.": "Vous avez atteint la limite d’utilisation de votre forfait ChatGPT. Attendez sa réinitialisation ou choisissez un autre fournisseur d’IA dans les Paramètres.",
  "ChatGPT did not finish its response. No task changes were applied.": "ChatGPT n’a pas terminé sa réponse. Aucune modification de tâche n’a été appliquée.",
  "Something went wrong. Please try again.": "Une erreur s’est produite. Veuillez réessayer.",
  "Task updated.": "Tâche mise à jour.",
  "Task created.": "Tâche créée.",
  "Switch to light theme": "Passer au thème clair",
  "Switch to dark theme": "Passer au thème sombre",
  "Help me adjust my remaining schedule for today.": "Aide-moi à ajuster le reste de mon planning pour aujourd’hui.",
  "Allow sending my chat requests and selected workday context to OpenRouter and the selected model provider.": "Autoriser l’envoi de mes demandes de chat et du contexte de journée sélectionné à OpenRouter et au fournisseur du modèle sélectionné.",
  "Allow sending my chat requests and selected workday context to {provider}.": "Autoriser l’envoi de mes demandes de chat et du contexte de journée sélectionné à {provider}.",
  "Signed out of ChatGPT.": "Déconnecté de ChatGPT.",
  "Signed out here. ChatGPT could not confirm it: also disconnect this app in your ChatGPT settings.": "Déconnecté ici. ChatGPT n’a pas pu le confirmer : déconnectez aussi cette application dans vos paramètres ChatGPT.",
  "Pause focus": "Mettre la concentration en pause",
  "Resume focus": "Reprendre la concentration",
  "Start focus": "Démarrer la concentration",
  "Unable to save meeting.": "Impossible d’enregistrer la réunion.",
  "Unable to plan the day.": "Impossible de planifier la journée.",
  "Review the extended estimate and updated plan below.": "Vérifiez l’estimation prolongée et le plan mis à jour ci-dessous.",
  "Check-in saved. Preview the plan to adjust remaining work.": "Point d’étape enregistré. Prévisualisez le plan pour ajuster le travail restant.",
  "Unable to save check-in.": "Impossible d’enregistrer le point d’étape.",
  "Unable to approve plan.": "Impossible d’approuver le plan.",
  "Unable to save settings.": "Impossible d’enregistrer les paramètres.",
  "Short break": "Courte pause"
}, f1 = "Recargar", m1 = "Cerrar", p1 = "Categoría", g1 = "Descripción", v1 = "Notas", y1 = "Prioridad", b1 = "Alta", w1 = "Media", k1 = "Baja", _1 = "Estado", T1 = "Cancelar", C1 = "Tareas", P1 = "Hoy", A1 = "Completadas", E1 = "Reabrir", S1 = "Completar", D1 = "min", I1 = "Vence", z1 = "Editar", R1 = "Aplazar", x1 = "Eliminar", O1 = "Ajustes", M1 = "Apariencia", $1 = "Idioma", N1 = "Conversación", j1 = "Tú", L1 = "Enviar", G1 = "Ninguno", F1 = "Tarea", U1 = "Conectado", Z1 = "Pausar", q1 = "Reanudar", K1 = "Concentrarse", W1 = "Horario", Y1 = "Compromiso", V1 = "Reuniones", B1 = "Zona horaria", H1 = "Lun", Q1 = "Mar", X1 = "Mié", J1 = "Jue", eP = "Vie", tP = "Sáb", nP = "Dom", rP = "Quitar", oP = "Recordatorios", iP = "En pausa", aP = "Aplazada", sP = "por hacer", uP = "en pausa", cP = "completada", lP = "aplazada", dP = "alta", hP = "media", fP = "baja", mP = "desarrollo", pP = "revisión", gP = "redacción", vP = "planificación", yP = "comunicación", bP = "otra", wP = "tarea", kP = "reunión", _P = "oscuro", TP = "claro", CP = "Título", PP = "Fecha límite", AP = "Requisitos previos", EP = "Inicio", SP = "Fin", DP = "Almuerzo", IP = {
  "Unable to open Workday": "No se puede abrir Workday",
  "Your data has not been deleted. Reload the panel to try again.": "Tus datos no se han eliminado. Recarga el panel para volver a intentarlo.",
  Reload: f1,
  Dismiss: m1,
  "Open Workday": "Abrir Workday",
  "Edit task": "Editar tarea",
  "New task": "Nueva tarea",
  "Close task editor": "Cerrar el editor de tareas",
  "Task title": "Título de la tarea",
  "What needs your attention?": "¿Qué necesita tu atención?",
  Category: p1,
  Description: g1,
  Notes: v1,
  "Anything you don’t want to forget": "Cualquier cosa que no quieras olvidar",
  Priority: y1,
  High: b1,
  Medium: w1,
  Low: k1,
  "Estimate · minutes": "Estimación · minutos",
  "Scheduled date": "Fecha programada",
  Status: _1,
  "Deadline ({zone})": "Fecha límite ({zone})",
  "Dependencies (optional)": "Dependencias (opcional)",
  "Missing prerequisite ({id}) — uncheck to remove": "Requisito previo no encontrado ({id}): desmarca para quitarlo",
  Cancel: T1,
  "Saving…": "Guardando…",
  "Save task": "Guardar tarea",
  "Local data exported.": "Datos locales exportados.",
  "Main navigation": "Navegación principal",
  "Local storage unavailable: {error}. Reload the panel to retry.": "Almacenamiento local no disponible: {error}. Recarga el panel para volver a intentarlo.",
  "Dismiss message": "Cerrar mensaje",
  "Day off": "Día libre",
  "Before work": "Antes del trabajo",
  "Workday ended": "Jornada terminada",
  "Workday in progress": "Jornada en curso",
  "Daily task progress": "Progreso de las tareas del día",
  "{done} of {total} done": "{done} de {total} completadas",
  "{minutes} min left": "Quedan {minutes} min",
  "{done} of {total} tasks completed": "{done} de {total} tareas completadas",
  Tasks: C1,
  "Add task": "Añadir tarea",
  "Filter tasks": "Filtrar tareas",
  Today: P1,
  "All tasks": "Todas las tareas",
  Completed: A1,
  "Loading local tasks…": "Cargando tareas locales…",
  "Your wins will appear here": "Tus logros aparecerán aquí",
  "Make room for your best work": "Haz sitio para tu mejor trabajo",
  "Add your first task for today. Keep it small, give it an estimate, and take it from there.": "Añade tu primera tarea de hoy. Que sea pequeña, ponle una estimación y avanza desde ahí.",
  "Create a task to get started.": "Crea una tarea para empezar.",
  "Create a task": "Crear una tarea",
  Reopen: E1,
  Complete: S1,
  "Task reopened.": "Tarea reabierta.",
  "Task completed.": "Tarea completada.",
  min: D1,
  Due: I1,
  Edit: z1,
  "Task deferred.": "Tarea aplazada.",
  Defer: R1,
  Delete: x1,
  "Delete this task and its work records?": "¿Eliminar esta tarea y sus registros de trabajo?",
  "Task deleted.": "Tarea eliminada.",
  "Delete task": "Eliminar tarea",
  "Ask AI to adjust my day": "Pedir a la IA que ajuste mi día",
  Settings: O1,
  Appearance: M1,
  "Color theme": "Tema de color",
  Language: $1,
  "Display language": "Idioma de la interfaz",
  "Same as browser": "El mismo que el navegador",
  "The assistant also replies in this language.": "El asistente también responde en este idioma.",
  "Your data": "Tus datos",
  "Everything is saved in this browser on this device and works offline. Uninstalling the extension or clearing browser data removes it.": "Todo se guarda en este navegador, en este dispositivo, y funciona sin conexión. Desinstalar la extensión o borrar los datos del navegador lo elimina.",
  "Export local data": "Exportar datos locales",
  "Exports contain tasks and work records, never keys or sign-ins.": "Las exportaciones contienen tareas y registros de trabajo, nunca claves ni inicios de sesión.",
  "Delete all local data": "Eliminar todos los datos locales",
  "Permanently delete all tasks, work records, chats and AI settings, and sign out of ChatGPT? Export a backup first if you need one.": "¿Eliminar permanentemente todas las tareas, los registros de trabajo, los chats y los ajustes de IA, y cerrar la sesión de ChatGPT? Exporta primero una copia de seguridad si la necesitas.",
  "All task and work records deleted.": "Se han eliminado todas las tareas y los registros de trabajo.",
  "Delete permanently": "Eliminar permanentemente",
  "AI Chat": "Chat de IA",
  "Back to Today": "Volver a Hoy",
  "Clear chat": "Borrar chat",
  "Connect your ChatGPT account, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Conecta tu cuenta de ChatGPT, elige un modelo y activa el uso compartido de datos en Ajustes. La planificación manual funciona sin IA.",
  "Connect your own {provider} API key, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Añade tu propia clave de API de {provider}, elige un modelo y activa el uso compartido de datos en Ajustes. La planificación manual funciona sin IA.",
  "Configure AI": "Configurar la IA",
  "Using ChatGPT plan ·": "Usando el plan de ChatGPT ·",
  "Manage usage": "Gestionar el uso",
  "You’re offline. Saved conversations and manual planning remain available; sending needs a connection.": "No tienes conexión. Las conversaciones guardadas y la planificación manual siguen disponibles; para enviar hace falta conexión.",
  "{provider} · Model: {model}": "{provider} · Modelo: {model}",
  "Chat options": "Opciones del chat",
  "Task changes require your approval.": "Los cambios en las tareas requieren tu aprobación.",
  "Planning date": "Fecha de planificación",
  "Task context": "Contexto de tareas",
  "This day, next day & unscheduled": "Este día, el siguiente y las tareas sin programar",
  "All dates (up to 80 tasks + prerequisites)": "Todas las fechas (hasta 80 tareas + requisitos previos)",
  "Include task descriptions and notes (up to 500 characters each)": "Incluir descripciones y notas de las tareas (hasta 500 caracteres cada una)",
  "Include meeting titles, so the assistant can find a meeting by name": "Incluir los títulos de las reuniones, para que el asistente pueda encontrar una reunión por su nombre",
  "Each request sends up to 80 tasks, your meeting times, work hours and your six most recent messages with this provider. Webpages are never sent.": "Cada solicitud envía hasta 80 tareas, los horarios de tus reuniones, tu horario de trabajo y tus seis mensajes más recientes con este proveedor. Las páginas web nunca se envían.",
  Conversation: N1,
  "Tell me what’s on your plate. I’ll suggest task changes for you to approve.": "Cuéntame qué tienes pendiente. Te sugeriré cambios en las tareas para que los apruebes.",
  "Plan my day.": "Planifica mi día.",
  "What should I work on next?": "¿En qué debería trabajar ahora?",
  "What tasks have I not completed?": "¿Qué tareas no he completado?",
  You: j1,
  "Thinking…": "Pensando…",
  "Interrupted or pending request. Retry with the latest context.": "Solicitud interrumpida o pendiente. Vuelve a intentarlo con el contexto más reciente.",
  "Request cancelled.": "Solicitud cancelada.",
  "Retry request": "Reintentar solicitud",
  " · retried once": " · se reintentó una vez",
  "Message to AI": "Mensaje para la IA",
  "What would you like to plan?": "¿Qué te gustaría planificar?",
  "Shift+Enter for a new line": "Mayús+Intro para una nueva línea",
  "Cancel request": "Cancelar solicitud",
  Send: L1,
  "Clear conversation": "Borrar conversación",
  "Delete this provider’s local conversation and proposals? Other conversations, approved tasks and schedules will remain.": "¿Eliminar la conversación y las propuestas locales de este proveedor? Las demás conversaciones, las tareas aprobadas y los horarios se conservarán.",
  "Unable to clear chat.": "No se pudo borrar el chat.",
  "Delete chat": "Eliminar chat",
  None: G1,
  "Missing prerequisite": "Requisito previo no encontrado",
  "AI change proposal": "Propuesta de cambios de la IA",
  "Changes approved": "Cambios aprobados",
  "Proposal rejected": "Propuesta rechazada",
  "Review proposed changes": "Revisa los cambios propuestos",
  "Nothing has been applied. Preview expires after 60 seconds; refresh it if needed. The local scheduler rechecks times at approval.": "No se ha aplicado nada. La vista previa caduca a los 60 segundos; actualízala si hace falta. El planificador local vuelve a comprobar los horarios al aprobar.",
  "AI proposed schedule": "Horario propuesto por la IA",
  "Showing 200 of {count} blocks. Use Today after approval for the full timeline.": "Mostrando 200 de {count} bloques. Consulta Hoy tras la aprobación para ver el horario completo.",
  "Overflow · {count} task(s)": "No cabe · {count} tarea(s)",
  Task: F1,
  "Approve changes": "Aprobar cambios",
  "Reject changes": "Rechazar cambios",
  "Refresh preview": "Actualizar vista previa",
  "Tasks and affected schedules were saved together.": "Las tareas y los horarios afectados se guardaron juntos.",
  "No task or schedule changes were applied.": "No se aplicó ningún cambio en tareas ni horarios.",
  "View Today": "Ver Hoy",
  "AI provider settings": "Ajustes del proveedor de IA",
  "AI assistant": "Asistente de IA",
  "Assistant name": "Nombre del asistente",
  "Shown in chat, and the assistant answers to it. Saved as you type.": "Se muestra en el chat y el asistente responde a él. Se guarda mientras escribes.",
  "AI provider": "Proveedor de IA",
  "{provider} selected. Each provider keeps its own settings and conversation.": "{provider} seleccionado. Cada proveedor conserva sus propios ajustes y su conversación.",
  "Unable to switch AI provider. Please retry.": "No se pudo cambiar de proveedor de IA. Vuelve a intentarlo.",
  "Retrieved {count} models from {provider}. Select a model and save.": "Se obtuvieron {count} modelos de {provider}. Selecciona un modelo y guarda.",
  "{provider} settings saved. Send a request in AI Chat to test the selected model.": "Ajustes de {provider} guardados. Envía una solicitud en el Chat de IA para probar el modelo seleccionado.",
  "Unable to save AI settings. Check the model ID and key (16–512 characters, no spaces).": "No se pudieron guardar los ajustes de IA. Comprueba el ID del modelo y la clave (16–512 caracteres, sin espacios).",
  "{provider} settings": "Ajustes de {provider}",
  "Uses your own API key, saved only in this extension on this device.": "Usa tu propia clave de API, guardada solo en esta extensión en este dispositivo.",
  " To sign in with a ChatGPT subscription instead, choose ChatGPT plan above.": " Para iniciar sesión con una suscripción de ChatGPT, elige Plan de ChatGPT arriba.",
  " Get a key from the Anthropic Console. A Claude subscription cannot be used here.": " Consigue una clave en la Consola de Anthropic. Aquí no se puede usar una suscripción de Claude.",
  "{provider} API key": "Clave de API de {provider}",
  "Saved key · enter a replacement": "Clave guardada · introduce otra para sustituirla",
  "Enter your own {provider} key": "Introduce tu propia clave de {provider}",
  "A key is saved on this device.": "Hay una clave guardada en este dispositivo.",
  "No API key saved.": "No hay ninguna clave de API guardada.",
  "Working…": "Trabajando…",
  "Refresh models": "Actualizar modelos",
  "{provider} key removed and sharing disabled. Other providers are unchanged.": "Clave de {provider} eliminada y uso compartido desactivado. Los demás proveedores no cambian.",
  "Unable to remove the saved key. Please retry.": "No se pudo eliminar la clave guardada. Vuelve a intentarlo.",
  "Forget key": "Olvidar clave",
  "Show free models only": "Mostrar solo modelos gratuitos",
  "Find a model": "Buscar un modelo",
  "Search name or ID": "Buscar por nombre o ID",
  "Discovered model": "Modelo detectado",
  "Choose a model…": "Elige un modelo…",
  " · Free": " · Gratis",
  " · Paid": " · De pago",
  "Model ID": "ID del modelo",
  "Select above or enter a model ID": "Selecciona arriba o introduce un ID de modelo",
  "Free model; account limits still apply.": "Modelo gratuito; siguen aplicándose los límites de la cuenta.",
  "Paid model · prompt {prompt} / completion {completion} USD per token.": "Modelo de pago · entrada {prompt} / salida {completion} USD por token.",
  "Requests may be billed by {provider}. Check pricing in your provider account.": "{provider} puede cobrar las solicitudes. Consulta los precios en tu cuenta del proveedor.",
  "Save AI settings": "Guardar ajustes de IA",
  "What gets shared?": "¿Qué se comparte?",
  "Each request sends task summaries, work hours, meeting times and your recent conversation with this provider. Meeting titles are sent unless you turn that off in Chat options; task descriptions and notes are sent only if you turn that on. Webpages and saved keys are never sent. An invalid answer may trigger one automatic retry, which can cost extra. There is no automatic switch to another provider or a paid model.": "Cada solicitud envía resúmenes de las tareas, tu horario de trabajo, los horarios de tus reuniones y tu conversación reciente con este proveedor. Los títulos de las reuniones se envían salvo que lo desactives en las Opciones del chat; las descripciones y las notas de las tareas solo se envían si lo activas. Las páginas web y las claves guardadas nunca se envían. Una respuesta no válida puede provocar un reintento automático, que puede tener un coste adicional. No hay cambio automático a otro proveedor ni a un modelo de pago.",
  "ChatGPT connected. Choose a model and allow sharing to finish.": "ChatGPT conectado. Elige un modelo y permite el uso compartido para terminar.",
  "ChatGPT plan settings": "Ajustes del plan de ChatGPT",
  "ChatGPT plan": "Plan de ChatGPT",
  "Use your ChatGPT subscription instead of an API key. Availability depends on your plan, workspace and region.": "Usa tu suscripción de ChatGPT en lugar de una clave de API. La disponibilidad depende de tu plan, tu espacio de trabajo y tu región.",
  "Finish signing in in the browser tab that opened, then come back here.": "Termina de iniciar sesión en la pestaña del navegador que se abrió y luego vuelve aquí.",
  "Cancel sign-in": "Cancelar inicio de sesión",
  "Continue with ChatGPT": "Continuar con ChatGPT",
  Connected: U1,
  "Plan access off": "Acceso al plan desactivado",
  "Signed out": "Sesión cerrada",
  " · In use": " · En uso",
  "Use account": "Usar esta cuenta",
  "Enable plan access": "Activar el acceso al plan",
  "Sign in again": "Volver a iniciar sesión",
  "Sign out": "Cerrar sesión",
  "You’re using your ChatGPT plan": "Estás usando tu plan de ChatGPT",
  "Got it": "Entendido",
  "ChatGPT is ready. Open AI Chat to start.": "ChatGPT está listo. Abre el Chat de IA para empezar.",
  "ChatGPT model": "Modelo de ChatGPT",
  "Refresh ChatGPT models": "Actualizar modelos de ChatGPT",
  "Allow sending my requests, selected workday context and this account’s recent chat to OpenAI using my ChatGPT plan.": "Permitir el envío de mis solicitudes, el contexto de jornada seleccionado y el chat reciente de esta cuenta a OpenAI usando mi plan de ChatGPT.",
  "Save ChatGPT settings": "Guardar ajustes de ChatGPT",
  "Task changes always wait for your approval.": "Los cambios en las tareas siempre esperan tu aprobación.",
  "Sign-in runs inside the extension; there is nothing else to install. Your ChatGPT session is saved in this extension’s private storage in this browser profile until you sign out. Signing out removes the account, its saved details and its conversation from this extension.": "El inicio de sesión se hace dentro de la extensión; no hay que instalar nada más. Tu sesión de ChatGPT se guarda en el almacenamiento privado de esta extensión, en este perfil del navegador, hasta que cierres la sesión. Al cerrar la sesión se eliminan de esta extensión la cuenta, sus datos guardados y su conversación.",
  "Focus timer": "Temporizador de concentración",
  "Focusing now": "Concentración en curso",
  "Focus paused": "Concentración en pausa",
  "{time} remaining": "Quedan {time}",
  "{time} over estimate": "{time} por encima de la estimación",
  "Focus paused.": "Concentración en pausa.",
  "Focus resumed.": "Concentración reanudada.",
  Pause: Z1,
  Resume: q1,
  "Task completed. Preview the plan to reuse the free time.": "Tarea completada. Previsualiza el plan para aprovechar el tiempo libre.",
  "Focus started.": "Concentración iniciada.",
  Focus: K1,
  "Meeting editor": "Editor de reuniones",
  "Edit meeting": "Editar reunión",
  "New meeting": "Nueva reunión",
  "Close meeting editor": "Cerrar el editor de reuniones",
  "Times in {zone}": "Horas en {zone}",
  "Meeting title": "Título de la reunión",
  "Meeting starts": "Inicio de la reunión",
  "Meeting ends": "Fin de la reunión",
  "Save meeting": "Guardar reunión",
  "Loading your schedule…": "Cargando tu horario…",
  "Plan approved and saved.": "Plan aprobado y guardado.",
  "Day planner": "Planificador del día",
  "Meeting now": "Reunión en curso",
  "Next meeting": "Próxima reunión",
  "How is this task going?": "¿Cómo va esta tarea?",
  "Need more time (+30m)": "Necesito más tiempo (+30 min)",
  "Skip for now": "Omitir por ahora",
  Schedule: W1,
  "Planning…": "Planificando…",
  "Preview plan": "Previsualizar plan",
  "Plan date": "Fecha del plan",
  " (next day)": " (día siguiente)",
  "Tasks or constraints changed. Preview and approve an updated plan before following this timeline.": "Las tareas o las restricciones han cambiado. Previsualiza y aprueba un plan actualizado antes de seguir este horario.",
  "Review your proposed plan": "Revisa el plan propuesto",
  "Includes 30 more minutes for the selected task. ": "Incluye 30 minutos más para la tarea seleccionada. ",
  "Nothing is saved until you approve. This preview expires in 60 seconds.": "No se guarda nada hasta que lo apruebes. Esta vista previa caduca en 60 segundos.",
  "Approve plan": "Aprobar plan",
  "Reject plan": "Rechazar plan",
  "Proposed schedule": "Horario propuesto",
  "Approved schedule": "Horario aprobado",
  Commitment: Y1,
  "No schedule yet. Preview a plan to fit tasks around meetings and breaks.": "Aún no hay horario. Previsualiza un plan para encajar las tareas entre reuniones y descansos.",
  "Doesn’t fit in this workday": "No cabe en esta jornada",
  "Shorten a task, change your hours, or move a task to {date}.": "Acorta una tarea, cambia tu horario o mueve una tarea al {date}.",
  Meetings: V1,
  "Add meeting": "Añadir reunión",
  "Meeting saved. Review the updated plan.": "Reunión guardada. Revisa el plan actualizado.",
  "No meetings for this day.": "No hay reuniones este día.",
  "Delete meeting": "Eliminar reunión",
  "Delete this meeting?": "¿Eliminar esta reunión?",
  "Meeting deleted. Review the updated plan.": "Reunión eliminada. Revisa el plan actualizado.",
  "System notifications could not be delivered. Check Windows notification settings for Microsoft Edge; your schedule and check-ins remain available here.": "No se pudieron mostrar las notificaciones del sistema. Comprueba los ajustes de notificaciones de Windows para Microsoft Edge; tu horario y tus seguimientos siguen disponibles aquí.",
  " · now": " · ahora",
  "Reminders only pop up in the installed extension.": "Los recordatorios solo aparecen en la extensión instalada.",
  "Workday reminders are on": "Los recordatorios de Workday están activados",
  "Reminders and check-ins will appear like this.": "Los recordatorios y los seguimientos aparecerán así.",
  "A reminder window should have opened.": "Debería haberse abierto una ventana de recordatorio.",
  "Sent to Windows. If nothing appeared, Windows is blocking notifications from Microsoft Edge (Settings → System → Notifications, or Do not disturb). Switch on “Pop up in a browser window” above to avoid that.": "Enviado a Windows. Si no apareció nada, Windows está bloqueando las notificaciones de Microsoft Edge (Configuración → Sistema → Notificaciones, o No molestar). Activa «Mostrar en una ventana del navegador» arriba para evitarlo.",
  "The reminder could not be shown. Try the other reminder style.": "No se pudo mostrar el recordatorio. Prueba el otro estilo de recordatorio.",
  "Workday settings saved. Preview your schedule to apply changed constraints.": "Ajustes de la jornada guardados. Previsualiza tu horario para aplicar las restricciones modificadas.",
  "Workday settings": "Ajustes de la jornada",
  "Workday start": "Inicio de la jornada",
  "Workday end": "Fin de la jornada",
  "An end time before the start means an overnight shift.": "Una hora de fin anterior a la de inicio indica un turno nocturno.",
  Timezone: B1,
  "Working days": "Días laborables",
  Mon: H1,
  Tue: Q1,
  Wed: X1,
  Thu: J1,
  Fri: eP,
  Sat: tP,
  Sun: nP,
  "Reserve lunch": "Reservar el almuerzo",
  "Lunch starts": "Inicio del almuerzo",
  "Lunch · minutes": "Almuerzo · minutos",
  "Additional breaks": "Descansos adicionales",
  "Break name": "Nombre del descanso",
  "Break starts": "Inicio del descanso",
  "Break · minutes": "Descanso · minutos",
  Remove: rP,
  "Remove break": "Quitar descanso",
  "Add break": "Añadir descanso",
  Reminders: oP,
  "Pop up reminders and check-ins": "Mostrar recordatorios y seguimientos",
  "Pop up in a browser window (works even when Windows notifications are off)": "Mostrar en una ventana del navegador (funciona aunque las notificaciones de Windows estén desactivadas)",
  "Reminders appear while Edge is running, even with this panel closed. Untick the second box to use Windows system notifications instead. Save after changing these.": "Los recordatorios aparecen mientras Edge esté abierto, incluso con este panel cerrado. Desmarca la segunda casilla para usar las notificaciones del sistema de Windows. Guarda después de cambiar estas opciones.",
  "Send a test reminder": "Enviar un recordatorio de prueba",
  "Task-start reminders": "Recordatorios de inicio de tarea",
  "Upcoming meetings": "Próximas reuniones",
  "Break reminders": "Recordatorios de descanso",
  "Workday-end reminder": "Recordatorio de fin de jornada",
  "Lead time · minutes": "Antelación · minutos",
  "Check-in · minutes": "Seguimiento · minutos",
  "Set check-in to 0 to turn off periodic check-ins.": "Pon el seguimiento en 0 para desactivar los seguimientos periódicos.",
  "Quiet hours for notifications": "Horas de silencio para las notificaciones",
  "Quiet hours start": "Inicio de las horas de silencio",
  "Quiet hours end": "Fin de las horas de silencio",
  "Save workday settings": "Guardar ajustes de la jornada",
  "The AI request could not be completed. No task changes were applied. Retry or use the manual planner.": "No se pudo completar la solicitud a la IA. No se aplicó ningún cambio en las tareas. Vuelve a intentarlo o usa el planificador manual.",
  "Reconnect your ChatGPT plan in Settings.": "Vuelve a conectar tu plan de ChatGPT en Ajustes.",
  "Enter a request between 1 and 6000 characters.": "Escribe una solicitud de entre 1 y 6000 caracteres.",
  "This request is already answered or no longer exists.": "Esta solicitud ya tiene respuesta o ya no existe.",
  "This request already has a proposal. Review it instead of retrying.": "Esta solicitud ya tiene una propuesta. Revísala en lugar de reintentar.",
  "Switch back to the original provider to retry this request.": "Vuelve al proveedor original para reintentar esta solicitud.",
  "AI request cancelled. No task changes were applied.": "Solicitud a la IA cancelada. No se aplicó ningún cambio en las tareas.",
  "This request was cancelled because chat data or AI configuration changed.": "Esta solicitud se canceló porque cambiaron los datos del chat o la configuración de la IA.",
  "Your workday changed while the model was responding. Retry with the latest context.": "Tu jornada cambió mientras el modelo respondía. Vuelve a intentarlo con el contexto más reciente.",
  "ChatGPT usage limit reached. Manage usage in ChatGPT, then retry here.": "Se alcanzó el límite de uso de ChatGPT. Gestiona tu uso en ChatGPT y vuelve a intentarlo aquí.",
  "ChatGPT plan access is unavailable for this account, workspace or region.": "El acceso al plan de ChatGPT no está disponible para esta cuenta, este espacio de trabajo o esta región.",
  "ChatGPT authorization expired. Sign in again.": "La autorización de ChatGPT ha caducado. Vuelve a iniciar sesión.",
  "ChatGPT could not complete this request. Please retry later.": "ChatGPT no pudo completar esta solicitud. Vuelve a intentarlo más tarde.",
  "ChatGPT request cancelled.": "Solicitud a ChatGPT cancelada.",
  "ChatGPT could not be reached. Your saved sign-in is kept.": "No se pudo contactar con ChatGPT. Tu inicio de sesión guardado se conserva.",
  "ChatGPT sign-in timed out. Please try again.": "El inicio de sesión en ChatGPT ha caducado. Vuelve a intentarlo.",
  "A ChatGPT sign-in is already open. Finish or cancel it first.": "Ya hay un inicio de sesión en ChatGPT abierto. Termínalo o cancélalo primero.",
  "The selected ChatGPT account no longer exists.": "La cuenta de ChatGPT seleccionada ya no existe.",
  "Sign out of the current ChatGPT account before signing in to another.": "Cierra la sesión de la cuenta de ChatGPT actual antes de iniciar sesión en otra.",
  "Unable to open the ChatGPT sign-in tab.": "No se pudo abrir la pestaña de inicio de sesión de ChatGPT.",
  "ChatGPT sign-in was not authorized.": "No se autorizó el inicio de sesión en ChatGPT.",
  "ChatGPT sign-in was cancelled.": "Se canceló el inicio de sesión en ChatGPT.",
  "ChatGPT sign-in did not complete. Please retry.": "El inicio de sesión en ChatGPT no se completó. Vuelve a intentarlo.",
  "Sign in with ChatGPT first.": "Primero inicia sesión con ChatGPT.",
  "Your ChatGPT session expired. Sign in again.": "Tu sesión de ChatGPT ha caducado. Vuelve a iniciar sesión.",
  "ChatGPT plan use is not enabled. Choose Enable plan access in Settings.": "El uso del plan de ChatGPT no está activado. Elige Activar el acceso al plan en Ajustes.",
  "Choose a ChatGPT model in Settings.": "Elige un modelo de ChatGPT en Ajustes.",
  "ChatGPT took too long to answer. No task changes were applied.": "ChatGPT tardó demasiado en responder. No se aplicó ningún cambio en las tareas.",
  "ChatGPT request interrupted. No task changes were applied.": "Solicitud a ChatGPT interrumpida. No se aplicó ningún cambio en las tareas.",
  "ChatGPT response was interrupted or empty. No task changes were applied.": "La respuesta de ChatGPT se interrumpió o estaba vacía. No se aplicó ningún cambio en las tareas.",
  "Connect a ChatGPT account first.": "Primero conecta una cuenta de ChatGPT.",
  "The AI request timed out. Retry or choose a faster model.": "La solicitud a la IA agotó el tiempo de espera. Vuelve a intentarlo o elige un modelo más rápido.",
  "Enter a valid provider API key (16–512 characters, no spaces or control characters).": "Introduce una clave de API válida (16–512 caracteres, sin espacios ni caracteres de control).",
  "Enter a model ID in the model field, not an API key.": "Introduce un ID de modelo en el campo del modelo, no una clave de API.",
  "Connect ChatGPT and enable plan access first.": "Primero conecta ChatGPT y activa el acceso al plan.",
  "Model discovery cancelled.": "Búsqueda de modelos cancelada.",
  "Model discovery cancelled because the saved key changed.": "Búsqueda de modelos cancelada porque cambió la clave guardada.",
  "The provider returned no usable model IDs. Retry discovery or enter a model ID manually.": "El proveedor no devolvió ningún ID de modelo utilizable. Repite la búsqueda o introduce un ID de modelo manualmente.",
  "Sign in to this ChatGPT account first.": "Primero inicia sesión en esta cuenta de ChatGPT.",
  "The AI request timed out. Your manual planner is still available.": "La solicitud a la IA agotó el tiempo de espera. Tu planificador manual sigue disponible.",
  "The provider response was too large. Try a smaller request or another model.": "La respuesta del proveedor era demasiado grande. Prueba con una solicitud más corta u otro modelo.",
  "No text chat models were found. Retry discovery or enter a model ID manually.": "No se encontraron modelos de chat de texto. Repite la búsqueda o introduce un ID de modelo manualmente.",
  "The model returned a refused, incomplete or invalid response. No task data changed. Try another model or a smaller request.": "El modelo devolvió una respuesta rechazada, incompleta o no válida. No cambió ningún dato de las tareas. Prueba con otro modelo o una solicitud más corta.",
  "The model could not produce valid task actions. No task data changed.": "El modelo no pudo generar acciones de tarea válidas. No cambió ningún dato de las tareas.",
  "Meeting times are invalid or ambiguous in your workday timezone.": "Los horarios de la reunión no son válidos o son ambiguos en la zona horaria de tu jornada.",
  "Meeting end must be after its start and within seven days.": "El fin de la reunión debe ser posterior a su inicio y estar dentro de siete días.",
  "The model referenced a meeting that does not exist.": "El modelo hizo referencia a una reunión que no existe.",
  "The referenced task no longer exists.": "La tarea a la que se hace referencia ya no existe.",
  "This task is already completed.": "Esta tarea ya está completada.",
  "Reopen the task before adding focus time.": "Reabre la tarea antes de añadir tiempo de concentración.",
  "Limit one proposal to seven affected workdays.": "Limita cada propuesta a siete jornadas afectadas.",
  "This proposal has already been resolved or removed.": "Esta propuesta ya se resolvió o se eliminó.",
  "This proposal expired. Refresh its preview before approval.": "Esta propuesta ha caducado. Actualiza su vista previa antes de aprobarla.",
  "Your tasks, meetings, focus or work settings changed. Refresh the preview before approval.": "Tus tareas, reuniones, concentración o ajustes de trabajo han cambiado. Actualiza la vista previa antes de aprobar.",
  "This proposal is no longer pending.": "Esta propuesta ya no está pendiente.",
  "Here are the changes for you to review.": "Aquí tienes los cambios para que los revises.",
  "The model did not return valid task actions. No task data changed. Try again or choose another model.": "El modelo no devolvió acciones de tarea válidas. No cambió ningún dato de las tareas. Vuelve a intentarlo o elige otro modelo.",
  "Reopen this task before starting focus.": "Reabre esta tarea antes de iniciar la concentración.",
  "Time to focus": "Hora de concentrarse",
  "Break time": "Hora del descanso",
  "Upcoming meeting": "Próxima reunión",
  "Your workday is ending": "Tu jornada está terminando",
  "Review your progress and leave unfinished tasks for another day.": "Revisa tu progreso y deja las tareas sin terminar para otro día.",
  "Work from another saved plan reserves time in this window.": "El trabajo de otro plan guardado reserva tiempo en este tramo.",
  "This is not a configured working day.": "Este no es un día laborable configurado.",
  "Unfinished, missing or circular dependency": "Dependencia sin terminar, inexistente o circular",
  "Estimate used up; complete this task or add more time": "Estimación agotada; completa esta tarea o añade más tiempo",
  "Insufficient time before deadline": "Tiempo insuficiente antes de la fecha límite",
  "Insufficient working time": "Tiempo de trabajo insuficiente",
  "This task is no longer available to extend.": "Esta tarea ya no se puede ampliar.",
  "The task estimate cannot exceed 1440 minutes.": "La estimación de la tarea no puede superar los 1440 minutos.",
  "This preview expired. Preview the plan again.": "Esta vista previa ha caducado. Vuelve a previsualizar el plan.",
  "Your tasks, focus, meetings or settings changed. Preview the plan again.": "Tus tareas, concentración, reuniones o ajustes han cambiado. Vuelve a previsualizar el plan.",
  "Meeting end must be after its start.": "El fin de la reunión debe ser posterior a su inicio.",
  "Meeting no longer exists.": "La reunión ya no existe.",
  "This local time is invalid or ambiguous (daylight saving). Choose another time.": "Esta hora local no es válida o es ambigua (cambio de hora). Elige otra hora.",
  "Enter a task title.": "Escribe un título para la tarea.",
  "Enter a valid IANA timezone.": "Introduce una zona horaria IANA válida.",
  "Start and end must differ. An earlier end means an overnight workday.": "El inicio y el fin deben ser distintos. Un fin anterior al inicio indica una jornada nocturna.",
  "Task no longer exists.": "La tarea ya no existe.",
  "Task dependencies cannot contain a cycle.": "Las dependencias entre tareas no pueden formar un ciclo.",
  "To do": "Por hacer",
  "In progress": "En curso",
  Paused: iP,
  Deferred: aP,
  todo: sP,
  "in progress": "en curso",
  paused: uP,
  completed: cP,
  deferred: lP,
  high: dP,
  medium: hP,
  low: fP,
  development: mP,
  review: pP,
  writing: gP,
  planning: vP,
  communication: yP,
  other: bP,
  task: wP,
  meeting: kP,
  break: "descanso",
  dark: _P,
  light: TP,
  Title: CP,
  "Estimate (min)": "Estimación (min)",
  Date: "Fecha",
  Deadline: PP,
  Prerequisites: AP,
  Starts: EP,
  Ends: SP,
  "Create task": "Crear tarea",
  "Update task": "Actualizar tarea",
  "Create meeting": "Crear reunión",
  "Update meeting": "Actualizar reunión",
  Lunch: DP,
  "Take a break": "Tómate un descanso",
  " — open Workday for Completed, Need more time, Pause or Skip.": " — abre Workday para elegir Completada, Necesito más tiempo, Pausar u Omitir.",
  "No task changes were applied.": "No se aplicó ningún cambio en las tareas.",
  "{provider} rejected this key or access policy. Check the key and account permissions in Settings.": "{provider} rechazó esta clave o la política de acceso. Comprueba la clave y los permisos de la cuenta en Ajustes.",
  "{provider} reports insufficient credits. Review your provider account or select another available model.": "{provider} informa de crédito insuficiente. Revisa tu cuenta del proveedor o selecciona otro modelo disponible.",
  "{provider} is rate limiting requests or reports exhausted quota. Review your quota and wait before retrying.": "{provider} está limitando las solicitudes o informa de una cuota agotada. Revisa tu cuota y espera antes de reintentar.",
  "{provider} could not serve the selected model or rejected the request. Refresh models, choose another model, or retry later.": "{provider} no pudo servir el modelo seleccionado o rechazó la solicitud. Actualiza los modelos, elige otro o vuelve a intentarlo más tarde.",
  "{provider} could not be reached. Check your connection; manual tasks and scheduling still work offline.": "No se pudo contactar con {provider}. Comprueba tu conexión; las tareas manuales y la planificación siguen funcionando sin conexión.",
  "Configure your {provider} connection, model and data-sharing consent in Settings first.": "Primero configura tu conexión con {provider}, el modelo y el consentimiento para compartir datos en Ajustes.",
  "Enter your {provider} API key before discovering models. You can use the key field without saving first.": "Introduce tu clave de API de {provider} antes de buscar modelos. Puedes usar el campo de la clave sin guardarla.",
  "Enter your {provider} API key before discovering models.": "Introduce tu clave de API de {provider} antes de buscar modelos.",
  "{provider} returned a refused, incomplete or invalid response. No task data changed. Try a smaller request or another model.": "{provider} devolvió una respuesta rechazada, incompleta o no válida. No cambió ningún dato de las tareas. Prueba con una solicitud más corta u otro modelo.",
  "{provider} returned an invalid model catalog. Retry discovery or enter a model ID manually.": "{provider} devolvió un catálogo de modelos no válido. Repite la búsqueda o introduce un ID de modelo manualmente.",
  "{provider} could not complete this request. Please retry later.": "{provider} no pudo completar esta solicitud. Vuelve a intentarlo más tarde.",
  "You’ve reached your ChatGPT plan’s usage limit. Wait for it to reset, or choose another AI provider in Settings.": "Has alcanzado el límite de uso de tu plan de ChatGPT. Espera a que se restablezca o elige otro proveedor de IA en Ajustes.",
  "ChatGPT did not finish its response. No task changes were applied.": "ChatGPT no terminó su respuesta. No se aplicó ningún cambio en las tareas.",
  "Something went wrong. Please try again.": "Algo salió mal. Vuelve a intentarlo.",
  "Task updated.": "Tarea actualizada.",
  "Task created.": "Tarea creada.",
  "Switch to light theme": "Cambiar al tema claro",
  "Switch to dark theme": "Cambiar al tema oscuro",
  "Help me adjust my remaining schedule for today.": "Ayúdame a ajustar lo que queda de mi horario de hoy.",
  "Allow sending my chat requests and selected workday context to OpenRouter and the selected model provider.": "Permitir el envío de mis solicitudes de chat y del contexto de jornada seleccionado a OpenRouter y al proveedor del modelo seleccionado.",
  "Allow sending my chat requests and selected workday context to {provider}.": "Permitir el envío de mis solicitudes de chat y del contexto de jornada seleccionado a {provider}.",
  "Signed out of ChatGPT.": "Sesión de ChatGPT cerrada.",
  "Signed out here. ChatGPT could not confirm it: also disconnect this app in your ChatGPT settings.": "Sesión cerrada aquí. ChatGPT no pudo confirmarlo: desconecta también esta aplicación en los ajustes de ChatGPT.",
  "Pause focus": "Pausar la concentración",
  "Resume focus": "Reanudar la concentración",
  "Start focus": "Iniciar la concentración",
  "Unable to save meeting.": "No se pudo guardar la reunión.",
  "Unable to plan the day.": "No se pudo planificar el día.",
  "Review the extended estimate and updated plan below.": "Revisa abajo la estimación ampliada y el plan actualizado.",
  "Check-in saved. Preview the plan to adjust remaining work.": "Seguimiento guardado. Previsualiza el plan para ajustar el trabajo restante.",
  "Unable to save check-in.": "No se pudo guardar el seguimiento.",
  "Unable to approve plan.": "No se pudo aprobar el plan.",
  "Unable to save settings.": "No se pudieron guardar los ajustes.",
  "Short break": "Descanso corto"
}, zP = "Neu laden", RP = "Schließen", xP = "Kategorie", OP = "Beschreibung", MP = "Notizen", $P = "Priorität", NP = "Hoch", jP = "Mittel", LP = "Niedrig", GP = "Status", FP = "Abbrechen", UP = "Aufgaben", ZP = "Heute", qP = "Erledigt", KP = "Wieder öffnen", WP = "Erledigen", YP = "Min.", VP = "Fällig", BP = "Bearbeiten", HP = "Zurückstellen", QP = "Löschen", XP = "Einstellungen", JP = "Darstellung", eA = "Sprache", tA = "Unterhaltung", nA = "Sie", rA = "Senden", oA = "Keine", iA = "Aufgabe", aA = "Verbunden", sA = "Pausieren", uA = "Fortsetzen", cA = "Fokus", lA = "Zeitplan", dA = "Termin", hA = "Besprechungen", fA = "Zeitzone", mA = "Mo", pA = "Di", gA = "Mi", vA = "Do", yA = "Fr", bA = "Sa", wA = "So", kA = "Entfernen", _A = "Erinnerungen", TA = "Pausiert", CA = "Zurückgestellt", PA = "zu erledigen", AA = "pausiert", EA = "erledigt", SA = "zurückgestellt", DA = "hoch", IA = "mittel", zA = "niedrig", RA = "Entwicklung", xA = "Review", OA = "Schreiben", MA = "Planung", $A = "Kommunikation", NA = "Sonstiges", jA = "Aufgabe", LA = "Besprechung", GA = "dunkel", FA = "hell", UA = "Titel", ZA = "Frist", qA = "Voraussetzungen", KA = "Beginn", WA = "Ende", YA = "Mittagspause", VA = {
  "Unable to open Workday": "Workday kann nicht geöffnet werden",
  "Your data has not been deleted. Reload the panel to try again.": "Ihre Daten wurden nicht gelöscht. Laden Sie das Panel neu, um es erneut zu versuchen.",
  Reload: zP,
  Dismiss: RP,
  "Open Workday": "Workday öffnen",
  "Edit task": "Aufgabe bearbeiten",
  "New task": "Neue Aufgabe",
  "Close task editor": "Aufgabeneditor schließen",
  "Task title": "Titel der Aufgabe",
  "What needs your attention?": "Was braucht Ihre Aufmerksamkeit?",
  Category: xP,
  Description: OP,
  Notes: MP,
  "Anything you don’t want to forget": "Alles, was Sie nicht vergessen möchten",
  Priority: $P,
  High: NP,
  Medium: jP,
  Low: LP,
  "Estimate · minutes": "Schätzung · Minuten",
  "Scheduled date": "Geplantes Datum",
  Status: GP,
  "Deadline ({zone})": "Frist ({zone})",
  "Dependencies (optional)": "Abhängigkeiten (optional)",
  "Missing prerequisite ({id}) — uncheck to remove": "Fehlende Voraussetzung ({id}) – zum Entfernen abwählen",
  Cancel: FP,
  "Saving…": "Wird gespeichert…",
  "Save task": "Aufgabe speichern",
  "Local data exported.": "Lokale Daten exportiert.",
  "Main navigation": "Hauptnavigation",
  "Local storage unavailable: {error}. Reload the panel to retry.": "Lokaler Speicher nicht verfügbar: {error}. Laden Sie das Panel neu, um es erneut zu versuchen.",
  "Dismiss message": "Meldung schließen",
  "Day off": "Freier Tag",
  "Before work": "Vor der Arbeit",
  "Workday ended": "Arbeitstag beendet",
  "Workday in progress": "Arbeitstag läuft",
  "Daily task progress": "Fortschritt der Tagesaufgaben",
  "{done} of {total} done": "{done} von {total} erledigt",
  "{minutes} min left": "Noch {minutes} Min.",
  "{done} of {total} tasks completed": "{done} von {total} Aufgaben erledigt",
  Tasks: UP,
  "Add task": "Aufgabe hinzufügen",
  "Filter tasks": "Aufgaben filtern",
  Today: ZP,
  "All tasks": "Alle Aufgaben",
  Completed: qP,
  "Loading local tasks…": "Lokale Aufgaben werden geladen…",
  "Your wins will appear here": "Ihre Erfolge erscheinen hier",
  "Make room for your best work": "Schaffen Sie Platz für Ihre beste Arbeit",
  "Add your first task for today. Keep it small, give it an estimate, and take it from there.": "Fügen Sie Ihre erste Aufgabe für heute hinzu. Halten Sie sie klein, geben Sie ihr eine Schätzung und machen Sie von dort aus weiter.",
  "Create a task to get started.": "Erstellen Sie eine Aufgabe, um loszulegen.",
  "Create a task": "Aufgabe erstellen",
  Reopen: KP,
  Complete: WP,
  "Task reopened.": "Aufgabe wieder geöffnet.",
  "Task completed.": "Aufgabe erledigt.",
  min: YP,
  Due: VP,
  Edit: BP,
  "Task deferred.": "Aufgabe zurückgestellt.",
  Defer: HP,
  Delete: QP,
  "Delete this task and its work records?": "Diese Aufgabe und ihre Arbeitsaufzeichnungen löschen?",
  "Task deleted.": "Aufgabe gelöscht.",
  "Delete task": "Aufgabe löschen",
  "Ask AI to adjust my day": "KI bitten, meinen Tag anzupassen",
  Settings: XP,
  Appearance: JP,
  "Color theme": "Farbschema",
  Language: eA,
  "Display language": "Anzeigesprache",
  "Same as browser": "Wie im Browser",
  "The assistant also replies in this language.": "Der Assistent antwortet ebenfalls in dieser Sprache.",
  "Your data": "Ihre Daten",
  "Everything is saved in this browser on this device and works offline. Uninstalling the extension or clearing browser data removes it.": "Alles wird in diesem Browser auf diesem Gerät gespeichert und funktioniert offline. Wenn Sie die Erweiterung deinstallieren oder die Browserdaten löschen, werden die Daten entfernt.",
  "Export local data": "Lokale Daten exportieren",
  "Exports contain tasks and work records, never keys or sign-ins.": "Exporte enthalten Aufgaben und Arbeitsaufzeichnungen, niemals Schlüssel oder Anmeldungen.",
  "Delete all local data": "Alle lokalen Daten löschen",
  "Permanently delete all tasks, work records, chats and AI settings, and sign out of ChatGPT? Export a backup first if you need one.": "Alle Aufgaben, Arbeitsaufzeichnungen, Chats und KI-Einstellungen endgültig löschen und von ChatGPT abmelden? Exportieren Sie bei Bedarf zuerst eine Sicherung.",
  "All task and work records deleted.": "Alle Aufgaben und Arbeitsaufzeichnungen wurden gelöscht.",
  "Delete permanently": "Endgültig löschen",
  "AI Chat": "KI-Chat",
  "Back to Today": "Zurück zu Heute",
  "Clear chat": "Chat leeren",
  "Connect your ChatGPT account, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Verbinden Sie Ihr ChatGPT-Konto, wählen Sie ein Modell und aktivieren Sie die Datenfreigabe in den Einstellungen. Die manuelle Planung funktioniert auch ohne KI.",
  "Connect your own {provider} API key, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Hinterlegen Sie Ihren eigenen {provider}-API-Schlüssel, wählen Sie ein Modell und aktivieren Sie die Datenfreigabe in den Einstellungen. Die manuelle Planung funktioniert auch ohne KI.",
  "Configure AI": "KI einrichten",
  "Using ChatGPT plan ·": "ChatGPT-Abo wird verwendet ·",
  "Manage usage": "Nutzung verwalten",
  "You’re offline. Saved conversations and manual planning remain available; sending needs a connection.": "Sie sind offline. Gespeicherte Unterhaltungen und die manuelle Planung bleiben verfügbar; zum Senden ist eine Verbindung nötig.",
  "{provider} · Model: {model}": "{provider} · Modell: {model}",
  "Chat options": "Chat-Optionen",
  "Task changes require your approval.": "Änderungen an Aufgaben erfordern Ihre Zustimmung.",
  "Planning date": "Planungsdatum",
  "Task context": "Aufgabenkontext",
  "This day, next day & unscheduled": "Dieser Tag, der nächste Tag und Ungeplantes",
  "All dates (up to 80 tasks + prerequisites)": "Alle Termine (bis zu 80 Aufgaben + Voraussetzungen)",
  "Include task descriptions and notes (up to 500 characters each)": "Beschreibungen und Notizen der Aufgaben einbeziehen (jeweils bis zu 500 Zeichen)",
  "Include meeting titles, so the assistant can find a meeting by name": "Besprechungstitel einbeziehen, damit der Assistent eine Besprechung anhand des Namens findet",
  "Each request sends up to 80 tasks, your meeting times, work hours and your six most recent messages with this provider. Webpages are never sent.": "Jede Anfrage sendet bis zu 80 Aufgaben, Ihre Besprechungszeiten, Ihre Arbeitszeiten und Ihre sechs letzten Nachrichten mit diesem Anbieter. Webseiten werden nie gesendet.",
  Conversation: tA,
  "Tell me what’s on your plate. I’ll suggest task changes for you to approve.": "Erzählen Sie mir, was ansteht. Ich schlage Änderungen an Aufgaben vor, die Sie bestätigen können.",
  "Plan my day.": "Plane meinen Tag.",
  "What should I work on next?": "Woran sollte ich als Nächstes arbeiten?",
  "What tasks have I not completed?": "Welche Aufgaben habe ich noch nicht erledigt?",
  You: nA,
  "Thinking…": "Denkt nach…",
  "Interrupted or pending request. Retry with the latest context.": "Anfrage unterbrochen oder ausstehend. Versuchen Sie es mit dem aktuellen Kontext erneut.",
  "Request cancelled.": "Anfrage abgebrochen.",
  "Retry request": "Anfrage wiederholen",
  " · retried once": " · einmal wiederholt",
  "Message to AI": "Nachricht an die KI",
  "What would you like to plan?": "Was möchten Sie planen?",
  "Shift+Enter for a new line": "Umschalt+Eingabe für eine neue Zeile",
  "Cancel request": "Anfrage abbrechen",
  Send: rA,
  "Clear conversation": "Unterhaltung leeren",
  "Delete this provider’s local conversation and proposals? Other conversations, approved tasks and schedules will remain.": "Die lokale Unterhaltung und die Vorschläge dieses Anbieters löschen? Andere Unterhaltungen, bestätigte Aufgaben und Zeitpläne bleiben erhalten.",
  "Unable to clear chat.": "Der Chat konnte nicht geleert werden.",
  "Delete chat": "Chat löschen",
  None: oA,
  "Missing prerequisite": "Fehlende Voraussetzung",
  "AI change proposal": "Änderungsvorschlag der KI",
  "Changes approved": "Änderungen bestätigt",
  "Proposal rejected": "Vorschlag abgelehnt",
  "Review proposed changes": "Vorgeschlagene Änderungen prüfen",
  "Nothing has been applied. Preview expires after 60 seconds; refresh it if needed. The local scheduler rechecks times at approval.": "Es wurde nichts angewendet. Die Vorschau läuft nach 60 Sekunden ab; aktualisieren Sie sie bei Bedarf. Der lokale Planer prüft die Zeiten bei der Bestätigung erneut.",
  "AI proposed schedule": "Von der KI vorgeschlagener Zeitplan",
  "Showing 200 of {count} blocks. Use Today after approval for the full timeline.": "Es werden 200 von {count} Blöcken angezeigt. Den vollständigen Zeitplan finden Sie nach der Bestätigung unter Heute.",
  "Overflow · {count} task(s)": "Passt nicht · {count} Aufgabe(n)",
  Task: iA,
  "Approve changes": "Änderungen bestätigen",
  "Reject changes": "Änderungen ablehnen",
  "Refresh preview": "Vorschau aktualisieren",
  "Tasks and affected schedules were saved together.": "Aufgaben und betroffene Zeitpläne wurden gemeinsam gespeichert.",
  "No task or schedule changes were applied.": "Es wurden keine Änderungen an Aufgaben oder Zeitplänen angewendet.",
  "View Today": "Heute anzeigen",
  "AI provider settings": "Einstellungen des KI-Anbieters",
  "AI assistant": "KI-Assistent",
  "Assistant name": "Name des Assistenten",
  "Shown in chat, and the assistant answers to it. Saved as you type.": "Wird im Chat angezeigt, und der Assistent hört darauf. Wird beim Tippen gespeichert.",
  "AI provider": "KI-Anbieter",
  "{provider} selected. Each provider keeps its own settings and conversation.": "{provider} ausgewählt. Jeder Anbieter behält seine eigenen Einstellungen und seine eigene Unterhaltung.",
  "Unable to switch AI provider. Please retry.": "Der KI-Anbieter konnte nicht gewechselt werden. Bitte versuchen Sie es erneut.",
  "Retrieved {count} models from {provider}. Select a model and save.": "{count} Modelle von {provider} abgerufen. Wählen Sie ein Modell und speichern Sie.",
  "{provider} settings saved. Send a request in AI Chat to test the selected model.": "{provider}-Einstellungen gespeichert. Senden Sie eine Anfrage im KI-Chat, um das gewählte Modell zu testen.",
  "Unable to save AI settings. Check the model ID and key (16–512 characters, no spaces).": "Die KI-Einstellungen konnten nicht gespeichert werden. Prüfen Sie die Modell-ID und den Schlüssel (16–512 Zeichen, keine Leerzeichen).",
  "{provider} settings": "{provider}-Einstellungen",
  "Uses your own API key, saved only in this extension on this device.": "Verwendet Ihren eigenen API-Schlüssel, der nur in dieser Erweiterung auf diesem Gerät gespeichert wird.",
  " To sign in with a ChatGPT subscription instead, choose ChatGPT plan above.": " Um sich stattdessen mit einem ChatGPT-Abo anzumelden, wählen Sie oben ChatGPT-Abo.",
  " Get a key from the Anthropic Console. A Claude subscription cannot be used here.": " Einen Schlüssel erhalten Sie in der Anthropic Console. Ein Claude-Abo kann hier nicht verwendet werden.",
  "{provider} API key": "{provider}-API-Schlüssel",
  "Saved key · enter a replacement": "Schlüssel gespeichert · zum Ersetzen neuen eingeben",
  "Enter your own {provider} key": "Eigenen {provider}-Schlüssel eingeben",
  "A key is saved on this device.": "Auf diesem Gerät ist ein Schlüssel gespeichert.",
  "No API key saved.": "Kein API-Schlüssel gespeichert.",
  "Working…": "Wird bearbeitet…",
  "Refresh models": "Modelle aktualisieren",
  "{provider} key removed and sharing disabled. Other providers are unchanged.": "{provider}-Schlüssel entfernt und Freigabe deaktiviert. Andere Anbieter bleiben unverändert.",
  "Unable to remove the saved key. Please retry.": "Der gespeicherte Schlüssel konnte nicht entfernt werden. Bitte versuchen Sie es erneut.",
  "Forget key": "Schlüssel vergessen",
  "Show free models only": "Nur kostenlose Modelle anzeigen",
  "Find a model": "Modell suchen",
  "Search name or ID": "Nach Name oder ID suchen",
  "Discovered model": "Gefundenes Modell",
  "Choose a model…": "Modell auswählen…",
  " · Free": " · Kostenlos",
  " · Paid": " · Kostenpflichtig",
  "Model ID": "Modell-ID",
  "Select above or enter a model ID": "Oben auswählen oder eine Modell-ID eingeben",
  "Free model; account limits still apply.": "Kostenloses Modell; die Kontolimits gelten weiterhin.",
  "Paid model · prompt {prompt} / completion {completion} USD per token.": "Kostenpflichtiges Modell · Eingabe {prompt} / Ausgabe {completion} USD pro Token.",
  "Requests may be billed by {provider}. Check pricing in your provider account.": "Anfragen können von {provider} berechnet werden. Prüfen Sie die Preise in Ihrem Anbieterkonto.",
  "Save AI settings": "KI-Einstellungen speichern",
  "What gets shared?": "Was wird geteilt?",
  "Each request sends task summaries, work hours, meeting times and your recent conversation with this provider. Meeting titles are sent unless you turn that off in Chat options; task descriptions and notes are sent only if you turn that on. Webpages and saved keys are never sent. An invalid answer may trigger one automatic retry, which can cost extra. There is no automatic switch to another provider or a paid model.": "Jede Anfrage sendet Aufgabenzusammenfassungen, Ihre Arbeitszeiten, Ihre Besprechungszeiten und Ihre letzte Unterhaltung mit diesem Anbieter. Besprechungstitel werden gesendet, sofern Sie das nicht in den Chat-Optionen ausschalten; Beschreibungen und Notizen der Aufgaben werden nur gesendet, wenn Sie das einschalten. Webseiten und gespeicherte Schlüssel werden nie gesendet. Eine ungültige Antwort kann einen automatischen Wiederholungsversuch auslösen, der zusätzliche Kosten verursachen kann. Es gibt keinen automatischen Wechsel zu einem anderen Anbieter oder einem kostenpflichtigen Modell.",
  "ChatGPT connected. Choose a model and allow sharing to finish.": "ChatGPT verbunden. Wählen Sie ein Modell und erlauben Sie die Freigabe, um abzuschließen.",
  "ChatGPT plan settings": "Einstellungen für das ChatGPT-Abo",
  "ChatGPT plan": "ChatGPT-Abo",
  "Use your ChatGPT subscription instead of an API key. Availability depends on your plan, workspace and region.": "Verwenden Sie Ihr ChatGPT-Abo statt eines API-Schlüssels. Die Verfügbarkeit hängt von Ihrem Tarif, Ihrem Arbeitsbereich und Ihrer Region ab.",
  "Finish signing in in the browser tab that opened, then come back here.": "Schließen Sie die Anmeldung im geöffneten Browser-Tab ab und kehren Sie dann hierher zurück.",
  "Cancel sign-in": "Anmeldung abbrechen",
  "Continue with ChatGPT": "Mit ChatGPT fortfahren",
  Connected: aA,
  "Plan access off": "Abo-Zugriff aus",
  "Signed out": "Abgemeldet",
  " · In use": " · In Verwendung",
  "Use account": "Konto verwenden",
  "Enable plan access": "Abo-Zugriff aktivieren",
  "Sign in again": "Erneut anmelden",
  "Sign out": "Abmelden",
  "You’re using your ChatGPT plan": "Sie verwenden Ihr ChatGPT-Abo",
  "Got it": "Verstanden",
  "ChatGPT is ready. Open AI Chat to start.": "ChatGPT ist bereit. Öffnen Sie den KI-Chat, um zu beginnen.",
  "ChatGPT model": "ChatGPT-Modell",
  "Refresh ChatGPT models": "ChatGPT-Modelle aktualisieren",
  "Allow sending my requests, selected workday context and this account’s recent chat to OpenAI using my ChatGPT plan.": "Erlauben, dass meine Anfragen, der ausgewählte Arbeitstag-Kontext und der letzte Chat dieses Kontos über mein ChatGPT-Abo an OpenAI gesendet werden.",
  "Save ChatGPT settings": "ChatGPT-Einstellungen speichern",
  "Task changes always wait for your approval.": "Änderungen an Aufgaben warten immer auf Ihre Zustimmung.",
  "Sign-in runs inside the extension; there is nothing else to install. Your ChatGPT session is saved in this extension’s private storage in this browser profile until you sign out. Signing out removes the account, its saved details and its conversation from this extension.": "Die Anmeldung läuft innerhalb der Erweiterung; es muss nichts weiter installiert werden. Ihre ChatGPT-Sitzung wird im privaten Speicher dieser Erweiterung in diesem Browserprofil gespeichert, bis Sie sich abmelden. Beim Abmelden werden das Konto, seine gespeicherten Angaben und seine Unterhaltung aus dieser Erweiterung entfernt.",
  "Focus timer": "Fokus-Timer",
  "Focusing now": "Fokus läuft",
  "Focus paused": "Fokus pausiert",
  "{time} remaining": "Noch {time}",
  "{time} over estimate": "{time} über der Schätzung",
  "Focus paused.": "Fokus pausiert.",
  "Focus resumed.": "Fokus fortgesetzt.",
  Pause: sA,
  Resume: uA,
  "Task completed. Preview the plan to reuse the free time.": "Aufgabe erledigt. Sehen Sie sich eine Planvorschau an, um die frei gewordene Zeit zu nutzen.",
  "Focus started.": "Fokus gestartet.",
  Focus: cA,
  "Meeting editor": "Besprechungseditor",
  "Edit meeting": "Besprechung bearbeiten",
  "New meeting": "Neue Besprechung",
  "Close meeting editor": "Besprechungseditor schließen",
  "Times in {zone}": "Zeiten in {zone}",
  "Meeting title": "Titel der Besprechung",
  "Meeting starts": "Beginn der Besprechung",
  "Meeting ends": "Ende der Besprechung",
  "Save meeting": "Besprechung speichern",
  "Loading your schedule…": "Ihr Zeitplan wird geladen…",
  "Plan approved and saved.": "Plan bestätigt und gespeichert.",
  "Day planner": "Tagesplaner",
  "Meeting now": "Besprechung läuft",
  "Next meeting": "Nächste Besprechung",
  "How is this task going?": "Wie läuft diese Aufgabe?",
  "Need more time (+30m)": "Mehr Zeit nötig (+30 Min.)",
  "Skip for now": "Vorerst überspringen",
  Schedule: lA,
  "Planning…": "Wird geplant…",
  "Preview plan": "Planvorschau",
  "Plan date": "Plandatum",
  " (next day)": " (nächster Tag)",
  "Tasks or constraints changed. Preview and approve an updated plan before following this timeline.": "Aufgaben oder Rahmenbedingungen haben sich geändert. Sehen Sie sich eine aktualisierte Planvorschau an und bestätigen Sie sie, bevor Sie diesem Zeitplan folgen.",
  "Review your proposed plan": "Vorgeschlagenen Plan prüfen",
  "Includes 30 more minutes for the selected task. ": "Enthält 30 zusätzliche Minuten für die ausgewählte Aufgabe. ",
  "Nothing is saved until you approve. This preview expires in 60 seconds.": "Es wird nichts gespeichert, bis Sie zustimmen. Diese Vorschau läuft in 60 Sekunden ab.",
  "Approve plan": "Plan bestätigen",
  "Reject plan": "Plan ablehnen",
  "Proposed schedule": "Vorgeschlagener Zeitplan",
  "Approved schedule": "Bestätigter Zeitplan",
  Commitment: dA,
  "No schedule yet. Preview a plan to fit tasks around meetings and breaks.": "Noch kein Zeitplan. Sehen Sie sich eine Planvorschau an, um Aufgaben um Besprechungen und Pausen herum einzuplanen.",
  "Doesn’t fit in this workday": "Passt nicht in diesen Arbeitstag",
  "Shorten a task, change your hours, or move a task to {date}.": "Kürzen Sie eine Aufgabe, ändern Sie Ihre Arbeitszeiten oder verschieben Sie eine Aufgabe auf den {date}.",
  Meetings: hA,
  "Add meeting": "Besprechung hinzufügen",
  "Meeting saved. Review the updated plan.": "Besprechung gespeichert. Prüfen Sie den aktualisierten Plan.",
  "No meetings for this day.": "Keine Besprechungen an diesem Tag.",
  "Delete meeting": "Besprechung löschen",
  "Delete this meeting?": "Diese Besprechung löschen?",
  "Meeting deleted. Review the updated plan.": "Besprechung gelöscht. Prüfen Sie den aktualisierten Plan.",
  "System notifications could not be delivered. Check Windows notification settings for Microsoft Edge; your schedule and check-ins remain available here.": "Systembenachrichtigungen konnten nicht zugestellt werden. Prüfen Sie die Windows-Benachrichtigungseinstellungen für Microsoft Edge; Ihr Zeitplan und Ihre Check-ins bleiben hier verfügbar.",
  " · now": " · jetzt",
  "Reminders only pop up in the installed extension.": "Erinnerungen erscheinen nur in der installierten Erweiterung.",
  "Workday reminders are on": "Workday-Erinnerungen sind aktiviert",
  "Reminders and check-ins will appear like this.": "Erinnerungen und Check-ins werden so angezeigt.",
  "A reminder window should have opened.": "Ein Erinnerungsfenster sollte sich geöffnet haben.",
  "Sent to Windows. If nothing appeared, Windows is blocking notifications from Microsoft Edge (Settings → System → Notifications, or Do not disturb). Switch on “Pop up in a browser window” above to avoid that.": "An Windows gesendet. Falls nichts erschienen ist, blockiert Windows Benachrichtigungen von Microsoft Edge (Einstellungen → System → Benachrichtigungen oder „Nicht stören“). Aktivieren Sie oben „In einem Browserfenster anzeigen“, um das zu vermeiden.",
  "The reminder could not be shown. Try the other reminder style.": "Die Erinnerung konnte nicht angezeigt werden. Probieren Sie die andere Erinnerungsart.",
  "Workday settings saved. Preview your schedule to apply changed constraints.": "Arbeitstag-Einstellungen gespeichert. Sehen Sie sich eine Vorschau Ihres Zeitplans an, um die geänderten Rahmenbedingungen anzuwenden.",
  "Workday settings": "Arbeitstag-Einstellungen",
  "Workday start": "Beginn des Arbeitstags",
  "Workday end": "Ende des Arbeitstags",
  "An end time before the start means an overnight shift.": "Eine Endzeit vor der Startzeit bedeutet eine Nachtschicht.",
  Timezone: fA,
  "Working days": "Arbeitstage",
  Mon: mA,
  Tue: pA,
  Wed: gA,
  Thu: vA,
  Fri: yA,
  Sat: bA,
  Sun: wA,
  "Reserve lunch": "Mittagspause reservieren",
  "Lunch starts": "Beginn der Mittagspause",
  "Lunch · minutes": "Mittagspause · Minuten",
  "Additional breaks": "Zusätzliche Pausen",
  "Break name": "Name der Pause",
  "Break starts": "Beginn der Pause",
  "Break · minutes": "Pause · Minuten",
  Remove: kA,
  "Remove break": "Pause entfernen",
  "Add break": "Pause hinzufügen",
  Reminders: _A,
  "Pop up reminders and check-ins": "Erinnerungen und Check-ins einblenden",
  "Pop up in a browser window (works even when Windows notifications are off)": "In einem Browserfenster anzeigen (funktioniert auch, wenn Windows-Benachrichtigungen aus sind)",
  "Reminders appear while Edge is running, even with this panel closed. Untick the second box to use Windows system notifications instead. Save after changing these.": "Erinnerungen erscheinen, solange Edge läuft, auch wenn dieses Panel geschlossen ist. Entfernen Sie das zweite Häkchen, um stattdessen Windows-Systembenachrichtigungen zu verwenden. Speichern Sie nach dem Ändern.",
  "Send a test reminder": "Testerinnerung senden",
  "Task-start reminders": "Erinnerungen zum Aufgabenbeginn",
  "Upcoming meetings": "Anstehende Besprechungen",
  "Break reminders": "Pausenerinnerungen",
  "Workday-end reminder": "Erinnerung zum Ende des Arbeitstags",
  "Lead time · minutes": "Vorlaufzeit · Minuten",
  "Check-in · minutes": "Check-in · Minuten",
  "Set check-in to 0 to turn off periodic check-ins.": "Setzen Sie den Check-in auf 0, um regelmäßige Check-ins auszuschalten.",
  "Quiet hours for notifications": "Ruhezeiten für Benachrichtigungen",
  "Quiet hours start": "Beginn der Ruhezeit",
  "Quiet hours end": "Ende der Ruhezeit",
  "Save workday settings": "Arbeitstag-Einstellungen speichern",
  "The AI request could not be completed. No task changes were applied. Retry or use the manual planner.": "Die KI-Anfrage konnte nicht abgeschlossen werden. Es wurden keine Änderungen an Aufgaben angewendet. Versuchen Sie es erneut oder verwenden Sie den manuellen Planer.",
  "Reconnect your ChatGPT plan in Settings.": "Verbinden Sie Ihr ChatGPT-Abo in den Einstellungen erneut.",
  "Enter a request between 1 and 6000 characters.": "Geben Sie eine Anfrage mit 1 bis 6000 Zeichen ein.",
  "This request is already answered or no longer exists.": "Diese Anfrage wurde bereits beantwortet oder existiert nicht mehr.",
  "This request already has a proposal. Review it instead of retrying.": "Zu dieser Anfrage gibt es bereits einen Vorschlag. Prüfen Sie ihn, statt es erneut zu versuchen.",
  "Switch back to the original provider to retry this request.": "Wechseln Sie zurück zum ursprünglichen Anbieter, um diese Anfrage zu wiederholen.",
  "AI request cancelled. No task changes were applied.": "KI-Anfrage abgebrochen. Es wurden keine Änderungen an Aufgaben angewendet.",
  "This request was cancelled because chat data or AI configuration changed.": "Diese Anfrage wurde abgebrochen, weil sich Chat-Daten oder die KI-Konfiguration geändert haben.",
  "Your workday changed while the model was responding. Retry with the latest context.": "Ihr Arbeitstag hat sich geändert, während das Modell geantwortet hat. Versuchen Sie es mit dem aktuellen Kontext erneut.",
  "ChatGPT usage limit reached. Manage usage in ChatGPT, then retry here.": "ChatGPT-Nutzungslimit erreicht. Verwalten Sie die Nutzung in ChatGPT und versuchen Sie es dann hier erneut.",
  "ChatGPT plan access is unavailable for this account, workspace or region.": "Der Zugriff über das ChatGPT-Abo ist für dieses Konto, diesen Arbeitsbereich oder diese Region nicht verfügbar.",
  "ChatGPT authorization expired. Sign in again.": "Die ChatGPT-Autorisierung ist abgelaufen. Melden Sie sich erneut an.",
  "ChatGPT could not complete this request. Please retry later.": "ChatGPT konnte diese Anfrage nicht abschließen. Bitte versuchen Sie es später erneut.",
  "ChatGPT request cancelled.": "ChatGPT-Anfrage abgebrochen.",
  "ChatGPT could not be reached. Your saved sign-in is kept.": "ChatGPT ist nicht erreichbar. Ihre gespeicherte Anmeldung bleibt erhalten.",
  "ChatGPT sign-in timed out. Please try again.": "Zeitüberschreitung bei der ChatGPT-Anmeldung. Bitte versuchen Sie es erneut.",
  "A ChatGPT sign-in is already open. Finish or cancel it first.": "Eine ChatGPT-Anmeldung ist bereits geöffnet. Schließen Sie sie zuerst ab oder brechen Sie sie ab.",
  "The selected ChatGPT account no longer exists.": "Das ausgewählte ChatGPT-Konto existiert nicht mehr.",
  "Sign out of the current ChatGPT account before signing in to another.": "Melden Sie sich vom aktuellen ChatGPT-Konto ab, bevor Sie sich bei einem anderen anmelden.",
  "Unable to open the ChatGPT sign-in tab.": "Der ChatGPT-Anmelde-Tab konnte nicht geöffnet werden.",
  "ChatGPT sign-in was not authorized.": "Die ChatGPT-Anmeldung wurde nicht autorisiert.",
  "ChatGPT sign-in was cancelled.": "Die ChatGPT-Anmeldung wurde abgebrochen.",
  "ChatGPT sign-in did not complete. Please retry.": "Die ChatGPT-Anmeldung wurde nicht abgeschlossen. Bitte versuchen Sie es erneut.",
  "Sign in with ChatGPT first.": "Melden Sie sich zuerst mit ChatGPT an.",
  "Your ChatGPT session expired. Sign in again.": "Ihre ChatGPT-Sitzung ist abgelaufen. Melden Sie sich erneut an.",
  "ChatGPT plan use is not enabled. Choose Enable plan access in Settings.": "Die Nutzung des ChatGPT-Abos ist nicht aktiviert. Wählen Sie in den Einstellungen Abo-Zugriff aktivieren.",
  "Choose a ChatGPT model in Settings.": "Wählen Sie in den Einstellungen ein ChatGPT-Modell.",
  "ChatGPT took too long to answer. No task changes were applied.": "ChatGPT hat zu lange für die Antwort gebraucht. Es wurden keine Änderungen an Aufgaben angewendet.",
  "ChatGPT request interrupted. No task changes were applied.": "ChatGPT-Anfrage unterbrochen. Es wurden keine Änderungen an Aufgaben angewendet.",
  "ChatGPT response was interrupted or empty. No task changes were applied.": "Die Antwort von ChatGPT wurde unterbrochen oder war leer. Es wurden keine Änderungen an Aufgaben angewendet.",
  "Connect a ChatGPT account first.": "Verbinden Sie zuerst ein ChatGPT-Konto.",
  "The AI request timed out. Retry or choose a faster model.": "Zeitüberschreitung bei der KI-Anfrage. Versuchen Sie es erneut oder wählen Sie ein schnelleres Modell.",
  "Enter a valid provider API key (16–512 characters, no spaces or control characters).": "Geben Sie einen gültigen API-Schlüssel ein (16–512 Zeichen, keine Leer- oder Steuerzeichen).",
  "Enter a model ID in the model field, not an API key.": "Geben Sie im Modellfeld eine Modell-ID ein, keinen API-Schlüssel.",
  "Connect ChatGPT and enable plan access first.": "Verbinden Sie zuerst ChatGPT und aktivieren Sie den Abo-Zugriff.",
  "Model discovery cancelled.": "Modellsuche abgebrochen.",
  "Model discovery cancelled because the saved key changed.": "Modellsuche abgebrochen, weil sich der gespeicherte Schlüssel geändert hat.",
  "The provider returned no usable model IDs. Retry discovery or enter a model ID manually.": "Der Anbieter hat keine verwendbaren Modell-IDs zurückgegeben. Wiederholen Sie die Suche oder geben Sie eine Modell-ID manuell ein.",
  "Sign in to this ChatGPT account first.": "Melden Sie sich zuerst bei diesem ChatGPT-Konto an.",
  "The AI request timed out. Your manual planner is still available.": "Zeitüberschreitung bei der KI-Anfrage. Ihr manueller Planer ist weiterhin verfügbar.",
  "The provider response was too large. Try a smaller request or another model.": "Die Antwort des Anbieters war zu groß. Versuchen Sie eine kürzere Anfrage oder ein anderes Modell.",
  "No text chat models were found. Retry discovery or enter a model ID manually.": "Es wurden keine Text-Chat-Modelle gefunden. Wiederholen Sie die Suche oder geben Sie eine Modell-ID manuell ein.",
  "The model returned a refused, incomplete or invalid response. No task data changed. Try another model or a smaller request.": "Das Modell hat eine abgelehnte, unvollständige oder ungültige Antwort zurückgegeben. Es wurden keine Aufgabendaten geändert. Versuchen Sie ein anderes Modell oder eine kürzere Anfrage.",
  "The model could not produce valid task actions. No task data changed.": "Das Modell konnte keine gültigen Aufgabenaktionen erzeugen. Es wurden keine Aufgabendaten geändert.",
  "Meeting times are invalid or ambiguous in your workday timezone.": "Die Besprechungszeiten sind in der Zeitzone Ihres Arbeitstags ungültig oder mehrdeutig.",
  "Meeting end must be after its start and within seven days.": "Das Ende der Besprechung muss nach ihrem Beginn und innerhalb von sieben Tagen liegen.",
  "The model referenced a meeting that does not exist.": "Das Modell hat auf eine Besprechung verwiesen, die nicht existiert.",
  "The referenced task no longer exists.": "Die referenzierte Aufgabe existiert nicht mehr.",
  "This task is already completed.": "Diese Aufgabe ist bereits erledigt.",
  "Reopen the task before adding focus time.": "Öffnen Sie die Aufgabe wieder, bevor Sie Fokuszeit hinzufügen.",
  "Limit one proposal to seven affected workdays.": "Beschränken Sie einen Vorschlag auf sieben betroffene Arbeitstage.",
  "This proposal has already been resolved or removed.": "Dieser Vorschlag wurde bereits bearbeitet oder entfernt.",
  "This proposal expired. Refresh its preview before approval.": "Dieser Vorschlag ist abgelaufen. Aktualisieren Sie seine Vorschau, bevor Sie ihn bestätigen.",
  "Your tasks, meetings, focus or work settings changed. Refresh the preview before approval.": "Ihre Aufgaben, Besprechungen, Fokuszeiten oder Arbeitseinstellungen haben sich geändert. Aktualisieren Sie die Vorschau vor der Bestätigung.",
  "This proposal is no longer pending.": "Dieser Vorschlag ist nicht mehr ausstehend.",
  "Here are the changes for you to review.": "Hier sind die Änderungen zur Prüfung.",
  "The model did not return valid task actions. No task data changed. Try again or choose another model.": "Das Modell hat keine gültigen Aufgabenaktionen zurückgegeben. Es wurden keine Aufgabendaten geändert. Versuchen Sie es erneut oder wählen Sie ein anderes Modell.",
  "Reopen this task before starting focus.": "Öffnen Sie diese Aufgabe wieder, bevor Sie den Fokus starten.",
  "Time to focus": "Zeit, sich zu konzentrieren",
  "Break time": "Zeit für eine Pause",
  "Upcoming meeting": "Anstehende Besprechung",
  "Your workday is ending": "Ihr Arbeitstag geht zu Ende",
  "Review your progress and leave unfinished tasks for another day.": "Sehen Sie sich Ihren Fortschritt an und heben Sie unerledigte Aufgaben für einen anderen Tag auf.",
  "Work from another saved plan reserves time in this window.": "Arbeit aus einem anderen gespeicherten Plan belegt Zeit in diesem Zeitfenster.",
  "This is not a configured working day.": "Dies ist kein konfigurierter Arbeitstag.",
  "Unfinished, missing or circular dependency": "Unerledigte, fehlende oder zirkuläre Abhängigkeit",
  "Estimate used up; complete this task or add more time": "Schätzung aufgebraucht; erledigen Sie diese Aufgabe oder fügen Sie Zeit hinzu",
  "Insufficient time before deadline": "Nicht genug Zeit vor der Frist",
  "Insufficient working time": "Nicht genug Arbeitszeit",
  "This task is no longer available to extend.": "Diese Aufgabe kann nicht mehr verlängert werden.",
  "The task estimate cannot exceed 1440 minutes.": "Die Schätzung der Aufgabe darf 1440 Minuten nicht überschreiten.",
  "This preview expired. Preview the plan again.": "Diese Vorschau ist abgelaufen. Sehen Sie sich die Planvorschau erneut an.",
  "Your tasks, focus, meetings or settings changed. Preview the plan again.": "Ihre Aufgaben, Fokuszeiten, Besprechungen oder Einstellungen haben sich geändert. Sehen Sie sich die Planvorschau erneut an.",
  "Meeting end must be after its start.": "Das Ende der Besprechung muss nach ihrem Beginn liegen.",
  "Meeting no longer exists.": "Die Besprechung existiert nicht mehr.",
  "This local time is invalid or ambiguous (daylight saving). Choose another time.": "Diese Ortszeit ist ungültig oder mehrdeutig (Zeitumstellung). Wählen Sie eine andere Zeit.",
  "Enter a task title.": "Geben Sie einen Aufgabentitel ein.",
  "Enter a valid IANA timezone.": "Geben Sie eine gültige IANA-Zeitzone ein.",
  "Start and end must differ. An earlier end means an overnight workday.": "Beginn und Ende müssen sich unterscheiden. Ein Ende vor dem Beginn bedeutet einen Arbeitstag über Nacht.",
  "Task no longer exists.": "Die Aufgabe existiert nicht mehr.",
  "Task dependencies cannot contain a cycle.": "Aufgabenabhängigkeiten dürfen keinen Zyklus bilden.",
  "To do": "Zu erledigen",
  "In progress": "In Arbeit",
  Paused: TA,
  Deferred: CA,
  todo: PA,
  "in progress": "in Arbeit",
  paused: AA,
  completed: EA,
  deferred: SA,
  high: DA,
  medium: IA,
  low: zA,
  development: RA,
  review: xA,
  writing: OA,
  planning: MA,
  communication: $A,
  other: NA,
  task: jA,
  meeting: LA,
  break: "Pause",
  dark: GA,
  light: FA,
  Title: UA,
  "Estimate (min)": "Schätzung (Min.)",
  Date: "Datum",
  Deadline: ZA,
  Prerequisites: qA,
  Starts: KA,
  Ends: WA,
  "Create task": "Aufgabe erstellen",
  "Update task": "Aufgabe aktualisieren",
  "Create meeting": "Besprechung erstellen",
  "Update meeting": "Besprechung aktualisieren",
  Lunch: YA,
  "Take a break": "Machen Sie eine Pause",
  " — open Workday for Completed, Need more time, Pause or Skip.": " – öffnen Sie Workday für Erledigt, Mehr Zeit nötig, Pausieren oder Überspringen.",
  "No task changes were applied.": "Es wurden keine Änderungen an Aufgaben angewendet.",
  "{provider} rejected this key or access policy. Check the key and account permissions in Settings.": "{provider} hat diesen Schlüssel oder die Zugriffsrichtlinie abgelehnt. Prüfen Sie den Schlüssel und die Kontoberechtigungen in den Einstellungen.",
  "{provider} reports insufficient credits. Review your provider account or select another available model.": "{provider} meldet unzureichendes Guthaben. Prüfen Sie Ihr Anbieterkonto oder wählen Sie ein anderes verfügbares Modell.",
  "{provider} is rate limiting requests or reports exhausted quota. Review your quota and wait before retrying.": "{provider} begrenzt die Anfragen oder meldet ein aufgebrauchtes Kontingent. Prüfen Sie Ihr Kontingent und warten Sie, bevor Sie es erneut versuchen.",
  "{provider} could not serve the selected model or rejected the request. Refresh models, choose another model, or retry later.": "{provider} konnte das gewählte Modell nicht bereitstellen oder hat die Anfrage abgelehnt. Aktualisieren Sie die Modelle, wählen Sie ein anderes Modell oder versuchen Sie es später erneut.",
  "{provider} could not be reached. Check your connection; manual tasks and scheduling still work offline.": "{provider} ist nicht erreichbar. Prüfen Sie Ihre Verbindung; manuelle Aufgaben und die Planung funktionieren weiterhin offline.",
  "Configure your {provider} connection, model and data-sharing consent in Settings first.": "Richten Sie zuerst in den Einstellungen Ihre {provider}-Verbindung, das Modell und die Zustimmung zur Datenfreigabe ein.",
  "Enter your {provider} API key before discovering models. You can use the key field without saving first.": "Geben Sie Ihren {provider}-API-Schlüssel ein, bevor Sie nach Modellen suchen. Sie können das Schlüsselfeld verwenden, ohne vorher zu speichern.",
  "Enter your {provider} API key before discovering models.": "Geben Sie Ihren {provider}-API-Schlüssel ein, bevor Sie nach Modellen suchen.",
  "{provider} returned a refused, incomplete or invalid response. No task data changed. Try a smaller request or another model.": "{provider} hat eine abgelehnte, unvollständige oder ungültige Antwort zurückgegeben. Es wurden keine Aufgabendaten geändert. Versuchen Sie eine kürzere Anfrage oder ein anderes Modell.",
  "{provider} returned an invalid model catalog. Retry discovery or enter a model ID manually.": "{provider} hat einen ungültigen Modellkatalog zurückgegeben. Wiederholen Sie die Suche oder geben Sie eine Modell-ID manuell ein.",
  "{provider} could not complete this request. Please retry later.": "{provider} konnte diese Anfrage nicht abschließen. Bitte versuchen Sie es später erneut.",
  "You’ve reached your ChatGPT plan’s usage limit. Wait for it to reset, or choose another AI provider in Settings.": "Sie haben das Nutzungslimit Ihres ChatGPT-Abos erreicht. Warten Sie, bis es zurückgesetzt wird, oder wählen Sie in den Einstellungen einen anderen KI-Anbieter.",
  "ChatGPT did not finish its response. No task changes were applied.": "ChatGPT hat seine Antwort nicht abgeschlossen. Es wurden keine Änderungen an Aufgaben angewendet.",
  "Something went wrong. Please try again.": "Etwas ist schiefgelaufen. Bitte versuchen Sie es erneut.",
  "Task updated.": "Aufgabe aktualisiert.",
  "Task created.": "Aufgabe erstellt.",
  "Switch to light theme": "Zum hellen Design wechseln",
  "Switch to dark theme": "Zum dunklen Design wechseln",
  "Help me adjust my remaining schedule for today.": "Hilf mir, meinen restlichen Zeitplan für heute anzupassen.",
  "Allow sending my chat requests and selected workday context to OpenRouter and the selected model provider.": "Erlauben, dass meine Chat-Anfragen und der ausgewählte Arbeitstag-Kontext an OpenRouter und den Anbieter des gewählten Modells gesendet werden.",
  "Allow sending my chat requests and selected workday context to {provider}.": "Erlauben, dass meine Chat-Anfragen und der ausgewählte Arbeitstag-Kontext an {provider} gesendet werden.",
  "Signed out of ChatGPT.": "Von ChatGPT abgemeldet.",
  "Signed out here. ChatGPT could not confirm it: also disconnect this app in your ChatGPT settings.": "Hier abgemeldet. ChatGPT konnte das nicht bestätigen: Trennen Sie diese App zusätzlich in Ihren ChatGPT-Einstellungen.",
  "Pause focus": "Fokus pausieren",
  "Resume focus": "Fokus fortsetzen",
  "Start focus": "Fokus starten",
  "Unable to save meeting.": "Die Besprechung konnte nicht gespeichert werden.",
  "Unable to plan the day.": "Der Tag konnte nicht geplant werden.",
  "Review the extended estimate and updated plan below.": "Prüfen Sie unten die verlängerte Schätzung und den aktualisierten Plan.",
  "Check-in saved. Preview the plan to adjust remaining work.": "Check-in gespeichert. Sehen Sie sich die Planvorschau an, um die verbleibende Arbeit anzupassen.",
  "Unable to save check-in.": "Der Check-in konnte nicht gespeichert werden.",
  "Unable to approve plan.": "Der Plan konnte nicht bestätigt werden.",
  "Unable to save settings.": "Die Einstellungen konnten nicht gespeichert werden.",
  "Short break": "Kurze Pause"
}, BA = "Recarregar", HA = "Dispensar", QA = "Categoria", XA = "Descrição", JA = "Notas", eE = "Prioridade", tE = "Alta", nE = "Média", rE = "Baixa", oE = "Status", iE = "Cancelar", aE = "Tarefas", sE = "Hoje", uE = "Concluídas", cE = "Reabrir", lE = "Concluir", dE = "min", hE = "Vence", fE = "Editar", mE = "Adiar", pE = "Excluir", gE = "Configurações", vE = "Aparência", yE = "Idioma", bE = "Conversa", wE = "Você", kE = "Enviar", _E = "Nenhum", TE = "Tarefa", CE = "Conectado", PE = "Pausar", AE = "Retomar", EE = "Focar", SE = "Agenda", DE = "Compromisso", IE = "Reuniões", zE = "Fuso horário", RE = "Seg", xE = "Ter", OE = "Qua", ME = "Qui", $E = "Sex", NE = "Sáb", jE = "Dom", LE = "Remover", GE = "Lembretes", FE = "Pausada", UE = "Adiada", ZE = "a fazer", qE = "pausada", KE = "concluída", WE = "adiada", YE = "alta", VE = "média", BE = "baixa", HE = "desenvolvimento", QE = "revisão", XE = "redação", JE = "planejamento", eS = "comunicação", tS = "outra", nS = "tarefa", rS = "reunião", oS = "escuro", iS = "claro", aS = "Título", sS = "Prazo", uS = "Pré-requisitos", cS = "Início", lS = "Fim", dS = "Almoço", hS = {
  "Unable to open Workday": "Não foi possível abrir o Workday",
  "Your data has not been deleted. Reload the panel to try again.": "Seus dados não foram excluídos. Recarregue o painel para tentar novamente.",
  Reload: BA,
  Dismiss: HA,
  "Open Workday": "Abrir o Workday",
  "Edit task": "Editar tarefa",
  "New task": "Nova tarefa",
  "Close task editor": "Fechar o editor de tarefas",
  "Task title": "Título da tarefa",
  "What needs your attention?": "O que precisa da sua atenção?",
  Category: QA,
  Description: XA,
  Notes: JA,
  "Anything you don’t want to forget": "Qualquer coisa que você não queira esquecer",
  Priority: eE,
  High: tE,
  Medium: nE,
  Low: rE,
  "Estimate · minutes": "Estimativa · minutos",
  "Scheduled date": "Data programada",
  Status: oE,
  "Deadline ({zone})": "Prazo ({zone})",
  "Dependencies (optional)": "Dependências (opcional)",
  "Missing prerequisite ({id}) — uncheck to remove": "Pré-requisito ausente ({id}) — desmarque para remover",
  Cancel: iE,
  "Saving…": "Salvando…",
  "Save task": "Salvar tarefa",
  "Local data exported.": "Dados locais exportados.",
  "Main navigation": "Navegação principal",
  "Local storage unavailable: {error}. Reload the panel to retry.": "Armazenamento local indisponível: {error}. Recarregue o painel para tentar novamente.",
  "Dismiss message": "Dispensar mensagem",
  "Day off": "Dia de folga",
  "Before work": "Antes do trabalho",
  "Workday ended": "Expediente encerrado",
  "Workday in progress": "Expediente em andamento",
  "Daily task progress": "Progresso das tarefas do dia",
  "{done} of {total} done": "{done} de {total} concluídas",
  "{minutes} min left": "Faltam {minutes} min",
  "{done} of {total} tasks completed": "{done} de {total} tarefas concluídas",
  Tasks: aE,
  "Add task": "Adicionar tarefa",
  "Filter tasks": "Filtrar tarefas",
  Today: sE,
  "All tasks": "Todas as tarefas",
  Completed: uE,
  "Loading local tasks…": "Carregando tarefas locais…",
  "Your wins will appear here": "Suas conquistas aparecerão aqui",
  "Make room for your best work": "Abra espaço para o seu melhor trabalho",
  "Add your first task for today. Keep it small, give it an estimate, and take it from there.": "Adicione sua primeira tarefa de hoje. Mantenha-a pequena, dê uma estimativa e siga a partir daí.",
  "Create a task to get started.": "Crie uma tarefa para começar.",
  "Create a task": "Criar uma tarefa",
  Reopen: cE,
  Complete: lE,
  "Task reopened.": "Tarefa reaberta.",
  "Task completed.": "Tarefa concluída.",
  min: dE,
  Due: hE,
  Edit: fE,
  "Task deferred.": "Tarefa adiada.",
  Defer: mE,
  Delete: pE,
  "Delete this task and its work records?": "Excluir esta tarefa e seus registros de trabalho?",
  "Task deleted.": "Tarefa excluída.",
  "Delete task": "Excluir tarefa",
  "Ask AI to adjust my day": "Pedir à IA para ajustar meu dia",
  Settings: gE,
  Appearance: vE,
  "Color theme": "Tema de cores",
  Language: yE,
  "Display language": "Idioma de exibição",
  "Same as browser": "O mesmo do navegador",
  "The assistant also replies in this language.": "O assistente também responde neste idioma.",
  "Your data": "Seus dados",
  "Everything is saved in this browser on this device and works offline. Uninstalling the extension or clearing browser data removes it.": "Tudo é salvo neste navegador, neste dispositivo, e funciona offline. Desinstalar a extensão ou limpar os dados do navegador remove tudo.",
  "Export local data": "Exportar dados locais",
  "Exports contain tasks and work records, never keys or sign-ins.": "As exportações contêm tarefas e registros de trabalho, nunca chaves nem logins.",
  "Delete all local data": "Excluir todos os dados locais",
  "Permanently delete all tasks, work records, chats and AI settings, and sign out of ChatGPT? Export a backup first if you need one.": "Excluir permanentemente todas as tarefas, registros de trabalho, conversas e configurações de IA, e sair do ChatGPT? Exporte um backup antes, se precisar.",
  "All task and work records deleted.": "Todas as tarefas e registros de trabalho foram excluídos.",
  "Delete permanently": "Excluir permanentemente",
  "AI Chat": "Chat com IA",
  "Back to Today": "Voltar para Hoje",
  "Clear chat": "Limpar chat",
  "Connect your ChatGPT account, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Conecte sua conta do ChatGPT, escolha um modelo e ative o compartilhamento de dados em Configurações. O planejamento manual funciona sem IA.",
  "Connect your own {provider} API key, choose a model and enable data sharing in Settings. Manual planning works without AI.": "Adicione sua própria chave de API de {provider}, escolha um modelo e ative o compartilhamento de dados em Configurações. O planejamento manual funciona sem IA.",
  "Configure AI": "Configurar a IA",
  "Using ChatGPT plan ·": "Usando o plano do ChatGPT ·",
  "Manage usage": "Gerenciar uso",
  "You’re offline. Saved conversations and manual planning remain available; sending needs a connection.": "Você está offline. As conversas salvas e o planejamento manual continuam disponíveis; para enviar é preciso estar conectado.",
  "{provider} · Model: {model}": "{provider} · Modelo: {model}",
  "Chat options": "Opções do chat",
  "Task changes require your approval.": "As alterações em tarefas exigem sua aprovação.",
  "Planning date": "Data do planejamento",
  "Task context": "Contexto das tarefas",
  "This day, next day & unscheduled": "Este dia, o dia seguinte e tarefas sem data",
  "All dates (up to 80 tasks + prerequisites)": "Todas as datas (até 80 tarefas + pré-requisitos)",
  "Include task descriptions and notes (up to 500 characters each)": "Incluir descrições e notas das tarefas (até 500 caracteres cada)",
  "Include meeting titles, so the assistant can find a meeting by name": "Incluir os títulos das reuniões, para que o assistente encontre uma reunião pelo nome",
  "Each request sends up to 80 tasks, your meeting times, work hours and your six most recent messages with this provider. Webpages are never sent.": "Cada solicitação envia até 80 tarefas, os horários das suas reuniões, seu horário de trabalho e suas seis mensagens mais recentes com este provedor. Páginas da web nunca são enviadas.",
  Conversation: bE,
  "Tell me what’s on your plate. I’ll suggest task changes for you to approve.": "Conte o que você tem para fazer. Vou sugerir alterações nas tarefas para você aprovar.",
  "Plan my day.": "Planeje meu dia.",
  "What should I work on next?": "No que devo trabalhar agora?",
  "What tasks have I not completed?": "Quais tarefas eu não concluí?",
  You: wE,
  "Thinking…": "Pensando…",
  "Interrupted or pending request. Retry with the latest context.": "Solicitação interrompida ou pendente. Tente novamente com o contexto mais recente.",
  "Request cancelled.": "Solicitação cancelada.",
  "Retry request": "Repetir solicitação",
  " · retried once": " · repetida uma vez",
  "Message to AI": "Mensagem para a IA",
  "What would you like to plan?": "O que você gostaria de planejar?",
  "Shift+Enter for a new line": "Shift+Enter para uma nova linha",
  "Cancel request": "Cancelar solicitação",
  Send: kE,
  "Clear conversation": "Limpar conversa",
  "Delete this provider’s local conversation and proposals? Other conversations, approved tasks and schedules will remain.": "Excluir a conversa e as propostas locais deste provedor? As outras conversas, as tarefas aprovadas e as agendas serão mantidas.",
  "Unable to clear chat.": "Não foi possível limpar o chat.",
  "Delete chat": "Excluir chat",
  None: _E,
  "Missing prerequisite": "Pré-requisito ausente",
  "AI change proposal": "Proposta de alteração da IA",
  "Changes approved": "Alterações aprovadas",
  "Proposal rejected": "Proposta rejeitada",
  "Review proposed changes": "Revise as alterações propostas",
  "Nothing has been applied. Preview expires after 60 seconds; refresh it if needed. The local scheduler rechecks times at approval.": "Nada foi aplicado. A prévia expira após 60 segundos; atualize-a se necessário. O agendador local verifica os horários novamente na aprovação.",
  "AI proposed schedule": "Agenda proposta pela IA",
  "Showing 200 of {count} blocks. Use Today after approval for the full timeline.": "Mostrando 200 de {count} blocos. Consulte Hoje após a aprovação para ver a agenda completa.",
  "Overflow · {count} task(s)": "Não coube · {count} tarefa(s)",
  Task: TE,
  "Approve changes": "Aprovar alterações",
  "Reject changes": "Rejeitar alterações",
  "Refresh preview": "Atualizar prévia",
  "Tasks and affected schedules were saved together.": "As tarefas e as agendas afetadas foram salvas juntas.",
  "No task or schedule changes were applied.": "Nenhuma alteração em tarefas ou agendas foi aplicada.",
  "View Today": "Ver Hoje",
  "AI provider settings": "Configurações do provedor de IA",
  "AI assistant": "Assistente de IA",
  "Assistant name": "Nome do assistente",
  "Shown in chat, and the assistant answers to it. Saved as you type.": "Aparece no chat, e o assistente responde por ele. Salvo enquanto você digita.",
  "AI provider": "Provedor de IA",
  "{provider} selected. Each provider keeps its own settings and conversation.": "{provider} selecionado. Cada provedor mantém suas próprias configurações e conversa.",
  "Unable to switch AI provider. Please retry.": "Não foi possível trocar o provedor de IA. Tente novamente.",
  "Retrieved {count} models from {provider}. Select a model and save.": "{count} modelos obtidos de {provider}. Selecione um modelo e salve.",
  "{provider} settings saved. Send a request in AI Chat to test the selected model.": "Configurações de {provider} salvas. Envie uma solicitação no Chat com IA para testar o modelo selecionado.",
  "Unable to save AI settings. Check the model ID and key (16–512 characters, no spaces).": "Não foi possível salvar as configurações de IA. Verifique o ID do modelo e a chave (16–512 caracteres, sem espaços).",
  "{provider} settings": "Configurações de {provider}",
  "Uses your own API key, saved only in this extension on this device.": "Usa sua própria chave de API, salva apenas nesta extensão neste dispositivo.",
  " To sign in with a ChatGPT subscription instead, choose ChatGPT plan above.": " Para entrar com uma assinatura do ChatGPT, escolha Plano do ChatGPT acima.",
  " Get a key from the Anthropic Console. A Claude subscription cannot be used here.": " Obtenha uma chave no Console da Anthropic. Uma assinatura do Claude não pode ser usada aqui.",
  "{provider} API key": "Chave de API de {provider}",
  "Saved key · enter a replacement": "Chave salva · digite outra para substituir",
  "Enter your own {provider} key": "Digite sua própria chave de {provider}",
  "A key is saved on this device.": "Há uma chave salva neste dispositivo.",
  "No API key saved.": "Nenhuma chave de API salva.",
  "Working…": "Trabalhando…",
  "Refresh models": "Atualizar modelos",
  "{provider} key removed and sharing disabled. Other providers are unchanged.": "Chave de {provider} removida e compartilhamento desativado. Os outros provedores não foram alterados.",
  "Unable to remove the saved key. Please retry.": "Não foi possível remover a chave salva. Tente novamente.",
  "Forget key": "Esquecer chave",
  "Show free models only": "Mostrar apenas modelos gratuitos",
  "Find a model": "Encontrar um modelo",
  "Search name or ID": "Pesquisar por nome ou ID",
  "Discovered model": "Modelo encontrado",
  "Choose a model…": "Escolha um modelo…",
  " · Free": " · Gratuito",
  " · Paid": " · Pago",
  "Model ID": "ID do modelo",
  "Select above or enter a model ID": "Selecione acima ou digite um ID de modelo",
  "Free model; account limits still apply.": "Modelo gratuito; os limites da conta continuam valendo.",
  "Paid model · prompt {prompt} / completion {completion} USD per token.": "Modelo pago · entrada {prompt} / saída {completion} USD por token.",
  "Requests may be billed by {provider}. Check pricing in your provider account.": "As solicitações podem ser cobradas por {provider}. Confira os preços na sua conta do provedor.",
  "Save AI settings": "Salvar configurações de IA",
  "What gets shared?": "O que é compartilhado?",
  "Each request sends task summaries, work hours, meeting times and your recent conversation with this provider. Meeting titles are sent unless you turn that off in Chat options; task descriptions and notes are sent only if you turn that on. Webpages and saved keys are never sent. An invalid answer may trigger one automatic retry, which can cost extra. There is no automatic switch to another provider or a paid model.": "Cada solicitação envia resumos das tarefas, seu horário de trabalho, os horários das suas reuniões e sua conversa recente com este provedor. Os títulos das reuniões são enviados, a menos que você desative isso nas Opções do chat; as descrições e notas das tarefas só são enviadas se você ativar. Páginas da web e chaves salvas nunca são enviadas. Uma resposta inválida pode gerar uma nova tentativa automática, que pode ter custo adicional. Não há troca automática para outro provedor nem para um modelo pago.",
  "ChatGPT connected. Choose a model and allow sharing to finish.": "ChatGPT conectado. Escolha um modelo e permita o compartilhamento para concluir.",
  "ChatGPT plan settings": "Configurações do plano do ChatGPT",
  "ChatGPT plan": "Plano do ChatGPT",
  "Use your ChatGPT subscription instead of an API key. Availability depends on your plan, workspace and region.": "Use sua assinatura do ChatGPT em vez de uma chave de API. A disponibilidade depende do seu plano, do seu espaço de trabalho e da sua região.",
  "Finish signing in in the browser tab that opened, then come back here.": "Conclua o login na aba do navegador que foi aberta e depois volte aqui.",
  "Cancel sign-in": "Cancelar login",
  "Continue with ChatGPT": "Continuar com o ChatGPT",
  Connected: CE,
  "Plan access off": "Acesso ao plano desativado",
  "Signed out": "Desconectado",
  " · In use": " · Em uso",
  "Use account": "Usar esta conta",
  "Enable plan access": "Ativar acesso ao plano",
  "Sign in again": "Entrar novamente",
  "Sign out": "Sair",
  "You’re using your ChatGPT plan": "Você está usando seu plano do ChatGPT",
  "Got it": "Entendi",
  "ChatGPT is ready. Open AI Chat to start.": "O ChatGPT está pronto. Abra o Chat com IA para começar.",
  "ChatGPT model": "Modelo do ChatGPT",
  "Refresh ChatGPT models": "Atualizar modelos do ChatGPT",
  "Allow sending my requests, selected workday context and this account’s recent chat to OpenAI using my ChatGPT plan.": "Permitir o envio das minhas solicitações, do contexto de expediente selecionado e do chat recente desta conta para a OpenAI usando meu plano do ChatGPT.",
  "Save ChatGPT settings": "Salvar configurações do ChatGPT",
  "Task changes always wait for your approval.": "As alterações em tarefas sempre aguardam sua aprovação.",
  "Sign-in runs inside the extension; there is nothing else to install. Your ChatGPT session is saved in this extension’s private storage in this browser profile until you sign out. Signing out removes the account, its saved details and its conversation from this extension.": "O login acontece dentro da extensão; não é preciso instalar mais nada. Sua sessão do ChatGPT fica salva no armazenamento privado desta extensão, neste perfil do navegador, até você sair. Ao sair, a conta, seus dados salvos e sua conversa são removidos desta extensão.",
  "Focus timer": "Temporizador de foco",
  "Focusing now": "Em foco agora",
  "Focus paused": "Foco pausado",
  "{time} remaining": "Faltam {time}",
  "{time} over estimate": "{time} acima da estimativa",
  "Focus paused.": "Foco pausado.",
  "Focus resumed.": "Foco retomado.",
  Pause: PE,
  Resume: AE,
  "Task completed. Preview the plan to reuse the free time.": "Tarefa concluída. Veja a prévia do plano para reaproveitar o tempo livre.",
  "Focus started.": "Foco iniciado.",
  Focus: EE,
  "Meeting editor": "Editor de reuniões",
  "Edit meeting": "Editar reunião",
  "New meeting": "Nova reunião",
  "Close meeting editor": "Fechar o editor de reuniões",
  "Times in {zone}": "Horários em {zone}",
  "Meeting title": "Título da reunião",
  "Meeting starts": "Início da reunião",
  "Meeting ends": "Fim da reunião",
  "Save meeting": "Salvar reunião",
  "Loading your schedule…": "Carregando sua agenda…",
  "Plan approved and saved.": "Plano aprovado e salvo.",
  "Day planner": "Planejador do dia",
  "Meeting now": "Reunião agora",
  "Next meeting": "Próxima reunião",
  "How is this task going?": "Como está indo esta tarefa?",
  "Need more time (+30m)": "Preciso de mais tempo (+30 min)",
  "Skip for now": "Pular por enquanto",
  Schedule: SE,
  "Planning…": "Planejando…",
  "Preview plan": "Ver prévia do plano",
  "Plan date": "Data do plano",
  " (next day)": " (dia seguinte)",
  "Tasks or constraints changed. Preview and approve an updated plan before following this timeline.": "As tarefas ou restrições mudaram. Veja a prévia e aprove um plano atualizado antes de seguir esta agenda.",
  "Review your proposed plan": "Revise o plano proposto",
  "Includes 30 more minutes for the selected task. ": "Inclui mais 30 minutos para a tarefa selecionada. ",
  "Nothing is saved until you approve. This preview expires in 60 seconds.": "Nada é salvo até você aprovar. Esta prévia expira em 60 segundos.",
  "Approve plan": "Aprovar plano",
  "Reject plan": "Rejeitar plano",
  "Proposed schedule": "Agenda proposta",
  "Approved schedule": "Agenda aprovada",
  Commitment: DE,
  "No schedule yet. Preview a plan to fit tasks around meetings and breaks.": "Ainda não há agenda. Veja a prévia de um plano para encaixar as tarefas entre reuniões e pausas.",
  "Doesn’t fit in this workday": "Não cabe neste expediente",
  "Shorten a task, change your hours, or move a task to {date}.": "Encurte uma tarefa, altere seu horário ou mova uma tarefa para {date}.",
  Meetings: IE,
  "Add meeting": "Adicionar reunião",
  "Meeting saved. Review the updated plan.": "Reunião salva. Revise o plano atualizado.",
  "No meetings for this day.": "Nenhuma reunião neste dia.",
  "Delete meeting": "Excluir reunião",
  "Delete this meeting?": "Excluir esta reunião?",
  "Meeting deleted. Review the updated plan.": "Reunião excluída. Revise o plano atualizado.",
  "System notifications could not be delivered. Check Windows notification settings for Microsoft Edge; your schedule and check-ins remain available here.": "Não foi possível exibir as notificações do sistema. Verifique as configurações de notificação do Windows para o Microsoft Edge; sua agenda e seus check-ins continuam disponíveis aqui.",
  " · now": " · agora",
  "Reminders only pop up in the installed extension.": "Os lembretes só aparecem na extensão instalada.",
  "Workday reminders are on": "Os lembretes do Workday estão ativados",
  "Reminders and check-ins will appear like this.": "Os lembretes e check-ins aparecerão assim.",
  "A reminder window should have opened.": "Uma janela de lembrete deve ter sido aberta.",
  "Sent to Windows. If nothing appeared, Windows is blocking notifications from Microsoft Edge (Settings → System → Notifications, or Do not disturb). Switch on “Pop up in a browser window” above to avoid that.": "Enviado ao Windows. Se nada apareceu, o Windows está bloqueando as notificações do Microsoft Edge (Configurações → Sistema → Notificações, ou Não perturbe). Ative “Mostrar em uma janela do navegador” acima para evitar isso.",
  "The reminder could not be shown. Try the other reminder style.": "Não foi possível mostrar o lembrete. Experimente o outro estilo de lembrete.",
  "Workday settings saved. Preview your schedule to apply changed constraints.": "Configurações do expediente salvas. Veja a prévia da sua agenda para aplicar as restrições alteradas.",
  "Workday settings": "Configurações do expediente",
  "Workday start": "Início do expediente",
  "Workday end": "Fim do expediente",
  "An end time before the start means an overnight shift.": "Um horário de término anterior ao de início indica um turno noturno.",
  Timezone: zE,
  "Working days": "Dias de trabalho",
  Mon: RE,
  Tue: xE,
  Wed: OE,
  Thu: ME,
  Fri: $E,
  Sat: NE,
  Sun: jE,
  "Reserve lunch": "Reservar o almoço",
  "Lunch starts": "Início do almoço",
  "Lunch · minutes": "Almoço · minutos",
  "Additional breaks": "Pausas adicionais",
  "Break name": "Nome da pausa",
  "Break starts": "Início da pausa",
  "Break · minutes": "Pausa · minutos",
  Remove: LE,
  "Remove break": "Remover pausa",
  "Add break": "Adicionar pausa",
  Reminders: GE,
  "Pop up reminders and check-ins": "Mostrar lembretes e check-ins",
  "Pop up in a browser window (works even when Windows notifications are off)": "Mostrar em uma janela do navegador (funciona mesmo com as notificações do Windows desativadas)",
  "Reminders appear while Edge is running, even with this panel closed. Untick the second box to use Windows system notifications instead. Save after changing these.": "Os lembretes aparecem enquanto o Edge estiver aberto, mesmo com este painel fechado. Desmarque a segunda caixa para usar as notificações do sistema do Windows. Salve depois de alterar.",
  "Send a test reminder": "Enviar um lembrete de teste",
  "Task-start reminders": "Lembretes de início de tarefa",
  "Upcoming meetings": "Próximas reuniões",
  "Break reminders": "Lembretes de pausa",
  "Workday-end reminder": "Lembrete de fim de expediente",
  "Lead time · minutes": "Antecedência · minutos",
  "Check-in · minutes": "Check-in · minutos",
  "Set check-in to 0 to turn off periodic check-ins.": "Defina o check-in como 0 para desativar os check-ins periódicos.",
  "Quiet hours for notifications": "Horário de silêncio para notificações",
  "Quiet hours start": "Início do horário de silêncio",
  "Quiet hours end": "Fim do horário de silêncio",
  "Save workday settings": "Salvar configurações do expediente",
  "The AI request could not be completed. No task changes were applied. Retry or use the manual planner.": "Não foi possível concluir a solicitação à IA. Nenhuma alteração em tarefas foi aplicada. Tente novamente ou use o planejador manual.",
  "Reconnect your ChatGPT plan in Settings.": "Reconecte seu plano do ChatGPT em Configurações.",
  "Enter a request between 1 and 6000 characters.": "Digite uma solicitação de 1 a 6000 caracteres.",
  "This request is already answered or no longer exists.": "Esta solicitação já foi respondida ou não existe mais.",
  "This request already has a proposal. Review it instead of retrying.": "Esta solicitação já tem uma proposta. Revise-a em vez de tentar novamente.",
  "Switch back to the original provider to retry this request.": "Volte ao provedor original para repetir esta solicitação.",
  "AI request cancelled. No task changes were applied.": "Solicitação à IA cancelada. Nenhuma alteração em tarefas foi aplicada.",
  "This request was cancelled because chat data or AI configuration changed.": "Esta solicitação foi cancelada porque os dados do chat ou a configuração da IA mudaram.",
  "Your workday changed while the model was responding. Retry with the latest context.": "Seu expediente mudou enquanto o modelo respondia. Tente novamente com o contexto mais recente.",
  "ChatGPT usage limit reached. Manage usage in ChatGPT, then retry here.": "Limite de uso do ChatGPT atingido. Gerencie o uso no ChatGPT e tente novamente aqui.",
  "ChatGPT plan access is unavailable for this account, workspace or region.": "O acesso ao plano do ChatGPT não está disponível para esta conta, este espaço de trabalho ou esta região.",
  "ChatGPT authorization expired. Sign in again.": "A autorização do ChatGPT expirou. Entre novamente.",
  "ChatGPT could not complete this request. Please retry later.": "O ChatGPT não conseguiu concluir esta solicitação. Tente novamente mais tarde.",
  "ChatGPT request cancelled.": "Solicitação ao ChatGPT cancelada.",
  "ChatGPT could not be reached. Your saved sign-in is kept.": "Não foi possível acessar o ChatGPT. Seu login salvo foi mantido.",
  "ChatGPT sign-in timed out. Please try again.": "O login no ChatGPT expirou. Tente novamente.",
  "A ChatGPT sign-in is already open. Finish or cancel it first.": "Já existe um login do ChatGPT aberto. Conclua-o ou cancele-o primeiro.",
  "The selected ChatGPT account no longer exists.": "A conta do ChatGPT selecionada não existe mais.",
  "Sign out of the current ChatGPT account before signing in to another.": "Saia da conta atual do ChatGPT antes de entrar em outra.",
  "Unable to open the ChatGPT sign-in tab.": "Não foi possível abrir a aba de login do ChatGPT.",
  "ChatGPT sign-in was not authorized.": "O login no ChatGPT não foi autorizado.",
  "ChatGPT sign-in was cancelled.": "O login no ChatGPT foi cancelado.",
  "ChatGPT sign-in did not complete. Please retry.": "O login no ChatGPT não foi concluído. Tente novamente.",
  "Sign in with ChatGPT first.": "Entre com o ChatGPT primeiro.",
  "Your ChatGPT session expired. Sign in again.": "Sua sessão do ChatGPT expirou. Entre novamente.",
  "ChatGPT plan use is not enabled. Choose Enable plan access in Settings.": "O uso do plano do ChatGPT não está ativado. Escolha Ativar acesso ao plano em Configurações.",
  "Choose a ChatGPT model in Settings.": "Escolha um modelo do ChatGPT em Configurações.",
  "ChatGPT took too long to answer. No task changes were applied.": "O ChatGPT demorou demais para responder. Nenhuma alteração em tarefas foi aplicada.",
  "ChatGPT request interrupted. No task changes were applied.": "Solicitação ao ChatGPT interrompida. Nenhuma alteração em tarefas foi aplicada.",
  "ChatGPT response was interrupted or empty. No task changes were applied.": "A resposta do ChatGPT foi interrompida ou veio vazia. Nenhuma alteração em tarefas foi aplicada.",
  "Connect a ChatGPT account first.": "Conecte uma conta do ChatGPT primeiro.",
  "The AI request timed out. Retry or choose a faster model.": "A solicitação à IA expirou. Tente novamente ou escolha um modelo mais rápido.",
  "Enter a valid provider API key (16–512 characters, no spaces or control characters).": "Digite uma chave de API válida (16–512 caracteres, sem espaços nem caracteres de controle).",
  "Enter a model ID in the model field, not an API key.": "Digite um ID de modelo no campo do modelo, não uma chave de API.",
  "Connect ChatGPT and enable plan access first.": "Conecte o ChatGPT e ative o acesso ao plano primeiro.",
  "Model discovery cancelled.": "Busca de modelos cancelada.",
  "Model discovery cancelled because the saved key changed.": "Busca de modelos cancelada porque a chave salva mudou.",
  "The provider returned no usable model IDs. Retry discovery or enter a model ID manually.": "O provedor não retornou nenhum ID de modelo utilizável. Repita a busca ou digite um ID de modelo manualmente.",
  "Sign in to this ChatGPT account first.": "Entre nesta conta do ChatGPT primeiro.",
  "The AI request timed out. Your manual planner is still available.": "A solicitação à IA expirou. Seu planejador manual continua disponível.",
  "The provider response was too large. Try a smaller request or another model.": "A resposta do provedor era grande demais. Tente uma solicitação menor ou outro modelo.",
  "No text chat models were found. Retry discovery or enter a model ID manually.": "Nenhum modelo de chat de texto foi encontrado. Repita a busca ou digite um ID de modelo manualmente.",
  "The model returned a refused, incomplete or invalid response. No task data changed. Try another model or a smaller request.": "O modelo retornou uma resposta recusada, incompleta ou inválida. Nenhum dado de tarefa foi alterado. Tente outro modelo ou uma solicitação menor.",
  "The model could not produce valid task actions. No task data changed.": "O modelo não conseguiu gerar ações de tarefa válidas. Nenhum dado de tarefa foi alterado.",
  "Meeting times are invalid or ambiguous in your workday timezone.": "Os horários da reunião são inválidos ou ambíguos no fuso horário do seu expediente.",
  "Meeting end must be after its start and within seven days.": "O fim da reunião deve ser depois do início e dentro de sete dias.",
  "The model referenced a meeting that does not exist.": "O modelo fez referência a uma reunião que não existe.",
  "The referenced task no longer exists.": "A tarefa referenciada não existe mais.",
  "This task is already completed.": "Esta tarefa já está concluída.",
  "Reopen the task before adding focus time.": "Reabra a tarefa antes de adicionar tempo de foco.",
  "Limit one proposal to seven affected workdays.": "Limite cada proposta a sete expedientes afetados.",
  "This proposal has already been resolved or removed.": "Esta proposta já foi resolvida ou removida.",
  "This proposal expired. Refresh its preview before approval.": "Esta proposta expirou. Atualize a prévia antes de aprovar.",
  "Your tasks, meetings, focus or work settings changed. Refresh the preview before approval.": "Suas tarefas, reuniões, foco ou configurações de trabalho mudaram. Atualize a prévia antes de aprovar.",
  "This proposal is no longer pending.": "Esta proposta não está mais pendente.",
  "Here are the changes for you to review.": "Aqui estão as alterações para você revisar.",
  "The model did not return valid task actions. No task data changed. Try again or choose another model.": "O modelo não retornou ações de tarefa válidas. Nenhum dado de tarefa foi alterado. Tente novamente ou escolha outro modelo.",
  "Reopen this task before starting focus.": "Reabra esta tarefa antes de iniciar o foco.",
  "Time to focus": "Hora de focar",
  "Break time": "Hora da pausa",
  "Upcoming meeting": "Próxima reunião",
  "Your workday is ending": "Seu expediente está terminando",
  "Review your progress and leave unfinished tasks for another day.": "Revise seu progresso e deixe as tarefas inacabadas para outro dia.",
  "Work from another saved plan reserves time in this window.": "O trabalho de outro plano salvo reserva tempo neste período.",
  "This is not a configured working day.": "Este não é um dia de trabalho configurado.",
  "Unfinished, missing or circular dependency": "Dependência inacabada, ausente ou circular",
  "Estimate used up; complete this task or add more time": "Estimativa esgotada; conclua esta tarefa ou adicione mais tempo",
  "Insufficient time before deadline": "Tempo insuficiente antes do prazo",
  "Insufficient working time": "Tempo de trabalho insuficiente",
  "This task is no longer available to extend.": "Esta tarefa não pode mais ser estendida.",
  "The task estimate cannot exceed 1440 minutes.": "A estimativa da tarefa não pode passar de 1440 minutos.",
  "This preview expired. Preview the plan again.": "Esta prévia expirou. Veja a prévia do plano novamente.",
  "Your tasks, focus, meetings or settings changed. Preview the plan again.": "Suas tarefas, foco, reuniões ou configurações mudaram. Veja a prévia do plano novamente.",
  "Meeting end must be after its start.": "O fim da reunião deve ser depois do início.",
  "Meeting no longer exists.": "A reunião não existe mais.",
  "This local time is invalid or ambiguous (daylight saving). Choose another time.": "Este horário local é inválido ou ambíguo (horário de verão). Escolha outro horário.",
  "Enter a task title.": "Digite um título para a tarefa.",
  "Enter a valid IANA timezone.": "Digite um fuso horário IANA válido.",
  "Start and end must differ. An earlier end means an overnight workday.": "O início e o fim devem ser diferentes. Um fim anterior ao início indica um expediente noturno.",
  "Task no longer exists.": "A tarefa não existe mais.",
  "Task dependencies cannot contain a cycle.": "As dependências entre tarefas não podem formar um ciclo.",
  "To do": "A fazer",
  "In progress": "Em andamento",
  Paused: FE,
  Deferred: UE,
  todo: ZE,
  "in progress": "em andamento",
  paused: qE,
  completed: KE,
  deferred: WE,
  high: YE,
  medium: VE,
  low: BE,
  development: HE,
  review: QE,
  writing: XE,
  planning: JE,
  communication: eS,
  other: tS,
  task: nS,
  meeting: rS,
  break: "pausa",
  dark: oS,
  light: iS,
  Title: aS,
  "Estimate (min)": "Estimativa (min)",
  Date: "Data",
  Deadline: sS,
  Prerequisites: uS,
  Starts: cS,
  Ends: lS,
  "Create task": "Criar tarefa",
  "Update task": "Atualizar tarefa",
  "Create meeting": "Criar reunião",
  "Update meeting": "Atualizar reunião",
  Lunch: dS,
  "Take a break": "Faça uma pausa",
  " — open Workday for Completed, Need more time, Pause or Skip.": " — abra o Workday para escolher Concluída, Preciso de mais tempo, Pausar ou Pular.",
  "No task changes were applied.": "Nenhuma alteração em tarefas foi aplicada.",
  "{provider} rejected this key or access policy. Check the key and account permissions in Settings.": "{provider} rejeitou esta chave ou a política de acesso. Verifique a chave e as permissões da conta em Configurações.",
  "{provider} reports insufficient credits. Review your provider account or select another available model.": "{provider} informa crédito insuficiente. Revise sua conta do provedor ou selecione outro modelo disponível.",
  "{provider} is rate limiting requests or reports exhausted quota. Review your quota and wait before retrying.": "{provider} está limitando as solicitações ou informa cota esgotada. Revise sua cota e aguarde antes de tentar novamente.",
  "{provider} could not serve the selected model or rejected the request. Refresh models, choose another model, or retry later.": "{provider} não conseguiu atender o modelo selecionado ou rejeitou a solicitação. Atualize os modelos, escolha outro ou tente novamente mais tarde.",
  "{provider} could not be reached. Check your connection; manual tasks and scheduling still work offline.": "Não foi possível acessar {provider}. Verifique sua conexão; as tarefas manuais e o agendamento continuam funcionando offline.",
  "Configure your {provider} connection, model and data-sharing consent in Settings first.": "Primeiro configure sua conexão com {provider}, o modelo e o consentimento de compartilhamento de dados em Configurações.",
  "Enter your {provider} API key before discovering models. You can use the key field without saving first.": "Digite sua chave de API de {provider} antes de buscar modelos. Você pode usar o campo da chave sem salvar antes.",
  "Enter your {provider} API key before discovering models.": "Digite sua chave de API de {provider} antes de buscar modelos.",
  "{provider} returned a refused, incomplete or invalid response. No task data changed. Try a smaller request or another model.": "{provider} retornou uma resposta recusada, incompleta ou inválida. Nenhum dado de tarefa foi alterado. Tente uma solicitação menor ou outro modelo.",
  "{provider} returned an invalid model catalog. Retry discovery or enter a model ID manually.": "{provider} retornou um catálogo de modelos inválido. Repita a busca ou digite um ID de modelo manualmente.",
  "{provider} could not complete this request. Please retry later.": "{provider} não conseguiu concluir esta solicitação. Tente novamente mais tarde.",
  "You’ve reached your ChatGPT plan’s usage limit. Wait for it to reset, or choose another AI provider in Settings.": "Você atingiu o limite de uso do seu plano do ChatGPT. Aguarde a renovação ou escolha outro provedor de IA em Configurações.",
  "ChatGPT did not finish its response. No task changes were applied.": "O ChatGPT não terminou a resposta. Nenhuma alteração em tarefas foi aplicada.",
  "Something went wrong. Please try again.": "Algo deu errado. Tente novamente.",
  "Task updated.": "Tarefa atualizada.",
  "Task created.": "Tarefa criada.",
  "Switch to light theme": "Mudar para o tema claro",
  "Switch to dark theme": "Mudar para o tema escuro",
  "Help me adjust my remaining schedule for today.": "Ajude-me a ajustar o restante da minha agenda de hoje.",
  "Allow sending my chat requests and selected workday context to OpenRouter and the selected model provider.": "Permitir o envio das minhas solicitações de chat e do contexto de expediente selecionado para o OpenRouter e o provedor do modelo selecionado.",
  "Allow sending my chat requests and selected workday context to {provider}.": "Permitir o envio das minhas solicitações de chat e do contexto de expediente selecionado para {provider}.",
  "Signed out of ChatGPT.": "Você saiu do ChatGPT.",
  "Signed out here. ChatGPT could not confirm it: also disconnect this app in your ChatGPT settings.": "Você saiu aqui. O ChatGPT não conseguiu confirmar: desconecte também este aplicativo nas configurações do ChatGPT.",
  "Pause focus": "Pausar o foco",
  "Resume focus": "Retomar o foco",
  "Start focus": "Iniciar o foco",
  "Unable to save meeting.": "Não foi possível salvar a reunião.",
  "Unable to plan the day.": "Não foi possível planejar o dia.",
  "Review the extended estimate and updated plan below.": "Revise abaixo a estimativa ampliada e o plano atualizado.",
  "Check-in saved. Preview the plan to adjust remaining work.": "Check-in salvo. Veja a prévia do plano para ajustar o trabalho restante.",
  "Unable to save check-in.": "Não foi possível salvar o check-in.",
  "Unable to approve plan.": "Não foi possível aprovar o plano.",
  "Unable to save settings.": "Não foi possível salvar as configurações.",
  "Short break": "Pausa curta"
}, fS = { en: "English", fr: "Français", es: "Español", de: "Deutsch", pt: "Português" }, mS = { fr: h1, es: IP, de: VA, pt: hS }, pS = ["ChatGPT plan", "OpenRouter", "OpenAI", "Gemini", "Claude", "ChatGPT"];
let Dc = "en";
function gS(t) {
  Dc = t, globalThis.document && (document.documentElement.lang = t);
}
function cr(t, e) {
  const n = Dc === "en" ? void 0 : mS[Dc];
  let r = n == null ? void 0 : n[t];
  if (r === void 0 && n)
    for (const o of pS) {
      if (!t.includes(o)) continue;
      const i = n[t.split(o).join("{provider}")];
      if (i !== void 0) {
        r = i.split("{provider}").join(o);
        break;
      }
    }
  if (r === void 0 && n) {
    const o = " No task changes were applied.", i = /^(.*\S)( \([^()]*\))$/s.exec(t);
    if (t.endsWith(o) && t.length > o.length) r = `${cr(t.slice(0, -o.length))} ${cr(o.trim())}`;
    else if (i) {
      const a = cr(i[1]);
      a !== i[1] && (r = a + i[2]);
    }
  }
  return r ?? (r = t), r;
}
async function vS(t, e) {
  const n = encodeURIComponent(JSON.stringify({ title: t, message: e, dismiss: cr("Dismiss"), open: cr("Open Workday") }));
  await chrome.windows.create({ url: chrome.runtime.getURL(`reminder.html#${n}`), type: "popup", width: 400, height: 230, focused: !0 });
}
const yS = {
  listAlarms: async () => (await chrome.alarms.getAll()).map((t) => t.name),
  setAlarm: async (t, e) => {
    const n = await chrome.alarms.get(t);
    (n == null ? void 0 : n.scheduledTime) !== e && await chrome.alarms.create(t, { when: e });
  },
  clearAlarm: async (t) => {
    await chrome.alarms.clear(t);
  },
  popup: async (t, e) => {
    await Rh();
    const n = xh(t, e);
    await vS(n.title, n.message);
  },
  // Check-ins stay on screen until dismissed so they are not missed.
  notify: async (t, e, n, r) => {
    await Rh();
    const o = xh(e, n);
    await chrome.notifications.create(t, { type: "basic", iconUrl: "icon128.png", title: o.title, message: o.message, priority: 2, requireInteraction: !!r });
  }
};
async function Rh() {
  try {
    const t = (await chrome.storage.local.get("workday.language"))["workday.language"];
    t in fS && gS(t);
  } catch {
  }
}
const qu = " — open Workday for Completed, Need more time, Pause or Skip.";
function xh(t, e) {
  const n = e.endsWith(qu), r = n ? e.slice(0, -qu.length) : e;
  return { title: cr(t), message: cr(r) + (n ? cr(qu) : "") };
}
let Ku = Promise.resolve();
function ml() {
  return Ku = Ku.catch(() => {
  }).then(() => VT(yS, Vc)).catch(() => {
    console.error("Unable to refresh local reminders. Reopen Workday to check your data.");
  }), Ku;
}
async function pl() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }), await chrome.alarms.create("workday-maintenance", { periodInMinutes: 1 }), await ml();
  } catch {
    console.error("Unable to initialize Workday.");
  }
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.onUpdated.addListener((t, e) => {
    const n = e.url;
    n != null && n.startsWith("http://127.0.0.1:") && (async () => {
      await P_(n) && (chrome.tabs.update(t, { url: chrome.runtime.getURL("signed-in.html") }).catch(() => {
      }), await A_(n));
    })().catch(() => {
      console.error("Unable to finish ChatGPT sign-in.");
    });
  }), pl();
});
chrome.runtime.onStartup.addListener(() => {
  pl();
});
chrome.alarms.onAlarm.addListener(() => {
  ml();
});
chrome.runtime.onMessage.addListener((t, e, n) => (t == null ? void 0 : t.type) !== "WORKDAY_CHANGED" ? !1 : (ml().then(() => n({ ok: !0 })), !0));
chrome.notifications.onClicked.addListener(() => {
  chrome.action.setBadgeText({ text: "•" });
});
chrome.action.onClicked.addListener(() => {
  chrome.action.setBadgeText({ text: "" });
});
pl();
